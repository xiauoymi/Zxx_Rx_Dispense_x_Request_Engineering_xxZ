/**
 * 
 */
package com.esrx.ref.cart.jaxrs;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.esrx.ref.cart.AddProductRequest;
import com.esrx.ref.cart.AddProductResponse;
import com.esrx.ref.cart.DeleteProductRequest;
import com.esrx.ref.cart.DeleteProductResponse;
import com.esrx.ref.cart.GetProductsRequest;
import com.esrx.ref.cart.GetProductsResponse;
import com.esrx.ref.cart.UpdateProductRequest;
import com.esrx.ref.cart.UpdateProductResponse;

/**
 * @author p043459
 *
 */
@Path("/")
@Consumes(MediaType.APPLICATION_XML)
@Produces(MediaType.APPLICATION_XML)
public interface CartResource {
	
	@POST
	@Path("getProducts")
	public GetProductsResponse getProducts(GetProductsRequest productsRequest);
	
	@POST
	@Path("addProduct")
	public AddProductResponse addProduct(AddProductRequest productRequest);
	
	@POST
	@Path("updateProduct")
	public UpdateProductResponse updateProduct(UpdateProductRequest productRequest);
	
	
	@POST
	@Path("deleteProduct")
	public DeleteProductResponse deleteProduct(DeleteProductRequest productRequest);
	
}
