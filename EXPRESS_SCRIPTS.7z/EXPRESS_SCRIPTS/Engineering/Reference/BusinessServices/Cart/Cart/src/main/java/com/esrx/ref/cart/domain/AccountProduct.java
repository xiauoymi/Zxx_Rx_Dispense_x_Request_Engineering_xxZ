package com.esrx.ref.cart.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="ACCOUNT_PRODUCT")
@NamedQueries({
	@NamedQuery(name = "accountProduct.findProducts", 
			query = "from AccountProduct a where a.accountId = :accountId and a.storeId= :storeId order by a.productId"),
	@NamedQuery(name = "accountProduct.getProduct", 
			query = "from AccountProduct a where a.accountId = :accountId and a.storeId= :storeId and a.productId= :productId")
})
public class AccountProduct implements Serializable {

	private static final long serialVersionUID = -391492652672418293L;
	
	private String accountProductId;
	private int quantity;
	private String accountId;
	private String productId;
	private String storeId;
	
	/**
	 * @return the accountId
	 */
	@Column(name="ACCOUNT_ID")
	public String getAccountId() {
		return accountId;
	}
	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * @return the productId
	 */
	@Column(name="PRODUCT_ID")
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the storeId
	 */
	@Column(name="STORE_ID")
	public String getStoreId() {
		return storeId;
	}
	/**
	 * @param storeId the storeId to set
	 */
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	
	/**
	 * @return the quantity
	 */
	@Column(name="QUANTITY")
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the accountProductId
	 */
	@Id
	@GeneratedValue(generator="system-uuid")
	@GenericGenerator(name="system-uuid", strategy="uuid" )
	@Column(name="ACCOUNT_PRODUCT_ID")
	public String getAccountProductId() {
		return accountProductId;
	}
	/**
	 * @param accountProductId the accountProductId to set
	 */
	public void setAccountProductId(String accountProductId) {
		this.accountProductId = accountProductId;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((accountId == null) ? 0 : accountId.hashCode());
		result = prime
				* result
				+ ((accountProductId == null) ? 0 : accountProductId.hashCode());
		result = prime * result
				+ ((productId == null) ? 0 : productId.hashCode());
		result = prime * result + quantity;
		result = prime * result + ((storeId == null) ? 0 : storeId.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountProduct other = (AccountProduct) obj;
		if (accountId == null || other.accountId != null){
				return false;
		} else if (!accountId.equals(other.accountId))
			return false;
		if (productId == null || other.productId != null){
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		if (storeId == null || other.storeId != null){
				return false;
		} else if (!storeId.equals(other.storeId))
			return false;
		return true;
	}
	
	
	

}
