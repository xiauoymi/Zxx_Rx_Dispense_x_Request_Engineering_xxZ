package com.esrx.ref.cart.bo.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.esrx.ref.cart.bo.CartProduct;
import com.esrx.ref.cart.bo.GetProductsResponse;
import com.esrx.ref.cart.domain.AccountProduct;

public class DomainTransformer {
	/**
	 * @param uuid 
	 * @param request
	 * @return
	 */
	public static AccountProduct convertToDomainAccountProduct(String productId, String accountId, String storeId, int quantity) {
		AccountProduct accountProduct = new AccountProduct();
		
		accountProduct.setQuantity(quantity);
		accountProduct.setAccountId(accountId);
		accountProduct.setProductId(productId);
		accountProduct.setStoreId(storeId);
		
		return accountProduct;
	}


	public static GetProductsResponse convertToBoGetProductResponse(
			List<AccountProduct> domainAccountProducts) {
		GetProductsResponse response = new GetProductsResponse();
		List<CartProduct> cartProducts = new ArrayList<CartProduct>();
		if(CollectionUtils.isNotEmpty(domainAccountProducts)){
			for(AccountProduct domainAccountProduct : domainAccountProducts){
				CartProduct cartProduct = convertToBoCartProduct(domainAccountProduct);
				
				cartProducts.add(cartProduct);
			}
		}
		response.setCartProductList(cartProducts);
		return response;
	}

	private static CartProduct convertToBoCartProduct(
			AccountProduct domainAccountProduct) {
		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId(domainAccountProduct.getProductId());
		cartProduct.setQuantity(domainAccountProduct.getQuantity());
		return cartProduct;
	}

}
