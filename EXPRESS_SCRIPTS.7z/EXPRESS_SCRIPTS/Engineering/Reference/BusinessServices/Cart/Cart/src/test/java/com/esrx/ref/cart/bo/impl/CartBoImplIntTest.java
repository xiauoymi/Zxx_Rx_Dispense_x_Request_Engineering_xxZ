package com.esrx.ref.cart.bo.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.carbonfive.testutils.spring.dbunit.DataSet;
import com.esrx.ref.cart.BaseIntTest;
import com.esrx.ref.cart.BaseTest;
import com.esrx.ref.cart.bo.AddProductRequest;
import com.esrx.ref.cart.bo.CartBo;
import com.esrx.ref.cart.bo.CartProduct;
import com.esrx.ref.cart.bo.DeleteProductRequest;
import com.esrx.ref.cart.bo.GetProductsRequest;
import com.esrx.ref.cart.bo.GetProductsResponse;
import com.esrx.ref.cart.bo.UpdateProductRequest;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;

public class CartBoImplIntTest extends BaseIntTest {
	@Autowired
	private CartBo cartBo;
	
	@Before
	public void setUp() throws Exception {
		ProcessTimer.startTimer();
	}
	
	@Test
	@DataSet("classpath:/testdata/AccountProduct.xml")
	public void testAddProduct() throws InvalidRequest, NotFound {
		AddProductRequest addProductRequest = new AddProductRequest();
		addProductRequest.setAccountId("2");
		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId("1");
		cartProduct.setQuantity(1);
		addProductRequest.setCartProduct(cartProduct);
		addProductRequest.setStoreId("2");
		addProductRequest.setTimeout(30000L);
		cartBo.addProduct(addProductRequest);
		
		
		GetProductsRequest  request =  new GetProductsRequest();
		request.setAccountId("2");
		request.setStoreId("2");
		request.setTimeout(30000L);
		GetProductsResponse getProductsResponse = cartBo.getProducts(request);
		assertNotNull(getProductsResponse);
		assertTrue(CollectionUtils.isNotEmpty(getProductsResponse.getCartProductList()));
		assertEquals(1, CollectionUtils.size(getProductsResponse.getCartProductList()));
		assertEquals(1, getProductsResponse.getCartProductList().get(0).getQuantity());
		
	}

	@Test
	@DataSet("classpath:/testdata/AccountProduct.xml")
	public void testUpdateProduct() throws InvalidRequest, NotFound {
		UpdateProductRequest productRequest = new UpdateProductRequest();
		productRequest.setAccountId("1");
		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId("1");
		cartProduct.setQuantity(10);
		productRequest.setCartProduct(cartProduct);
		productRequest.setStoreId("1");
		productRequest.setTimeout(30000L);
		
		cartBo.updateProduct(productRequest);
		
		GetProductsRequest  request =  new GetProductsRequest();
		request.setAccountId("1");
		request.setStoreId("1");
		request.setTimeout(30000L);
		GetProductsResponse getProductsResponse = cartBo.getProducts(request);
		assertNotNull(getProductsResponse);
		assertTrue(CollectionUtils.isNotEmpty(getProductsResponse.getCartProductList()));
		assertEquals(1, CollectionUtils.size(getProductsResponse.getCartProductList()));
		assertEquals(10, getProductsResponse.getCartProductList().get(0).getQuantity());
	}

	@Test
	@DataSet("classpath:/testdata/AccountProduct.xml")
	public void testGetProduct() throws InvalidRequest, NotFound {
		GetProductsRequest getProductsRequest = new GetProductsRequest();
		getProductsRequest.setStoreId("1");
		getProductsRequest.setAccountId("1");
		getProductsRequest.setTimeout(30000L);
		GetProductsResponse getProductsResponse = cartBo.getProducts(getProductsRequest);
		assertNotNull(getProductsResponse);
		assertTrue(CollectionUtils.isNotEmpty(getProductsResponse.getCartProductList()));
		assertEquals(1, CollectionUtils.size(getProductsResponse.getCartProductList()));
		assertEquals(1, getProductsResponse.getCartProductList().get(0).getQuantity());
		
	}
	
	@Test
	@DataSet("classpath:/testdata/AccountProduct.xml")
	public void testGetProductNotFound()  {
		GetProductsRequest getProductsRequest = new GetProductsRequest();
		getProductsRequest.setStoreId("2");
		getProductsRequest.setAccountId("2");
		getProductsRequest.setTimeout(30000L);
		try {
			cartBo.getProducts(getProductsRequest);
		} catch (Exception e) {
			assertTrue(e instanceof NotFound);
			NotFound found = (NotFound) e;
			assertEquals(StringUtils.EMPTY, found.getMessage());
			assertEquals(ErrorCodes.CART_PRODUCT_NOT_FOUND, found.getCode());
		}
		
	}

	@Test
	@DataSet("classpath:/testdata/AccountProduct.xml")
	public void testDeleteProduct() throws InvalidRequest {
		AddProductRequest addProductRequest = new AddProductRequest();
		addProductRequest.setAccountId("3");
		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId("3");
		cartProduct.setQuantity(3);
		addProductRequest.setCartProduct(cartProduct);
		addProductRequest.setStoreId("3");
		addProductRequest.setTimeout(30000L);
		cartBo.addProduct(addProductRequest);
		
		DeleteProductRequest deleteProductRequest = new DeleteProductRequest();
		deleteProductRequest.setAccountId("3");
		deleteProductRequest.setProductId("3");
		deleteProductRequest.setStoreId("3");
		deleteProductRequest.setTimeout(30000L);
		
		cartBo.deleteProduct(deleteProductRequest);
		
		GetProductsRequest getProductsRequest = new GetProductsRequest();
		getProductsRequest.setStoreId("3");
		getProductsRequest.setAccountId("3");
		getProductsRequest.setTimeout(30000L);
		try {
			cartBo.getProducts(getProductsRequest);
		} catch (Exception e) {
			assertTrue(e instanceof NotFound);
			NotFound found = (NotFound) e;
			assertEquals(StringUtils.EMPTY, found.getMessage());
			assertEquals(ErrorCodes.CART_PRODUCT_NOT_FOUND, found.getCode());
		}
	
	}

}
