package com.esrx.ref.cart.dao;

import java.util.List;

import com.esrx.ref.cart.domain.AccountProduct;
import com.express_scripts.inf.dao.GenericDao;

public interface CartDao extends GenericDao<AccountProduct>{

	List<AccountProduct> findProducts(String accountId, String storeId, Long timeLeft);

	AccountProduct getProduct(String accountId, String productId,
			String storeId, Long timeLeft);


}
