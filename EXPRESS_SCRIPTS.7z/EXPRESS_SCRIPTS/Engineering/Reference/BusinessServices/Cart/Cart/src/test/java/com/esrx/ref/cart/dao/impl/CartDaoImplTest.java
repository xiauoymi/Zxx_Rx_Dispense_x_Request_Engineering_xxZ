package com.esrx.ref.cart.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.carbonfive.testutils.spring.dbunit.DataSet;
import com.esrx.ref.cart.BaseTest;
import com.esrx.ref.cart.dao.CartDao;
import com.esrx.ref.cart.domain.AccountProduct;

public class CartDaoImplTest extends BaseTest {
	@Autowired
	private CartDao cartDao;

	@Test
	@DataSet("classpath:/testdata/AccountProduct.xml")
	public void testFindProducts() {
		List<AccountProduct> response = cartDao.findProducts("1", "1", 30000L);
		assertTrue(CollectionUtils.isNotEmpty(response));
	}

	@Test
	@DataSet("classpath:/testdata/AccountProduct.xml")
	public void testgetProduct() {
		AccountProduct response = cartDao.getProduct("1", "1", "1", 30000L);
		assertNotNull(response);
	}

}
