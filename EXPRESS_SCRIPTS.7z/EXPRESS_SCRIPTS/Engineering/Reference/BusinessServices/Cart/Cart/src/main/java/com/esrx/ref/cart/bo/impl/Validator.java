package com.esrx.ref.cart.bo.impl;

import static com.express_scripts.inf.validator.NullValidator.assertNotNull;
import static com.express_scripts.inf.validator.NumberValidator.assertGreaterThan;
import static com.express_scripts.inf.validator.NumberValidator.assertGreaterThanOrEqualTo;
import static com.express_scripts.inf.validator.NumberValidator.assertNumber;
import static com.express_scripts.inf.validator.StringValidator.assertNotBlank;

import java.math.BigDecimal;

import com.esrx.ref.cart.bo.AddProductRequest;
import com.esrx.ref.cart.bo.DeleteProductRequest;
import com.esrx.ref.cart.bo.GetProductsRequest;
import com.esrx.ref.cart.bo.UpdateProductRequest;
import com.express_scripts.inf.types.InvalidRequest;

public class Validator {
	
	private static final String REQUEST_STR= "REQUEST";
	private static final String ACCOUNT_ID_STR = "ACCOUNT_ID";
	private static final String STORE_ID_STR = "STORE_ID";
	private static final String PRODUCT_ID_STR = "PRODUCT_ID";
	private static final String CART_PRODUCT_STR = "CART_PRODUCT";
	private static final String QUANTITY_STR = "QUANTITY";

	public static void validateAddProductRequest(AddProductRequest request) throws InvalidRequest {
		assertNotNull(REQUEST_STR, request);
		assertNotBlank(ACCOUNT_ID_STR, request.getAccountId());
		assertNumber(ACCOUNT_ID_STR, request.getAccountId());
		assertNotBlank(STORE_ID_STR, request.getStoreId());
		assertNumber(STORE_ID_STR, request.getStoreId());
		assertNotNull(CART_PRODUCT_STR, request.getCartProduct());
		assertNotBlank(PRODUCT_ID_STR, request.getCartProduct().getProductId());
		assertNumber(PRODUCT_ID_STR, request.getCartProduct().getProductId());
		assertGreaterThan(QUANTITY_STR, new BigDecimal(request.getCartProduct().getQuantity()), new BigDecimal(0));
	}

	public static void validateUpdateProductRequest(UpdateProductRequest request) throws InvalidRequest {
		assertNotNull(REQUEST_STR, request);
		assertNotBlank(ACCOUNT_ID_STR, request.getAccountId());
		assertNumber(ACCOUNT_ID_STR, request.getAccountId());
		assertNotBlank(STORE_ID_STR, request.getStoreId());
		assertNumber(STORE_ID_STR, request.getStoreId());
		assertNotNull(CART_PRODUCT_STR, request.getCartProduct());
		assertNotBlank(PRODUCT_ID_STR, request.getCartProduct().getProductId());
		assertNumber(PRODUCT_ID_STR, request.getCartProduct().getProductId());
		assertGreaterThanOrEqualTo(QUANTITY_STR, new BigDecimal(request.getCartProduct().getQuantity()), new BigDecimal(0));
	}

	public static void validateGetProductsRequest(GetProductsRequest request) throws InvalidRequest {
		assertNotNull(REQUEST_STR, request);
		assertNotBlank(ACCOUNT_ID_STR, request.getAccountId());
		assertNumber(ACCOUNT_ID_STR, request.getAccountId());
	}

	public static void validateDeleteProductRequest(DeleteProductRequest request) throws InvalidRequest {
		assertNotNull(REQUEST_STR, request);
		assertNotBlank(ACCOUNT_ID_STR, request.getAccountId());
		assertNumber(ACCOUNT_ID_STR, request.getAccountId());
		assertNotBlank(STORE_ID_STR, request.getStoreId());
		assertNumber(STORE_ID_STR, request.getStoreId());
		assertNotBlank(PRODUCT_ID_STR, request.getProductId());
		assertNumber(PRODUCT_ID_STR, request.getProductId());
	}
}
