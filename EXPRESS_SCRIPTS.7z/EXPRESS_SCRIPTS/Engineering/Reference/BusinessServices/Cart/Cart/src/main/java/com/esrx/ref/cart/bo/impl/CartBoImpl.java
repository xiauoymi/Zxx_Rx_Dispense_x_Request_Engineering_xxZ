package com.esrx.ref.cart.bo.impl;

import static com.express_scripts.inf.concurrent.ProcessTimer.assertTimeRemaining;

import java.util.List;

import com.esrx.ref.cart.bo.AddProductRequest;
import com.esrx.ref.cart.bo.CartBo;
import com.esrx.ref.cart.bo.DeleteProductRequest;
import com.esrx.ref.cart.bo.GetProductsRequest;
import com.esrx.ref.cart.bo.GetProductsResponse;
import com.esrx.ref.cart.bo.UpdateProductRequest;
import com.esrx.ref.cart.dao.CartDao;
import com.esrx.ref.cart.domain.AccountProduct;
import com.esrx.ref.cart.management.SleepTimeMBean;
import com.express_scripts.inf.types.InvalidRequest;

public class CartBoImpl implements CartBo {

	private Long defaultTimeout = 30000L;
	private Long bufferTime = 100L;
	private CartDao cartDao;
	private ProductResourceAdapter productResourceAdapter;
	private SleepTimeMBean sleepTimeMBean;
	
	@Override
	public void addProduct(AddProductRequest request) throws InvalidRequest {
		Validator.validateAddProductRequest(request);

		productResourceAdapter.validateProduct(request.getCartProduct().getProductId(),
				assertTimeRemaining(request.getTimeout(), defaultTimeout, bufferTime));
		
		delay(); // For testing purposes only
		
		AccountProduct domainAccountProduct = cartDao.getProduct(request.getAccountId(), request.getCartProduct()
				.getProductId(), request.getStoreId(), assertTimeRemaining(request.getTimeout(), defaultTimeout));

		if (domainAccountProduct != null) {
			domainAccountProduct.setQuantity(request.getCartProduct().getQuantity()
					+ domainAccountProduct.getQuantity());
		} else {
			AccountProduct accountProduct = DomainTransformer.convertToDomainAccountProduct(request.getCartProduct()
					.getProductId(), request.getAccountId(), request.getStoreId(), request.getCartProduct()
					.getQuantity());

			cartDao.persist(accountProduct);
		}
	}

	@Override
	public void updateProduct(UpdateProductRequest request) throws InvalidRequest {

		Validator.validateUpdateProductRequest(request);
		productResourceAdapter.validateProduct(request.getCartProduct().getProductId(),
				assertTimeRemaining(request.getTimeout(), defaultTimeout, bufferTime));
		
		delay(); // For testing purposes only
		
		AccountProduct domainAccountProduct = cartDao.getProduct(request.getAccountId(), request.getCartProduct()
				.getProductId(), request.getStoreId(), assertTimeRemaining(request.getTimeout(), defaultTimeout));

		if (domainAccountProduct != null) {
			if (request.getCartProduct().getQuantity() == 0) {
				cartDao.delete(domainAccountProduct);
			} else {
				domainAccountProduct.setQuantity(request.getCartProduct().getQuantity());
			}

		} else {
			throw new InvalidRequest(ErrorCodes.CART_PRODUCT_NOT_FOUND, Constants.CART_PRODUCT_NOT_FOUND, null, null);
		}

	}

	@Override
	public GetProductsResponse getProducts(GetProductsRequest request) throws InvalidRequest {
		Validator.validateGetProductsRequest(request);
		Long timeLeft = assertTimeRemaining(request.getTimeout(), defaultTimeout, bufferTime);

		delay(); // For testing purposes only
		
		List<AccountProduct> domainAccountProduct = cartDao.findProducts(request.getAccountId(), request.getStoreId(),
				timeLeft);

		GetProductsResponse response = DomainTransformer.convertToBoGetProductResponse(domainAccountProduct);

		return response;
	}

	@Override
	public void deleteProduct(DeleteProductRequest request) throws InvalidRequest {
		Validator.validateDeleteProductRequest(request);
		productResourceAdapter.validateProduct(request.getProductId(),
				assertTimeRemaining(request.getTimeout(), defaultTimeout, bufferTime));
		
		delay(); // For testing purposes only
		
		AccountProduct domainAccountProduct = cartDao.getProduct(request.getAccountId(), request.getProductId(),
				request.getStoreId(), assertTimeRemaining(request.getTimeout(), defaultTimeout));

		if (domainAccountProduct != null) {
			cartDao.delete(domainAccountProduct);
		} else {
			throw new InvalidRequest(ErrorCodes.CART_PRODUCT_NOT_FOUND, Constants.CART_PRODUCT_NOT_FOUND, null, null);
		}

	}

	/**
	 * @param defaultTimeout
	 *            the defaultTimeout to set
	 */
	public void setDefaultTimeout(Long defaultTimeout) {
		this.defaultTimeout = defaultTimeout;
	}

	/**
	 * @param bufferTime
	 *            the bufferTime to set
	 */
	public void setBufferTime(Long bufferTime) {
		this.bufferTime = bufferTime;
	}

	/**
	 * @param cartDao
	 *            the cartDao to set
	 */
	public void setCartDao(CartDao cartDao) {
		this.cartDao = cartDao;
	}

	/**
	 * @param productResourceAdapter
	 *            the productResourceAdapter to set
	 */
	public void setProductResourceAdapter(ProductResourceAdapter productResourceAdapter) {
		this.productResourceAdapter = productResourceAdapter;
	}

	public void setSleepTimeMBean(SleepTimeMBean sleepTimeMBean) {
		this.sleepTimeMBean = sleepTimeMBean;
	}
	
	private void delay() {
		long delayTime = sleepTimeMBean.getSleepTimeMS();
		if (delayTime > 0) {
			try {
				Thread.sleep(delayTime);
			} catch (Exception e) {
				// do nothing
			}
		}
	}
}
