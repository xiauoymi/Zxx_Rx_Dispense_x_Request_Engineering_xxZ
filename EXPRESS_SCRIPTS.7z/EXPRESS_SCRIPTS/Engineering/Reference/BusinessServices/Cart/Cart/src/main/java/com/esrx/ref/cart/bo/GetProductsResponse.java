package com.esrx.ref.cart.bo;

import java.io.Serializable;
import java.util.List;

public class GetProductsResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3209517342262395806L;
	private List<CartProduct> cartProductList;
	/**
	 * @return the cartProductList
	 */
	public List<CartProduct> getCartProductList() {
		return cartProductList;
	}
	/**
	 * @param cartProductList the cartProductList to set
	 */
	public void setCartProductList(List<CartProduct> cartProductList) {
		this.cartProductList = cartProductList;
	}

}
