package com.esrx.ref.cart.bo;

import java.io.Serializable;

public class UpdateProductRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3304981935616660774L;
	private String accountId;
	private String storeId;
	private CartProduct cartProduct;
	private Long timeout;

	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}

	/**
	 * @param accountId
	 *            the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	/**
	 * @return the storeId
	 */
	public String getStoreId() {
		return storeId;
	}

	/**
	 * @param storeId
	 *            the storeId to set
	 */
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	/**
	 * @return the cartProduct
	 */
	public CartProduct getCartProduct() {
		return cartProduct;
	}

	/**
	 * @param cartProduct
	 *            the cartProduct to set
	 */
	public void setCartProduct(CartProduct cartProduct) {
		this.cartProduct = cartProduct;
	}

	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}

	/**
	 * @param timeout
	 *            the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}

}
