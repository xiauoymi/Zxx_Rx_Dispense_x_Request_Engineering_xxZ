package com.esrx.ref.cart.bo;

import com.express_scripts.inf.types.InvalidRequest;

public interface CartBo {
	
	void addProduct(AddProductRequest request) throws InvalidRequest;
	
	void updateProduct(UpdateProductRequest request) throws InvalidRequest;
	
	GetProductsResponse getProducts(GetProductsRequest request) throws InvalidRequest;
	
	void deleteProduct(DeleteProductRequest request) throws InvalidRequest;

}
