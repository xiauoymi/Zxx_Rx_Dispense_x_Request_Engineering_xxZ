package com.esrx.ref.cart.bo.impl;

import com.esrx.ref.product.GetProductRequest;
import com.esrx.ref.product.jaxrs.ProductResource;
import com.express_scripts.inf.jersey.ResourceException;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.sun.jersey.api.client.ClientHandlerException;

public class ProductResourceAdapter {

	private ProductResource productResource;
	private ExceptionStrategy exceptionStrategy;

	public void setExceptionStrategy(ExceptionStrategy exceptionStrategy) {
		this.exceptionStrategy = exceptionStrategy;
	}

	public void validateProduct(String productId, Long timeout) throws InvalidRequest {

		GetProductRequest getProductRequest = new GetProductRequest();
		getProductRequest.setProductId(productId);
		getProductRequest.setTimeout(timeout);

		try {
			productResource.getProduct(getProductRequest);
		} catch (ClientHandlerException e) {
			exceptionStrategy.handleClientHandlerException(e);
		} catch (ResourceException e) {
			try {
				exceptionStrategy.handleResourceExceptionWithNotFound(e);
			} catch (NotFound e1) {
				throw new InvalidRequest(ErrorCodes.PRODUCT_ID_INVALID, Constants.INVALID_PRODUCT_ID, null, null);
			}
		}
	}

	/**
	 * @param productResource
	 *            the productResource to set
	 */
	public void setProductResource(ProductResource productResource) {
		this.productResource = productResource;
	}

}
