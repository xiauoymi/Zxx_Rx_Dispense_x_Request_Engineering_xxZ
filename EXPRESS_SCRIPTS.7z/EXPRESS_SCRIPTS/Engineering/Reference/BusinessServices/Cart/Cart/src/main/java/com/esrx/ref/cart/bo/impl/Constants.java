package com.esrx.ref.cart.bo.impl;

public class Constants {

	public static final String TIMED_OUT = "Timed out";
	public static final String REQUEST_NULL = "Request required";
	public static final String ACCOUNT_ID_REQUIRED = "Account id required";
	public static final String INVALID_ACCOUNT_ID = "Account id not numeric";
	public static final String STORE_ID_REQUIRED = "Store id required";
	public static final String INVALID_STORE_ID = "Store id not numeric";
	public static final String CART_PRODUCT_NULL = "Product information required";
	public static final String PRODUCT_ID_REQUIRED = "Product id required";
	public static final String INVALID_PRODUCT_ID = "Product id not numeric";
	public static final String QUANTITY_REQUIRED = "Quantity required.";
	public static final String CART_PRODUCT_NOT_FOUND = "Cart product not found.";
	public static final String UNEXPECTED_ERROR = "Unexpected error";
	

}
