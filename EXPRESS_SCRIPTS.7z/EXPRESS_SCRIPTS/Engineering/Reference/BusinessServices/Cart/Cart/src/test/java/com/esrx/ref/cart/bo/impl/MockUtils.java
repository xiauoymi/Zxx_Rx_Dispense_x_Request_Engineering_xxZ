package com.esrx.ref.cart.bo.impl;

import org.easymock.EasyMock;

import com.esrx.ref.product.CreateProductRequest;
import com.esrx.ref.product.CreateProductResponse;
import com.esrx.ref.product.GetProductRequest;
import com.esrx.ref.product.GetProductResponse;
import com.esrx.ref.product.jaxrs.ProductResource;

public class MockUtils {

	public static Object pacifyMock(String mockClassname){
		Object returnObject =  null;
		if(mockClassname.equals(ProductResource.class.getCanonicalName())) {
			
			ProductResource productResource =  EasyMock.createMock(ProductResource.class);
			CreateProductResponse response =  new CreateProductResponse();
			response.setProductId("PROD_1");
			GetProductResponse getResponse =  new GetProductResponse();
			response.setProductId("PROD_1");
			
			EasyMock.expect(productResource.getProduct(EasyMock.anyObject(GetProductRequest.class))).andReturn(getResponse);
			EasyMock.expect(productResource.getProduct(EasyMock.anyObject(GetProductRequest.class))).andReturn(getResponse);
			EasyMock.expect(productResource.getProduct(EasyMock.anyObject(GetProductRequest.class))).andReturn(getResponse);
			EasyMock.expect(productResource.getProduct(EasyMock.anyObject(GetProductRequest.class))).andReturn(getResponse);
			EasyMock.expect(productResource.createProduct(EasyMock.anyObject(CreateProductRequest.class))).andReturn(response);
			EasyMock.replay(productResource);
			returnObject = productResource;
		}
		
		return returnObject;
	}
	
}
