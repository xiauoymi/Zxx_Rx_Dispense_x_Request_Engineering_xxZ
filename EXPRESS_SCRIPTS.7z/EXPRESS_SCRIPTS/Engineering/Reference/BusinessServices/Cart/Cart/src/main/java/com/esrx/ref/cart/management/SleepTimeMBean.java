package com.esrx.ref.cart.management;

public interface SleepTimeMBean {
	long getSleepTimeMS();
	void setSleepTimeMS(long sleepTimeMS);
}
