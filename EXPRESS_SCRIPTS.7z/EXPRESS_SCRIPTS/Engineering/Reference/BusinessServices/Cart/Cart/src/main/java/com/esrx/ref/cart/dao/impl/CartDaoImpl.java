package com.esrx.ref.cart.dao.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.SessionFactory;

import com.esrx.ref.cart.dao.CartDao;
import com.esrx.ref.cart.domain.AccountProduct;
import com.express_scripts.inf.dao.QueryParameter;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class CartDaoImpl extends GenericDaoHibernate<AccountProduct> implements CartDao {

	public CartDaoImpl(SessionFactory sf) {
		super(AccountProduct.class, sf);
	}

	@Override
	public List<AccountProduct> findProducts(String accountId, String storeId,
			Long timeLeft) {
		QueryParameter accountIdParam = new QueryParameter("accountId", accountId);
		QueryParameter storeIdParam = new QueryParameter("storeId", storeId);
		return executeNamedQuery("accountProduct.findProducts", 0, 0, timeLeft, accountIdParam, storeIdParam);
	}

	@Override
	public AccountProduct getProduct(String accountId, String productId,
			String storeId, Long timeLeft) {
		QueryParameter accountIdParam = new QueryParameter("accountId", accountId);
		QueryParameter storeIdParam = new QueryParameter("storeId", storeId);
		QueryParameter productIdParam = new QueryParameter("productId", productId);
		List<AccountProduct> accountProducts = executeNamedQuery("accountProduct.getProduct", 0, 0, timeLeft, accountIdParam, storeIdParam, productIdParam);
		AccountProduct accountProduct = null;
		if(CollectionUtils.isNotEmpty(accountProducts)){
			accountProduct = accountProducts.get(0);
		}
		return accountProduct;
	}

}