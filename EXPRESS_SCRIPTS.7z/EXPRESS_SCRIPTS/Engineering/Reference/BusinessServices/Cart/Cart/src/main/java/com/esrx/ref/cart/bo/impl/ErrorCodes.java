package com.esrx.ref.cart.bo.impl;

public class ErrorCodes {

	public static final String RESOURCE_UNAVAILABLE = "RESOURCE_UNAVAILABLE";
	public static final String REQUEST_REQUIRED = "REQUEST_REQUIRED";
	public static final String ACCOUNT_ID_REQUIRED = "ACCOUNT_ID_REQUIRED";
	public static final String ACCOUNT_ID_INVALID = "ACCOUNT_ID_INVALID";
	public static final String STORE_ID_REQUIRED = "STORE_ID_REQUIRED";
	public static final String STORE_ID_INVALID = "STORE_ID_INVALID";
	public static final String CART_PRODUCT_REQUIRED = "CART_PRODUCT_REQUIRED";
	public static final String PRODUCT_ID_REQUIRED = "PRODUCT_ID_REQUIRED";
	public static final String PRODUCT_ID_INVALID = "PRODUCT_ID_INVALID";
	public static final String QUANTITY_REQUIRED = "QUANTITY_REQUIRED";
	public static final String CART_PRODUCT_NOT_FOUND = "CART_PRODUCT_NOT_FOUND";
	public static final String UNEXPECTED_ERROR = "UNEXPECTED_ERROR";

}
