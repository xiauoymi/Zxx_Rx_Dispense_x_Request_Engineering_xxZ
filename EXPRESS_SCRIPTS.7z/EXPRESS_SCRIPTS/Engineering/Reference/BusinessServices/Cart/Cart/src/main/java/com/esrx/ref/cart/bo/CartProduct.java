package com.esrx.ref.cart.bo;

import java.io.Serializable;

public class CartProduct implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1139554744632745663L;
	private String productId;
	private int quantity;

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



}
