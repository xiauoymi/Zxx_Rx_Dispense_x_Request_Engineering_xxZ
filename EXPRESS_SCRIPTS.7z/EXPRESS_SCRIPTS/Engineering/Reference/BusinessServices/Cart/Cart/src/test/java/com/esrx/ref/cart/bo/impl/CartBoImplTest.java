package com.esrx.ref.cart.bo.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.esrx.ref.cart.bo.AddProductRequest;
import com.esrx.ref.cart.bo.CartProduct;
import com.esrx.ref.cart.bo.DeleteProductRequest;
import com.esrx.ref.cart.bo.GetProductsRequest;
import com.esrx.ref.cart.bo.GetProductsResponse;
import com.esrx.ref.cart.bo.UpdateProductRequest;
import com.esrx.ref.cart.dao.CartDao;
import com.esrx.ref.cart.domain.AccountProduct;
import com.esrx.ref.cart.management.SleepTimeMBean;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;

public class CartBoImplTest {
	
	private CartDao cartDao = EasyMock.createMock(CartDao.class);
	ProductResourceAdapter helper = EasyMock.createMock(ProductResourceAdapter.class);
	
	private SleepTimeMBean sleepTimeMBeanMock = EasyMock.createMock(SleepTimeMBean.class);
	private CartBoImpl boImpl;
	
	@Before
	public void setup(){
		boImpl = new CartBoImpl();
		boImpl.setBufferTime(1000L);
		boImpl.setCartDao(cartDao);
		boImpl.setDefaultTimeout(30000L);
		boImpl.setProductResourceAdapter(helper);
		boImpl.setSleepTimeMBean(sleepTimeMBeanMock);
		ProcessTimer.startTimer();
	}

	@Test
	public void testAddProduct() throws InvalidRequest {
		AddProductRequest addProductRequest = new AddProductRequest();
		addProductRequest.setAccountId("1");
		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId("1");
		cartProduct.setQuantity(1);
		addProductRequest.setCartProduct(cartProduct);
		addProductRequest.setStoreId("1");
		addProductRequest.setTimeout(30000L);
		helper.validateProduct(EasyMock.anyObject(String.class), EasyMock.anyLong());
		EasyMock.expectLastCall();
		cartDao.persist(EasyMock.anyObject(AccountProduct.class));
		EasyMock.expectLastCall();
		EasyMock.expect(cartDao.getProduct(EasyMock.anyObject(String.class), EasyMock.anyObject(String.class), EasyMock.anyObject(String.class),  EasyMock.anyLong())).andReturn(new AccountProduct());
		EasyMock.replay(cartDao);
		EasyMock.replay(helper);
		
		boImpl.addProduct(addProductRequest);
	}
	
	@Test
	public void testAddProductInvalidRequest() {
		AddProductRequest addProductRequest = new AddProductRequest();
		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId("1");
		cartProduct.setQuantity(1);
		addProductRequest.setCartProduct(cartProduct);
		addProductRequest.setStoreId("1");
		addProductRequest.setTimeout(30000L);
		cartDao.persist(EasyMock.anyObject(AccountProduct.class));
		EasyMock.expectLastCall();
		EasyMock.replay(cartDao);
		
		try {
			boImpl.addProduct(addProductRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
			InvalidRequest found = (InvalidRequest) e;
			assertEquals("ACCOUNT_ID is null.", found.getMessage());
			assertEquals("ACCOUNT_ID_IS_NULL", found.getCode());
		}
	}

	@Test
	public void testUpdateProduct() throws InvalidRequest {
		UpdateProductRequest productRequest = new UpdateProductRequest();
		productRequest.setAccountId("1");
		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId("1");
		cartProduct.setQuantity(1);
		productRequest.setCartProduct(cartProduct);
		productRequest.setStoreId("1");
		productRequest.setTimeout(30000L);
		helper.validateProduct(EasyMock.anyObject(String.class), EasyMock.anyLong());
		EasyMock.expectLastCall();
		EasyMock.expect(cartDao.getProduct(EasyMock.anyObject(String.class), EasyMock.anyObject(String.class), EasyMock.anyObject(String.class), EasyMock.anyLong())).andReturn(new AccountProduct());
		EasyMock.replay(cartDao);
		EasyMock.replay(helper);
		boImpl.updateProduct(productRequest);
		EasyMock.verify(cartDao);
	}

	@Test
	public void testGetProduct() throws InvalidRequest, NotFound {
		GetProductsRequest getProductsRequest = new GetProductsRequest();
		getProductsRequest.setStoreId("1");
		getProductsRequest.setAccountId("1");
		getProductsRequest.setTimeout(30000L);
		AccountProduct accountProduct = new AccountProduct();
		accountProduct.setAccountProductId("11");
		List<AccountProduct> accountProducts = new ArrayList<AccountProduct>();
		accountProducts.add(accountProduct);
		EasyMock.expect(cartDao.findProducts(EasyMock.anyObject(String.class), EasyMock.anyObject(String.class),EasyMock.anyLong())).andReturn(accountProducts);
		EasyMock.replay(cartDao);
		GetProductsResponse getProductsResponse = boImpl.getProducts(getProductsRequest);
		assertNotNull(getProductsResponse);
		
	}
	
	@Test
	public void testGetProductNotFound()  {
		GetProductsRequest getProductsRequest = new GetProductsRequest();
		getProductsRequest.setStoreId("1");
		getProductsRequest.setAccountId("1");
		getProductsRequest.setTimeout(30000L);
		AccountProduct accountProduct = new AccountProduct();
		accountProduct.setAccountProductId("11");
		List<AccountProduct> accountProducts = new ArrayList<AccountProduct>();
		accountProducts.add(accountProduct);
		EasyMock.expect(cartDao.findProducts(EasyMock.anyObject(String.class), EasyMock.anyObject(String.class),EasyMock.anyLong())).andReturn(new ArrayList<AccountProduct>());
		EasyMock.replay(cartDao);
		try {
			boImpl.getProducts(getProductsRequest);
		} catch (Exception e) {
			assertTrue(e instanceof NotFound);
			NotFound found = (NotFound) e;
			assertEquals(StringUtils.EMPTY, found.getMessage());
			assertEquals(ErrorCodes.CART_PRODUCT_NOT_FOUND, found.getCode());
		}
		
	}

	@Test
	public void testDeleteProduct() throws InvalidRequest {
		DeleteProductRequest deleteProductRequest = new DeleteProductRequest();
		deleteProductRequest.setAccountId("1");
		deleteProductRequest.setProductId("1");
		deleteProductRequest.setStoreId("1");
		deleteProductRequest.setTimeout(30000L);
		AccountProduct accountProduct = new AccountProduct();
		accountProduct.setAccountProductId("11");
		helper.validateProduct(EasyMock.anyObject(String.class), EasyMock.anyLong());
		EasyMock.expectLastCall();
		EasyMock.expect(cartDao.getProduct(EasyMock.anyObject(String.class), EasyMock.anyObject(String.class), EasyMock.anyObject(String.class), EasyMock.anyLong())).andReturn(accountProduct);
		cartDao.delete(EasyMock.anyObject(AccountProduct.class));
		EasyMock.expectLastCall();
		EasyMock.replay(cartDao);
		EasyMock.replay(helper);
		
		boImpl.deleteProduct(deleteProductRequest);
		EasyMock.verify(cartDao);
	}

}
