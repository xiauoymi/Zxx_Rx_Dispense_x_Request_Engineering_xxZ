package com.esrx.ref.cart.jaxrs.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.esrx.ref.cart.ArrayOfCartProduct;
import com.esrx.ref.cart.GetProductsResponse;
import com.esrx.ref.cart.bo.CartProduct;

public class ResponseTransformer {

	public static GetProductsResponse createGetProductResponse(
			com.esrx.ref.cart.bo.GetProductsResponse response) {
		GetProductsResponse getProductsResponse = null;
		
		if(response != null){
			getProductsResponse = new GetProductsResponse();
			ArrayOfCartProduct arrayOfCartProduct = buildArrayOfCartProduct(response.getCartProductList());
			getProductsResponse.setCartProductList(arrayOfCartProduct);
		}
		
		return getProductsResponse;
	}

	private static ArrayOfCartProduct buildArrayOfCartProduct(
			List<CartProduct> cartProductList) {
		ArrayOfCartProduct arrayOfCartProduct = new ArrayOfCartProduct();
		if(CollectionUtils.isNotEmpty(cartProductList)){
			for(CartProduct cartProduct : cartProductList){
				com.esrx.ref.cart.CartProduct product = new com.esrx.ref.cart.CartProduct();
				product.setProductId(cartProduct.getProductId());
				product.setQuantity(cartProduct.getQuantity());
				arrayOfCartProduct.getCartProducts().add(product);
			}
		}
		return arrayOfCartProduct;
	}

}
