package com.esrx.ref.cart.jaxrs.impl;

import com.esrx.ref.cart.AddProductRequest;
import com.esrx.ref.cart.DeleteProductRequest;
import com.esrx.ref.cart.GetProductsRequest;
import com.esrx.ref.cart.UpdateProductRequest;
import com.esrx.ref.cart.bo.CartProduct;

public class RequestTransformer {

	public static com.esrx.ref.cart.bo.GetProductsRequest convertToBoGetProductsRequest(
			GetProductsRequest productsRequest) {
		com.esrx.ref.cart.bo.GetProductsRequest request = null;
		
		if(productsRequest != null){
			request = new com.esrx.ref.cart.bo.GetProductsRequest();
			request.setAccountId(productsRequest.getAccountId());
			request.setStoreId(productsRequest.getStoreId());
			request.setTimeout(productsRequest.getTimeout());
		}
		return request;
	}

	public static com.esrx.ref.cart.bo.AddProductRequest convertToBoAddProductRequest(
			AddProductRequest productRequest) {
		com.esrx.ref.cart.bo.AddProductRequest addProductRequest = null;
		if(productRequest != null){
			addProductRequest = new com.esrx.ref.cart.bo.AddProductRequest();
			addProductRequest.setAccountId(productRequest.getAccountId());
			addProductRequest.setStoreId(productRequest.getStoreId());
			addProductRequest.setTimeout(productRequest.getTimeout());
			addProductRequest.setCartProduct(buildCartProduct(productRequest.getCartProduct()));
		}
		
		return addProductRequest;
	}

	public static com.esrx.ref.cart.bo.UpdateProductRequest convertToBoUpdateProductRequest(
			UpdateProductRequest productRequest) {
		com.esrx.ref.cart.bo.UpdateProductRequest updateProductRequest = null;
		if(productRequest != null){
			updateProductRequest = new com.esrx.ref.cart.bo.UpdateProductRequest();
			updateProductRequest.setAccountId(productRequest.getAccountId());
			updateProductRequest.setStoreId(productRequest.getStoreId());
			updateProductRequest.setTimeout(productRequest.getTimeout());
			updateProductRequest.setCartProduct(buildCartProduct(productRequest.getCartProduct()));
		}
		return updateProductRequest;
	}

	public static com.esrx.ref.cart.bo.DeleteProductRequest convertToBoDeleteProductRequest(
			DeleteProductRequest productRequest) {
		com.esrx.ref.cart.bo.DeleteProductRequest deleteProductRequest = null;
		if(productRequest != null){
			deleteProductRequest = new com.esrx.ref.cart.bo.DeleteProductRequest();
			deleteProductRequest.setAccountId(productRequest.getAccountId());
			deleteProductRequest.setStoreId(productRequest.getStoreId());
			deleteProductRequest.setProductId(productRequest.getProductId());
			deleteProductRequest.setTimeout(productRequest.getTimeout());
		}
		return deleteProductRequest;
	}
	
	private static CartProduct buildCartProduct(
			com.esrx.ref.cart.CartProduct cartProduct) {
		CartProduct product = null;
		if(cartProduct != null){
			product = new CartProduct();
			product.setProductId(cartProduct.getProductId());
			product.setQuantity(cartProduct.getQuantity());
		}
		return product;
	}

}
