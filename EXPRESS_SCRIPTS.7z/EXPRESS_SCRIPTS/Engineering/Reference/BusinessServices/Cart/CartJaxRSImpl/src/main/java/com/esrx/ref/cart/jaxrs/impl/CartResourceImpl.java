package com.esrx.ref.cart.jaxrs.impl;

import com.esrx.ref.cart.AddProductRequest;
import com.esrx.ref.cart.AddProductResponse;
import com.esrx.ref.cart.DeleteProductRequest;
import com.esrx.ref.cart.DeleteProductResponse;
import com.esrx.ref.cart.GetProductsRequest;
import com.esrx.ref.cart.GetProductsResponse;
import com.esrx.ref.cart.UpdateProductRequest;
import com.esrx.ref.cart.UpdateProductResponse;
import com.esrx.ref.cart.bo.CartBo;
import com.esrx.ref.cart.jaxrs.CartResource;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;
import com.express_scripts.inf.types.ResourceUnavailable;

public class CartResourceImpl implements CartResource{
	
	private CartBo cartBo;
	
	@Override
	public GetProductsResponse getProducts(GetProductsRequest productsRequest) {
		ProcessTimer.startTimer();
		GetProductsResponse productsResponse = null;
		try {
			com.esrx.ref.cart.bo.GetProductsRequest request = RequestTransformer.convertToBoGetProductsRequest(productsRequest);
			com.esrx.ref.cart.bo.GetProductsResponse response = cartBo.getProducts(request);
			productsResponse = ResponseTransformer.createGetProductResponse(response);
		} catch(Exception ex) { 
			catchAndThrow(ex);
		}
		return productsResponse;
	}

	@Override
	public AddProductResponse addProduct(AddProductRequest productRequest) {
		ProcessTimer.startTimer();
		AddProductResponse productsResponse = null;
		try {
			com.esrx.ref.cart.bo.AddProductRequest request = RequestTransformer.convertToBoAddProductRequest(productRequest);
			cartBo.addProduct(request);
			productsResponse = new AddProductResponse();
		}catch(Exception ex) { 
			catchAndThrow(ex);
		}
		return productsResponse;
	}

	@Override
	public UpdateProductResponse updateProduct(
			UpdateProductRequest productRequest) {
		ProcessTimer.startTimer();
		UpdateProductResponse productsResponse = null;
		try {
			com.esrx.ref.cart.bo.UpdateProductRequest request = RequestTransformer.convertToBoUpdateProductRequest(productRequest);
			cartBo.updateProduct(request);
			productsResponse = new UpdateProductResponse();
		} catch(Exception ex) { 
			catchAndThrow(ex);
		}
		return productsResponse;
	}

	@Override
	public DeleteProductResponse deleteProduct(
			DeleteProductRequest productRequest) {
		ProcessTimer.startTimer();
		DeleteProductResponse productsResponse = null;
		try {
			com.esrx.ref.cart.bo.DeleteProductRequest request = RequestTransformer.convertToBoDeleteProductRequest(productRequest);
			cartBo.deleteProduct(request);
			productsResponse = new DeleteProductResponse();
		} catch(Exception ex) { 
			catchAndThrow(ex);
		}
		return productsResponse;
	}
	
	/**
	 * This method will help to move the Exception handling to a common method.
	 * Catch the exception and throw it again so that no need for the 
	 * @param ex
	 */
	private void catchAndThrow(Exception ex) {
		
		try {
			throw ex;
		}
		catch (InvalidRequest e) {
			throw new com.express_scripts.inf.types.jaxb.support.InvalidRequest(e);
		}catch (NotFound e) {
			throw new com.express_scripts.inf.types.jaxb.support.NotFound(e);
		}catch (ProcessTimeoutException e) {
			throw new com.express_scripts.inf.types.jaxb.support.ResourceUnavailable();
		}catch (ResourceUnavailable e) {
			throw new com.express_scripts.inf.types.jaxb.support.ResourceUnavailable(e);
		}catch (ProcessFailed e) {
			throw new com.express_scripts.inf.types.jaxb.support.ProcessFailed(e);
		}catch (Exception e) {
			throw new com.express_scripts.inf.types.jaxb.support.ProcessFailed();
		}
	}

	/**
	 * @param cartBo the cartBo to set
	 */
	public void setCartBo(CartBo cartBo) {
		this.cartBo = cartBo;
	}

}
