package com.esrx.ref.order.jaxrs.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.esrx.ref.order.ArrayOfLineItem;
import com.esrx.ref.order.CreateOrderRequest;
import com.esrx.ref.order.FindOrderRequest;
import com.esrx.ref.order.GetOrderRequest;
import com.esrx.ref.order.UpdateOrderStatusRequest;
import com.esrx.ref.order.bo.Address;
import com.esrx.ref.order.bo.CreditCardSummary;
import com.esrx.ref.order.bo.LineItem;
import com.esrx.ref.order.bo.Order;
import com.esrx.ref.order.bo.OrderStatus;
import com.esrx.ref.order.bo.Price;
import com.esrx.ref.order.bo.ProductSummary;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.jaxb.support.SortOptionsUtils;

public class RequestTransformer {

	public static com.esrx.ref.order.bo.CreateOrderRequest convertToCreateOrderRequest(
			CreateOrderRequest orderRequest) throws InvalidRequest {
		com.esrx.ref.order.bo.CreateOrderRequest createOrderRequest = null;
		if(orderRequest != null && orderRequest.getOrder() != null){
			createOrderRequest = new com.esrx.ref.order.bo.CreateOrderRequest();
			Order order = new Order();
			order.setAccountId(orderRequest.getOrder().getAccountId());
			order.setDate(OrderUtil.parseDate(orderRequest.getOrder().getDate()));
			
			order.setStatus(OrderStatus.valueOf(orderRequest.getOrder().getOrderStatus().name()));
			order.setTotalAmount(convertToPrice(orderRequest.getOrder().getTotalAmount()));
			order.setBillingAddress(convertToAddress(orderRequest.getOrder().getBillingAddress()));
			order.setShippingAddress(convertToAddress(orderRequest.getOrder().getShippingAddress()));
			order.setCreditCardSummary(convertToCreditCardSummary(orderRequest.getOrder().getCreditCardSummary()));
			order.setLineItemList(convertToLineItems(orderRequest.getOrder().getLineItemList()));
			createOrderRequest.setOrder(order);
			createOrderRequest.setTimeout(orderRequest.getTimeout());
		}
		return createOrderRequest;
	}

	public static com.esrx.ref.order.bo.GetOrderRequest convertToGetOrderRequest(
			GetOrderRequest orderRequest) {
		com.esrx.ref.order.bo.GetOrderRequest getOrderRequest = null;
		if(orderRequest != null){
			getOrderRequest = new com.esrx.ref.order.bo.GetOrderRequest();
			getOrderRequest.setOrderId(orderRequest.getOrderId());
			getOrderRequest.setTimeout(orderRequest.getTimeout());
		}
		return getOrderRequest;
	}

	public static com.esrx.ref.order.bo.FindOrderRequest convertToFindOrderRequest(
			FindOrderRequest orderRequest) {
		com.esrx.ref.order.bo.FindOrderRequest findOrderRequest = null;
		if(orderRequest != null){
			findOrderRequest = new com.esrx.ref.order.bo.FindOrderRequest();
			findOrderRequest.setAccountId(orderRequest.getAccountId());
			findOrderRequest.setCount(orderRequest.getCount());
			findOrderRequest.setOffset(orderRequest.getOffset());
			findOrderRequest.setTimeout(orderRequest.getTimeout());
			findOrderRequest.setSortOptions(SortOptionsUtils.convertToListSortOptions(orderRequest.getSortOptionList()));
		}
		return findOrderRequest;
	}

	public static com.esrx.ref.order.bo.UpdateOrderStatusRequest convertToUpdateOrderStatusRequest(
			UpdateOrderStatusRequest orderRequest) {
		com.esrx.ref.order.bo.UpdateOrderStatusRequest orderStatusRequest = null;
		if(orderRequest != null){
			orderStatusRequest = new com.esrx.ref.order.bo.UpdateOrderStatusRequest();
			orderStatusRequest.setOrderId(orderRequest.getOrderId());
			orderStatusRequest.setOrderStatus(OrderStatus.valueOf(orderRequest.getOrderStatus().value()));
			orderStatusRequest.setTimeout(orderRequest.getTimeout());
		}
		return orderStatusRequest;		
	}
	
	private static List<LineItem> convertToLineItems(
			ArrayOfLineItem lineItemList) {
		List<LineItem> lineItems = null;
		if(lineItemList != null && CollectionUtils.isNotEmpty(lineItemList.getLineItems())){
			lineItems = new ArrayList<LineItem>();
			for(com.esrx.ref.order.LineItem item : lineItemList.getLineItems()){
				LineItem lineItem = null;
				if(item != null){
					lineItem = new LineItem();
					lineItem.setQuantity(item.getQuantity());
					lineItem.setProductSummary(convertToProductSummary(item.getProductSummary()));
					lineItems.add(lineItem);
				}
			}
		}
		return lineItems;
	}

	private static ProductSummary convertToProductSummary(
			com.esrx.ref.order.ProductSummary productSummary) {
		ProductSummary summary = null;
		if(productSummary != null){
			summary = new ProductSummary();
			summary.setImageId(productSummary.getImageId());
			summary.setProductId(productSummary.getProductId());
			summary.setProductName(productSummary.getProductName());
			//summary.setPrice(convertToPrice(productSummary.getPrice()));
		}
		return summary;
	}

	private static CreditCardSummary convertToCreditCardSummary(
			com.esrx.ref.order.CreditCardSummary creditCardSummary) {
		CreditCardSummary cardSummary = null;
		if(creditCardSummary != null){
			cardSummary = new CreditCardSummary();
			cardSummary.setAlias(creditCardSummary.getAlias());
			cardSummary.setCreditCardId(creditCardSummary.getCreditCardId());
		}
		return cardSummary;
	}

	private static Address convertToAddress(
			com.esrx.ref.order.Address address) {
		Address boAddress = null;
		if(address != null){
			boAddress = new Address();
			boAddress.setAddressId(address.getAddressId());
			boAddress.setCity(address.getCity());
			boAddress.setLine1(address.getLine1());
			boAddress.setLine2(address.getLine2());
			boAddress.setLine3(address.getLine3());
			boAddress.setLine4(address.getLine4());
			boAddress.setName(address.getName());
			boAddress.setState(address.getState());
			boAddress.setZip4(address.getZip4());
			boAddress.setZip5(address.getZip5());
		}
		return boAddress;
	}

	private static Price convertToPrice(com.esrx.ref.order.Price price) {
		Price boPrice = null;
		if(price != null){
			boPrice = new Price();
			boPrice.setAmount(price.getAmount());
			boPrice.setCurrency(price.getCurrency());
			boPrice.setFormattedAmount(price.getFormattedAmount());
		}
		return boPrice;
	}

	/*private static List<SortOption> convertToSortOptions(
			ArrayOfSortOption sortOptions) {
		List<SortOption> sortOptionsList = null;
		if(sortOptions != null && CollectionUtils.isNotEmpty(sortOptions.getSortOptions())){
			sortOptionsList = new ArrayList<SortOption>();
			for(com.esrx.ref.order.SortOption option : sortOptions.getSortOptions()){
				if(option != null){
					SortOption sortOption = new SortOption();
					sortOption.setFieldName(option.getFieldName());
					sortOption.setOrder(SortOrder.fromValue(option.getOrder().value()));
					sortOptionsList.add(sortOption);
				}
			}
		}
		return SortOptionsUtils.convertToListSortOptions(sortOptions);
	}*/

}
