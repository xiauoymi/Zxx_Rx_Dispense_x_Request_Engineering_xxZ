package com.esrx.ref.order.jaxrs.impl;

import org.apache.log4j.Logger;

import com.esrx.ref.order.CreateOrderRequest;
import com.esrx.ref.order.CreateOrderResponse;
import com.esrx.ref.order.FindOrderRequest;
import com.esrx.ref.order.FindOrderResponse;
import com.esrx.ref.order.GetOrderRequest;
import com.esrx.ref.order.GetOrderResponse;
import com.esrx.ref.order.UpdateOrderStatusRequest;
import com.esrx.ref.order.UpdateOrderStatusResponse;
import com.esrx.ref.order.bo.OrderBo;
import com.esrx.ref.order.jaxrs.OrderResource;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;
import com.express_scripts.inf.types.ResourceUnavailable;

public class OrderResourceImpl implements OrderResource {
	
	private OrderBo orderBo;
	
	Logger logger = Logger.getLogger(OrderResourceImpl.class);

	@Override
	public CreateOrderResponse createOrder(CreateOrderRequest orderRequest) {
		ProcessTimer.startTimer();
		CreateOrderResponse response = null;
		try {
			com.esrx.ref.order.bo.CreateOrderRequest createOrderRequest  = RequestTransformer.convertToCreateOrderRequest(orderRequest);
			com.esrx.ref.order.bo.CreateOrderResponse orderResponse = orderBo.createOrder(createOrderRequest);
			response = ResponseTransformer.convertToCreateOrderResponse(orderResponse);
		} catch (Exception e) {
			catchAndThrow(e);
		}
		return response;
	}
	
	@Override
	public GetOrderResponse getOrder(GetOrderRequest orderRequest) {
		ProcessTimer.startTimer();
		GetOrderResponse response = null;
		try {
			com.esrx.ref.order.bo.GetOrderRequest getOrderRequest  = RequestTransformer.convertToGetOrderRequest(orderRequest);
			com.esrx.ref.order.bo.GetOrderResponse orderResponse = orderBo.getOrder(getOrderRequest);
			response = ResponseTransformer.convertToGetOrderResponse(orderResponse);
		} catch (Exception e) {
			catchAndThrow(e);
		}
		return response;
	}

	@Override
	public FindOrderResponse findOrder(FindOrderRequest orderRequest) {
		ProcessTimer.startTimer();
		FindOrderResponse response = null;
		try {
			com.esrx.ref.order.bo.FindOrderRequest findOrderRequest  = RequestTransformer.convertToFindOrderRequest(orderRequest);
			com.esrx.ref.order.bo.FindOrderResponse orderResponse = orderBo.findOrders(findOrderRequest);
			response = ResponseTransformer.convertToFindOrderResponse(orderResponse);
		} catch (Exception e) {
			catchAndThrow(e);
		}
		return response;
	}

	@Override
	public UpdateOrderStatusResponse updateOrderStatus(
			UpdateOrderStatusRequest orderRequest) {
		ProcessTimer.startTimer();
		try {
			com.esrx.ref.order.bo.UpdateOrderStatusRequest updateOrderStatusRequest  = RequestTransformer.convertToUpdateOrderStatusRequest(orderRequest);
			orderBo.updateOrderStatus(updateOrderStatusRequest);
		} catch (Exception e) {
			catchAndThrow(e);
		}
		return new UpdateOrderStatusResponse();
	}
	
	private void catchAndThrow(Exception ex) {
		try {
			throw ex;
		} catch (InvalidRequest e) {
			throw new com.express_scripts.inf.types.jaxb.support.InvalidRequest(e);
		} catch (NotFound e) {
			throw new com.express_scripts.inf.types.jaxb.support.NotFound(e);
		} catch (ProcessTimeoutException e) {
			throw new com.express_scripts.inf.types.jaxb.support.ResourceUnavailable();
		}catch (ResourceUnavailable e) {
			throw new com.express_scripts.inf.types.jaxb.support.ResourceUnavailable(e);
		}catch (ProcessFailed e) {
			throw new com.express_scripts.inf.types.jaxb.support.ProcessFailed(e);
		}catch (Exception e) {
			throw new com.express_scripts.inf.types.jaxb.support.ProcessFailed();
		}
	}

	@Override
	public void queueUpdateOrderStatus(UpdateOrderStatusRequest orderStatusRequest){
		ProcessTimer.startTimer();
		com.esrx.ref.order.bo.UpdateOrderStatusRequest updateOrderStatusRequest  = RequestTransformer.convertToUpdateOrderStatusRequest(orderStatusRequest);
		try {
			orderBo.updateOrderStatus(updateOrderStatusRequest);
		} catch (InvalidRequest e) {
			logger.error("invalid request from queue"+e);
		}catch (ProcessTimeoutException e) {
			logger.error(e.getMessage());
		}catch (ResourceUnavailable e) {
			logger.error(e.getMessage());
		}catch (ProcessFailed e) {
			logger.error(e.getMessage());
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	

	/**
	 * @param orderBo the orderBo to set
	 */
	public void setOrderBo(OrderBo orderBo) {
		this.orderBo = orderBo;
	}

}
