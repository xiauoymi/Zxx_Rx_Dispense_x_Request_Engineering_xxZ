package com.esrx.ref.order.jaxrs.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.esrx.ref.order.bo.impl.ErrorCodes;
import com.esrx.ref.order.bo.impl.ErrorMessages;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.ProcessFailed;

public class OrderUtil {

	
	private static final String DATE_FORMAT = "yyyy-MM-dd";

	public static Date parseDate(String dateToChange) throws InvalidRequest {
		if(StringUtils.isBlank(dateToChange)){
			return null;
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		dateFormat.setLenient(false);
		Date date;
		try {
			date = dateFormat.parse(dateToChange);
		} catch (ParseException e) {
			throw new InvalidRequest(ErrorMessages.DATE_INVALID, ErrorCodes.DATE_INVALID, null, null);
		}
		return date;
	}
	
	public static String parseDate(Date dateToChange) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		dateFormat.setLenient(false);
		String date = StringUtils.EMPTY;
		
		try {
			date = dateFormat.format(dateToChange);
		} catch (Exception e) {
			throw new ProcessFailed(ErrorMessages.UNEXPECTED_EXCEPTION, ErrorCodes.UNEXPECTED_EXCEPTION, null, null);
		}
		return date;
	}

}
