package com.esrx.ref.order.jaxrs.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.esrx.ref.order.Address;
import com.esrx.ref.order.ArrayOfLineItem;
import com.esrx.ref.order.ArrayOfOrderSummary;
import com.esrx.ref.order.CreateOrderResponse;
import com.esrx.ref.order.CreditCardSummary;
import com.esrx.ref.order.FindOrderResponse;
import com.esrx.ref.order.GetOrderResponse;
import com.esrx.ref.order.Order;
import com.esrx.ref.order.OrderStatus;
import com.esrx.ref.order.Price;
import com.esrx.ref.order.ProductSummary;
import com.esrx.ref.order.bo.LineItem;
import com.esrx.ref.order.bo.OrderSummary;

public class ResponseTransformer {

	public static CreateOrderResponse convertToCreateOrderResponse(
			com.esrx.ref.order.bo.CreateOrderResponse orderResponse) {
		CreateOrderResponse createOrderResponse = null;
		if(orderResponse != null){
			createOrderResponse = new CreateOrderResponse();
			createOrderResponse.setOrderId(orderResponse.getOrderId());
		}
		return createOrderResponse;
	}

	public static GetOrderResponse convertToGetOrderResponse(
			com.esrx.ref.order.bo.GetOrderResponse orderResponse) {
		GetOrderResponse getOrderResponse = null;
		if(orderResponse != null && orderResponse.getOrder() != null){
			getOrderResponse = new GetOrderResponse();
			Order order = new Order();
			order.setOrderId(orderResponse.getOrder().getOrderId());
			order.setAccountId(orderResponse.getOrder().getAccountId());
			order.setDate(OrderUtil.parseDate(orderResponse.getOrder().getDate()));
			order.setOrderStatus(OrderStatus./*TEST*/fromValue(orderResponse.getOrder().getStatus().name()));
			order.setTotalAmount(convertToPrice(orderResponse.getOrder().getTotalAmount()));
			order.setBillingAddress(convertToAddress(orderResponse.getOrder().getBillingAddress()));
			order.setShippingAddress(convertToAddress(orderResponse.getOrder().getShippingAddress()));
			order.setCreditCardSummary(convertToCreditCardSummary(orderResponse.getOrder().getCreditCardSummary()));
			order.setLineItemList(convertToLineItems(orderResponse.getOrder().getLineItemList()));
			getOrderResponse.setOrder(order);
		}
		return getOrderResponse;
	}

	public static FindOrderResponse convertToFindOrderResponse(
			com.esrx.ref.order.bo.FindOrderResponse orderResponse) {
		FindOrderResponse findOrderResponse = new FindOrderResponse();
		ArrayOfOrderSummary arrayOfOrderSummary = new ArrayOfOrderSummary();
		if(orderResponse != null && CollectionUtils.isNotEmpty(orderResponse.getOrderSummaryList())){
			for(OrderSummary orderSummary : orderResponse.getOrderSummaryList()){
				if(orderSummary != null){
					com.esrx.ref.order.OrderSummary summary = new com.esrx.ref.order.OrderSummary();
					summary.setDate(OrderUtil.parseDate(orderSummary.getDate()));
					summary.setOrderId(orderSummary.getOrderId());
					summary.setOrderStatus(OrderStatus.fromValue(orderSummary.getOrderStatus().name()));
					summary.setTotalAmount(convertToPrice(orderSummary.getTotalAmount()));
					summary.setAccountId(orderSummary.getAccountId());
					arrayOfOrderSummary.getOrderSummaries().add(summary);
				}
			}
			findOrderResponse.setTotalCount(orderResponse.getTotalCount());
		}
		findOrderResponse.setOrderSummaryList(arrayOfOrderSummary);
		return findOrderResponse;
	}
	
	private static ArrayOfLineItem convertToLineItems(
			 List<LineItem> boLineItems) {
		ArrayOfLineItem arrayOfLineItem = null;
		
		if(CollectionUtils.isNotEmpty(boLineItems)){
			arrayOfLineItem = new ArrayOfLineItem();
			List<com.esrx.ref.order.LineItem> lineItems = new ArrayList<com.esrx.ref.order.LineItem>();
			for(com.esrx.ref.order.bo.LineItem item : boLineItems){
				if(item != null){
					com.esrx.ref.order.LineItem lineItem = new com.esrx.ref.order.LineItem();
					lineItem.setQuantity(item.getQuantity());
					lineItem.setProductSummary(convertToProductSummary(item.getProductSummary()));
					lineItem.setPurchasePrice(convertToPrice(item.getPurchasePrice()));
					lineItems.add(lineItem);
				}
			}
			arrayOfLineItem.getLineItems().addAll(lineItems);
		}
		return arrayOfLineItem;
	}

	private static ProductSummary convertToProductSummary(
			com.esrx.ref.order.bo.ProductSummary boProductSummary) {
		ProductSummary summary = null;
		if(boProductSummary != null){
			summary = new ProductSummary();
			summary.setImageId(boProductSummary.getImageId());
			summary.setProductId(boProductSummary.getProductId());
			summary.setProductName(boProductSummary.getProductName());
			summary.setPrice(convertToPrice(boProductSummary.getPrice()));
		}
		return summary;
	}

	private static CreditCardSummary convertToCreditCardSummary(
			com.esrx.ref.order.bo.CreditCardSummary boCreditCardSummary) {
		CreditCardSummary cardSummary = null;
		if(boCreditCardSummary != null){
			cardSummary = new CreditCardSummary();
			cardSummary.setAlias(boCreditCardSummary.getAlias());
			cardSummary.setCreditCardId(boCreditCardSummary.getCreditCardId());
		}
		return cardSummary;
	}

	private static Address convertToAddress(
			com.esrx.ref.order.bo.Address boAddress) {
		Address address = null;
		if(boAddress != null){
			address = new Address();
			address.setAddressId(boAddress.getAddressId());
			address.setCity(boAddress.getCity());
			address.setLine1(boAddress.getLine1());
			address.setLine2(boAddress.getLine2());
			address.setLine3(boAddress.getLine3());
			address.setLine4(boAddress.getLine4());
			address.setName(boAddress.getName());
			address.setState(boAddress.getState());
			address.setZip4(boAddress.getZip4());
			address.setZip5(boAddress.getZip5());
		}
		return address;
	}

	private static Price convertToPrice(com.esrx.ref.order.bo.Price boPrice) {
		Price price = null;
		if(boPrice != null){
			price = new Price();
			price.setAmount(boPrice.getAmount());
			price.setCurrency(boPrice.getCurrency());
			price.setFormattedAmount(boPrice.getFormattedAmount());
		}
		return price;
	}

}
