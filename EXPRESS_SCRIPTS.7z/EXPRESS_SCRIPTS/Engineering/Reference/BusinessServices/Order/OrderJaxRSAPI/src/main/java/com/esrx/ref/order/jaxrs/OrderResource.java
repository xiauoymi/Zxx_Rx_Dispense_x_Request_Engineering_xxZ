package com.esrx.ref.order.jaxrs;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.esrx.ref.order.CreateOrderRequest;
import com.esrx.ref.order.CreateOrderResponse;
import com.esrx.ref.order.FindOrderRequest;
import com.esrx.ref.order.FindOrderResponse;
import com.esrx.ref.order.GetOrderRequest;
import com.esrx.ref.order.GetOrderResponse;
import com.esrx.ref.order.UpdateOrderStatusRequest;
import com.esrx.ref.order.UpdateOrderStatusResponse;

@Path("/")
@Consumes(MediaType.APPLICATION_XML)
@Produces(MediaType.APPLICATION_XML)
public interface OrderResource {
	
	@POST
	@Path("createOrder")
	public CreateOrderResponse createOrder(CreateOrderRequest orderRequest);
	
	@POST
	@Path("getOrder")
	public GetOrderResponse getOrder(GetOrderRequest orderRequest);
	
	
	@POST
	@Path("findOrder")
	public FindOrderResponse findOrder(FindOrderRequest orderRequest);
	
	@POST
	@Path("updateOrderStatus")
	public UpdateOrderStatusResponse updateOrderStatus(UpdateOrderStatusRequest orderRequest);

	public void queueUpdateOrderStatus(UpdateOrderStatusRequest orderStatusRequest);
	

}
