package com.esrx.ref.order.mule.transformer;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import com.esrx.ref.order.bo.UpdateOrderStatusRequest;
import com.express_scripts.inf.bind.Unmarshaller;
import com.express_scripts.inf.protocols.common2.Envelope;
import com.express_scripts.inf.protocols.common2.xml.bind.UnmarshallerImpl;
import com.express_scripts.inf.types.ProcessFailed;
import com.wily.org.apache.log4j.Logger;

public class JmsRequestTransformer extends AbstractMessageTransformer {

	private static final String COM_ESRX_REF_ORDER = "com.esrx.ref.order";
	private static final Logger LOG = Logger
			.getLogger(JmsRequestTransformer.class);

	private Unmarshaller xmlUnmarshaller;
	private JAXBContext jaxbContext;

	// constructor to initialize jaxbContext,xmlUnmarshaller
	public JmsRequestTransformer() {
		try {
			jaxbContext = JAXBContext.newInstance(COM_ESRX_REF_ORDER);
			xmlUnmarshaller = new UnmarshallerImpl();
		} catch (JAXBException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Object transformMessage(MuleMessage msg, String arg1)
			throws TransformerException {
		try {
			String messageXml = (msg.getPayloadAsString());

			// transform xml to obj
			UpdateOrderStatusRequest requestObject = unmarshal(messageXml);
			msg.setPayload(requestObject);
			return msg;
		} catch (Exception e) {
			LOG.error(e.getMessage());
			throw new ProcessFailed(e);
		}
	}

	protected UpdateOrderStatusRequest unmarshal(String messageXml)
			throws Exception {

		UpdateOrderStatusRequest boReq = null;
		Envelope envelope = (Envelope) xmlUnmarshaller.unmarshal(messageXml
				.getBytes());
		// HeaderType header = envelope.getHeader();
		javax.xml.bind.Unmarshaller jaxbUnmarshaller = jaxbContext
				.createUnmarshaller();
		JAXBElement<?> body = (JAXBElement) jaxbUnmarshaller
				.unmarshal((org.w3c.dom.Node) envelope.getBody());

		// we expect one type of request, if we ever support multiple request in
		// future - we need to handle it here
		com.esrx.ref.order.UpdateOrderStatusRequest jaxbReq = (com.esrx.ref.order.UpdateOrderStatusRequest) body
				.getValue();

		// create new bo obect and populate the values from jaxbReq
		boReq = new UpdateOrderStatusRequest();
		boReq.setOrderId(jaxbReq.getOrderId());
		com.esrx.ref.order.OrderStatus jaxbOrderStatus = jaxbReq
				.getOrderStatus();
		String os = jaxbOrderStatus.value();
		com.esrx.ref.order.bo.OrderStatus boOrderStatus = com.esrx.ref.order.bo.OrderStatus
				.valueOf(os);
		boReq.setOrderStatus(boOrderStatus);
		boReq.setTimeout(jaxbReq.getTimeout());

		return boReq;
	}

}
