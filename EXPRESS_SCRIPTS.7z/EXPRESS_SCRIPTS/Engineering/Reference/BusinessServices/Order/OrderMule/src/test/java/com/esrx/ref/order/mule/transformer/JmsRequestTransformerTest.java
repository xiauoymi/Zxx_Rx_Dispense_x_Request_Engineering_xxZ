package com.esrx.ref.order.mule.transformer;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.esrx.ref.order.bo.UpdateOrderStatusRequest;
import com.esrx.ref.order.mule.transformer.JmsRequestTransformer;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.protocols.common2.xml.bind.UnmarshallerImpl;
import com.express_scripts.inf.types.InvalidRequest;

public class JmsRequestTransformerTest {

	@Before
	public void setUp() throws Exception {
		ProcessTimer.startTimer();
	}

	@Test
	public void testUnmarshall() throws InvalidRequest {
		UnmarshallerImpl xmlUnmarshaller = null;
		try {
			xmlUnmarshaller = new UnmarshallerImpl();
		} catch (JAXBException e1) {
			//
			e1.printStackTrace();
		}

		JmsRequestTransformer jmsRequestTransformer = new JmsRequestTransformer();
		

		String messageXml1 = "<?xml version=\"1.0\" encoding=\"UTF-8\" "
				+ "standalone=\"yes\"?><Envelope xmlns=\"urn:common2.protocols.inf.express_scripts.com\" "
				+ "xmlns:ns2=\"http://order.ref.esrx.com\">"
				+ "<header><entry><name>testHeader</name><value>testHeaderValue</value>"
				+ "</entry><entry><name>ESI_TRANSACTION_ID</name><value>abcde-12345</value>"
				+ "</entry><entry><name>ESI_CALLER_ID</name><value>testApp</value>"
				+ "</entry><entry><name>ESI_ORIG_CALLER_ID</name><value>testOrigApp</value>"
				+ "</entry></header>"
				+ "<body xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"ns2:UpdateOrderStatusRequest\">"
				+ "<ns2:orderId>orderId</ns2:orderId><ns2:orderStatus>REQUESTED</ns2:orderStatus><ns2:timeout>0</ns2:timeout></body></Envelope>";
		
		String messageXml2 = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" 
			+ "<Envelope xmlns=\"urn:common2.protocols.inf.express_scripts.com\" xmlns:ns2=\"http://order.ref.esrx.com\">" 
			+ "<header><entry><name>ESI_CALLER_ID</name><value>OrderB2B</value></entry></header>" 
			+ "<body xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"ns2:UpdateOrderStatusRequest\">" 
			+ "<ns2:orderId>2000</ns2:orderId><ns2:orderStatus>REQUESTED</ns2:orderStatus><ns2:timeout>99040</ns2:timeout></body></Envelope>";
		
			
				
			
			
				
				
				
			
		
/*	
 * 
 		<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
				
				<Envelope xmlns="urn:common2.protocols.inf.express_scripts.com" xmlns:ns2="http://order.ref.esrx.com">
					<header>
						<entry><name>testHeader</name><value>testHeaderValue</value></entry>
						<entry><name>ESI_TRANSACTION_ID</name><value>abcde-12345</value></entry>
						<entry><name>ESI_CALLER_ID</name><value>testApp</value></entry>
						<entry><name>ESI_ORIG_CALLER_ID</name><value>testOrigApp</value></entry>
					</header>
					<body xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="ns2:UpdateOrderStatusRequest">
						<ns2:orderId>orderId</ns2:orderId>
						<ns2:orderStatus>REQUESTED</ns2:orderStatus>
						<ns2:timeout>0</ns2:timeout>
					</body>
				</Envelope>
		
		<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
			<Envelope xmlns="urn:common2.protocols.inf.express_scripts.com" xmlns:ns2="http://order.ref.esrx.com">
				<header>
					<entry><name>ESI_CALLER_ID</name><value>OrderB2B</value></entry>
				</header>
				<body xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="ns2:UpdateOrderStatusRequest">
					<ns2:orderId>2000</ns2:orderId>
					<ns2:orderStatus>REQUESTED</ns2:orderStatus>
					<ns2:timeout>99040</ns2:timeout>
				</body>
			</Envelope>
*/

		UpdateOrderStatusRequest reqObj = null;
		try {
			reqObj = jmsRequestTransformer.unmarshal(messageXml2);
			System.out.println("orderId:" + reqObj.getOrderId());
		} catch (Exception e) {
			e.printStackTrace();
		}

		Assert.assertEquals(reqObj.getOrderId(),"2000");
	}

}
