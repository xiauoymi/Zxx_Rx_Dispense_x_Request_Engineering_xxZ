package com.esrx.ref.order.bo.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.esrx.ref.order.bo.Address;
import com.esrx.ref.order.bo.CreateOrderRequest;
import com.esrx.ref.order.bo.CreateOrderResponse;
import com.esrx.ref.order.bo.CreditCardSummary;
import com.esrx.ref.order.bo.FindOrderRequest;
import com.esrx.ref.order.bo.FindOrderResponse;
import com.esrx.ref.order.bo.GetOrderRequest;
import com.esrx.ref.order.bo.GetOrderResponse;
import com.esrx.ref.order.bo.LineItem;
import com.esrx.ref.order.bo.OrderBo;
import com.esrx.ref.order.bo.OrderSummary;
import com.esrx.ref.order.bo.ProductSummary;
import com.esrx.ref.order.bo.UpdateOrderStatusRequest;
import com.esrx.ref.order.dao.OrderDao;
import com.esrx.ref.order.domain.FindOrdersResponse;
import com.esrx.ref.order.domain.Order;
import com.esrx.ref.order.domain.Status;
import com.esrx.ref.order.management.SleepTimeMBean;
import com.express_scripts.inf.concurrent.Process;
import com.express_scripts.inf.concurrent.ProcessException;
import com.express_scripts.inf.concurrent.ProcessManager;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.concurrent.Processor;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;
import com.express_scripts.inf.types.ResourceUnavailable;

public class OrderBoImpl implements OrderBo {

	private Long defaultTimeout = 30000L;
	private Long bufferTime = 100L;

	private OrderDao orderDao;

	private AccountServiceAdapter accountServiceAdapter;

	private ProcessManager processManager;

	private Processor accountProductProcessor;
	
	private SleepTimeMBean sleepTimeMBean;

	@Override
	public CreateOrderResponse createOrder(CreateOrderRequest createOrderRequest)
			throws InvalidRequest {
		Validator.validateCreateOrderRequest(createOrderRequest);
		
		delay(); // For testing purposes only
		
		CreditCardSummary cardSummary = accountServiceAdapter
				.getCreditCardById(createOrderRequest.getOrder()
						.getCreditCardSummary().getCreditCardId(),
						createOrderRequest.getOrder().getAccountId(),
						ProcessTimer.assertTimeRemaining(
								createOrderRequest.getTimeout(),
								defaultTimeout, bufferTime));
		Order order = DomainTransformer.convertToDomainOrder(createOrderRequest
				.getOrder(), cardSummary.getBillingAddressId(), ProcessTimer
				.assertTimeRemaining(createOrderRequest.getTimeout(),
						defaultTimeout, bufferTime));
		orderDao.persist(order);
		updateLineitemsWithPrice(createOrderRequest.getOrder()
				.getLineItemList(), ProcessTimer.assertTimeRemaining(
				createOrderRequest.getTimeout(), defaultTimeout, bufferTime));
		order.setLineItems(DomainTransformer.convertToDomainLineItems(
				createOrderRequest.getOrder().getLineItemList(),
				order.getOrderId()));
		CreateOrderResponse createOrderResponse = new CreateOrderResponse();
		createOrderResponse.setOrderId(String.valueOf(order.getOrderId()));
		return createOrderResponse;
	}

	@Override
	public GetOrderResponse getOrder(GetOrderRequest getOrderRequest)
			throws InvalidRequest, NotFound {
		Validator.validateGetOrderRequest(getOrderRequest);
		
		delay(); // For testing purposes only
		
		ProcessTimer.assertTimeRemaining(getOrderRequest.getTimeout(),
				defaultTimeout, bufferTime);
		GetOrderResponse getOrderResponse = null;
		Order order = orderDao.findById(Integer.parseInt(getOrderRequest
				.getOrderId()));
		if (order != null) {
			com.esrx.ref.order.bo.Order order2 = buildBoOrder(order,
					getOrderRequest.getTimeout());
			getOrderResponse = new GetOrderResponse();
			getOrderResponse.setOrder(order2);
		} else {
			throw new NotFound(ErrorCodes.NOT_FOUND, StringUtils.EMPTY,  null,
					null);
		}
		return getOrderResponse;
	}

	@Override
	public FindOrderResponse findOrders(FindOrderRequest findOrderRequest)
			throws InvalidRequest {
		Validator.validateFindOrderRequest(findOrderRequest);
		
		delay(); // For testing purposes only
		
		FindOrdersResponse ordersResponse = orderDao.findOrders(
				findOrderRequest.getAccountId(), findOrderRequest.getCount(),
				findOrderRequest.getOffset(), ProcessTimer.assertTimeRemaining(
						findOrderRequest.getTimeout(), defaultTimeout,
						bufferTime), findOrderRequest.getSortOptions());
		List<OrderSummary> orderSummaries = DomainTransformer
				.convertToOrderSummaries(ordersResponse.getOrders());
		FindOrderResponse findOrderResponse = new FindOrderResponse();
		findOrderResponse.setOrderSummaryList(orderSummaries);
		if (ordersResponse.getTotalCount() != null) {
			findOrderResponse.setTotalCount(ordersResponse.getTotalCount()
					.intValue());
		} else {
			findOrderResponse.setTotalCount(0);
		}

		return findOrderResponse;
	}

	@Override
	public void updateOrderStatus(
			UpdateOrderStatusRequest updateOrderStatusRequest)
			throws InvalidRequest {
		Validator.validateUpdateOrderStatusRequest(updateOrderStatusRequest);
		
		delay(); // For testing purposes only
		
		updateOrderStatusRequest.setTimeout(ProcessTimer.assertTimeRemaining(
				updateOrderStatusRequest.getTimeout(), defaultTimeout,
				bufferTime));
		Order order = orderDao.findById(Integer
				.parseInt(updateOrderStatusRequest.getOrderId()));
		if (order != null) {
			Status requestStatus = Status.valueOf(updateOrderStatusRequest
					.getOrderStatus().name());
			if (order.getOrderStatus() == Status.CANCELLED) {
				throw new InvalidRequest(ErrorMessages.ORDER_CANCELLED,
						ErrorCodes.ORDER_CANCELLED, null, null);
			}
			if (requestStatus.compareTo(order.getOrderStatus()) < 0) {
				throw new InvalidRequest(ErrorMessages.STATUS_NOT_VALID,
						ErrorCodes.STATUS_NOT_VALID, null, null);
			}
			order.setOrderStatus(Status.valueOf(updateOrderStatusRequest
					.getOrderStatus().name()));
		} else {
			throw new InvalidRequest(ErrorMessages.ORDER_NOT_FOUND,
					ErrorCodes.ORDER_NOT_FOUND, null, null);
		}
	}


	/**
	 * 
	 * @param lineItems
	 * @param timeout
	 * @throws InvalidRequest
	 */
	private void updateLineitemsWithPrice(List<LineItem> lineItems, Long timeout)
			throws InvalidRequest {
		List<Process> processes = new ArrayList<Process>();
		if (CollectionUtils.isNotEmpty(lineItems)) {

			// Start a process for each line item
			for (LineItem lineItem : lineItems) {
				GetPurchasePriceRequest priceRequest = RequestTransformer
						.buildGetPurchasePriceReqest(lineItem, ProcessTimer
								.assertTimeRemaining(timeout, defaultTimeout,
										bufferTime));
				try {
					processes.add(processManager.startProcess(priceRequest,
							accountProductProcessor));
				} catch (ProcessException e) {
					throw new ProcessFailed(ErrorMessages.UNEXPECTED_EXCEPTION,
							ErrorCodes.UNEXPECTED_EXCEPTION, null, null, e);
				}
			}

			// Wait for all process to finish
			try {
				processManager.waitForAll(processes, ProcessTimer
						.assertTimeRemaining(timeout, defaultTimeout,
								bufferTime));
			} catch (ProcessException e) {
				throw new ResourceUnavailable(ErrorMessages.TIMED_OUT,
						ErrorCodes.RESOURCE_UNAVAILABLE, null, null, e);
			}

			// Handle the result of each process
			for (Process process : processes) {
				Object result = process.getResult();
				if (result instanceof ProductSummary) {
					ProductSummary productSummary = (ProductSummary) result;
					for (LineItem lineItem : lineItems) {
						if (StringUtils.equals(lineItem.getProductSummary()
								.getProductId(), productSummary.getProductId())) {
							lineItem.setPurchasePrice(productSummary.getPrice());
							lineItem.getProductSummary().setImageId(
									productSummary.getImageId());
							lineItem.getProductSummary().setProductName(
									productSummary.getProductName());
						}
					}
				} else if (result instanceof InvalidRequest) {
					throw (InvalidRequest) result;
				} else if (result instanceof ProcessFailed) {
					throw (ProcessFailed) result;
				} else {
					throw new ProcessFailed(ErrorMessages.UNEXPECTED_EXCEPTION,
							ErrorCodes.UNEXPECTED_EXCEPTION, null, null,
							(Throwable) result);
				}
			}
		}
	}

	private com.esrx.ref.order.bo.Order buildBoOrder(Order order, Long timeout)
			throws InvalidRequest {
		List<Process> processes = new ArrayList<Process>();
		Address shippingAddress = null;
		Address billingAddress = null;
		CreditCardSummary cardSummary = null;

		GetAddressRequest shippingAddressRequest = RequestTransformer
				.buildGetAddressRequest(order.getShippingAddressId(),
						ProcessTimer.assertTimeRemaining(timeout,
								defaultTimeout, bufferTime));
		GetAddressRequest billingAddressRequest = RequestTransformer
				.buildGetAddressRequest(order.getBillingAddressId(),
						ProcessTimer.assertTimeRemaining(timeout,
								defaultTimeout, bufferTime));
		CreditCardRequest cardRequest = RequestTransformer
				.buildGetCreditCardRequest(order.getCreditCardId(),
						order.getAccountId(), ProcessTimer.assertTimeRemaining(timeout, defaultTimeout, bufferTime));
		try {
			processes.add(processManager.startProcess(shippingAddressRequest,
					accountProductProcessor));
			processes.add(processManager.startProcess(billingAddressRequest,
					accountProductProcessor));
			processes.add(processManager.startProcess(cardRequest,
					accountProductProcessor));
		} catch (ProcessException e) {
			throw new ProcessFailed(ErrorMessages.UNEXPECTED_EXCEPTION,
					ErrorCodes.UNEXPECTED_EXCEPTION, null, null, e);
		}
		// Wait for all process to finish
		try {
			processManager.waitForAll(processes, ProcessTimer
					.assertTimeRemaining(timeout, defaultTimeout, bufferTime));
		} catch (ProcessException e) {
			throw new ResourceUnavailable(ErrorMessages.TIMED_OUT,
					ErrorCodes.RESOURCE_UNAVAILABLE, null, null, e);
		}
		// Handle the result of each process
		for (Process process : processes) {
			Object result = process.getResult();
			if (result instanceof Address) {
				Address address = (Address) result;
				if (StringUtils.equals(address.getAddressId(),
						order.getShippingAddressId())) {
					shippingAddress = address;
				} else if (StringUtils.equals(address.getAddressId(),
						order.getBillingAddressId())) {
					billingAddress = address;
				}
				if (StringUtils.equals(order.getShippingAddressId(),
						order.getBillingAddressId())) {
					billingAddress = address;
				}
			} else if (result instanceof CreditCardSummary) {
				cardSummary = (CreditCardSummary) result;
			} else if (result instanceof InvalidRequest) {
				throw (InvalidRequest) result;
			} else if (result instanceof ResourceUnavailable) {
				throw (ResourceUnavailable) result;
			} else if (result instanceof ProcessFailed) {
				throw (ProcessFailed) result;
			} else {
				throw new ProcessFailed(ErrorMessages.UNEXPECTED_EXCEPTION,
						ErrorCodes.UNEXPECTED_EXCEPTION, null, null,
						(Throwable) result);
			}
		}
		com.esrx.ref.order.bo.Order order2 = DomainTransformer
				.convertToBoOrder(order, shippingAddress, billingAddress,
						cardSummary);
		return order2;
	}

	/**
	 * @return the defaultTimeout
	 */
	public Long getDefaultTimeout() {
		return defaultTimeout;
	}

	/**
	 * @param defaultTimeout
	 *            the defaultTimeout to set
	 */
	public void setDefaultTimeout(Long defaultTimeout) {
		this.defaultTimeout = defaultTimeout;
	}

	/**
	 * @return the bufferTime
	 */
	public Long getBufferTime() {
		return bufferTime;
	}

	/**
	 * @param bufferTime
	 *            the bufferTime to set
	 */
	public void setBufferTime(Long bufferTime) {
		this.bufferTime = bufferTime;
	}

	/**
	 * @param orderDao
	 *            the orderDao to set
	 */
	public void setOrderDao(OrderDao orderDao) {
		this.orderDao = orderDao;
	}

	/**
	 * @param accountServiceHelper
	 *            the accountServiceHelper to set
	 */
	public void setAccountServiceAdapter(
			AccountServiceAdapter accountServiceAdapter) {
		this.accountServiceAdapter = accountServiceAdapter;
	}

	/**
	 * @param processManager
	 *            the processManager to set
	 */
	public void setProcessManager(ProcessManager processManager) {
		this.processManager = processManager;
	}

	/**
	 * @param accountProductProcessor
	 *            the accountProductProcessor to set
	 */
	public void setAccountProductProcessor(Processor accountProductProcessor) {
		this.accountProductProcessor = accountProductProcessor;
	}

	public void setSleepTimeMBean(SleepTimeMBean sleepTimeMBean) {
		this.sleepTimeMBean = sleepTimeMBean;
	}

	/**
	 * @param updateOrderMQAdapter
	 *            the updateOrderMQAdapter to set
	 */
	/*
	 * public void setUpdateOrderMQAdapter(UpdateOrderMQAdapter
	 * updateOrderMQAdapter) { this.updateOrderMQAdapter = updateOrderMQAdapter;
	 * }
	 */

	private void delay() {
		long delayTime = sleepTimeMBean.getSleepTimeMS();
		if (delayTime > 0) {
			try {
				Thread.sleep(delayTime);
			} catch (Exception e) {
				// do nothing
			}
		}
	}
}
