package com.esrx.ref.order.bo;


public enum OrderStatus {

    REQUESTED,
    PROCESSING,
    CANCELLED,
    SHIPPED,
    DELIVERED,
    COMPLETED;

}
