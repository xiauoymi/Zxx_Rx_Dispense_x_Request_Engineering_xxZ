package com.esrx.ref.order.bo.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.esrx.ref.order.bo.Address;
import com.esrx.ref.order.bo.CreditCardSummary;
import com.esrx.ref.order.bo.LineItem;
import com.esrx.ref.order.bo.OrderStatus;
import com.esrx.ref.order.bo.OrderSummary;
import com.esrx.ref.order.bo.Price;
import com.esrx.ref.order.bo.ProductSummary;
import com.esrx.ref.order.domain.Order;
import com.esrx.ref.order.domain.Status;

public class DomainTransformer {

	public static com.esrx.ref.order.bo.Order convertToBoOrder(Order order, Address shippingAddress, Address billingAddress, CreditCardSummary cardSummary) {
		com.esrx.ref.order.bo.Order order2 = new com.esrx.ref.order.bo.Order();
		order2.setAccountId(order.getAccountId());
		order2.setDate(order.getOrderDate());
		order2.setOrderId(String.valueOf(order.getOrderId()));
		order2.setStatus(OrderStatus.valueOf(order.getOrderStatus().name()));
		order2.setBillingAddress(billingAddress);
		order2.setShippingAddress(shippingAddress);
		order2.setCreditCardSummary(cardSummary);
		order2.setLineItemList(convertToItemList(order.getLineItems()));
		order2.setTotalAmount(calculateTotalAmt(order.getLineItems()));
		return order2;
	}

	private static Price calculateTotalAmt(
			Set<com.esrx.ref.order.domain.LineItem> lineItems) {
		Price price = null;
		if(CollectionUtils.isNotEmpty(lineItems)){
			price = new Price();
			BigDecimal totalAmt = new BigDecimal(0);
			for(com.esrx.ref.order.domain.LineItem item : lineItems){
				if(item!=null && StringUtils.equalsIgnoreCase(item.getCurrencyCode(), "USD")){
					BigDecimal productPrice = new BigDecimal(item.getPurchasePrice());
					BigDecimal quantity = new BigDecimal(item.getQuantity());
					BigDecimal productvalue = productPrice.multiply(quantity);
					totalAmt = totalAmt.add(productvalue);
					price.setAmount(totalAmt);
					price.setCurrency("USD");
				}
			}
			
			price.setFormattedAmount("$"+price.getAmount());
		}
		return price;
	}

	private static List<LineItem> convertToItemList(
			Set<com.esrx.ref.order.domain.LineItem> lineItems) {
		List<LineItem> items = null;
		if(CollectionUtils.isNotEmpty(lineItems)){
			items = new ArrayList<LineItem>();
			for(com.esrx.ref.order.domain.LineItem item : lineItems){
				if(item!=null){
					LineItem lineItem = new LineItem();
					lineItem.setQuantity(item.getQuantity());
					ProductSummary productSummary = new ProductSummary();
					Price price = new Price();
					price.setAmount(new BigDecimal(item.getPurchasePrice()));
					price.setCurrency(item.getCurrencyCode());
					price.setFormattedAmount("$"+item.getPurchasePrice());
					productSummary.setPrice(price);
					productSummary.setImageId(item.getProductId());
					productSummary.setProductId(item.getProductId());
					lineItem.setProductSummary(productSummary);
					lineItem.setPurchasePrice(price);
					items.add(lineItem);
				}
			}
		}
		return items;
	}

	public static List<OrderSummary> convertToOrderSummaries(List<Order> orders)  {
		List<OrderSummary> orderSummaries = new ArrayList<OrderSummary>();
		if(CollectionUtils.isNotEmpty(orders)){
			for(Order order : orders){
				if(order != null){
					OrderSummary orderSummary = new OrderSummary();
					orderSummary.setDate(order.getOrderDate());
					orderSummary.setOrderId(String.valueOf(order.getOrderId()));
					orderSummary.setOrderStatus(OrderStatus.valueOf(order.getOrderStatus().name()));
					orderSummary.setAccountId(order.getAccountId());
					orderSummary.setTotalAmount(calculateTotalAmt(order.getLineItems()));
					orderSummaries.add(orderSummary);
				}
			}
		}
		return orderSummaries;
	}

	public static Set<com.esrx.ref.order.domain.LineItem> convertToDomainLineItems(
			List<LineItem> lineItemList, Integer orderId) {
		Set<com.esrx.ref.order.domain.LineItem> lineItems = new HashSet<com.esrx.ref.order.domain.LineItem>();
		if(CollectionUtils.isNotEmpty(lineItemList)){
			for(LineItem lineItem : lineItemList){
				com.esrx.ref.order.domain.LineItem item = new com.esrx.ref.order.domain.LineItem();
				if(lineItem.getProductSummary() != null && lineItem.getPurchasePrice() != null){
					item.setCurrencyCode(lineItem.getPurchasePrice().getCurrency());
					item.setProductId(lineItem.getProductSummary().getProductId());
					item.setOrderId(String.valueOf(orderId));
					item.setPurchasePrice(lineItem.getPurchasePrice().getAmount().toString());
					item.setQuantity(lineItem.getQuantity());
					lineItems.add(item);
				}
			}
		}
		return lineItems;
	}

	public static Order convertToDomainOrder(com.esrx.ref.order.bo.Order order,
			String billingAddressId, Long timeout) {
		Order orderDomain = new Order();
		orderDomain.setAccountId(order.getAccountId());
		
		orderDomain.setOrderDate(order.getDate());
		orderDomain.setOrderStatus(Status.REQUESTED);
		
		orderDomain.setBillingAddressId(billingAddressId);
		orderDomain.setShippingAddressId(order.getShippingAddress().getAddressId());
		orderDomain.setCreditCardId(order.getCreditCardSummary().getCreditCardId());
		
		return orderDomain;
	}
	

}
