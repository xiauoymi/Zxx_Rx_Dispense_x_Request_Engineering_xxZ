package com.esrx.ref.order.bo;

import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;


public interface OrderBo {

	CreateOrderResponse createOrder(CreateOrderRequest createOrderRequest) throws InvalidRequest;

	GetOrderResponse getOrder(GetOrderRequest getOrderRequest) throws InvalidRequest, NotFound;

	FindOrderResponse findOrders(FindOrderRequest findOrderRequest) throws InvalidRequest;

	void updateOrderStatus(UpdateOrderStatusRequest updateOrderStatusRequest) throws InvalidRequest;
	
}
