package com.esrx.ref.order.bo.impl;

public class ErrorMessages {

	public static final String TIMED_OUT = "Timed out";
	public static final String REQUEST_REQUIRED = "Request required";
	public static final String UNEXPECTED_EXCEPTION = "Unexpected exception";
	public static final String ORDER_REQUIRED = "Order information required";
	public static final String ACCOUNT_ID_REQUIRED = "Account id required";
	public static final String ACCOUNT_ID_INVALID = "Account id not a number";
	public static final String ORDER_DATE_REQUIRED = "Order date required";
	public static final String PRICE_REQUIRED = "Price required";
	public static final String CREDITCARD_REQUIRED = "Credit card information required";
	public static final String BILLING_ADDRESS_REQUIRED = "Billing address required";
	public static final String SHIPPING_ADDRESS_REQUIRED = "Shipping address required";
	public static final String LINE_ITEMS_REQUIRED = "Line items required";
	public static final String AMOUNT_INVALID = "Amount empty";
	public static final String CITY_REQUIRED = "City required";
	public static final String LINE1_REQUIRED = "Line1 required";
	public static final String STATE_REQUIRED = "State required";
	public static final String ZIP_5_INVALID = "Zip 5 invalid";
	public static final String ZIP5_LENGTH_INCORRECT = "Zip 5 length incorrect";
	public static final String ZIP4_LENGTH_INCORRECT = "Zip 4 length incorrect";
	public static final String ORDER_ID_REQUIRED = "Order id required";
	public static final String UNEXPECTED_REQUEST = "Unexpected request";
	public static final String ORDER_STATUS_REQUIRED = "Order status required";
	public static final String ORDER_ID_INVALID = "Order id invalid";
	public static final String DATE_FORMAT = "MM/dd/yyyy";
	public static final String DATE_INVALID = "Invalid date";
	public static final String ORDER_NOT_FOUND = "Order not found";
	public static final String UNABLE_TO_SAVE_ADDRESS = "Error while saving address";
	public static final String SORT_OPTIONS_INVALID = "Sort options invalid";
	public static final String ADDRESS_ID_REQUIRED = "Address id required";
	public static final String CREDITCARD_ID_REQUIRED = "Credit card id required";
	public static final String CARD_INFO_NOT_FOUND = "Credit card info not found";
	public static final String STATUS_NOT_VALID = "Cannot update the status.";
	public static final String ORDER_CANCELLED = "Order cancelled. Create new order.";
	public static final String CREDITCARD_ID_IS_INVALID = "CREDITCARD_ID is invalid.";

}
