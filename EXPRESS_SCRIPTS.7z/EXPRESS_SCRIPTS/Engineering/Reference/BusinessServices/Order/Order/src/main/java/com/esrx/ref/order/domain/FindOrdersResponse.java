package com.esrx.ref.order.domain;

import java.io.Serializable;
import java.util.List;

public class FindOrdersResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6513890186651099366L;
	
	private List<Order> orders;
	private Long totalCount;
	/**
	 * @return the orders
	 */
	public List<Order> getOrders() {
		return orders;
	}
	/**
	 * @param orders the orders to set
	 */
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	/**
	 * @return the totalCount
	 */
	public Long getTotalCount() {
		return totalCount;
	}
	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

}
