package com.esrx.ref.order.bo;

import java.io.Serializable;

public class GetOrderResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5748717170369666019L;
	private Order order;

	/**
	 * @return the order
	 */
	public Order getOrder() {
		return order;
	}

	/**
	 * @param order the order to set
	 */
	public void setOrder(Order order) {
		this.order = order;
	}

}
