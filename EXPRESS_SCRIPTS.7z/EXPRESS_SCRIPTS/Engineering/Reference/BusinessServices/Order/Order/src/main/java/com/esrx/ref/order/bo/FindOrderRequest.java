package com.esrx.ref.order.bo;

import java.io.Serializable;
import java.util.List;

import com.express_scripts.inf.types.SortOption;

public class FindOrderRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8284780410413507360L;
	private String accountId;
	private List<SortOption> sortOptions;
	private int offset;
	private int count;
	private Long timeout;
	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}
	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * @return the offset
	 */
	public int getOffset() {
		return offset;
	}
	/**
	 * @param offset the offset to set
	 */
	public void setOffset(int offset) {
		this.offset = offset;
	}
	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}
	/**
	 * @param count the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}
	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}
	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}
	/**
	 * @return the sortOptions
	 */
	public List<SortOption> getSortOptions() {
		return sortOptions;
	}
	/**
	 * @param sortOptions the sortOptions to set
	 */
	public void setSortOptions(List<SortOption> sortOptions) {
		this.sortOptions = sortOptions;
	}

}
