package com.esrx.ref.order.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="ORDER_LINE_ITEM")
public class LineItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8672498465021959212L;
	
	private Integer orderProductId;
	private int quantity;
	private String purchasePrice;
	private String currencyCode;
	private String orderId;
	private String productId;
	/**
	 * @return the orderId
	 */
	@Column(name="ORDER_ID")
	public String getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the productId
	 */
	@Column(name="PRODUCT_ID")
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the quantity
	 */
	@Column(name="QUANTITY")
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the purchasePrice
	 */
	@Column(name="PURCHASE_PRICE")
	public String getPurchasePrice() {
		return purchasePrice;
	}
	/**
	 * @param purchasePrice the purchasePrice to set
	 */
	public void setPurchasePrice(String purchasePrice) {
		this.purchasePrice = purchasePrice;
	}
	/**
	 * @return the currencyCode
	 */
	@Column(name="CURRENCY_CODE")
	public String getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	/**
	 * @return the orderProductId
	 */
	@Id
	@GeneratedValue(generator="orderProductIdSeq")
	@SequenceGenerator(name="orderProductIdSeq", sequenceName="ORDER_PRODUCT_ID_SEQ")
	@Column(name="ORDER_PRODUCT_ID")
	public Integer getOrderProductId() {
		return orderProductId;
	}
	/**
	 * @param orderProductId the orderProductId to set
	 */
	public void setOrderProductId(Integer orderProductId) {
		this.orderProductId = orderProductId;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		result = prime * result
				+ ((orderProductId == null) ? 0 : orderProductId.hashCode());
		result = prime * result
				+ ((productId == null) ? 0 : productId.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LineItem other = (LineItem) obj;
		if (orderId == null || other.orderId != null){
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		if (orderProductId == null || other.orderProductId != null){
				return false;
		} else if (!orderProductId.equals(other.orderProductId))
			return false;
		if (productId == null || other.productId != null){
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		return true;
	}
	
}
