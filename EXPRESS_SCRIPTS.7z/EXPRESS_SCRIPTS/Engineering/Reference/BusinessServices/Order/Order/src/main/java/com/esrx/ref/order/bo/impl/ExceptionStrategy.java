package com.esrx.ref.order.bo.impl;

import java.net.SocketTimeoutException;

import org.apache.commons.lang.StringUtils;

import com.express_scripts.inf.jersey.ResourceException;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.ProcessFailed;
import com.express_scripts.inf.types.ResourceUnavailable;
import com.express_scripts.inf.types.jaxb.ErrorInfo;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.ClientResponse.Status;
import com.sun.jersey.api.client.UniformInterfaceException;

public class ExceptionStrategy {
	public void handleResourceException(ResourceException e) throws InvalidRequest {
		ClientResponse response = e.getClientResponse();
		final Status status = getStatusFromClientResponse(response);
		
		switch(status) {
			case NOT_FOUND:
				handleNotFoundStatusResponse();
				break;
			case INTERNAL_SERVER_ERROR:
				handleInternalServerErrorStatusResponse(response);
				break;
			default:
				ErrorInfo errInfo = getErrorInfoFromClientResponse(response);
				throw buildProcessFailedException(errInfo);
		}
	}
	
	private void handleNotFoundStatusResponse() throws InvalidRequest {
		throw new InvalidRequest();
	}
	
	private void handleInternalServerErrorStatusResponse(ClientResponse response) {
		ErrorInfo errInfo = getErrorInfoFromClientResponse(response);
		throw buildProcessFailedException(errInfo);
	}
	
	private ErrorInfo getErrorInfoFromClientResponse(ClientResponse response) {
		try {
			return response.getEntity(ErrorInfo.class);
		} catch (ClientHandlerException che) {
			if (che.getCause() instanceof SocketTimeoutException) {
				throw buildResourceUnavailable(ErrorCodes.RESOURCE_UNAVAILABLE, ErrorMessages.TIMED_OUT);
			}
			throw buildProcessFailedException();
		} catch (UniformInterfaceException uie) {
			throw buildProcessFailedException();
		}
	}
	
	private Status getStatusFromClientResponse(ClientResponse response) {
		if (response == null) {
			throw buildProcessFailedException();
		}
		return Status.fromStatusCode(response.getStatus());
	}
	
	private ProcessFailed buildProcessFailedException(ErrorInfo errInfo) {
		if(StringUtils.equalsIgnoreCase(ErrorCodes.RESOURCE_UNAVAILABLE, errInfo.getCode())){
			throw buildResourceUnavailable(errInfo);
		} else {
			return new ProcessFailed(errInfo.getCode(),errInfo.getMessage(),errInfo.getId(), errInfo.getData());
		}
	}
	
	private ProcessFailed buildProcessFailedException() {
		return new ProcessFailed(ErrorMessages.UNEXPECTED_EXCEPTION, ErrorCodes.UNEXPECTED_EXCEPTION, null, null);
	}
	
	private ResourceUnavailable buildResourceUnavailable(ErrorInfo errInfo) {
		return new ResourceUnavailable(ErrorCodes.RESOURCE_UNAVAILABLE, errInfo.getMessage(),null,null);
	}
	
	private ResourceUnavailable buildResourceUnavailable(String code, String message) {
		return new ResourceUnavailable(code, message,null,null);
	}
}
