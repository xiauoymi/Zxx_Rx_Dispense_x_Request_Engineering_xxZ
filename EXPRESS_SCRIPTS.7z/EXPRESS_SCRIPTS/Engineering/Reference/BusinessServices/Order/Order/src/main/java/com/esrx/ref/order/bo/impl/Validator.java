package com.esrx.ref.order.bo.impl;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.esrx.ref.order.bo.CreateOrderRequest;
import com.esrx.ref.order.bo.FindOrderRequest;
import com.esrx.ref.order.bo.GetOrderRequest;
import com.esrx.ref.order.bo.UpdateOrderStatusRequest;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.SortOption;
import com.express_scripts.inf.types.support.SortOptionListValidator;
import com.express_scripts.inf.validator.NullValidator;
import com.express_scripts.inf.validator.NumberValidator;

public class Validator {
	private static String[] VALID_ORDER_SORT_FIELDS = new String[] {"orderId","accountId","orderStatus","shippingAddressId","billingAddressId","creditCardId","orderDate"};

	public static void validateCreateOrderRequest(
			CreateOrderRequest createOrderRequest) throws InvalidRequest {
		
		NullValidator.assertNotNull("REQUEST", createOrderRequest);
		NullValidator.assertNotNull("ORDER", createOrderRequest.getOrder());
		NullValidator.assertNotNull("ACCOUNT_ID", createOrderRequest.getOrder().getAccountId());
		NullValidator.assertNotNull("ORDER_DATE", createOrderRequest.getOrder().getDate());
		NullValidator.assertNotNull("CREDIT_CARD", createOrderRequest.getOrder().getCreditCardSummary());
		NullValidator.assertNotNull("CREDIT_CARD_ID", createOrderRequest.getOrder().getCreditCardSummary().getCreditCardId());
		NullValidator.assertNotNull("SHIPPING_ADDRESS", createOrderRequest.getOrder().getShippingAddress());
		NullValidator.assertNotNull("ADDRESS_ID", createOrderRequest.getOrder().getShippingAddress().getAddressId());
		//NullValidator.assertCollectionNullOrEmpty("LINE_ITEMS", createOrderRequest.getOrder().getLineItemList());
		if (CollectionUtils.isEmpty(createOrderRequest.getOrder()
				.getLineItemList())) {
			throw new InvalidRequest(ErrorMessages.LINE_ITEMS_REQUIRED,
					ErrorCodes.LINE_ITEMS_REQUIRED, null, null);
		}
	}

	public static void validateGetOrderRequest(GetOrderRequest getOrderRequest)
			throws InvalidRequest {
		NullValidator.assertNotNull("REQUEST", getOrderRequest);
		NullValidator.assertNotNull("ORDER_ID", getOrderRequest.getOrderId());
		NumberValidator.assertNumber("ORDER_ID", getOrderRequest.getOrderId());
	}

	public static void validateFindOrderRequest(
			FindOrderRequest findOrderRequest) throws InvalidRequest {
		NullValidator.assertNotNull("REQUEST", findOrderRequest);
		NullValidator.assertNotNull("ACCOUNT_ID", findOrderRequest.getAccountId());
		
		List<SortOption> sortOptions = findOrderRequest.getSortOptions();
		if (sortOptions != null && !sortOptions.isEmpty()) {
			SortOptionListValidator.assertValidSortOptionList(sortOptions, Arrays.asList(VALID_ORDER_SORT_FIELDS));
		}
	}

	public static void validateUpdateOrderStatusRequest(
			UpdateOrderStatusRequest updateOrderStatusRequest)
			throws InvalidRequest {
		NullValidator.assertNotNull("REQUEST", updateOrderStatusRequest);
		NullValidator.assertNotNull("ORDER_ID", updateOrderStatusRequest.getOrderId());
		NullValidator.assertNotNull("ORDER_STATUS", updateOrderStatusRequest.getOrderStatus());
	}
}
