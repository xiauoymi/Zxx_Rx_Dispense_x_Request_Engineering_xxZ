package com.esrx.ref.order.bo.impl;

import java.io.Serializable;

public class GetPurchasePriceRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2599960980301663694L;
	private String productId;
	private Long timeout;
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}
	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}
}
