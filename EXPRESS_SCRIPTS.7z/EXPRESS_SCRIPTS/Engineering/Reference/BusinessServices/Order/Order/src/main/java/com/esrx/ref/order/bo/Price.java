package com.esrx.ref.order.bo;

import java.io.Serializable;
import java.math.BigDecimal;

public class Price implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1439060349186868328L;
	private	String currency;
	private BigDecimal amount;
	private String formattedAmount;
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	/**
	 * @return the formattedAmount
	 */
	public String getFormattedAmount() {
		return formattedAmount;
	}
	/**
	 * @param formattedAmount the formattedAmount to set
	 */
	public void setFormattedAmount(String formattedAmount) {
		this.formattedAmount = formattedAmount;
	}

}
