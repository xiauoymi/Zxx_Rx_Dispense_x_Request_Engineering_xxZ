package com.esrx.ref.order.bo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Order implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -259858069628770448L;
	private String orderId;
	private Date date;
	private OrderStatus status;
	private Address shippingAddress;
	private Address billingAddress;
	private CreditCardSummary creditCardSummary;
	private String accountId;
	private Price totalAmount;
	private List<LineItem> lineItemList;
	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the status
	 */
	public OrderStatus getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(OrderStatus status) {
		this.status = status;
	}
	/**
	 * @return the shippingAddress
	 */
	public Address getShippingAddress() {
		return shippingAddress;
	}
	/**
	 * @param shippingAddress the shippingAddress to set
	 */
	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	/**
	 * @return the billingAddress
	 */
	public Address getBillingAddress() {
		return billingAddress;
	}
	/**
	 * @param billingAddress the billingAddress to set
	 */
	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}
	/**
	 * @return the creditCardSummary
	 */
	public CreditCardSummary getCreditCardSummary() {
		return creditCardSummary;
	}
	/**
	 * @param creditCardSummary the creditCardSummary to set
	 */
	public void setCreditCardSummary(CreditCardSummary creditCardSummary) {
		this.creditCardSummary = creditCardSummary;
	}
	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}
	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * @return the totalAmount
	 */
	public Price getTotalAmount() {
		return totalAmount;
	}
	/**
	 * @param totalAmount the totalAmount to set
	 */
	public void setTotalAmount(Price totalAmount) {
		this.totalAmount = totalAmount;
	}
	/**
	 * @return the lineItemList
	 */
	public List<LineItem> getLineItemList() {
		return lineItemList;
	}
	/**
	 * @param lineItemList the lineItemList to set
	 */
	public void setLineItemList(List<LineItem> lineItemList) {
		this.lineItemList = lineItemList;
	}
	/**
	 * @return the date
	 *//*
	public String getDate() {
		return date;
	}
	*//**
	 * @param date the date to set
	 *//*
	public void setDate(String date) {
		this.date = date;
	}*/
	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

}
