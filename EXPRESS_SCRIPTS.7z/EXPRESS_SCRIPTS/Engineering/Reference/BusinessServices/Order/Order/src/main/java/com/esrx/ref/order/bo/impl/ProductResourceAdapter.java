package com.esrx.ref.order.bo.impl;

import org.apache.commons.lang.StringUtils;

import com.esrx.ref.order.bo.impl.ExceptionStrategy;
import com.esrx.ref.order.bo.Price;
import com.esrx.ref.order.bo.ProductSummary;
import com.esrx.ref.product.GetProductRequest;
import com.esrx.ref.product.GetProductResponse;
import com.esrx.ref.product.jaxrs.ProductResource;
import com.express_scripts.inf.jersey.ResourceException;
import com.express_scripts.inf.types.InvalidRequest;

public class ProductResourceAdapter {
	
	private ProductResource productResource;
	private ExceptionStrategy exceptionStrategy;

	public ProductSummary getProductById(String productId, Long timeout) throws  InvalidRequest{
		ProductSummary productSummary = null;
		
		GetProductRequest productRequest = new GetProductRequest();
		productRequest.setProductId(productId);
		productRequest.setTimeout(timeout);
		try {
			GetProductResponse productResponse = productResource.getProduct(productRequest);
			productSummary = convertToProductSummary(productResponse);
		} catch (ResourceException e) {
			exceptionStrategy.handleResourceException(e);
		}
		return productSummary;
	}
	
	
	private ProductSummary convertToProductSummary(
			GetProductResponse productResponse) {
		ProductSummary productSummary = null;
		if(productResponse != null && productResponse.getProduct() != null){
			productSummary = new ProductSummary();
			productSummary.setImageId(productResponse.getProduct().getProductId());
			productSummary.setProductId(productResponse.getProduct().getProductId());
			productSummary.setProductName(productResponse.getProduct().getProductName());
			productSummary.setPrice(convertToPrice(productResponse.getProduct().getPrice()));
		}
		return productSummary;
	}


	private Price convertToPrice(com.esrx.ref.product.Price price) {
		Price price2 = null;
		if(price != null){
			price2 = new Price();
			price2.setAmount(price.getAmount());
			price2.setCurrency(StringUtils.equalsIgnoreCase("$", price.getCurrency()) ? "USD" : price.getCurrency());
			price2.setFormattedAmount(price2.getCurrency()+ " " +price.getAmount());
		}
		return price2;
	}

	/**
	 * @param productResource the productResource to set
	 */
	public void setProductResource(ProductResource productResource) {
		this.productResource = productResource;
	}

	public void setExceptionStrategy(ExceptionStrategy exceptionStrategy) {
		this.exceptionStrategy = exceptionStrategy;
	}
}
