package com.esrx.ref.order.bo.impl;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.esrx.ref.account.GetAddressResponse;
import com.esrx.ref.account.GetCreditCardRequest;
import com.esrx.ref.account.GetCreditCardResponse;
import com.esrx.ref.account.ws.AccountService;
import com.esrx.ref.account.ws.InvalidRequest;
import com.esrx.ref.account.ws.NotFound;
import com.esrx.ref.account.ws.ProcessFailed;
import com.esrx.ref.account.ws.ResourceUnavailable;
import com.esrx.ref.order.bo.Address;
import com.esrx.ref.order.bo.CreditCardSummary;

public class AccountServiceAdapter {

	private AccountService accountService;

	Logger logger = Logger.getLogger(AccountServiceAdapter.class);

	/**
	 * @param accountService
	 *            the accountService to set
	 */
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}

	public Address getAddressById(GetAddressRequest addressRequest) throws com.express_scripts.inf.types.InvalidRequest {
		Address addressResponse = null;
		if (StringUtils.isNotBlank(addressRequest.getAddressId())) {
			com.esrx.ref.account.GetAddressRequest getAddressRequest = new com.esrx.ref.account.GetAddressRequest();
			getAddressRequest.setAddressId(addressRequest.getAddressId());
			getAddressRequest.setTimeout(addressRequest.getTimeout());
			try {
				GetAddressResponse response = accountService
						.getAddress(getAddressRequest);
				addressResponse = convertToBoAddress(response);
			} catch (InvalidRequest e) {
				throw new com.express_scripts.inf.types.ProcessFailed(
						ErrorCodes.UNEXPECTED_EXCEPTION, ErrorMessages.UNEXPECTED_EXCEPTION,
						 null, null, e);
			} catch (NotFound e) {
				throw new com.express_scripts.inf.types.InvalidRequest(
						ErrorCodes.CARD_INFO_NOT_FOUND, ErrorMessages.CARD_INFO_NOT_FOUND,
						null, null, e);
			} catch (ResourceUnavailable e) {
				throw new com.express_scripts.inf.types.ResourceUnavailable(
						ErrorCodes.RESOURCE_UNAVAILABLE, ErrorMessages.TIMED_OUT,
						 null, null, e);
			} catch (ProcessFailed e) {
				throw new com.express_scripts.inf.types.ProcessFailed(
						ErrorCodes.UNEXPECTED_EXCEPTION, ErrorMessages.UNEXPECTED_EXCEPTION,
						 null, null, e);
			}
		}
		return addressResponse;
	}

	public CreditCardSummary getCreditCardById(String creditCardId,
			String accountId, Long checkTimeout) throws com.express_scripts.inf.types.InvalidRequest {
		CreditCardSummary cardSummary = null;
		if (StringUtils.isNotBlank(creditCardId)) {
			GetCreditCardRequest cardRequest = new GetCreditCardRequest();
			cardRequest.setAccountId(accountId);
			cardRequest.setCreditCardId(creditCardId);
			cardRequest.setTimeout(checkTimeout);
			try {
				GetCreditCardResponse cardResponse = accountService
						.getCreditCard(cardRequest);
				cardSummary = convertToCreditCardSummary(cardResponse);
			} catch (InvalidRequest e) {
				throw new com.express_scripts.inf.types.ProcessFailed(
						ErrorCodes.UNEXPECTED_EXCEPTION, ErrorMessages.UNEXPECTED_EXCEPTION,
						 null, null, e);
			} catch (NotFound e) {
				throw new com.express_scripts.inf.types.InvalidRequest(
						ErrorCodes.CREDITCARD_ID_IS_INVALID, ErrorMessages.CREDITCARD_ID_IS_INVALID,
						 null, null, e);
			} catch (ResourceUnavailable e) {
				throw new com.express_scripts.inf.types.ResourceUnavailable(
						ErrorCodes.RESOURCE_UNAVAILABLE, ErrorMessages.TIMED_OUT,
						 null, null, e);
			} catch (ProcessFailed e) {
				throw new com.express_scripts.inf.types.ProcessFailed(
						ErrorCodes.UNEXPECTED_EXCEPTION, ErrorMessages.UNEXPECTED_EXCEPTION,
						null, null, e);
			}
		}
		return cardSummary;
	}

	private static Address convertToBoAddress(GetAddressResponse response) {
		Address address2 = null;
		if (response != null && response.getAddress() != null) {
			address2 = new Address();
			address2.setAddressId(String.valueOf(response.getAddress()
					.getAddressId()));
			address2.setCity(response.getAddress().getCity());
			address2.setLine1(response.getAddress().getLine1());
			address2.setLine2(response.getAddress().getLine2());
			address2.setLine3(response.getAddress().getLine3());
			address2.setLine4(response.getAddress().getLine4());
			address2.setName(response.getAddress().getName());
			address2.setState(response.getAddress().getState());
			address2.setZip4(response.getAddress().getZip4());
			address2.setZip5(response.getAddress().getZip5());
		}
		return address2;
	}

	private CreditCardSummary convertToCreditCardSummary(
			GetCreditCardResponse cardResponse) {
		CreditCardSummary cardSummary = null;
		if (cardResponse != null && cardResponse.getCreditCard() != null) {
			cardSummary = new CreditCardSummary();
			cardSummary.setAlias(cardResponse.getCreditCard().getAlias());
			cardSummary.setCreditCardId(String.valueOf(cardResponse
					.getCreditCard().getCreditCardId()));
			if (cardResponse.getCreditCard().getBillingAddress() != null) {
				cardSummary.setBillingAddressId(cardResponse.getCreditCard()
						.getBillingAddress().getAddressId());
			}
		}
		return cardSummary;
	}

}
