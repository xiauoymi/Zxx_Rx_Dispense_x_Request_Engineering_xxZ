package com.esrx.ref.order.bo.impl;

import java.io.Serializable;

public class CreditCardRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7548498010831608217L;
	
	private String creditCardId;
	private String accountId;
	private Long timeout;
	/**
	 * @return the creditCardId
	 */
	public String getCreditCardId() {
		return creditCardId;
	}
	/**
	 * @param creditCardId the creditCardId to set
	 */
	public void setCreditCardId(String creditCardId) {
		this.creditCardId = creditCardId;
	}
	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountId;
	}
	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}
	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}

}
