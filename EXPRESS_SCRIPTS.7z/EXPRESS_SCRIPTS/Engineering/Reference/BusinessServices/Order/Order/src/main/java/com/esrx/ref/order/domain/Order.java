package com.esrx.ref.order.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ORDERS")
public class Order implements Serializable {

	private static final long serialVersionUID = 2933633418177358611L;
	
	private Integer orderId;
	private String accountId;
	private Status orderStatus;
	private String shippingAddressId;
	private String billingAddressId;
	private String creditCardId;
	private Date orderDate;
	private Set<LineItem> lineItems;
	/**
	 * @return the orderId
	 */
	@Id
	@GeneratedValue(generator="orderIdSeq")
	@SequenceGenerator(name="orderIdSeq", sequenceName="ORDER_ID_SEQ")
	@Column(name="ORDER_ID")
	public Integer getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the accountId
	 */
	@Column(name="ACCOUNT_ID")
	public String getAccountId() {
		return accountId;
	}
	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * @return the orderStatus
	 */
	@Column(name="ORDER_STATUS")
	@Enumerated(EnumType.ORDINAL)
	public Status getOrderStatus() {
		return orderStatus;
	}
	/**
	 * @param orderStatus the orderStatus to set
	 */
	public void setOrderStatus(Status orderStatus) {
		this.orderStatus = orderStatus;
	}
	/**
	 * @return the orderDate
	 */
	@Column(name="ORDER_DATE")
	public Date getOrderDate() {
		return orderDate;
	}
	/**
	 * @param orderDate the orderDate to set
	 */
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	@JoinColumn(name="ORDER_ID")
	public Set<LineItem> getLineItems() {
		return lineItems;
	}
	/**
	 * @param lineItems the lineItems to set
	 */
	public void setLineItems(Set<LineItem> lineItems) {
		this.lineItems = lineItems;
	}
	/**
	 * @return the shippingAddress
	 */
	@Column(name="SHIPPING_ADDRESS_ID")
	public String getShippingAddressId() {
		return shippingAddressId;
	}
	/**
	 * @param shippingAddress the shippingAddress to set
	 */
	public void setShippingAddressId(String shippingAddressId) {
		this.shippingAddressId = shippingAddressId;
	}
	/**
	 * @return the billingAddress
	 */
	@Column(name="BILLING_ADDRESS_ID")
	public String getBillingAddressId() {
		return billingAddressId;
	}
	/**
	 * @param billingAddress the billingAddress to set
	 */
	public void setBillingAddressId(String billingAddressId) {
		this.billingAddressId = billingAddressId;
	}
	/**
	 * @return the creditCard
	 */
	@Column(name="CREDIT_CARD_ID")
	public String getCreditCardId() {
		return creditCardId;
	}
	/**
	 * @param creditCard the creditCard to set
	 */
	public void setCreditCardId(String creditCardId) {
		this.creditCardId = creditCardId;
	}
}
