package com.esrx.ref.order.domain;


public enum Status {
	REQUESTED, 
	PROCESSING, 
	CANCELLED,
	SHIPPED, 
	DELIVERED, 
	COMPLETED;

}
