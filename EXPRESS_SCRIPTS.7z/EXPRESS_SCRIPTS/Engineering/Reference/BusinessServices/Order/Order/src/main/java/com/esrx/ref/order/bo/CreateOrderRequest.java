package com.esrx.ref.order.bo;

import java.io.Serializable;

public class CreateOrderRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3179337819772674625L;
	private Order order;
	private Long timeout;
	/**
	 * @return the order
	 */
	public Order getOrder() {
		return order;
	}
	/**
	 * @param order the order to set
	 */
	public void setOrder(Order order) {
		this.order = order;
	}
	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}
	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}

}
