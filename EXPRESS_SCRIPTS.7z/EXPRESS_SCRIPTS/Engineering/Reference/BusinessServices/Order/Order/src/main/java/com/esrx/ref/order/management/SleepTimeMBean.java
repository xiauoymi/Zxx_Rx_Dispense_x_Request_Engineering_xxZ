package com.esrx.ref.order.management;

public interface SleepTimeMBean {
	long getSleepTimeMS();
	void setSleepTimeMS(long sleepTimeMS);
}
