package com.esrx.ref.order.bo;

import java.io.Serializable;
import java.util.List;

public class FindOrderResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -834285362885585746L;
	private List<OrderSummary> orderSummaryList;
	private int totalCount;
	/**
	 * @return the orderSummaryList
	 */
	public List<OrderSummary> getOrderSummaryList() {
		return orderSummaryList;
	}
	/**
	 * @param orderSummaryList the orderSummaryList to set
	 */
	public void setOrderSummaryList(List<OrderSummary> orderSummaryList) {
		this.orderSummaryList = orderSummaryList;
	}
	/**
	 * @return the totalCount
	 */
	public int getTotalCount() {
		return totalCount;
	}
	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

}
