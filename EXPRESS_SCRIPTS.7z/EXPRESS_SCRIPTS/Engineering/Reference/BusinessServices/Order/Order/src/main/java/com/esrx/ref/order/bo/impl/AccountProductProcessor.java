package com.esrx.ref.order.bo.impl;

import com.express_scripts.inf.concurrent.Processor;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.ProcessFailed;

public class AccountProductProcessor implements Processor {
	
	private AccountServiceAdapter accountServiceAdapter;
	
	private ProductResourceAdapter productResourceAdapter;
	
	@Override
	public Object process(Object request) {
		if(request instanceof GetAddressRequest){
			return getAddress((GetAddressRequest) request);
		}else if(request instanceof CreditCardRequest){
			return getCreditCard((CreditCardRequest) request);
		}else if(request instanceof GetPurchasePriceRequest){
			return getPurchasePrice((GetPurchasePriceRequest) request);
		}else{
			throw new ProcessFailed(ErrorMessages.UNEXPECTED_REQUEST, ErrorCodes.UNEXPECTED_REQUEST, null, null);
		}
	}
	
	private Object getAddress(GetAddressRequest addressRequest){
		try {
			return accountServiceAdapter.getAddressById(addressRequest);
		} catch (InvalidRequest e) {
			return e;
		}
	}
	
	private Object getCreditCard(CreditCardRequest cardRequest){
		try {
			return accountServiceAdapter.getCreditCardById(cardRequest.getCreditCardId(), cardRequest.getAccountId(), cardRequest.getTimeout());
		} catch (InvalidRequest e) {
			return e;
		}
	}
	
	private Object getPurchasePrice(GetPurchasePriceRequest priceRequest){
		try {
			return productResourceAdapter.getProductById(priceRequest.getProductId(), priceRequest.getTimeout());
		} catch (InvalidRequest e) {
			return e;
		}
	}

	/**
	 * @param accountServiceHelper the accountServiceHelper to set
	 */
	public void setAccountServiceAdapter(AccountServiceAdapter accountServiceAdapter) {
		this.accountServiceAdapter = accountServiceAdapter;
	}

	/**
	 * @param productResourceHelper the productResourceHelper to set
	 */
	public void setProductResourceAdapter(ProductResourceAdapter productResourceAdapter) {
		this.productResourceAdapter = productResourceAdapter;
	}

}
