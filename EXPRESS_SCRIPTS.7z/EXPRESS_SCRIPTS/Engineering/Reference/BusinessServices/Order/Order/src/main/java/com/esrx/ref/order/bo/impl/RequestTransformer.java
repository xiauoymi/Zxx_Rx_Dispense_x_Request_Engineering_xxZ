package com.esrx.ref.order.bo.impl;

import com.esrx.ref.order.bo.LineItem;


public class RequestTransformer {

	public static GetAddressRequest buildGetAddressRequest(
			String addressId, Long timeout) {
		GetAddressRequest addressRequest = new  GetAddressRequest();
		addressRequest.setAddressId(addressId);
		addressRequest.setTimeout(timeout);
		return addressRequest;
	}

	public static CreditCardRequest buildGetCreditCardRequest(
			String creditCardId, String accountId, Long timeout) {
		CreditCardRequest creditCardRequest = new CreditCardRequest();
		creditCardRequest.setAccountId(accountId);
		creditCardRequest.setCreditCardId(creditCardId);
		creditCardRequest.setTimeout(timeout);
		return creditCardRequest;
	}

	public static GetPurchasePriceRequest buildGetPurchasePriceReqest(
			LineItem lineItem, Long checkTimeout) {
		if(lineItem == null){
			return null;
		}
		GetPurchasePriceRequest getPurchasePriceRequest = new GetPurchasePriceRequest();
		getPurchasePriceRequest.setProductId(lineItem.getProductSummary().getProductId());
		getPurchasePriceRequest.setTimeout(checkTimeout);
		return getPurchasePriceRequest;
	}

}
