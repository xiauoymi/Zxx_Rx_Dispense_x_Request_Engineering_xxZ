package com.esrx.ref.order.bo;

import java.io.Serializable;

public class CreateOrderResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -15248506107098256L;
	private String orderId;
	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

}
