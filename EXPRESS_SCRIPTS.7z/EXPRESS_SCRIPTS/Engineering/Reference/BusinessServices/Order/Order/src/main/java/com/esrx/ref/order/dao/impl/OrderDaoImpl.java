package com.esrx.ref.order.dao.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.esrx.ref.order.dao.OrderDao;
import com.esrx.ref.order.domain.FindOrdersResponse;
import com.esrx.ref.order.domain.Order;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.SortOption;

public class OrderDaoImpl extends GenericDaoHibernate<Order> implements OrderDao {

	public OrderDaoImpl(SessionFactory sf) {
		super(Order.class, sf);
	}

	@Override
	public FindOrdersResponse findOrders(String accountId, int count, int offset,
			Long timeout, List<SortOption> sortOptions) throws InvalidRequest {
		Criteria criteria = getSession().createCriteria(Order.class);
		criteria.setTimeout(timeout.intValue());
		criteria.add(Restrictions.eq("accountId", accountId));
		if(offset > 0){
			criteria.setFirstResult(offset);
		}
		if(count > 0){
			criteria.setMaxResults(count);
		}
		
		if (!CollectionUtils.isEmpty(sortOptions)) {
			for (SortOption sortOption : sortOptions) {
				String sortBy = sortOption.getFieldName();
				String order = sortOption.getSortOrder().value();
				if (StringUtils.equalsIgnoreCase(order, "asc")) {
					criteria.addOrder(org.hibernate.criterion.Order.asc(sortBy));
				} else {
					criteria.addOrder(org.hibernate.criterion.Order
							.desc(sortBy));
				}
			}
		} else {
			criteria.addOrder(org.hibernate.criterion.Order.asc("accountId"));
		}
		@SuppressWarnings("unchecked")
		List<Order> orders = criteria.list();
		long rowCount = getTotalRows(accountId, timeout);
		FindOrdersResponse findOrdersResponse = new FindOrdersResponse();
		findOrdersResponse.setOrders(orders);
		findOrdersResponse.setTotalCount(rowCount);
		return findOrdersResponse;
	}
	
	private Long getTotalRows(String accountId, Long checkTimeout) {
		Criteria criteria = getSession().createCriteria(Order.class);
		Long timeRemaining = ProcessTimer.getTimeRemaining(checkTimeout);
		criteria.setTimeout(timeRemaining.intValue());
		criteria.setProjection(Projections.rowCount());
		criteria.add(Restrictions.eq("accountId", accountId));
		return (Long) criteria.list().get(0);
	}
}
