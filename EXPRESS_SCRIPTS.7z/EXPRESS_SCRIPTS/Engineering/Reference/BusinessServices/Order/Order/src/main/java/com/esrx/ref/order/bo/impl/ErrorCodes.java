package com.esrx.ref.order.bo.impl;

public class ErrorCodes {

	public static final String RESOURCE_UNAVAILABLE = "RESOURCE_UNAVAILABLE";
	public static final String REQUEST_REQUIRED = "REQUEST_REQUIRED";
	public static final String UNEXPECTED_EXCEPTION = "UNEXPECTED_EXCEPTION";
	public static final String ORDER_REQUIRED = "ORDER_REQUIRED";
	public static final String ACCOUNT_ID_REQUIRED = "ACCOUNT_ID_REQUIRED";
	public static final String ACCOUNT_ID_INVALID = "ACCOUNT_ID_INVALID";
	public static final String ORDER_DATE_REQUIRED = "ORDER_DATE_REQUIRED";
	public static final String PRICE_REQUIRED = "PRICE_REQUIRED";
	public static final String CREDITCARD_REQUIRED = "CREDITCARD_REQUIRED";
	public static final String BILLING_ADDRESS_REQUIRED = "BILLING_ADDRESS_REQUIRED";
	public static final String SHIPPING_ADDRESS_REQUIRED = "SHIPPING_ADDRESS_REQUIRED";
	public static final String LINE_ITEMS_REQUIRED = "LINE_ITEMS_REQUIRED";
	public static final String AMOUNT_INVALID = "AMOUNT_INVALID";
	public static final String CITY_EMPTY = "CITY_EMPTY";
	public static final String LINE_1_EMPTY = "LINE_1_EMPTY";
	public static final String STATE_EMPTY = "STATE_EMPTY";
	public static final String ZIP5_EMPTY = "ZIP5_EMPTY";
	public static final String ZIP5_LENGTH_INCORRECT = "ZIP5_LENGTH_INCORRECT";
	public static final String ZIP4_LENGTH_INCORRECT = "ZIP4_LENGTH_INCORRECT";
	public static final String ORDER_ID_REQUIRED = "ORDER_ID_REQUIRED";
	public static final String ORDER_STATUS_REQUIRED = "ORDER_STATUS_REQUIRED";
	public static final String ORDER_ID_INVALID = "ORDER_ID_INVALID";
	public static final String DATE_INVALID = "DATE_INVALID";
	public static final String NOT_FOUND = "NOT_FOUND";
	public static final String UNEXPECTED_REQUEST = "UNEXPECTED_REQUEST";
	public static final String ORDER_NOT_FOUND = "ORDER_NOT_FOUND";
	public static final String UNABLE_TO_SAVE_ADDRESS = "UNABLE_TO_SAVE_ADDRESS";
	public static final String SORT_OPTIONS_INVALID = "SORT_OPTIONS_INVALID";
	public static final String ADDRESS_ID_REQUIRED = "ADDRESS_ID_REQUIRED";
	public static final String CREDITCARD_ID_REQUIRED = "CREDITCARD_ID_REQUIRED";
	public static final String CARD_INFO_NOT_FOUND = "CARD_INFO_NOT_FOUND";
	public static final String STATUS_NOT_VALID = "STATUS_NOT_VALID";
	public static final String ORDER_CANCELLED = "ORDER_CANCELLED";
	public static final String CREDITCARD_ID_IS_INVALID = "CREDITCARD_ID_IS_INVALID";

}
