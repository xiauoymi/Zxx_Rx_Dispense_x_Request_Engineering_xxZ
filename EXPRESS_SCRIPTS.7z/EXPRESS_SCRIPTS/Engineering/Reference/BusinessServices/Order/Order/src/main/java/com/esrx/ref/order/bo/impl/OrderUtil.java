package com.esrx.ref.order.bo.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.express_scripts.inf.types.ProcessFailed;

public class OrderUtil {

	public static String parseDate(Date dateToChange) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				ErrorMessages.DATE_FORMAT);
		dateFormat.setLenient(false);
		String date = StringUtils.EMPTY;
		
		try {
			date = dateFormat.format(dateToChange);
		} catch (Exception e) {
			throw new ProcessFailed(ErrorMessages.UNEXPECTED_EXCEPTION, ErrorCodes.UNEXPECTED_EXCEPTION, null, null);
		}
		return date;
	}

}
