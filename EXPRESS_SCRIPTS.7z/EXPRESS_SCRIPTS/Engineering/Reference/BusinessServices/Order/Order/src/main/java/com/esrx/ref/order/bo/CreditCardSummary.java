package com.esrx.ref.order.bo;

import java.io.Serializable;

public class CreditCardSummary implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4266709385120580551L;
	private String creditCardId;
	private String alias;
	private String billingAddressId;
	/**
	 * @return the creditCardId
	 */
	public String getCreditCardId() {
		return creditCardId;
	}
	/**
	 * @param creditCardId the creditCardId to set
	 */
	public void setCreditCardId(String creditCardId) {
		this.creditCardId = creditCardId;
	}
	/**
	 * @return the alias
	 */
	public String getAlias() {
		return alias;
	}
	/**
	 * @param alias the alias to set
	 */
	public void setAlias(String alias) {
		this.alias = alias;
	}
	/**
	 * @return the billingAddressId
	 */
	public String getBillingAddressId() {
		return billingAddressId;
	}
	/**
	 * @param billingAddressId the billingAddressId to set
	 */
	public void setBillingAddressId(String billingAddressId) {
		this.billingAddressId = billingAddressId;
	}


}
