package com.esrx.ref.order.bo;

import java.io.Serializable;

public class GetOrderRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8742831319471651235L;
	private String orderId;
	private Long timeout;
	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}
	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}

}
