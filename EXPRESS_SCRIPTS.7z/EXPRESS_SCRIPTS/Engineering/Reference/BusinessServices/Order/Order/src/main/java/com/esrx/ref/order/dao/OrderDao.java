package com.esrx.ref.order.dao;

import java.util.List;

import com.esrx.ref.order.domain.FindOrdersResponse;
import com.esrx.ref.order.domain.Order;
import com.express_scripts.inf.dao.GenericDao;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.SortOption;

public interface OrderDao extends GenericDao<Order> {

	FindOrdersResponse findOrders(String accountId, int count, int offset,
			Long checkTimeout, List<SortOption> sortOptions) throws InvalidRequest;
	
}
