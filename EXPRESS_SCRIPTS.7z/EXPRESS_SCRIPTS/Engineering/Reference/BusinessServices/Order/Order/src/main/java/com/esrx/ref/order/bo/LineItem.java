package com.esrx.ref.order.bo;

import java.io.Serializable;

public class LineItem implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5793917774539203061L;
	private ProductSummary productSummary;
	private int quantity;
	private Price purchasePrice;

	/**
	 * @return the productSummary
	 */
	public ProductSummary getProductSummary() {
		return productSummary;
	}

	/**
	 * @param productSummary
	 *            the productSummary to set
	 */
	public void setProductSummary(ProductSummary productSummary) {
		this.productSummary = productSummary;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity
	 *            the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the purchasePrice
	 */
	public Price getPurchasePrice() {
		return purchasePrice;
	}

	/**
	 * @param purchasePrice the purchasePrice to set
	 */
	public void setPurchasePrice(Price purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

}
