package com.esrx.ref.order.bo.impl;

import java.io.Serializable;

public class GetAddressRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 418332977524441685L;
	
	private String addressId;
	private Long timeout;
	/**
	 * @return the addressId
	 */
	public String getAddressId() {
		return addressId;
	}
	/**
	 * @param addressId the addressId to set
	 */
	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}
	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}
	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}

}
