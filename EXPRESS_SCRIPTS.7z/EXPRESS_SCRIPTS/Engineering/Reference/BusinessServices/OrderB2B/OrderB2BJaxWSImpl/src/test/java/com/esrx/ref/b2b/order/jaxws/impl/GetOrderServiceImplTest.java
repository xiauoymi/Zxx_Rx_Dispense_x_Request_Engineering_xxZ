package com.esrx.ref.b2b.order.jaxws.impl;

import static org.easymock.EasyMock.replay;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.esrx.ref.b2b.order.GetOrderStatusRequest;
import com.esrx.ref.b2b.order.bo.GetOrderStatusResponse;
import com.esrx.ref.b2b.order.bo.Order;
import com.esrx.ref.b2b.order.bo.OrderBo;
import com.esrx.ref.b2b.order.bo.OrderStatus;
import com.esrx.ref.b2b.order.ws.ProcessFailed;
import com.esrx.ref.b2b.order.ws.ResourceUnavailable;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;

public class GetOrderServiceImplTest
{
	OrderServiceImpl orderServiceImpl = new OrderServiceImpl();
	OrderBo orderBo =  EasyMock.createMock(OrderBo.class);
	ObjectTransformer transformer =  new ObjectTransformer();
	private static final String TEST_ORDER_ID =  "ORDER_ID";
	Util wsUtil =  new Util();
	
	@Before
	public void setup()
	{
		EasyMock.reset(orderBo);
		orderServiceImpl.setOrderBo(orderBo);
		orderServiceImpl.setObjectTransformer(transformer);
	}
	
	@Test
	public void getOrderStatus() throws InvalidRequest, NotFound, com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed, ResourceUnavailable, com.esrx.ref.b2b.order.ws.NotFound
	{
		
		GetOrderStatusResponse boResponse =  new GetOrderStatusResponse();
		Order boOrder =  new Order();
		boOrder.setOrderId(TEST_ORDER_ID);
		boOrder.setStatus(OrderStatus.COMPLETED);
		boResponse.setOrder(boOrder);
		
		//Mock
		EasyMock.expect(orderBo.getOrderStatus(EasyMock.anyObject(com.esrx.ref.b2b.order.bo.GetOrderStatusRequest.class))).andReturn(boResponse);
		
		GetOrderStatusRequest wsRequest =  createValidGetOrderRequest();
		replay(orderBo);
		ProcessTimer.startTimer();
		com.esrx.ref.b2b.order.GetOrderStatusResponse wsGetOrderResponse =  orderServiceImpl.getOrderStatus(wsRequest);
		
		EasyMock.verify(orderBo);
		
		assertNotNull( wsGetOrderResponse);
		assertNotNull( wsGetOrderResponse.getOrder());
		assertEquals(wsGetOrderResponse.getOrder().getOrderId(), TEST_ORDER_ID);
		
		
	}
	@Test(expected=com.esrx.ref.b2b.order.ws.InvalidRequest.class)
	public void getOrderStatusNullRequest() throws InvalidRequest, NotFound, com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed, ResourceUnavailable, com.esrx.ref.b2b.order.ws.NotFound
	{
		
		GetOrderStatusResponse boResponse =  new GetOrderStatusResponse();
		Order boOrder =  new Order();
		boOrder.setOrderId(TEST_ORDER_ID);
		boOrder.setStatus(OrderStatus.COMPLETED);
		boResponse.setOrder(boOrder);
		
		//Mock
		EasyMock.expect(orderBo.getOrderStatus(EasyMock.anyObject(com.esrx.ref.b2b.order.bo.GetOrderStatusRequest.class))).andReturn(boResponse);
		replay(orderBo);
		ProcessTimer.startTimer();
		com.esrx.ref.b2b.order.GetOrderStatusResponse wsGetOrderResponse =  orderServiceImpl.getOrderStatus(null);
		EasyMock.verify(orderBo);
	}
	@Test(expected=com.esrx.ref.b2b.order.ws.InvalidRequest.class)
	public void getOrderStatusInvalidRequest() throws InvalidRequest, NotFound, com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed, ResourceUnavailable, com.esrx.ref.b2b.order.ws.NotFound
	{
		GetOrderStatusRequest wsRequest =  createValidGetOrderRequest();
		GetOrderStatusResponse boResponse =  new GetOrderStatusResponse();
		Order boOrder =  new Order();
		boOrder.setOrderId(wsRequest.getOrderId());
		boOrder.setStatus(OrderStatus.COMPLETED);
		boResponse.setOrder(boOrder);
		
		InvalidRequest invalidRequest = new InvalidRequest();
		//Mock
		EasyMock.expect(orderBo.getOrderStatus(EasyMock.anyObject(com.esrx.ref.b2b.order.bo.GetOrderStatusRequest.class))).andThrow(invalidRequest);
		
		
		replay(orderBo);
		ProcessTimer.startTimer();
		com.esrx.ref.b2b.order.GetOrderStatusResponse wsGetOrderResponse =  orderServiceImpl.getOrderStatus(wsRequest);
		
		EasyMock.verify(orderBo);
		
	}
	@Test(expected=com.esrx.ref.b2b.order.ws.InvalidRequest.class)
	public void getOrderStatusInvalidStatus() throws InvalidRequest, NotFound, com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed, ResourceUnavailable, com.esrx.ref.b2b.order.ws.NotFound
	{
		
		GetOrderStatusRequest wsRequest =  createValidGetOrderRequest();
		GetOrderStatusResponse boResponse =  new GetOrderStatusResponse();
		Order boOrder =  new Order();
		boOrder.setOrderId(wsRequest.getOrderId());
		boOrder.setStatus(null);
		boResponse.setOrder(boOrder);
		
		InvalidRequest invalidRequest = new InvalidRequest();
		//Mock
		EasyMock.expect(orderBo.getOrderStatus(EasyMock.anyObject(com.esrx.ref.b2b.order.bo.GetOrderStatusRequest.class))).andThrow(invalidRequest);
		
		replay(orderBo);
		ProcessTimer.startTimer();
		com.esrx.ref.b2b.order.GetOrderStatusResponse wsGetOrderResponse =  orderServiceImpl.getOrderStatus(wsRequest);
		
		EasyMock.verify(orderBo);
		
	}
	@Test(expected=com.esrx.ref.b2b.order.ws.ProcessFailed.class)
	public void getOrderStatusThrowProcessFailed() throws InvalidRequest, NotFound, com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed, ResourceUnavailable, com.esrx.ref.b2b.order.ws.NotFound
	{
		
		GetOrderStatusRequest wsRequest =  createValidGetOrderRequest();
		GetOrderStatusResponse boResponse =  new GetOrderStatusResponse();
		Order boOrder =  new Order();
		boOrder.setOrderId(wsRequest.getOrderId());
		boOrder.setStatus(null);
		boResponse.setOrder(boOrder);
		
		com.express_scripts.inf.types.ProcessFailed processFailed =  new com.express_scripts.inf.types.ProcessFailed();
		//Mock
		EasyMock.expect(orderBo.getOrderStatus(EasyMock.anyObject(com.esrx.ref.b2b.order.bo.GetOrderStatusRequest.class))).andThrow(processFailed);
		
		replay(orderBo);
		ProcessTimer.startTimer();
		com.esrx.ref.b2b.order.GetOrderStatusResponse wsGetOrderResponse =  orderServiceImpl.getOrderStatus(wsRequest);
		EasyMock.verify(orderBo);
	}
	@Test(expected=com.esrx.ref.b2b.order.ws.NotFound.class)
	public void getOrderStatusThrowNotFound() throws InvalidRequest, NotFound, com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed, ResourceUnavailable, com.esrx.ref.b2b.order.ws.NotFound
	{
		
		GetOrderStatusRequest wsRequest =  createValidGetOrderRequest();
		GetOrderStatusResponse boResponse =  new GetOrderStatusResponse();
		Order boOrder =  new Order();
		boOrder.setOrderId(wsRequest.getOrderId());
		boOrder.setStatus(null);
		boResponse.setOrder(boOrder);
		
		com.express_scripts.inf.types.NotFound notfound = new com.express_scripts.inf.types.NotFound(
				"Order could not be found.", "NOT_FOUND", null,
				null);
		//Mock
		EasyMock.expect(orderBo.getOrderStatus(EasyMock.anyObject(com.esrx.ref.b2b.order.bo.GetOrderStatusRequest.class))).andThrow(notfound);
		
		replay(orderBo);
		ProcessTimer.startTimer();
		com.esrx.ref.b2b.order.GetOrderStatusResponse wsGetOrderResponse =  orderServiceImpl.getOrderStatus(wsRequest);
		EasyMock.verify(orderBo);
	}
	@Test(expected=com.esrx.ref.b2b.order.ws.ResourceUnavailable.class)
	public void getOrderStatusThrowProcessTimeout() throws InvalidRequest, NotFound, com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed, ResourceUnavailable, com.esrx.ref.b2b.order.ws.NotFound
	{
		
		GetOrderStatusRequest wsRequest =  createValidGetOrderRequest();
		GetOrderStatusResponse boResponse =  new GetOrderStatusResponse();
		Order boOrder =  new Order();
		boOrder.setOrderId(wsRequest.getOrderId());
		boOrder.setStatus(null);
		boResponse.setOrder(boOrder);
		
		ProcessTimeoutException processTimeoutException =  new ProcessTimeoutException();
		//Mock
		EasyMock.expect(orderBo.getOrderStatus(EasyMock.anyObject(com.esrx.ref.b2b.order.bo.GetOrderStatusRequest.class))).andThrow(processTimeoutException);
		
		replay(orderBo);
		ProcessTimer.startTimer();
		com.esrx.ref.b2b.order.GetOrderStatusResponse wsGetOrderResponse =  orderServiceImpl.getOrderStatus(wsRequest);
		EasyMock.verify(orderBo);
	}
	
	@Test(expected=ResourceUnavailable.class)
	public void getOrderStatusTimeout() throws InvalidRequest, NotFound, com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed, ResourceUnavailable, com.esrx.ref.b2b.order.ws.NotFound
	{
		
		
		GetOrderStatusResponse boResponse =  new GetOrderStatusResponse();
		Order boOrder =  new Order();
		boOrder.setOrderId(TEST_ORDER_ID);
		boOrder.setStatus(OrderStatus.COMPLETED);
		boResponse.setOrder(boOrder);
		
		com.express_scripts.inf.types.ResourceUnavailable resourceUnavailable = new com.express_scripts.inf.types.ResourceUnavailable();
		//Mock
		EasyMock.expect(orderBo.getOrderStatus(EasyMock.anyObject(com.esrx.ref.b2b.order.bo.GetOrderStatusRequest.class))).andThrow(resourceUnavailable);
		
		GetOrderStatusRequest wsRequest =  createValidGetOrderRequest();
		replay(orderBo);
		ProcessTimer.startTimer();
		com.esrx.ref.b2b.order.GetOrderStatusResponse wsGetOrderResponse =  orderServiceImpl.getOrderStatus(wsRequest);
		EasyMock.verify(orderBo);
		
	}
	private GetOrderStatusRequest createValidGetOrderRequest() {
		GetOrderStatusRequest wsRequest =  new GetOrderStatusRequest();
		wsRequest.setOrderId(TEST_ORDER_ID);
		wsRequest.setTimeout(11000L);
		return wsRequest;
	}
}
