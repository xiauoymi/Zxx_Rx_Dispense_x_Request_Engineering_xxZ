package com.esrx.ref.b2b.order.jaxws.impl;

import static org.easymock.EasyMock.replay;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.esrx.ref.b2b.order.ArrayOfOrder;
import com.esrx.ref.b2b.order.UpdateOrderStatusRequest;
import com.esrx.ref.b2b.order.bo.OrderBo;
import com.esrx.ref.b2b.order.ws.ProcessFailed;
import com.esrx.ref.b2b.order.ws.ResourceUnavailable;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;

public class UpdateOrderServiceImplTest {
	OrderServiceImpl orderServiceImpl = new OrderServiceImpl();
	OrderBo orderBo = EasyMock.createMock(OrderBo.class);
	ObjectTransformer transformer = new ObjectTransformer();
	private Long TIMEOUT = 11000L;
	Util wsUtil = new Util();

	@Before
	public void setup() {
		EasyMock.reset(orderBo);
		orderServiceImpl.setOrderBo(orderBo);
		orderServiceImpl.setObjectTransformer(transformer);
	}

	@Test
	public void updateOrderStatus() throws InvalidRequest,
			com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed,
			ResourceUnavailable {
		String TEST_ORDER_ID_1 = "ORDER_1";
		String TEST_ORDER_ID_2 = "ORDER_2";

		ArrayOfOrder arrayOfOrder = new ArrayOfOrder();
		com.esrx.ref.b2b.order.Order order1 = new com.esrx.ref.b2b.order.Order();
		com.esrx.ref.b2b.order.Order order2 = new com.esrx.ref.b2b.order.Order();

		order1.setOrderId(TEST_ORDER_ID_1);
		order1.setStatus(com.esrx.ref.b2b.order.OrderStatus.DELIVERED);
		arrayOfOrder.getOrderList().add(order1);

		order2.setOrderId(TEST_ORDER_ID_2);
		order2.setStatus(com.esrx.ref.b2b.order.OrderStatus.PROCESSING);
		arrayOfOrder.getOrderList().add(order2);

		UpdateOrderStatusRequest updateOrderStatusRequest = new UpdateOrderStatusRequest();
		updateOrderStatusRequest.setOrderList(arrayOfOrder);


		// Mock
		
				orderBo.updateOrder(EasyMock
						.anyObject(com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest.class));
						EasyMock.expectLastCall();
		updateOrderStatusRequest.setTimeout(TIMEOUT);
		replay(orderBo);
		ProcessTimer.startTimer();

		orderServiceImpl.updateOrderStatus(updateOrderStatusRequest);
	}

	@Test(expected = com.esrx.ref.b2b.order.ws.InvalidRequest.class)
	public void updateOrderStatusNoOrderList() throws InvalidRequest,
			com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed,
			ResourceUnavailable {
		UpdateOrderStatusRequest updateOrderStatusRequest = new UpdateOrderStatusRequest();
		updateOrderStatusRequest.setOrderList(null);

		orderBo.updateOrder(EasyMock
				.anyObject(com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest.class));
				EasyMock.expectLastCall();

		updateOrderStatusRequest.setTimeout(TIMEOUT);
		replay(orderBo);
		ProcessTimer.startTimer();

		orderServiceImpl.updateOrderStatus(updateOrderStatusRequest);
	}

	@Test(expected = com.esrx.ref.b2b.order.ws.InvalidRequest.class)
	public void updateOrderStatusNullRequest() throws InvalidRequest,
			com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed,
			ResourceUnavailable {
		orderBo.updateOrder(EasyMock
				.anyObject(com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest.class));
				EasyMock.expectLastCall();

		replay(orderBo);
		ProcessTimer.startTimer();

		orderServiceImpl.updateOrderStatus(null);
	}

	@Test(expected = com.esrx.ref.b2b.order.ws.InvalidRequest.class)
	public void updateOrderStatusInvalidOrderList() throws InvalidRequest,
			com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed,
			ResourceUnavailable {
		ArrayOfOrder arrayOfOrder = new ArrayOfOrder();
		UpdateOrderStatusRequest updateOrderStatusRequest = new UpdateOrderStatusRequest();
		updateOrderStatusRequest.setOrderList(arrayOfOrder);

		InvalidRequest invalidRequest = new InvalidRequest();

		orderBo.updateOrder(EasyMock
				.anyObject(com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest.class));
				EasyMock.expectLastCall().andThrow(invalidRequest);

		updateOrderStatusRequest.setTimeout(TIMEOUT);
		replay(orderBo);
		ProcessTimer.startTimer();

		orderServiceImpl.updateOrderStatus(updateOrderStatusRequest);
	}

	@Test(expected = com.esrx.ref.b2b.order.ws.ProcessFailed.class)
	public void updateOrderStatusThrowProcessFailed() throws InvalidRequest,
			com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed,
			ResourceUnavailable {
		ArrayOfOrder arrayOfOrder = new ArrayOfOrder();
		UpdateOrderStatusRequest updateOrderStatusRequest = new UpdateOrderStatusRequest();
		updateOrderStatusRequest.setOrderList(arrayOfOrder);

		com.express_scripts.inf.types.ProcessFailed processFailed = new com.express_scripts.inf.types.ProcessFailed();

		// Mock
	
				orderBo.updateOrder(EasyMock
						.anyObject(com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest.class));
					EasyMock.expectLastCall().andThrow(processFailed);

		updateOrderStatusRequest.setTimeout(TIMEOUT);
		replay(orderBo);
		ProcessTimer.startTimer();
		orderServiceImpl.updateOrderStatus(updateOrderStatusRequest);
	}

	@Test(expected = com.esrx.ref.b2b.order.ws.ResourceUnavailable.class)
	public void updateOrderStatusThrowResourceTimeout() throws InvalidRequest,
			com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed,
			ResourceUnavailable {
		ArrayOfOrder arrayOfOrder = new ArrayOfOrder();
		UpdateOrderStatusRequest updateOrderStatusRequest = new UpdateOrderStatusRequest();
		updateOrderStatusRequest.setOrderList(arrayOfOrder);

		com.express_scripts.inf.types.ResourceUnavailable resourceUnavailable = new com.express_scripts.inf.types.ResourceUnavailable();

		// Mock
		
				orderBo.updateOrder(EasyMock
						.anyObject(com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest.class));
				EasyMock.expectLastCall().andThrow(resourceUnavailable);

		updateOrderStatusRequest.setTimeout(TIMEOUT);
		replay(orderBo);
		ProcessTimer.startTimer();
		orderServiceImpl.updateOrderStatus(updateOrderStatusRequest);
	}

	@Test(expected = com.esrx.ref.b2b.order.ws.ResourceUnavailable.class)
	public void updateOrderStatusThrowProcessTimedout() throws InvalidRequest,
			com.esrx.ref.b2b.order.ws.InvalidRequest, ProcessFailed,
			ResourceUnavailable {

		ArrayOfOrder arrayOfOrder = new ArrayOfOrder();

		UpdateOrderStatusRequest updateOrderStatusRequest = new UpdateOrderStatusRequest();
		updateOrderStatusRequest.setOrderList(arrayOfOrder);

		ProcessTimeoutException processTimeoutException = new ProcessTimeoutException();

		// Mock
				orderBo.updateOrder(EasyMock
						.anyObject(com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest.class));
				EasyMock.expectLastCall().andThrow(processTimeoutException);

		updateOrderStatusRequest.setTimeout(TIMEOUT);
		replay(orderBo);
		ProcessTimer.startTimer();
		orderServiceImpl.updateOrderStatus(updateOrderStatusRequest);
	}

}
