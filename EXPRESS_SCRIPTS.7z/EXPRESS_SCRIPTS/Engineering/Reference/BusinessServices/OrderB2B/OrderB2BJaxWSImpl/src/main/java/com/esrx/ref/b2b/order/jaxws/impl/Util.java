package com.esrx.ref.b2b.order.jaxws.impl;

import java.util.UUID;

import com.esrx.ref.b2b.order.ws.InvalidRequest;
import com.esrx.ref.b2b.order.ws.NotFound;
import com.esrx.ref.b2b.order.ws.ProcessFailed;
import com.esrx.ref.b2b.order.ws.ResourceUnavailable;

/**
 * @author p081095
 */
public class Util {

	

	private static final String ERR_CODE_UNEXPECTED_ERROR = "UNEXPECTED_ERROR";
	private static final String ERR_CODE_RESOURCE_UNAVAILABLE = "RESOURCE_UNAVAILABLE";
	private static final String MSG_UNEXPECTED_ERROR = "Unexpected error.";
	private static final String MSG_TIMED_OUT = "Timed out while getting response.";
	/**
	 * Create WS InvalidRequest from the INF-Exception
	 * @param message
	 * @param code
	 * @param id
	 * @param data
	 * @return
	 */
	public static InvalidRequest buildInvalidRequest(String code, String message,
			String id, String data) {
		com.esrx.ref.b2b.order.InvalidRequest invalidRequest = new com.esrx.ref.b2b.order.InvalidRequest();
		invalidRequest.setCode(code);
		// TODO : Define strategy for data in exceptions.
		/*
		 * if(StringUtils.isNotBlank(data)) invalidRequest.setData(data);
		 */
		if(id == null) {
			id = UUID.randomUUID().toString();
		}
		invalidRequest.setId(id);
		invalidRequest.setMessage(message);
		return new InvalidRequest(message, invalidRequest);
	}
	/**
	 * Build WS NotFound exception from INF-Exception
	 * @param message
	 * @param code
	 * @param id
	 * @param data
	 * @return
	 */
	public static NotFound buildNotFound(String code, String message,
			String id, String data) {
		com.esrx.ref.b2b.order.NotFound notFound = new com.esrx.ref.b2b.order.NotFound();
		notFound.setCode(code);
		if(id == null) {
			id = UUID.randomUUID().toString();
		}
		notFound.setId(id);
		notFound.setMessage(message);
		return new NotFound(message, notFound);
	}

	/**
	 * Build WS Resource Unavailable from INF-Exception
	 * @param message
	 * @param code
	 * @param id
	 * @param data
	 * @return
	 */
	public static ResourceUnavailable buildResourceUnavailable(String code, String message,
			String id, String data) {
		com.esrx.ref.b2b.order.ResourceUnavailable resourceUnavailable = new com.esrx.ref.b2b.order.ResourceUnavailable();
		resourceUnavailable.setCode(code);
		if(id == null) {
			id = UUID.randomUUID().toString();
		}
		resourceUnavailable.setId(id);
		resourceUnavailable.setMessage(message);
		return new ResourceUnavailable(message, resourceUnavailable);
	}

	public static ResourceUnavailable buildResourceUnavailable() {
		return buildResourceUnavailable(ERR_CODE_RESOURCE_UNAVAILABLE, MSG_TIMED_OUT, null, null);
	}
	
	/**
	 * Build WS Process failed exception from INF-Exception
	 * @param message
	 * @param code
	 * @param id
	 * @param data
	 * @return
	 */
	public static ProcessFailed buildProcessFailed(String code, String message, 
			String id, String data) {
		com.esrx.ref.b2b.order.ProcessFailed processFailed = new com.esrx.ref.b2b.order.ProcessFailed();
		processFailed.setCode(code);
		if(id == null) {
			id = UUID.randomUUID().toString();
		}
		processFailed.setId(id);
		processFailed.setMessage(message);

		return new ProcessFailed(message, processFailed);
	}
	/**
	 * Build WS Process failed exception from INF-Exception
	 * @param message
	 * @param code
	 * @param id
	 * @param data
	 * @return
	 */
	public static ProcessFailed buildProcessFailed() {
		return buildProcessFailed(ERR_CODE_UNEXPECTED_ERROR, MSG_UNEXPECTED_ERROR, null,null);
	}
	
}
