/**
 * 
 */
package com.esrx.ref.b2b.order.jaxws.impl;

import javax.jws.WebService;

import com.esrx.ref.b2b.order.GetOrderStatusRequest;
import com.esrx.ref.b2b.order.GetOrderStatusResponse;
import com.esrx.ref.b2b.order.UpdateOrderStatusRequest;
import com.esrx.ref.b2b.order.bo.OrderBo;
import com.esrx.ref.b2b.order.ws.InvalidRequest;
import com.esrx.ref.b2b.order.ws.NotFound;
import com.esrx.ref.b2b.order.ws.OrderService;
import com.esrx.ref.b2b.order.ws.ProcessFailed;
import com.esrx.ref.b2b.order.ws.ResourceUnavailable;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;

/**
 * @author p081095 Service impl class responsible for contacting the business
 *         module.
 */
@WebService(serviceName = "OrderService", portName = "OrderService", targetNamespace = "http://ws.order.b2b.ref.esrx.com", endpointInterface = "com.esrx.ref.b2b.order.ws.OrderService")
public class OrderServiceImpl implements OrderService {

	private OrderBo orderBo;
	private ObjectTransformer objectTransformer;

	public void setOrderBo(OrderBo orderBo) {
		this.orderBo = orderBo;
	}

	public void setObjectTransformer(ObjectTransformer objectTransformer) {
		this.objectTransformer = objectTransformer;
	}

	/**
	 * method used to update the order information. Can send multiple orders and
	 * its statuses, If one of the Order Update fails then the entire set will
	 * be considered failed
	 */
	public void updateOrderStatus(UpdateOrderStatusRequest request) throws InvalidRequest,
			ProcessFailed, ResourceUnavailable {

		ProcessTimer.startTimer();
		try {
			Validator.validate(request);
			com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest updateOrderStatusRequest = objectTransformer
					.transform(request);
			orderBo.updateOrder(updateOrderStatusRequest);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw Util.buildInvalidRequest(e.getCode(), e.getMessage(), e.getId(), null);
		} catch (ProcessTimeoutException e) {
			throw Util.buildResourceUnavailable();
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw Util.buildResourceUnavailable(e.getCode(), e.getMessage(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw Util.buildProcessFailed(e.getCode(), e.getMessage(), e.getId(), null);
		}catch(Exception e) {
			throw Util.buildProcessFailed();
		}
	}

	/**
	 * method used to get the Order status information
	 * 
	 */
	public GetOrderStatusResponse getOrderStatus(GetOrderStatusRequest request) throws InvalidRequest, ProcessFailed,
			ResourceUnavailable, NotFound {

		ProcessTimer.startTimer();

		try {
			Validator.validate(request);
			com.esrx.ref.b2b.order.bo.GetOrderStatusRequest getOrderStatusRequest = objectTransformer
					.transform(request);
			com.esrx.ref.b2b.order.bo.GetOrderStatusResponse boResponse = orderBo.getOrderStatus(getOrderStatusRequest);
			return objectTransformer.transform(boResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw Util.buildInvalidRequest(e.getCode(), e.getMessage(), e.getId(), null);
		} catch (com.express_scripts.inf.types.NotFound e) {
			throw Util.buildNotFound(e.getCode(), e.getMessage(), e.getId(), null);
		} catch (ProcessTimeoutException e) {
			throw Util.buildResourceUnavailable();
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw Util.buildResourceUnavailable(e.getCode(), e.getMessage(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw Util.buildProcessFailed(e.getCode(), e.getMessage(), e.getId(), null);
		}catch(Exception e) {
			throw Util.buildProcessFailed();
		}
	}
}
