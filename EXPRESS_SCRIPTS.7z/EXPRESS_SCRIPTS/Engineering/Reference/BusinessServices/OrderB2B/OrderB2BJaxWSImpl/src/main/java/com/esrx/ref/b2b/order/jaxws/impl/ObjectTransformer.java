package com.esrx.ref.b2b.order.jaxws.impl;

import static com.express_scripts.inf.validator.NullValidator.assertNotNull;
import static com.express_scripts.inf.validator.StringValidator.assertNotBlank;

import java.util.ArrayList;
import java.util.List;

import com.esrx.ref.b2b.order.GetOrderStatusResponse;
import com.esrx.ref.b2b.order.OrderStatus;
import com.esrx.ref.b2b.order.bo.GetOrderStatusRequest;
import com.esrx.ref.b2b.order.bo.Order;
import com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest;
import com.esrx.ref.b2b.order.ws.InvalidRequest;
import com.express_scripts.inf.validator.CollectionValidator;

public class ObjectTransformer {

	/**
	 * Transform the Web objects to BusinessObjects
	 * 
	 * @param
	 * @param wsGetOrderStatusRequest
	 * @return GetOrderStatusRequest
	 * @throws InvalidRequest
	 */
	public GetOrderStatusRequest transform(
			com.esrx.ref.b2b.order.GetOrderStatusRequest wsGetOrderStatusRequest) {
		GetOrderStatusRequest boRequest = new GetOrderStatusRequest();
		boRequest.setOrderId(wsGetOrderStatusRequest.getOrderId());
		boRequest.setTimeout(wsGetOrderStatusRequest.getTimeout());
		return boRequest;
	}

	/**
	 * Transform the Business Get Order Status response to Web service response
	 * 
	 * @param
	 * @param wsGetOrderStatusRequest
	 * @return GetOrderStatusRequest
	 * @throws InvalidRequest
	 */
	public GetOrderStatusResponse transform(
			com.esrx.ref.b2b.order.bo.GetOrderStatusResponse boGetOrderStatusResponse) {
		GetOrderStatusResponse wsResponse = new GetOrderStatusResponse();
		com.esrx.ref.b2b.order.Order wsOrder = new com.esrx.ref.b2b.order.Order();
		wsOrder.setOrderId(boGetOrderStatusResponse.getOrder().getOrderId());
		wsOrder.setStatus(OrderStatus.fromValue(boGetOrderStatusResponse
				.getOrder().getStatus().name()));
		wsResponse.setOrder(wsOrder);

		return wsResponse;
	}

	/**
	 * Transform the Update status Request Web Service request to Business
	 * Service request
	 * 
	 * @param wsUpdateOrderStatusRequest
	 * @return
	 * @throws InvalidRequest
	 */
	public UpdateOrderStatusRequest transform(
			com.esrx.ref.b2b.order.UpdateOrderStatusRequest wsUpdateOrderStatusRequest){
		UpdateOrderStatusRequest updateOrderStatusRequest = new UpdateOrderStatusRequest();
		updateOrderStatusRequest.setTimeout(wsUpdateOrderStatusRequest
				.getTimeout());
		List<Order> orderList = new ArrayList<Order>();
		for (com.esrx.ref.b2b.order.Order wsOrder : wsUpdateOrderStatusRequest
				.getOrderList().getOrderList()) {
			Order boOrder = new Order();
			boOrder.setOrderId(wsOrder.getOrderId());
			boOrder.setStatus(com.esrx.ref.b2b.order.bo.OrderStatus
					.valueOf(wsOrder.getStatus().value()));
			orderList.add(boOrder);
		}
		updateOrderStatusRequest.setOrderList(orderList);
		return updateOrderStatusRequest;
	}
}
