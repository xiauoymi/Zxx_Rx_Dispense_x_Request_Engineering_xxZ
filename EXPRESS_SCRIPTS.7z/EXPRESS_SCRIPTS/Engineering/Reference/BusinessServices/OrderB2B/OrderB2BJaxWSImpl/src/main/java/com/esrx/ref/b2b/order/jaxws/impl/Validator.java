package com.esrx.ref.b2b.order.jaxws.impl;

import static com.express_scripts.inf.validator.NullValidator.assertNotNull;

import com.esrx.ref.b2b.order.GetOrderStatusRequest;
import com.esrx.ref.b2b.order.UpdateOrderStatusRequest;
import com.express_scripts.inf.types.InvalidRequest;

/**
 * @author p081095 This class is used for validating the incoming request. If a
 *         fault is found com.esrx.inf.exceptions.InvalidRequest Is thrown back.
 */
public class Validator {

	/**
	 * Validation method for validating UpdateOrderRequest
	 * 
	 * @param request
	 * @throws InvalidRequest
	 */
	public static void validate(UpdateOrderStatusRequest request)
			throws InvalidRequest {
		assertNotNull("REQUEST", request);
		assertNotNull("ORDER_LIST", request.getOrderList());
	}

	/**
	 * Validation method for validating UpdateAccountRequest
	 * 
	 * @param request
	 * @throws InvalidRequest
	 */
	public static void validate(GetOrderStatusRequest request)
			throws InvalidRequest {
		assertNotNull("REQUEST", request);
	}
}
