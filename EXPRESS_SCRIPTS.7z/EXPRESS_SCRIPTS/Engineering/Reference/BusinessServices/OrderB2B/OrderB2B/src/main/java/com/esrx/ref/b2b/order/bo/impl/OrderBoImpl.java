package com.esrx.ref.b2b.order.bo.impl;

import static com.esrx.ref.b2b.order.bo.impl.Validator.validate;
import static com.express_scripts.inf.concurrent.ProcessTimer.assertTimeRemaining;

import java.util.ArrayList;
import java.util.List;

import com.esrx.ref.b2b.order.bo.GetOrderStatusRequest;
import com.esrx.ref.b2b.order.bo.GetOrderStatusResponse;
import com.esrx.ref.b2b.order.bo.OrderBo;
import com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest;
import com.esrx.ref.b2b.order.management.SleepTimeMBean;
import com.esrx.ref.order.GetOrderRequest;
import com.esrx.ref.order.GetOrderResponse;
import com.express_scripts.inf.concurrent.ProcessException;
import com.express_scripts.inf.concurrent.ProcessManager;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;
import com.express_scripts.inf.types.ResourceUnavailable;

public class OrderBoImpl implements OrderBo {

	private OrderResourceAdapter orderResourceAdapter;

	private OrderUpdateProcessor orderUpdateProcessor;
	
	private SleepTimeMBean sleepTimeMBean;

	private Long defaultTimeout = 30000L;
	private Long bufferTime = 100L;
	private ObjectTransformer transformer;
	private ProcessManager processManager;

	public void setOrderResourceAdapter(OrderResourceAdapter orderResourceAdapter) {
		this.orderResourceAdapter = orderResourceAdapter;
	}
	public void setOrderUpdateProcessor(OrderUpdateProcessor orderUpdateProcessor) {
		this.orderUpdateProcessor = orderUpdateProcessor;
	}

	public void setProcessManager(ProcessManager processManager) {
		this.processManager = processManager;
	}

	public void setTransformer(ObjectTransformer transformer) {
		this.transformer = transformer;
	}

	public void setDefaultTimeout(Long defaultTimeout) {
		this.defaultTimeout = defaultTimeout;
	}

	public void setBufferTime(Long bufferTime) {
		this.bufferTime = bufferTime;
	}

	/**
	 * This method helps to update the Order Status and send a async MQ message
	 * to subscribers
	 * 
	 * @param request
	 * @return
	 * @throws InvalidRequest
	 */
	public void updateOrder(UpdateOrderStatusRequest request) throws InvalidRequest {
		validate(request);
		
		delay(); // For Testing Purposes Only
		
		long remainingTime = assertTimeRemaining(request.getTimeout(), defaultTimeout, bufferTime);
		List<com.express_scripts.inf.concurrent.Process> processList = new ArrayList<com.express_scripts.inf.concurrent.Process>();
		List<com.esrx.ref.order.UpdateOrderStatusRequest> orderRequest = transformer.transform(request, remainingTime);
		for (com.esrx.ref.order.UpdateOrderStatusRequest updateOrderStatusRequest : orderRequest) {
			try {
				processList.add(processManager.startProcess(updateOrderStatusRequest, orderUpdateProcessor));
			} catch (ProcessException e) {
				throw new ProcessFailed(e);
			}
		}
		remainingTime = assertTimeRemaining(request.getTimeout(), defaultTimeout);
		try {
			processManager.waitForAll(processList, remainingTime);
		} catch (ProcessTimeoutException e) {
			throw new ResourceUnavailable();
		} catch (ProcessException e) {
			throw new ProcessFailed(e);
		}
	}

	/**
	 * Gather the order Statues and the form a response. If a single order not
	 * found from the list then
	 * 
	 * @param request
	 * @param bufferTime
	 * @param defaultTimeout
	 * @return
	 * @throws InvalidRequest
	 */
	public GetOrderStatusResponse getOrderStatus(GetOrderStatusRequest request) throws InvalidRequest, NotFound {
		validate(request);
		
		delay(); // For Testing Purposes Only
		
		long remainingTime = assertTimeRemaining(request.getTimeout(), defaultTimeout, bufferTime);
		GetOrderRequest getOrderRequest = transformer.transform(request, remainingTime);
		GetOrderResponse getOrderResponse = orderResourceAdapter.getOrder(getOrderRequest);
		return transformer.transform(getOrderResponse);
	}
	
	public void setSleepTimeMBean(SleepTimeMBean sleepTimeMBean) {
		this.sleepTimeMBean = sleepTimeMBean;
	}
	
	private void delay() {
		long delayTime = sleepTimeMBean.getSleepTimeMS();
		if (delayTime > 0) {
			try {
				Thread.sleep(delayTime);
			} catch (Exception e) {
				// do nothing
			}
		}
	}
	
}
