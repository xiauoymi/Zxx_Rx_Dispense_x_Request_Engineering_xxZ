package com.esrx.ref.b2b.order.bo.impl;

public interface UpdateOrderMQAdapter {
	public void updateOrderStatus(
			com.esrx.ref.order.UpdateOrderStatusRequest orderStatusRequest);
}
