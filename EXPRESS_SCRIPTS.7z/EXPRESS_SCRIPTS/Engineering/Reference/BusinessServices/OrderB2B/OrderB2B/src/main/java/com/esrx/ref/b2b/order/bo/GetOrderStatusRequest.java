package com.esrx.ref.b2b.order.bo;

import java.io.Serializable;

public class GetOrderStatusRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 68403147639884993L;
	/**
	 * 
	 */
	private String orderId;
	private Long timeout;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	/**
	 * Gets the value of the timeout property.
	 * 
	 * @return
	 * 
	 */
	public Long getTimeout() {
		return timeout;
	}

	/**
	 * Sets the value of the timeout property.
	 * 
	 * @param value
	 * 
	 */
	public void setTimeout(Long value) {
		this.timeout = value;
	}

}
