package com.esrx.ref.b2b.order.bo.impl;

import java.util.ArrayList;
import java.util.List;

import com.esrx.ref.b2b.order.bo.GetOrderStatusRequest;
import com.esrx.ref.b2b.order.bo.GetOrderStatusResponse;
import com.esrx.ref.b2b.order.bo.Order;
import com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest;
import com.esrx.ref.order.GetOrderRequest;
import com.esrx.ref.order.GetOrderResponse;
import com.esrx.ref.order.OrderStatus;
import com.express_scripts.inf.types.InvalidRequest;

public class ObjectTransformer {
	/**
	 * Creates the Order Service request object. Call this method only after
	 * Validation and null checks.
	 * 
	 * @param statusRequest
	 * @return
	 */
	public GetOrderRequest transform(GetOrderStatusRequest statusRequest,
			Long timeOut) throws InvalidRequest {
		GetOrderRequest returnValue = new GetOrderRequest();
		returnValue.setOrderId(statusRequest.getOrderId());
		returnValue.setTimeout(timeOut);
		return returnValue;
	}

	/**
	 * Transform Order Response from Order Service to B2b Bo Response
	 * 
	 * @param orderResponse
	 * @return
	 * @throws InvalidRequest
	 */
	public GetOrderStatusResponse transform(GetOrderResponse orderResponse)
			throws InvalidRequest {
		GetOrderStatusResponse returnValue = new GetOrderStatusResponse();
		Order order = transform(orderResponse.getOrder());
		returnValue.setOrder(order);
		return returnValue;
	}

	public static Order transform(com.esrx.ref.order.Order order)
			throws InvalidRequest {
		Order returnValue = new Order();
		returnValue.setOrderId(order.getOrderId());
		returnValue.setStatus(com.esrx.ref.b2b.order.bo.OrderStatus.valueOf(order.getOrderStatus().value()));
		return returnValue;

	}

	/**
	 * Creates a list of Update order Requests so that it could be used by the
	 * Processor
	 * 
	 * @param request
	 * @param timeOut
	 * @return
	 */
	public List<com.esrx.ref.order.UpdateOrderStatusRequest> transform(
			UpdateOrderStatusRequest request, Long timeOut) {
		List<com.esrx.ref.order.UpdateOrderStatusRequest> returnValue = new ArrayList<com.esrx.ref.order.UpdateOrderStatusRequest>();

		for (Order order : request.getOrderList()) {
			com.esrx.ref.order.UpdateOrderStatusRequest orderUpdateRequest = new com.esrx.ref.order.UpdateOrderStatusRequest();
			orderUpdateRequest.setOrderId(order.getOrderId());
			orderUpdateRequest.setOrderStatus(OrderStatus.valueOf(order
					.getStatus().name()));
			orderUpdateRequest.setTimeout(timeOut);
			returnValue.add(orderUpdateRequest);
		}
		return returnValue;
	}
}
