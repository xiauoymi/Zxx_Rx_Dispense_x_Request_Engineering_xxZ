package com.esrx.ref.b2b.order.bo.impl;

import com.esrx.ref.order.UpdateOrderStatusRequest;
import com.express_scripts.inf.concurrent.Processor;

public class OrderUpdateProcessor implements Processor {

	UpdateOrderMQAdapter updateOrderAdapter;

	public void setUpdateOrderAdapter(UpdateOrderMQAdapter updateOrderAdapter) {
		this.updateOrderAdapter = updateOrderAdapter;
	}

	@Override
	public Object process(Object request) {
		updateOrderAdapter
				.updateOrderStatus((UpdateOrderStatusRequest) request);
		return null;
	}

}
