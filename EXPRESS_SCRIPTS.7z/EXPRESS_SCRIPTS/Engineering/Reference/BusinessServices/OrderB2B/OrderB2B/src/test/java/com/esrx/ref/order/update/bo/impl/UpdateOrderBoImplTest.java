package com.esrx.ref.order.update.bo.impl;

import static com.express_scripts.inf.concurrent.ProcessTimer.startTimer;
import static org.easymock.EasyMock.anyObject;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest;
import com.esrx.ref.b2b.order.bo.impl.ObjectTransformer;
import com.esrx.ref.b2b.order.bo.impl.OrderBoImpl;
import com.esrx.ref.b2b.order.bo.impl.OrderResourceAdapter;
import com.esrx.ref.b2b.order.bo.impl.OrderUpdateProcessor;
import com.esrx.ref.b2b.order.bo.impl.UpdateOrderMQAdapter;
import com.esrx.ref.b2b.order.bo.impl.Validator;
import com.esrx.ref.b2b.order.management.SleepTimeMBean;
import com.esrx.ref.order.jaxrs.OrderResource;
import com.express_scripts.inf.concurrent.Process;
import com.express_scripts.inf.concurrent.ProcessException;
import com.express_scripts.inf.concurrent.ProcessManager;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.concurrent.impl.Java5Process;
import com.express_scripts.inf.concurrent.impl.Java5ProcessManager;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.ProcessFailed;

public class UpdateOrderBoImplTest {
	OrderBoImpl orderBoImpl = new OrderBoImpl();
	OrderResourceAdapter orderProcessAdapter = new OrderResourceAdapter();
	OrderUpdateProcessor processor = new OrderUpdateProcessor();
	ProcessManager manager = new Java5ProcessManager(false);
	OrderResource orderResource = EasyMock.createMock(OrderResource.class);
	UpdateOrderMQAdapter adapter =  EasyMock.createMock(UpdateOrderMQAdapter.class);
	SleepTimeMBean sleepTimeMBean = EasyMock.createMock(SleepTimeMBean.class);
	ObjectTransformer transformer = new ObjectTransformer();
	Validator validator = new Validator();
	private static Long DEFAULT_TIMEOUT = 10000L;
	private static Long TIMEOUT = 10000L;
	private static Long BUFFER_TIME = 1000L;

	@Before
	public void setupMocks() {
		EasyMock.reset(orderResource);
		orderProcessAdapter.setOrderResource(orderResource);
		orderBoImpl.setOrderResourceAdapter(orderProcessAdapter);
		orderBoImpl.setBufferTime(BUFFER_TIME);
		orderBoImpl.setDefaultTimeout(DEFAULT_TIMEOUT);
		orderBoImpl.setTransformer(transformer);
		orderBoImpl.setSleepTimeMBean(sleepTimeMBean);
		processor.setUpdateOrderAdapter(adapter);
		startTimer();
	}


	@Test
	public void updateOrderStatus() throws InvalidRequest {
		// Processors
		orderBoImpl.setOrderUpdateProcessor(processor);
		orderBoImpl.setProcessManager(manager);
		// Timer
		orderBoImpl.updateOrder(createValidUpdateOrderRequest());

	}

	@Test(expected = InvalidRequest.class)
	public void updateOrderStatusBlankOrderId() throws InvalidRequest {

		UpdateOrderStatusRequest updateOrderRequest = createValidUpdateOrderRequest();
		updateOrderRequest.getOrderList().get(0).setOrderId("");
		// Processors
		orderBoImpl.setOrderUpdateProcessor(processor);
		orderBoImpl.setProcessManager(manager);
		// Timer
		orderBoImpl.updateOrder(updateOrderRequest);

	}

	@Test(expected = InvalidRequest.class)
	public void updateOrderStatusInvalidRequestNoOrderList()
			throws InvalidRequest {
		List<com.esrx.ref.b2b.order.bo.Order> orderList = new ArrayList<com.esrx.ref.b2b.order.bo.Order>();
		UpdateOrderStatusRequest boRequest = new UpdateOrderStatusRequest();
		boRequest.setOrderList(orderList);
		boRequest.setTimeout(TIMEOUT);

		// Processors
		orderBoImpl.setOrderUpdateProcessor(processor);
		orderBoImpl.setProcessManager(manager);
		// Timer

		orderBoImpl.updateOrder(boRequest);

	}

	@Test(expected = ProcessFailed.class)
	public void updateOrderStatusProcessFailed() throws InvalidRequest {
		// Processors
		orderBoImpl.setOrderUpdateProcessor(processor);
		ProcessManager processManager = EasyMock
				.createMock(ProcessManager.class);
		ProcessException processException = new ProcessException(
				"Process Failed");
		expect(
				processManager.startProcess(
						anyObject(UpdateOrderStatusRequest.class),
						anyObject(OrderUpdateProcessor.class))).andThrow(
				processException);
		orderBoImpl.setProcessManager(processManager);
		replay(processManager);
		// Timer
		orderBoImpl.updateOrder(createValidUpdateOrderRequest());
	}
	@Test(expected = ProcessFailed.class)
	public void updateOrderStatusProcessFailedOnWaitForAll() throws InvalidRequest {
		
		UpdateOrderStatusRequest createValidUpdateOrderRequest = createValidUpdateOrderRequest();
		// Processors
		orderBoImpl.setOrderUpdateProcessor(processor);
		ProcessManager processManager = EasyMock
		.createMock(ProcessManager.class);
		ProcessException processException = new ProcessException(
				"Process Failed");
		Process process =  new Java5Process(createValidUpdateOrderRequest, processor, null, null);
		List<Process> processList =  new ArrayList<Process>();
		processList.add(process);
		processList.add(process);
		expect(
				processManager.startProcess(
						anyObject(UpdateOrderStatusRequest.class),
						anyObject(OrderUpdateProcessor.class))).andReturn(process);
		expect(
				processManager.startProcess(
						anyObject(UpdateOrderStatusRequest.class),
						anyObject(OrderUpdateProcessor.class))).andReturn(process);
		processManager.waitForAll(anyObject(List.class), EasyMock.anyLong());
		EasyMock.expectLastCall().andThrow(processException);
		orderBoImpl.setProcessManager(processManager);
		replay(processManager);
		// Timer
		orderBoImpl.updateOrder(createValidUpdateOrderRequest);
	}

	@Test(expected = InvalidRequest.class)
	public void updateOrderStatusInvalidRequestNullOrderList()
			throws InvalidRequest {
		UpdateOrderStatusRequest boRequest = new UpdateOrderStatusRequest();
		boRequest.setOrderList(null);
		boRequest.setTimeout(TIMEOUT);

		// Processors
		orderBoImpl.setOrderUpdateProcessor(processor);
		orderBoImpl.setProcessManager(manager);
		// Timer
		orderBoImpl.updateOrder(boRequest);

	}

	@Test(expected = InvalidRequest.class)
	public void updateOrderStatusNullRequest() throws InvalidRequest {
		// Processors
		orderBoImpl.setOrderUpdateProcessor(processor);
		orderBoImpl.setProcessManager(manager);
		// Timer
		ProcessTimer.startTimer();
		orderBoImpl.updateOrder(null);

	}

	@Test(expected = InvalidRequest.class)
	public void updateOrderStatusResourceTimedout() throws InvalidRequest {
		List<com.esrx.ref.b2b.order.bo.Order> orderList = new ArrayList<com.esrx.ref.b2b.order.bo.Order>();
		UpdateOrderStatusRequest boRequest = new UpdateOrderStatusRequest();
		boRequest.setOrderList(orderList);
		boRequest.setTimeout(10L);

		// Processors
		orderBoImpl.setOrderUpdateProcessor(processor);
		orderBoImpl.setProcessManager(manager);
		orderBoImpl.updateOrder(boRequest);
	}

	private UpdateOrderStatusRequest createValidUpdateOrderRequest() {
		String TEST_ORDER_ID_1 = "TEST_ORDER_1";
		String TEST_ORDER_ID_2 = "TEST_ORDER_2";
		List<com.esrx.ref.b2b.order.bo.Order> orderList = new ArrayList<com.esrx.ref.b2b.order.bo.Order>();
		com.esrx.ref.b2b.order.bo.Order boOrder1 = new com.esrx.ref.b2b.order.bo.Order();
		boOrder1.setOrderId(TEST_ORDER_ID_1);
		boOrder1.setStatus(com.esrx.ref.b2b.order.bo.OrderStatus.COMPLETED);
		orderList.add(boOrder1);
		com.esrx.ref.b2b.order.bo.Order boOrder2 = new com.esrx.ref.b2b.order.bo.Order();
		boOrder2.setOrderId(TEST_ORDER_ID_2);
		boOrder2.setStatus(com.esrx.ref.b2b.order.bo.OrderStatus.REQUESTED);
		orderList.add(boOrder2);
		UpdateOrderStatusRequest boRequest = new UpdateOrderStatusRequest();
		boRequest.setOrderList(orderList);
		boRequest.setTimeout(TIMEOUT);
		return boRequest;
	}


}
