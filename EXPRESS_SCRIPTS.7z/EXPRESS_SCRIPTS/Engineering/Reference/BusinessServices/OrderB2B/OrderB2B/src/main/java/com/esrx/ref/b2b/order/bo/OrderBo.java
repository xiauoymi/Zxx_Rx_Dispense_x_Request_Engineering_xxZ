package com.esrx.ref.b2b.order.bo;

import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;


public interface OrderBo {

	public void updateOrder(
			UpdateOrderStatusRequest request) throws InvalidRequest;

	public GetOrderStatusResponse getOrderStatus(GetOrderStatusRequest request)
			throws InvalidRequest, NotFound;
}
