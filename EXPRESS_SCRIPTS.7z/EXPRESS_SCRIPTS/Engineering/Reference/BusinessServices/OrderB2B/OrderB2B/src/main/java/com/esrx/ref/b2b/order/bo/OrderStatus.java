package com.esrx.ref.b2b.order.bo;


/**
 * Enum represent hard coded order status values that are allowed to be updated
 * by certain systems
 * 
 */
public enum OrderStatus {

	REQUESTED, PROCESSING, SHIPPED, DELIVERED, COMPLETED;
}
