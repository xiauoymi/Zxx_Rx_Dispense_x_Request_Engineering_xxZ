package com.esrx.ref.b2b.order.bo.impl;

import static com.express_scripts.inf.validator.CollectionValidator.assertNotEmpty;
import static com.express_scripts.inf.validator.NullValidator.assertNotNull;
import static com.express_scripts.inf.validator.StringValidator.assertNotBlank;

import com.esrx.ref.b2b.order.bo.GetOrderStatusRequest;
import com.esrx.ref.b2b.order.bo.Order;
import com.esrx.ref.b2b.order.bo.UpdateOrderStatusRequest;
import com.express_scripts.inf.types.InvalidRequest;

/**
 * @author p081095 This class is used for validating the incoming request. If a
 *         fault is found com.esrx.inf.exceptions.InvalidRequest Is thrown back.
 */
public class Validator {

	/**
	 * Validation method for validating UpdateOrderRequest
	 * 
	 * @param request
	 * @throws InvalidRequest
	 */
	public static void validate(UpdateOrderStatusRequest request)
			throws InvalidRequest {
		
		assertNotNull("REQUEST", request);
		assertNotEmpty("ORDER_LIST", request.getOrderList());
		for (Order orderInfo : request.getOrderList()) {
			assertNotBlank("ORDER_ID", orderInfo.getOrderId());
			assertNotNull("ORDER_STATUS",orderInfo.getStatus());
		}
	}

	/**
	 * Validation method for validating UpdateAccountRequest
	 * 
	 * @param request
	 * @throws InvalidRequest
	 */
	public static void validate(GetOrderStatusRequest request)
			throws InvalidRequest {
		assertNotNull("REQUEST", request);
		assertNotBlank("ORDER_ID", request.getOrderId());
	}
}
