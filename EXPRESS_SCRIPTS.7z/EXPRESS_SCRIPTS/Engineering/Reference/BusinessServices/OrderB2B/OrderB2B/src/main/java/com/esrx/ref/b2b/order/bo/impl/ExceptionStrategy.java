package com.esrx.ref.b2b.order.bo.impl;

import java.net.SocketTimeoutException;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;

import com.express_scripts.inf.types.jaxb.ErrorInfo;
import com.express_scripts.inf.jersey.ResourceException;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;
import com.express_scripts.inf.types.ResourceUnavailable;
import com.sun.jersey.api.client.ClientHandlerException;

public class ExceptionStrategy {
	private static final Logger LOG = Logger.getLogger(ExceptionStrategy.class);
	public static final String ERR_CODE_RESOURCE_UNAVAILABLE = "RESOURCE_UNAVAILABLE";
	//TODO: Logging
	public void handleClientHandlerException (ClientHandlerException e) {
		if(e.getCause() instanceof SocketTimeoutException){
			throw new ResourceUnavailable();
		} else {
			throw e;
		}
		
	}
	public void handleResourceException(ResourceException e) throws InvalidRequest {
		ErrorInfo errorInfo = getErrorInfo(e);
		Status errorStatus = Response.Status.fromStatusCode(e
				.getClientResponse().getStatus());
		LOG.error("Http Status: " + errorStatus.getStatusCode());
		LOG.error(errorInfo);
		handleResourceExceptionsWithErrorStatusWithoutNotFound(errorStatus,
				errorInfo);		
	}
	public void handleResourceExceptionWithNotFound(ResourceException e) throws InvalidRequest, NotFound {
		ErrorInfo errorInfo = getErrorInfo(e);
		Status errorStatus = Response.Status.fromStatusCode(e
				.getClientResponse().getStatus());
		
		LOG.error("Http Status: " + errorStatus.getStatusCode());
		LOG.error(errorInfo);
		handleResourceExceptionsWithErrorStatus(errorStatus, errorInfo);		
	}	

	private ErrorInfo getErrorInfo(ResourceException e) throws InvalidRequest {
		ResourceException re = (ResourceException)e;
		if (null == re.getClientResponse()) {
			handleInvalidResponse();
		}
		ErrorInfo errorInfo = null;
		try {
			errorInfo = e.getClientResponse().getEntity(ErrorInfo.class);
			
		} catch (Exception exception) {
			handleInvalidResponse();
		}
		return errorInfo;
	}

	private void handleResourceExceptionsWithErrorStatus(Status errorStatus,
			ErrorInfo errorInfo) throws InvalidRequest, NotFound {
		switch (errorStatus) {
		case BAD_REQUEST:
			handleBadRequestStatus(errorInfo);
		case NOT_FOUND:
			handleNotFoundStatus(errorInfo);
		case INTERNAL_SERVER_ERROR:
			handleInternalServerStatus(errorInfo);
		}
	}

	private void handleResourceExceptionsWithErrorStatusWithoutNotFound(
			Status errorStatus, ErrorInfo errorInfo) throws InvalidRequest {
		switch (errorStatus) {
		case BAD_REQUEST:
			handleBadRequestStatus(errorInfo);
		case INTERNAL_SERVER_ERROR:
		default:
			handleInternalServerStatus(errorInfo);
		}
	}

	private void handleInvalidResponse(){
		throw new ProcessFailed();
	}

	public void handleInternalServerStatus(ErrorInfo errorInfo) {
		throw buildProcessFailed(errorInfo);
	}

	public void handleNotFoundStatus(ErrorInfo errorInfo) throws NotFound {
		throw buildNotFound(errorInfo);
	}

	public void handleBadRequestStatus(ErrorInfo errorInfo)
			throws InvalidRequest {
		throw buildInvalidRequest(errorInfo);
	}

	private ProcessFailed buildProcessFailed(ErrorInfo entity) {
		ProcessFailed processFailed = null;
		if (entity.getCode().equalsIgnoreCase(ERR_CODE_RESOURCE_UNAVAILABLE)) {
			processFailed = new ResourceUnavailable();
		} else {
			processFailed = new ProcessFailed();
		}
		return processFailed;
	}

	private NotFound buildNotFound(ErrorInfo entity) {
		return new NotFound();
	}

	private InvalidRequest buildInvalidRequest(ErrorInfo entity) {
		return new InvalidRequest(entity.getCode(), entity.getMessage(), null,
				entity.getData());
	}

}
