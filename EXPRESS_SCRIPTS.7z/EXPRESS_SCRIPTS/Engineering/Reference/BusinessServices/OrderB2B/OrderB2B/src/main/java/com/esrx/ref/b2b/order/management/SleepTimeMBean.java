package com.esrx.ref.b2b.order.management;

public interface SleepTimeMBean {
	long getSleepTimeMS();
	void setSleepTimeMS(long sleepTimeMS);
}
