package com.esrx.ref.order.update.bo.impl;

import static com.express_scripts.inf.concurrent.ProcessTimer.startTimer;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.esrx.ref.b2b.order.bo.GetOrderStatusRequest;
import com.esrx.ref.b2b.order.bo.GetOrderStatusResponse;
import com.esrx.ref.b2b.order.bo.impl.ExceptionStrategy;
import com.esrx.ref.b2b.order.bo.impl.ObjectTransformer;
import com.esrx.ref.b2b.order.bo.impl.OrderBoImpl;
import com.esrx.ref.b2b.order.bo.impl.OrderResourceAdapter;
import com.esrx.ref.b2b.order.bo.impl.OrderUpdateProcessor;
import com.esrx.ref.b2b.order.bo.impl.UpdateOrderMQAdapter;
import com.esrx.ref.b2b.order.bo.impl.Validator;
import com.esrx.ref.b2b.order.management.SleepTimeMBean;
import com.esrx.ref.order.GetOrderRequest;
import com.esrx.ref.order.GetOrderResponse;
import com.esrx.ref.order.Order;
import com.esrx.ref.order.OrderStatus;
import com.esrx.ref.order.jaxrs.OrderResource;
import com.express_scripts.inf.concurrent.ProcessManager;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.concurrent.impl.Java5ProcessManager;
import com.express_scripts.inf.jersey.ResourceException;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;
import com.express_scripts.inf.types.ResourceUnavailable;
import com.express_scripts.inf.types.jaxb.ErrorInfo;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.ClientResponse.Status;

public class GetOrderBoImplTest {
	OrderBoImpl orderBoImpl = new OrderBoImpl();
	OrderResourceAdapter orderProcessAdapter = new OrderResourceAdapter();
	OrderUpdateProcessor processor = new OrderUpdateProcessor();
	ProcessManager manager = new Java5ProcessManager(false);
	OrderResource orderResource = EasyMock.createMock(OrderResource.class);
	UpdateOrderMQAdapter adapter =  EasyMock.createMock(UpdateOrderMQAdapter.class);
	SleepTimeMBean sleepTimeMBean = EasyMock.createMock(SleepTimeMBean.class);
	ObjectTransformer transformer = new ObjectTransformer();
	ExceptionStrategy exceptionStrategy =  new ExceptionStrategy();
	Validator validator = new Validator();
	private static Long DEFAULT_TIMEOUT = 10000L;
	private static Long TIMEOUT = 10000L;
	private static Long BUFFER_TIME = 1000L;

	@Before
	public void setupMocks() {
		EasyMock.reset(orderResource);
		orderProcessAdapter.setOrderResource(orderResource);
		orderProcessAdapter.setExceptionStrategy(exceptionStrategy);
		orderBoImpl.setOrderResourceAdapter(orderProcessAdapter);
		orderBoImpl.setSleepTimeMBean(sleepTimeMBean);
		orderBoImpl.setBufferTime(BUFFER_TIME);
		orderBoImpl.setDefaultTimeout(DEFAULT_TIMEOUT);
		orderBoImpl.setTransformer(transformer);
		processor.setUpdateOrderAdapter(adapter);
		startTimer();
	}

	@Test
	// (timeout= 10000L)
	public void getOrderStatus() throws InvalidRequest, NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();

		GetOrderResponse orderResponse = createValidGetOrderResponse(boRequest);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andReturn(
				orderResponse);
		replay(orderResource);
		GetOrderStatusResponse boResponse = orderBoImpl
				.getOrderStatus(boRequest);
		assertNotNull(boResponse);
		assertNotNull(boResponse.getOrder());
		assertEquals(boResponse.getOrder().getOrderId(), boRequest.getOrderId());
		assertEquals(boResponse.getOrder().getStatus(),
				com.esrx.ref.b2b.order.bo.OrderStatus.REQUESTED);
	}

	private GetOrderResponse createValidGetOrderResponse(
			GetOrderStatusRequest boRequest) {
		GetOrderResponse orderResponse = new GetOrderResponse();
		Order order = new Order();
		order.setOrderId(boRequest.getOrderId());
		order.setOrderStatus(OrderStatus.REQUESTED);
		orderResponse.setOrder(order);
		return orderResponse;
	}

	@Test(expected = InvalidRequest.class)
	public void getOrderStatusRequestNull() throws InvalidRequest, NotFound {
		orderBoImpl.getOrderStatus(null);
	}

	@Test(expected = InvalidRequest.class)
	public void getOrderStatusInvalidRequest() throws InvalidRequest, NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();
		boRequest.setOrderId(null);

		GetOrderResponse orderResponse = createValidGetOrderResponse(boRequest);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andReturn(
				orderResponse);
		replay(orderResource);
		orderBoImpl.getOrderStatus(boRequest);
	}

	@Test(expected = NullPointerException.class)
	public void getOrderStatusInvalidRequestOrderStatusNull()
			throws InvalidRequest, NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();

		GetOrderResponse orderResponse = createValidGetOrderResponse(boRequest);
		orderResponse.getOrder().setOrderStatus(null);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andReturn(
				orderResponse);
		replay(orderResource);
		orderBoImpl.getOrderStatus(boRequest);
	}

	@Test(expected = ProcessTimeoutException.class)
	public void getOrderStatusResourceTimedout() throws InvalidRequest,
			NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();
		boRequest.setTimeout(23L);

		GetOrderResponse orderResponse = createValidGetOrderResponse(boRequest);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andReturn(
				orderResponse);
		replay(orderResource);
		orderBoImpl.getOrderStatus(boRequest);
	}

	@Test(expected = NotFound.class)
	public void getOrderStatusClientThrowResourceNotFound()
			throws InvalidRequest, NotFound {

		GetOrderStatusRequest getOrderStatusRequest = createValidOrderStatusRequest();

		ClientResponse clientResponse = createClientResponseWithStatus(Status.NOT_FOUND);
		ResourceException resourceException = new ResourceException(
				clientResponse);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andThrow(
				resourceException);
		replay(orderResource, clientResponse);
		try {
			orderBoImpl.getOrderStatus(getOrderStatusRequest);
		} catch (InvalidRequest e) {
			assertEquals(e.getMessage(), "Order Not Found");
			assertEquals(e.getCode(), "ORDER_NOT_FOUND");
			throw e;
		}
	}

	@Test(expected = InvalidRequest.class)
	public void getOrderStatusClientThrowResourceBadRequest()
			throws InvalidRequest, NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();

		ClientResponse clientResponse = createClientResponseWithStatus(Status.BAD_REQUEST);

		ResourceException resourceException = new ResourceException(
				clientResponse);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andThrow(
				resourceException);
		replay(orderResource, clientResponse);
		try {
			orderBoImpl.getOrderStatus(boRequest);
		} catch (NotFound e) {
			System.out.println(e.getCode());
			throw e;
		}
	}

	@Test(expected = ProcessFailed.class)
	public void getOrderStatusClientThrowResourceInternalServerError()
			throws InvalidRequest, NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();

		ClientResponse clientResponse = createClientResponseWithStatus(Status.INTERNAL_SERVER_ERROR);

		ResourceException resourceException = new ResourceException(
				clientResponse);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andThrow(
				resourceException);
		replay(orderResource, clientResponse);
		try {
			orderBoImpl.getOrderStatus(boRequest);
		} catch (InvalidRequest e) {
			assertEquals(e.getMessage(), "Order Not Found");
			assertEquals(e.getCode(), "ORDER_NOT_FOUND");
			throw e;
		}
	}
	@Test(expected = ProcessFailed.class)
	public void getOrderStatusClientThrowResourceInternalServerError2()
	throws InvalidRequest, NotFound {
		
		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();
		
		ClientResponse clientResponse = createClientResponseWithStatus(Status.INTERNAL_SERVER_ERROR);
		
		ResourceException resourceException = new ResourceException(
				clientResponse);
		
		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andThrow(
								resourceException);
		replay(orderResource, clientResponse);
		try {
			orderBoImpl.getOrderStatus(boRequest);
		} catch (InvalidRequest e) {
			assertEquals(e.getMessage(), "Order Not Found");
			assertEquals(e.getCode(), "ORDER_NOT_FOUND");
			throw e;
		}
	}


	@Test(expected = ProcessFailed.class)
	public void getOrderStatusClientThrowResourceNoErrorInfo()
			throws InvalidRequest, NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();

		ClientResponse clientResponse = EasyMock
				.createMock(ClientResponse.class);

		expect(clientResponse.getEntity(com.express_scripts.inf.types.jaxb.ErrorInfo.class)).andThrow(
				new IllegalArgumentException());
		expect(clientResponse.getClientResponseStatus()).andReturn(
				Status.BAD_GATEWAY);

		ResourceException resourceException = new ResourceException(
				clientResponse);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andThrow(
				resourceException);
		replay(orderResource, clientResponse);
		ProcessTimer.startTimer();
		orderBoImpl.getOrderStatus(boRequest);
	}

	@Test(expected = ResourceUnavailable.class)
	public void getOrderStatusClientThrowClientHandlerException()
			throws InvalidRequest, NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();
		
		SocketTimeoutException socketTime = new SocketTimeoutException();
		ClientHandlerException clientHandlerException = new ClientHandlerException(
				"Socket Timedout", socketTime);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andThrow(
				clientHandlerException);
		replay(orderResource);
		try {
			orderBoImpl.getOrderStatus(boRequest);
		} catch (InvalidRequest e) {
			assertEquals(e.getMessage(), "Order Not Found");
			assertEquals(e.getCode(), "ORDER_NOT_FOUND");
			throw e;
		}
	}

	@Test(expected = ClientHandlerException.class)
	public void getOrderStatusClientThrowClientHandlerExceptionNoSocket()
			throws InvalidRequest, NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();

		UnknownHostException unknown = new UnknownHostException();
		ClientHandlerException clientHandlerException = new ClientHandlerException(
				"Unknown Host", unknown);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andThrow(
				clientHandlerException);
		replay(orderResource);
		try {
			orderBoImpl.getOrderStatus(boRequest);
		} catch (InvalidRequest e) {
			assertEquals(e.getMessage(), "Order Not Found");
			assertEquals(e.getCode(), "ORDER_NOT_FOUND");
			throw e;
		}
	}

	@Test(expected = IllegalStateException.class)
	public void getOrderStatusClientThrowSomeException() throws InvalidRequest,
			NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andThrow(
				new IllegalStateException());
		replay(orderResource);
		try {
			orderBoImpl.getOrderStatus(boRequest);
		} catch (InvalidRequest e) {
			assertEquals(e.getMessage(), "Order Not Found");
			assertEquals(e.getCode(), "ORDER_NOT_FOUND");
			throw e;
		}
	}

	@Test(expected = ProcessFailed.class)
	public void getOrderStatusClientThrowResourceNoClientResponse()
			throws InvalidRequest, NotFound {

		GetOrderStatusRequest boRequest = createValidOrderStatusRequest();

		ResourceException resourceException = new ResourceException(null);

		expect(
				orderResource.getOrder(EasyMock
						.anyObject(GetOrderRequest.class))).andThrow(
				resourceException);
		replay(orderResource);
		try {
			orderBoImpl.getOrderStatus(boRequest);
		} catch (InvalidRequest e) {
			assertEquals(e.getMessage(), "Order Not Found");
			assertEquals(e.getCode(), "ORDER_NOT_FOUND");
			throw e;
		}
	}

	private GetOrderStatusRequest createValidOrderStatusRequest() {
		GetOrderStatusRequest boRequest = new GetOrderStatusRequest();
		boRequest.setOrderId("ORDER_1");
		boRequest.setTimeout(TIMEOUT);
		return boRequest;
	}

	private ClientResponse createClientResponseWithStatus(Status status) {
		ClientResponse clientResponse = EasyMock
				.createMock(ClientResponse.class);
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setMessage("Order Not Found");
		errorInfo.setCode("ORDER_NOT_FOUND");
		errorInfo.setData(null);
		errorInfo.setId("errorId");

		expect(clientResponse.getEntity(ErrorInfo.class)).andReturn(errorInfo);
		expect(clientResponse.getStatus()).andReturn(status.getStatusCode());

		return clientResponse;
	}
}
