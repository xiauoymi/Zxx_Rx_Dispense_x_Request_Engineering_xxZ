package com.esrx.ref.b2b.order.bo.impl;

import com.esrx.ref.order.GetOrderRequest;
import com.esrx.ref.order.GetOrderResponse;
import com.esrx.ref.order.jaxrs.OrderResource;
import com.express_scripts.inf.jersey.ResourceException;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;
import com.sun.jersey.api.client.ClientHandlerException;

public class OrderResourceAdapter {

	private OrderResource orderResource;
	private ExceptionStrategy exceptionStratergy;
	
	public void setExceptionStrategy(ExceptionStrategy exceptionStratergy) {
		this.exceptionStratergy = exceptionStratergy;
	}

	public void setOrderResource(OrderResource orderResource) {
		this.orderResource = orderResource;
	}

	/**
	 * This method will get the Order details from Order Service web service
	 * 
	 * @param getOrderStatusRequest
	 * @return
	 * @throws ProcessFailed
	 * @throws InvalidRequest
	 */
	public GetOrderResponse getOrder(GetOrderRequest getOrderRequest)
			throws ProcessFailed, InvalidRequest, NotFound {
		GetOrderResponse getOrderResponse = null;
		try {
			getOrderResponse = orderResource.getOrder(getOrderRequest);
		} catch(ClientHandlerException e) {
			exceptionStratergy.handleClientHandlerException(e);
		}catch (ResourceException e) {
			exceptionStratergy.handleResourceExceptionWithNotFound(e);
		}
		return getOrderResponse;
	}

}
