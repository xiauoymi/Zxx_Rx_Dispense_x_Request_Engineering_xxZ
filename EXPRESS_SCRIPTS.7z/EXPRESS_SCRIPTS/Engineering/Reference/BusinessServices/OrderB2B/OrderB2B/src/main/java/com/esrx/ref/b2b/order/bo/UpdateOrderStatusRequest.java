package com.esrx.ref.b2b.order.bo;

import java.io.Serializable;
import java.util.List;

public class UpdateOrderStatusRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2294677776911320783L;

	private List<Order> orderList;
	private Long timeout;


	public List<Order> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<Order> orderList) {
		this.orderList = orderList;
	}

	/**
	 * Gets the value of the timeout property.
	 * 
	 * @return
	 * 
	 */
	public Long getTimeout() {
		return timeout;
	}

	/**
	 * Sets the value of the timeout property.
	 * 
	 * @param value
	 * 
	 */
	public void setTimeout(Long value) {
		this.timeout = value;
	}

}
