package com.esrx.ref.b2b.order.bo;

import java.io.Serializable;

/**
 * This Order Info object contains the very basic and identifiable information
 * along with the update information such as Status
 */
public class Order implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4879301746991514395L;
	protected String orderId;
	protected OrderStatus status;

	/**
	 * Gets the value of the orderId property.
	 * 
	 * @return
	 * 
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * Sets the value of the orderId property.
	 * 
	 * @param value
	 * 
	 */
	public void setOrderId(String value) {
		this.orderId = value;
	}

	/**
	 * Gets the value of the status property. The status value is received to
	 * update this Order
	 * 
	 * @return Status
	 * 
	 */
	public OrderStatus getStatus() {
		return status;
	}

	/**
	 * Sets the value of the status property.
	 * 
	 * @param value
	 * 
	 */
	public void setStatus(OrderStatus value) {
		this.status = value;
	}

}
