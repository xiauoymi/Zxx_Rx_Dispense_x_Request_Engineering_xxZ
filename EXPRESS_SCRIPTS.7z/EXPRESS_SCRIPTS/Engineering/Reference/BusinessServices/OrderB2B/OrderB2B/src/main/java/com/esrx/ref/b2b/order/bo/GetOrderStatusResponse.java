package com.esrx.ref.b2b.order.bo;

import java.io.Serializable;

/**
 * 
 * 
 */
public class GetOrderStatusResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4868327003293417684L;

	private Order order;

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

}
