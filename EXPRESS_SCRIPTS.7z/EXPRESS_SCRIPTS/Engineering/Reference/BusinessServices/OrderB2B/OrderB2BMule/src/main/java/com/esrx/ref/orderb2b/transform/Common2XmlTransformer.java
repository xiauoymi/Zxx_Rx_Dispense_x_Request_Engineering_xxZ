package com.esrx.ref.orderb2b.transform;

import org.mule.api.MuleMessage;
import org.mule.message.DefaultExceptionPayload;
import org.mule.transformer.AbstractMessageTransformer;

import com.esrx.ref.order.UpdateOrderStatusRequest;
import com.express_scripts.inf.bind.MarshallerException;
import com.express_scripts.inf.deptracking.DependencyTrackingConstants;
import com.express_scripts.inf.protocols.common2.Envelope;
import com.express_scripts.inf.protocols.common2.HeaderType;
import com.express_scripts.inf.protocols.common2.NameValue;
import com.express_scripts.inf.protocols.common2.xml.bind.MarshallerImpl;
import com.express_scripts.inf.types.ProcessFailed;

public class Common2XmlTransformer extends AbstractMessageTransformer {
	
	private MarshallerImpl common2XmlMarshaller;
	private static String ORDER_B2B = "OrderB2B";
	
	@Override
	public Object transformMessage(MuleMessage muleMsg, String encoding){
		
		HeaderType header = new HeaderType();
		NameValue nv = new NameValue();
		nv.setName(DependencyTrackingConstants.CALLER_ID);
		nv.setValue(ORDER_B2B);
		header.getEntry().add(nv);
		Envelope envelope = new Envelope();
		UpdateOrderStatusRequest body = (UpdateOrderStatusRequest) muleMsg.getPayload();
		envelope.setBody(body);		
		envelope.setHeader(header);
		
		try {
			muleMsg.setPayload(common2XmlMarshaller.marshal(envelope));
		} catch (MarshallerException e) {
			handleException(e, muleMsg);
		}	
		return muleMsg;
	
	}
	
	private void handleException(Throwable cause, MuleMessage muleMsg){
		String msg = cause.getClass().getName() + ":" + cause.getMessage();
		muleMsg.setExceptionPayload(new DefaultExceptionPayload(new ProcessFailed(msg)));
	}	
}	
	

