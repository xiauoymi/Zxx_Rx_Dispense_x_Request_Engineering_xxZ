package com.esrx.ref.account.jaxws.impl;

import org.springframework.util.CollectionUtils;

import com.esrx.ref.account.Address;
import com.esrx.ref.account.ArrayOfAccount;
import com.esrx.ref.account.ArrayOfAddress;
import com.esrx.ref.account.ArrayOfCreditCard;
import com.esrx.ref.account.CreateAccountResponse;
import com.esrx.ref.account.CreateCreditCardResponse;
import com.esrx.ref.account.CreateShippingAddressResponse;
import com.esrx.ref.account.CreditCard;
import com.esrx.ref.account.FindAccountResponse;
import com.esrx.ref.account.FindCreditCardResponse;
import com.esrx.ref.account.FindShippingAddressResponse;
import com.esrx.ref.account.GetAccountResponse;
import com.esrx.ref.account.GetAddressResponse;
import com.esrx.ref.account.GetCreditCardResponse;
import com.esrx.ref.account.GetShippingAddressResponse;
import com.esrx.ref.account.UpdateCreditCardResponse;
import com.esrx.ref.account.UpdateShippingAddressResponse;
import com.esrx.ref.account.bo.Account;
import com.esrx.ref.account.bo.Status;

/**
 * 
 * @author p043459
 *
 */
public class ResponseTransformer {
	/**
	 * Convert from com.esrx.ref.account.bo.FindAccountResponse to com.esrx.ref.account.FindAccountResponse
	 * @param accountResponse
	 * @return
	 */
	public static FindAccountResponse convertToFindAccountResponse(com.esrx.ref.account.bo.FindAccountResponse accountResponse) {
		
		FindAccountResponse findAccountResponse = new FindAccountResponse();
		
		if(accountResponse != null){
			ArrayOfAccount arrayOfAccount = new ArrayOfAccount();
			for(Account account : accountResponse.getAccountList()){
				com.esrx.ref.account.Account resAccount = convertToAccount(account);
				arrayOfAccount.getAccount().add(resAccount);
			}
			findAccountResponse.setAccountList(arrayOfAccount);
			findAccountResponse.setTotalCount(accountResponse.getTotalCount());
		}
		
		return findAccountResponse;
	}
	/**
	 * Converts com.esrx.ref.account.bo.UpdateShippingAddressResponse to com.esrx.ref.account.UpdateShippingAddressResponse
	 * @param shippingAddressResponse
	 * @return
	 */
	public static UpdateShippingAddressResponse convertToUpdateShippingAddressResponse(
			com.esrx.ref.account.bo.UpdateShippingAddressResponse shippingAddressResponse) {
		UpdateShippingAddressResponse addressResponse = new UpdateShippingAddressResponse();
		if(shippingAddressResponse != null){
			addressResponse.setAddressId(shippingAddressResponse.getAddressId());
		}
		return addressResponse;
	}
	
	/**
	 * Converts com.esrx.ref.account.FindShippingAddressResponse to com.esrx.ref.account.bo.FindShippingAddressResponse
	 * @param findShippingAddressResponse
	 * @return
	 */
	public static FindShippingAddressResponse convertToFindShippingAddressResponse(
			com.esrx.ref.account.bo.FindShippingAddressResponse findShippingAddressResponse) {
		FindShippingAddressResponse addressResponse = new FindShippingAddressResponse();
		ArrayOfAddress arrayOfAddress = new ArrayOfAddress();
		if(findShippingAddressResponse != null && !CollectionUtils.isEmpty(findShippingAddressResponse.getAddressList())){
			for(com.esrx.ref.account.bo.Address address : findShippingAddressResponse.getAddressList()){
				Address resAddress = converToResAddress(address);
				arrayOfAddress.getAddress().add(resAddress);
			}
		}
		addressResponse.setAddressList(arrayOfAddress);
		addressResponse.setTotalCount(findShippingAddressResponse.getTotalCount());
		return addressResponse;
	}
	
	/**
	 * Converts com.esrx.ref.account.bo.CreateCreditCardResponse to com.esrx.ref.account.CreateCreditCardResponse
	 * @param createCreditCardResponse
	 * @return
	 */
	public static CreateCreditCardResponse convertToCreateCreditCardResponse(
			com.esrx.ref.account.bo.CreateCreditCardResponse createCreditCardResponse) {
		CreateCreditCardResponse creditCardResponse = new CreateCreditCardResponse();
		if(createCreditCardResponse != null){
			creditCardResponse.setCreditCardId(createCreditCardResponse.getCreditCardId());
		}
		return creditCardResponse;
	}
	
	/**
	 * Converts com.esrx.ref.account.bo.CreateShippingAddressResponse to com.esrx.ref.account.CreateShippingAddressResponse
	 * @param createShippingAddressResponse
	 * @return
	 */
	public static CreateShippingAddressResponse convertToCreateShippingAddressResponse(
			com.esrx.ref.account.bo.CreateShippingAddressResponse createShippingAddressResponse) {
		CreateShippingAddressResponse response = new CreateShippingAddressResponse();
		if(createShippingAddressResponse != null){
			response.setAddressId(createShippingAddressResponse.getAddressId());
		}
		return response;
	}
	
	/**
	 * Converts com.esrx.ref.account.bo.GetCreditCardResponse to com.esrx.ref.account.GetCreditCardResponse
	 * @param creditCardResponse
	 * @return
	 */
	public static GetCreditCardResponse convertToGetCreditCardResponse(
			com.esrx.ref.account.bo.GetCreditCardResponse creditCardResponse) {
		GetCreditCardResponse cardResponse = new GetCreditCardResponse();
		if(creditCardResponse != null){
			CreditCard creditCard = convertToResCreditCard(creditCardResponse.getCreditCard());
			cardResponse.setCreditCard(creditCard);
		}
		return cardResponse;
	}
	/**
	 * Converts com.esrx.ref.account.bo.GetShippingAddressResponse to com.esrx.ref.account.GetShippingAddressResponse
	 * @param shippingAddressResponse
	 * @return
	 */
	public static GetShippingAddressResponse convertToGetShippingAddressResponse(
			com.esrx.ref.account.bo.GetShippingAddressResponse shippingAddressResponse) {
		GetShippingAddressResponse addressResponse = new GetShippingAddressResponse();
		if(shippingAddressResponse != null){
			Address address = converToResAddress(shippingAddressResponse.getAddress());
			addressResponse.setAddress(address);
		}	
		return addressResponse;
	}
	/**
	 * Convert com.esrx.ref.account.bo.CreateAccountResponse to com.esrx.ref.account.CreateAccountResponse
	 * @param createAccountResponse
	 * @return
	 */
	public static CreateAccountResponse convertToCreateAccountResponse(
			com.esrx.ref.account.bo.CreateAccountResponse createAccountResponse) {
		CreateAccountResponse response = new CreateAccountResponse();
		if(createAccountResponse != null){
			response.setAccountId(createAccountResponse.getAccountId());
		}
		return response;
	}
	/**
	 * Converts com.esrx.ref.account.bo.GetAccountResponse to com.esrx.ref.account.GetAccountResponse
	 * @param accountResponse
	 * @return
	 */
	public static GetAccountResponse convertToGetAccountresponse(
			com.esrx.ref.account.bo.GetAccountResponse accountResponse) {
		GetAccountResponse response = new GetAccountResponse();
		if(accountResponse != null){
			response.setAccount(convertToAccount(accountResponse.getAccount()));
		}		
		return response;
	}
	/**
	 * Converts com.esrx.ref.account.bo.UpdateCreditCardResponse to com.esrx.ref.account.UpdateCreditCardResponse
	 * @param creditCardResponse
	 * @return
	 */
	public static UpdateCreditCardResponse convertToUpdateCreditCardResponse(
			com.esrx.ref.account.bo.UpdateCreditCardResponse creditCardResponse) {
		UpdateCreditCardResponse cardResponse = new UpdateCreditCardResponse();
		if(creditCardResponse != null){
			cardResponse.setCreditCardId(creditCardResponse.getCreditCardId());
		}
		return cardResponse;
	}
	/**
	 * Converts com.esrx.ref.account.bo.FindCreditCardResponse to com.esrx.ref.account.FindCreditCardResponse
	 * @param findCreditCardResponse
	 * @return
	 */
	public static FindCreditCardResponse convertToFindCreditCardResponse(
			com.esrx.ref.account.bo.FindCreditCardResponse findCreditCardResponse) {
		
		FindCreditCardResponse cardResponse = new FindCreditCardResponse();
		
		ArrayOfCreditCard arrayOfCreditCard = new ArrayOfCreditCard();
		if(findCreditCardResponse != null && !CollectionUtils.isEmpty(findCreditCardResponse.getCreditCardList())){
			for(com.esrx.ref.account.bo.CreditCard creditCard : findCreditCardResponse.getCreditCardList()){
				CreditCard resCreditcard = convertToResCreditCard(creditCard);
				arrayOfCreditCard.getCreditCard().add(resCreditcard);
			}
		}
		cardResponse.setCreditCardList(arrayOfCreditCard);
		cardResponse.setTotalCount(findCreditCardResponse.getTotalCount());
		return cardResponse;
	}
	
	
	/**
	 * Convert from com.esrx.ref.account.bo.Account to com.esrx.ref.account.Account
	 * @param account
	 * @return 
	 */
	private static com.esrx.ref.account.Account convertToAccount(Account account) {
		com.esrx.ref.account.Account resAccount = new com.esrx.ref.account.Account();
		if(account != null){
			resAccount.setAccountId(account.getAccountId());
			resAccount.setAccountNumber(account.getAccountNumber());
			resAccount.setDateOfBirth(account.getDateOfBirth());
			resAccount.setEmailAddress(account.getEmailAddress());
			resAccount.setFirstName(account.getFirstName());
			resAccount.setLastName(account.getLastName());
			resAccount.setUsername(account.getUsername());
		}
		return resAccount;
	}
	
	

	/**
	 * Converts com.esrx.ref.account.bo.CreditCard to com.esrx.ref.account.CreditCard
	 * @param creditCard
	 * @return
	 */
	private static CreditCard convertToResCreditCard(
			com.esrx.ref.account.bo.CreditCard creditCard) {
		CreditCard card = new CreditCard();
		if(creditCard != null){
			card.setStatus(conevrtToActiveInactive(creditCard.getStatus()));
			card.setAlias(creditCard.getAlias());
			card.setCreditCardId(creditCard.getCreditCardId());
			card.setCreditCardNumber(creditCard.getCreditCardNumber());
			card.setExpirationMonth(creditCard.getExpirationMonth());
			card.setExpirationYear(creditCard.getExpirationYear());
			card.setCreditCardType(com.esrx.ref.account.CreditCardType.fromValue(creditCard.getCreditCardType().toString()));
			card.setNameOnCard(creditCard.getNameOnCard());
			Address address = converToResAddress(creditCard.getBillingAddress());
			card.setBillingAddress(address);
		}
		return card;
	}
	
	private static Address converToResAddress(com.esrx.ref.account.bo.Address address){
		Address resAddress = new Address();
		if(address != null){
			resAddress.setAddressId(address.getAddressId());
			resAddress.setCity(address.getCity());
			resAddress.setLine1(address.getLine1());
			resAddress.setLine2(address.getLine2());
			resAddress.setLine3(address.getLine3());
			resAddress.setLine4(address.getLine4());
			resAddress.setName(address.getName());
			resAddress.setState(address.getState());
			resAddress.setStatus(com.esrx.ref.account.Status.valueOf(address.getStatus().value()));
			resAddress.setZip4(address.getZip4());
			resAddress.setZip5(address.getZip5());
		}
		return resAddress;
	}
	
	/**
	 * 
	 * @param active
	 * @return
	 */
	private static com.esrx.ref.account.Status conevrtToActiveInactive(
			Status active) {
		if(Status.ACTIVE == active)
		{
			return com.esrx.ref.account.Status.ACTIVE;
		}
		return com.esrx.ref.account.Status.INACTIVE;
	}
	public static GetAddressResponse convertToGetAddressResponse(
			com.esrx.ref.account.bo.GetAddressResponse getAddressResponse) {
		GetAddressResponse addressResponse = null;
		if(getAddressResponse != null){
			addressResponse = new GetAddressResponse();
			addressResponse.setAddress(converToResAddress(getAddressResponse.getAddress()));			
		}
		return addressResponse;
	}
	

}
