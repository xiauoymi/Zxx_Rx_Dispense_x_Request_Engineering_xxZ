package com.esrx.ref.account.jaxws.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import com.esrx.ref.account.ArrayOfStatus;
import com.esrx.ref.account.ArrayOfString;
import com.esrx.ref.account.bo.Status;
import com.esrx.ref.account.ws.InvalidRequest;
import com.esrx.ref.account.ws.NotFound;
import com.esrx.ref.account.ws.ProcessFailed;
import com.esrx.ref.account.ws.ResourceUnavailable;

/**
 * @author p043459
 */
public class AccountUtil {
	

	/**
	 * Converts com.esrx.ref.account.ArrayOfString to com.esrx.ref.account.bo.ArrayOfString
	 * @param arrayOfString
	 * @return
	 */
	public static List<String> convertToBoArrayOfString(
			ArrayOfString arrayOfString) {
		List<String> boListOfString = new ArrayList<String>();
		if(arrayOfString != null && !CollectionUtils.isEmpty(arrayOfString.getValue()))
		for(String value :arrayOfString.getValue()){
			boListOfString.add(value);
		}
		return boListOfString;
	}
	
	public static List<Status> copyStatus(ArrayOfStatus active) {
		List<Status> status = new ArrayList<Status>();
		if(active != null){
			for(com.esrx.ref.account.Status status2:active.getStatus()){
				if(status2 == com.esrx.ref.account.Status.ALL){
					return new ArrayList<Status>();
				}
				status.add(Status.valueOf(status2.name()));
			}
		}
		return status;
	}
	
	public static InvalidRequest buildInvalidRequest(String message, String code, String id, String data){
		com.esrx.ref.account.InvalidRequest invalidRequest = new com.esrx.ref.account.InvalidRequest();
		/*invalidRequest.setCode(code);
		//TODO : Define strategy for data in exceptions.
		if(StringUtils.isNotBlank(data))
		invalidRequest.setData(data);
		invalidRequest.setId(id);
		invalidRequest.setMessage(message);*/
		
		return new InvalidRequest(message, invalidRequest);
		
	}
	public static NotFound buildNotFound(String message, String code, String id, String data){
		//ErrorInfo notFound = ErrorInfoFactory.create(code, message, id, data);
		com.esrx.ref.account.NotFound notFound = new com.esrx.ref.account.NotFound();
		notFound.setCode(code);
		//TODO : Define strategy for data in exceptions.
		notFound.setData(data);
		notFound.setId(id);
		notFound.setMessage(message);
		
		return new NotFound(message, notFound);
		
	}
	public static ResourceUnavailable buildResourceUnavailable(String message, String code, String id, String data){
		com.esrx.ref.account.ResourceUnavailable resourceUnavailable = new com.esrx.ref.account.ResourceUnavailable();
		resourceUnavailable.setCode(code);
		//TODO : Define strategy for data in exceptions.
		resourceUnavailable.setData(data);
		resourceUnavailable.setId(id);
		resourceUnavailable.setMessage(message);
		
		return new ResourceUnavailable(message, resourceUnavailable);
		
	}
	
	public static ProcessFailed buildProcessFailed(String message, String code, String id, String data){
		com.esrx.ref.account.ProcessFailed processFailed = new com.esrx.ref.account.ProcessFailed();
		processFailed.setCode(code);
		//TODO : Define strategy for data in exceptions.
		processFailed.setData(data);
		
		if(StringUtils.isBlank(id)){
			id = UUID.randomUUID().toString();
		}
		processFailed.setId(id);
		processFailed.setMessage(message);
		
		return new ProcessFailed(message, processFailed);
		
	}

}
