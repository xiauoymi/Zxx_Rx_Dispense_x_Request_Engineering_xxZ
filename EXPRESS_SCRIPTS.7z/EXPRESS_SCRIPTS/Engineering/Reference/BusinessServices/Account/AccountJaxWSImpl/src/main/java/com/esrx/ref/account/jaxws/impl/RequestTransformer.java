package com.esrx.ref.account.jaxws.impl;

import org.apache.commons.lang.StringUtils;

import com.esrx.ref.account.CreateAccountRequest;
import com.esrx.ref.account.CreateCreditCardRequest;
import com.esrx.ref.account.CreateShippingAddressRequest;
import com.esrx.ref.account.CreditCard;
import com.esrx.ref.account.FindAccountRequest;
import com.esrx.ref.account.FindCreditCardRequest;
import com.esrx.ref.account.FindShippingAddressRequest;
import com.esrx.ref.account.GetAccountRequest;
import com.esrx.ref.account.GetAddressRequest;
import com.esrx.ref.account.GetCreditCardRequest;
import com.esrx.ref.account.GetShippingAddressRequest;
import com.esrx.ref.account.UpdateAccountRequest;
import com.esrx.ref.account.UpdateCreditCardRequest;
import com.esrx.ref.account.UpdateShippingAddressRequest;
import com.esrx.ref.account.bo.Account;
import com.esrx.ref.account.bo.Address;
import com.esrx.ref.account.bo.Status;
import com.express_scripts.inf.types.jaxb.support.SortOptionsUtils;

/**
 * 
 * @author p043459
 *
 */
public class RequestTransformer {
	/**
	 * Convert com.esrx.ref.account.FindAccountRequest to com.esrx.ref.account.bo.FindAccountRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.FindAccountRequest convertToBoFindAccountRequest(FindAccountRequest request) {
		
		com.esrx.ref.account.bo.FindAccountRequest accountRequest = null;
		
		if(request != null){
			accountRequest = new com.esrx.ref.account.bo.FindAccountRequest();
			accountRequest.setCount(request.getCount());
			accountRequest.setDateOfBirth(StringUtils.isNotBlank(request.getDateOfBirth()) ? request.getDateOfBirth() : StringUtils.EMPTY);
			accountRequest.setEmailAddress(StringUtils.isNotBlank(request.getEmailAddress()) ? request.getEmailAddress() : StringUtils.EMPTY);
			accountRequest.setFirstName(StringUtils.isNotBlank(request.getFirstName()) ? request.getFirstName() : StringUtils.EMPTY);
			accountRequest.setLastName(StringUtils.isNotBlank(request.getLastName()) ? request.getLastName() : StringUtils.EMPTY);
			accountRequest.setUsername(StringUtils.isNotBlank(request.getUsername()) ? request.getUsername() : StringUtils.EMPTY);
			accountRequest.setOffset(request.getOffset());
			accountRequest.setMatchCase(request.isMatchCase());
			accountRequest.setSortOptions(SortOptionsUtils.convertToListSortOptions(request.getSortOptions()));
			
			accountRequest.setTimeout(request.getTimeout());
		}
		
		return accountRequest;
	}
	
	/**
	 * Converts com.esrx.ref.account.CreateCreditCardRequest to com.esrx.ref.account.bo.CreateCreditCardRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.CreateCreditCardRequest convertToCreateCreditCardRequest(
			CreateCreditCardRequest request) {
		com.esrx.ref.account.bo.CreateCreditCardRequest cardRequest = null;
		
		if(request != null){
			cardRequest = new com.esrx.ref.account.bo.CreateCreditCardRequest();
			com.esrx.ref.account.bo.CreditCard creditCard = convertToBoCreditCard(request.getCreditCard());
			cardRequest.setAccountId(request.getAccountId());
			cardRequest.setCreditCard(creditCard);
			cardRequest.setTimeout(request.getTimeout());
		}
		
		return cardRequest;
	}
	
	/**
	 * Converts com.esrx.ref.account.UpdateShippingAddressRequest to com.esrx.ref.account.bo.UpdateShippingAddressRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.UpdateShippingAddressRequest convertToUpdateShippingAddressRequest(
			UpdateShippingAddressRequest request) {
		com.esrx.ref.account.bo.UpdateShippingAddressRequest addressRequest = null;
		if(request != null){
			addressRequest = new com.esrx.ref.account.bo.UpdateShippingAddressRequest();
			com.esrx.ref.account.bo.Address address = convertToBoAddress(request.getAddress());
			addressRequest.setAccountId(request.getAccountId());
			addressRequest.setAddress(address);
			addressRequest.setTimeout(request.getTimeout());
		}
		return addressRequest;
	}
	/**
	 * Converts com.esrx.ref.account.FindShippingAddressRequest to com.esrx.ref.account.bo.FindShippingAddressRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.FindShippingAddressRequest convertToFindShippingAddressRequest(
			FindShippingAddressRequest request) {
		com.esrx.ref.account.bo.FindShippingAddressRequest findShippingAddressRequest = null;
		if(request != null){
			findShippingAddressRequest = new com.esrx.ref.account.bo.FindShippingAddressRequest();
			findShippingAddressRequest.setAccountId(request.getAccountId());
			findShippingAddressRequest.setStatus(AccountUtil.copyStatus(request.getStatusList()));
			findShippingAddressRequest.setCount(request.getCount());
			findShippingAddressRequest.setMatchCase(request.isMatchCase());
			findShippingAddressRequest.setOffset(request.getOffset());
			findShippingAddressRequest.setSortOptions(SortOptionsUtils.convertToListSortOptions(request.getSortOptions()));
			findShippingAddressRequest.setTimeout(request.getTimeout());
		}
		return findShippingAddressRequest;
	}
	/**
	 * Converts com.esrx.ref.account.CreateShippingAddressRequest to com.esrx.ref.account.bo.CreateShippingAddressRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.CreateShippingAddressRequest convertToCreateShippingAddressRequest(
			CreateShippingAddressRequest request) {
		com.esrx.ref.account.bo.CreateShippingAddressRequest createShippingAddressRequest = null;
		if(request != null){
			createShippingAddressRequest = new com.esrx.ref.account.bo.CreateShippingAddressRequest();
			com.esrx.ref.account.bo.Address address = convertToBoAddress(request.getAddress());
			createShippingAddressRequest.setAddress(address);
			createShippingAddressRequest.setAccountId(request.getAccountId());
			createShippingAddressRequest.setTimeout(request.getTimeout());
		}
		return createShippingAddressRequest;
	}
	
	/**
	 * Converts com.esrx.ref.account.FindCreditCardRequest to com.esrx.ref.account.bo.FindCreditCardRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.FindCreditCardRequest convertToFindCreditCardRequest(
			FindCreditCardRequest request) {
		com.esrx.ref.account.bo.FindCreditCardRequest cardRequest = null;
		if(request != null){
			cardRequest = new com.esrx.ref.account.bo.FindCreditCardRequest();
			cardRequest.setAccountId(request.getAccountId());
			cardRequest.setStatus(AccountUtil.copyStatus(request.getStatusList()));
			cardRequest.setCount(request.getCount());
			cardRequest.setMatchCase(request.isMatchCase());
			cardRequest.setSortOptions(SortOptionsUtils.convertToListSortOptions(request.getSortOptions()));
			cardRequest.setOffset(request.getOffset());
			cardRequest.setTimeout(request.getTimeout());
		}
		return cardRequest;
	}
	
	/**
	 * Converts com.esrx.ref.account.UpdateCreditCardRequest to com.esrx.ref.account.bo.UpdateCreditCardRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.UpdateCreditCardRequest convertToUpdateCreditCardRequest(
			UpdateCreditCardRequest request) {
		com.esrx.ref.account.bo.UpdateCreditCardRequest cardRequest = new com.esrx.ref.account.bo.UpdateCreditCardRequest();
		if(request != null){
			com.esrx.ref.account.bo.CreditCard creditCard = convertToBoCreditCard(request.getCreditCard());
			cardRequest.setCreditCard(creditCard);
			cardRequest.setAccountId(request.getAccountId());
			cardRequest.setTimeout(request.getTimeout());
		}
		return cardRequest;
	}
	
	/**
	 * Converts com.esrx.ref.account.UpdateAccountRequest to com.esrx.ref.account.bo.UpdateAccountRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.UpdateAccountRequest convertToUpdateAccountRequest(
			UpdateAccountRequest request) {
		com.esrx.ref.account.bo.UpdateAccountRequest accountRequest = null;
		if(request != null){
			accountRequest = new com.esrx.ref.account.bo.UpdateAccountRequest();
			accountRequest.setAccount(convertToBoAccount(request.getAccount()));
			accountRequest.setTimeout(request.getTimeout());
		}
		return accountRequest;
	}
	/**
	 * Converts com.esrx.ref.account.GetCreditCardRequest to com.esrx.ref.account.bo.GetCreditCardRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.GetCreditCardRequest convertToGetCreditCardRequest(
			GetCreditCardRequest request) {
		com.esrx.ref.account.bo.GetCreditCardRequest cardRequest = null;
		if(request != null){
			cardRequest = new com.esrx.ref.account.bo.GetCreditCardRequest();
			cardRequest.setCreditCardId(request.getCreditCardId());
			cardRequest.setAccountId(request.getAccountId());
			cardRequest.setTimeout(request.getTimeout());
		}
		return cardRequest;
	}
	
	/**
	 * Convert com.esrx.ref.account.GetShippingAddressRequest to com.esrx.ref.account.bo.GetShippingAddressRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.GetShippingAddressRequest convertToGetShippingAddressRequest(
			GetShippingAddressRequest request) {
		com.esrx.ref.account.bo.GetShippingAddressRequest addressRequest = null;
		if(request != null){
			addressRequest = new com.esrx.ref.account.bo.GetShippingAddressRequest();
			addressRequest.setAccountId(request.getAccountId());
			addressRequest.setAddressId(request.getAddressId());
			addressRequest.setTimeout(request.getTimeout());
		}
		return addressRequest;
	}
	/**
	 * Converts com.esrx.ref.account.GetAccountRequest to com.esrx.ref.account.bo.GetAccountRequest
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.GetAccountRequest convertToBoGetAccountRequest(
			GetAccountRequest request) {
		com.esrx.ref.account.bo.GetAccountRequest accountRequest = null;
		if(request != null){
			accountRequest = new com.esrx.ref.account.bo.GetAccountRequest();
			accountRequest.setAccountId(request.getAccountId());
			accountRequest.setTimeout(request.getTimeout());
		}
		
		return accountRequest;
	}
	/**
	 * Converts com.esrx.ref.account.CreateAccountRequest to com.esrx.ref.account.bo.CreateAccountRequest.
	 * @param request
	 * @param defaultTimeOut 
	 * @return
	 */
	public static com.esrx.ref.account.bo.CreateAccountRequest convertToCreateAccountRequest(
			CreateAccountRequest request) {
		
		com.esrx.ref.account.bo.CreateAccountRequest createAccountRequest = null;
		if(request != null){
			createAccountRequest = new com.esrx.ref.account.bo.CreateAccountRequest();
			createAccountRequest.setAccount(convertToBoAccount(request.getAccount()));
			createAccountRequest.setTimeout(request.getTimeout());
		}
		return createAccountRequest;
	}
	
	/**
	 * Converts com.esrx.ref.account.CreditCard to com.esrx.ref.account.bo.CreditCard
	 * @param creditCard
	 * @return
	 */
	private static com.esrx.ref.account.bo.CreditCard convertToBoCreditCard(
			CreditCard creditCard) {
		com.esrx.ref.account.bo.CreditCard card = null;
		if(creditCard != null){
			card = new com.esrx.ref.account.bo.CreditCard();
			if (creditCard.getStatus() != null) {
				card.setStatus(Status.fromValue(creditCard.getStatus().value()));
			}
			card.setAlias(creditCard.getAlias());
			card.setCreditCardId(creditCard.getCreditCardId());
			card.setCreditCardNumber(creditCard.getCreditCardNumber());
			card.setExpirationMonth(creditCard.getExpirationMonth());
			card.setExpirationYear(creditCard.getExpirationYear());
			if (creditCard.getCreditCardType() != null) {
				card.setCreditCardType(com.esrx.ref.account.bo.CreditCardtype.fromValue(creditCard.getCreditCardType().toString()));
			}
			card.setNameOnCard(creditCard.getNameOnCard());
			com.esrx.ref.account.bo.Address address =  convertToBoAddress(creditCard.getBillingAddress());
			card.setBillingAddress(address);
		}
		return card;
	}
	/**
	 * Converts com.esrx.ref.account.Account to com.esrx.ref.account.bo.Account
	 * @param account
	 * @return
	 */
	private static Account convertToBoAccount(
			com.esrx.ref.account.Account account) {
		com.esrx.ref.account.bo.Account resAccount = null;
		if(account != null ){
			resAccount = new com.esrx.ref.account.bo.Account();
			resAccount.setAccountId(account.getAccountId());
			resAccount.setAccountNumber(account.getAccountNumber());
			resAccount.setDateOfBirth(account.getDateOfBirth());
			resAccount.setEmailAddress(account.getEmailAddress());
			resAccount.setFirstName(account.getFirstName());
			resAccount.setLastName(account.getLastName());
			resAccount.setUsername(account.getUsername());
		}
		return resAccount;
	}
	
	/**
	 * Converts com.esrx.ref.account.Account to com.esrx.ref.account.bo.Account
	 * @param account
	 * @return
	 */
	private static Address convertToBoAddress(
			com.esrx.ref.account.Address address) {
		com.esrx.ref.account.bo.Address resAddress = null;
		if(address != null){
			resAddress = new com.esrx.ref.account.bo.Address();
			resAddress.setAddressId(address.getAddressId());
			resAddress.setCity(address.getCity());
			resAddress.setLine1(address.getLine1());
			resAddress.setLine2(address.getLine2());
			resAddress.setLine3(address.getLine3());
			resAddress.setLine4(address.getLine4());
			resAddress.setName(address.getName());
			resAddress.setState(address.getState());
			if (address.getStatus() != null) {
				resAddress.setStatus(Status.valueOf(address.getStatus().value()));
			}
			resAddress.setZip4(address.getZip4());
			resAddress.setZip5(address.getZip5());
		}
		return resAddress;
	}

	public static com.esrx.ref.account.bo.GetAddressRequest convettoGetAddressRequest(
			GetAddressRequest getAddressRequest) {
		com.esrx.ref.account.bo.GetAddressRequest addressRequest = null;
		if(getAddressRequest != null){
			addressRequest = new com.esrx.ref.account.bo.GetAddressRequest();
			addressRequest.setAddressId(getAddressRequest.getAddressId());
			addressRequest.setTimeout(getAddressRequest.getTimeout());
		}
		return addressRequest;
	}
}
