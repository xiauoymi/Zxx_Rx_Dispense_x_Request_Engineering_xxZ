package com.esrx.ref.account.jaxws.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.esrx.ref.account.ArrayOfStatus;
import com.esrx.ref.account.CreateAccountRequest;
import com.esrx.ref.account.CreateCreditCardRequest;
import com.esrx.ref.account.CreateShippingAddressRequest;
import com.esrx.ref.account.CreditCard;
import com.esrx.ref.account.CreditCardType;
import com.esrx.ref.account.FindAccountRequest;
import com.esrx.ref.account.FindAccountResponse;
import com.esrx.ref.account.FindCreditCardRequest;
import com.esrx.ref.account.FindShippingAddressRequest;
import com.esrx.ref.account.GetAccountRequest;
import com.esrx.ref.account.GetCreditCardRequest;
import com.esrx.ref.account.GetShippingAddressRequest;
import com.esrx.ref.account.Status;
import com.esrx.ref.account.UpdateCreditCardRequest;
import com.esrx.ref.account.UpdateCreditCardResponse;
import com.esrx.ref.account.UpdateShippingAddressRequest;
import com.esrx.ref.account.bo.Account;
import com.esrx.ref.account.bo.AccountBo;
import com.esrx.ref.account.bo.CreateAccountResponse;
import com.esrx.ref.account.bo.CreateCreditCardResponse;
import com.esrx.ref.account.bo.CreateShippingAddressResponse;
import com.esrx.ref.account.bo.FindCreditCardResponse;
import com.esrx.ref.account.bo.FindShippingAddressResponse;
import com.esrx.ref.account.bo.GetAccountResponse;
import com.esrx.ref.account.bo.GetCreditCardResponse;
import com.esrx.ref.account.bo.GetShippingAddressResponse;
import com.esrx.ref.account.bo.UpdateShippingAddressResponse;
import com.esrx.ref.account.bo.impl.AccountBoImpl;
import com.esrx.ref.account.ws.InvalidRequest;
import com.esrx.ref.account.ws.ProcessFailed;
import com.esrx.ref.account.ws.ResourceUnavailable;
import com.express_scripts.inf.types.NotFound;

public class AccountServiceImplTest {

	AccountServiceImpl accountServiceImpl = new AccountServiceImpl();

	AccountBo accountBoMock = EasyMock.createMock(AccountBoImpl.class);

	@Before
	public void setup() {
		EasyMock.reset(accountBoMock);
		accountServiceImpl.setAccountImpl(accountBoMock);
	}
	@Test
	public void testFindAccount() throws InvalidRequest, ProcessFailed,
			ResourceUnavailable, com.express_scripts.inf.types.ProcessFailed, com.express_scripts.inf.types.InvalidRequest {
		FindAccountRequest accountRequest = new FindAccountRequest();
		accountRequest.setFirstName("S%");
		EasyMock.expect(
				accountBoMock.findAccount(EasyMock
						.anyObject(com.esrx.ref.account.bo.FindAccountRequest.class)))
				.andReturn(buildFindAccountResponse());
		EasyMock.replay(accountBoMock);
		FindAccountResponse accountResponse = accountServiceImpl
				.findAccount(accountRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(accountResponse);
		assertNotNull(accountResponse.getAccountList());
	}

	@Test
	public void testGetAccount() throws NotFound,
			InvalidRequest, com.esrx.ref.account.ws.NotFound, ProcessFailed,
			ResourceUnavailable, com.express_scripts.inf.types.InvalidRequest {
		GetAccountRequest accountRequest = new GetAccountRequest();
		accountRequest.setAccountId("1");
		EasyMock.expect(
				accountBoMock.getAccount(EasyMock
						.anyObject(com.esrx.ref.account.bo.GetAccountRequest.class)))
				.andReturn(buildGetAccountResponse());
		EasyMock.replay(accountBoMock);
		com.esrx.ref.account.GetAccountResponse accountResponse = accountServiceImpl
				.getAccount(accountRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(accountResponse);
	}
	
	@Test
	public void testCreateAccount() throws com.express_scripts.inf.types.InvalidRequest, InvalidRequest, ProcessFailed, ResourceUnavailable{
		CreateAccountRequest accountRequest = new CreateAccountRequest();
		accountRequest.setAccount(buildAccountReq(null, "test"));
		EasyMock.expect(
				accountBoMock.createAccount(EasyMock
						.anyObject(com.esrx.ref.account.bo.CreateAccountRequest.class)))
				.andReturn(buildCreateAccountResponse());
		EasyMock.replay(accountBoMock);
		com.esrx.ref.account.CreateAccountResponse accountResponse = accountServiceImpl.createAccount(accountRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(accountResponse);
		assertEquals("2", accountResponse.getAccountId());
	}
	
	@Test
	public void testFindCreditCard() throws com.express_scripts.inf.types.InvalidRequest, InvalidRequest, ProcessFailed, ResourceUnavailable{
		FindCreditCardRequest cardRequest = new FindCreditCardRequest();
		cardRequest.setAccountId("1");
		ArrayOfStatus arrayOfStatus = new ArrayOfStatus();
		arrayOfStatus.getStatus().add(Status.ACTIVE);
		cardRequest.setStatusList(arrayOfStatus);
		EasyMock.expect(
				accountBoMock.findCreditCard(EasyMock
						.anyObject(com.esrx.ref.account.bo.FindCreditCardRequest.class)))
				.andReturn(buildCreditCardResponse());
		EasyMock.replay(accountBoMock);
		com.esrx.ref.account.FindCreditCardResponse cardResponse = accountServiceImpl.findCreditCard(cardRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(cardResponse);
	}
	
	@Test
	public void testGetCreditCard() throws com.express_scripts.inf.types.InvalidRequest, NotFound, InvalidRequest, com.esrx.ref.account.ws.NotFound, ProcessFailed, ResourceUnavailable{
		GetCreditCardRequest cardRequest = new GetCreditCardRequest();
		cardRequest.setAccountId("1");
		cardRequest.setCreditCardId("1");
		EasyMock.expect(
				accountBoMock.getCreditCard(EasyMock
						.anyObject(com.esrx.ref.account.bo.GetCreditCardRequest.class)))
				.andReturn(new GetCreditCardResponse());
		EasyMock.replay(accountBoMock);
		com.esrx.ref.account.GetCreditCardResponse cardResponse = accountServiceImpl.getCreditCard(cardRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(cardResponse);
	}
	
	@Test
	public void testFindShippingAddress() throws com.express_scripts.inf.types.InvalidRequest, InvalidRequest, ProcessFailed, ResourceUnavailable{
		FindShippingAddressRequest addressRequest = new FindShippingAddressRequest();
		addressRequest.setAccountId("1");
		ArrayOfStatus arrayOfStatus = new ArrayOfStatus();
		arrayOfStatus.getStatus().add(Status.ACTIVE);
		addressRequest.setStatusList(arrayOfStatus);
		EasyMock.expect(
				accountBoMock.findShippingAddress(EasyMock
						.anyObject(com.esrx.ref.account.bo.FindShippingAddressRequest.class)))
				.andReturn(new FindShippingAddressResponse());
		EasyMock.replay(accountBoMock);
		com.esrx.ref.account.FindShippingAddressResponse cardResponse = accountServiceImpl.findShippingAddress(addressRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(cardResponse);
	}
	
	@Test
	public void testGetShippingAddress() throws com.express_scripts.inf.types.InvalidRequest, NotFound, InvalidRequest, com.esrx.ref.account.ws.NotFound, ProcessFailed, ResourceUnavailable{
		GetShippingAddressRequest cardRequest = new GetShippingAddressRequest();
		cardRequest.setAccountId("1");
		cardRequest.setAddressId("1");
		EasyMock.expect(
				accountBoMock.getShippingAddress(EasyMock
						.anyObject(com.esrx.ref.account.bo.GetShippingAddressRequest.class)))
				.andReturn(new GetShippingAddressResponse());
		EasyMock.replay(accountBoMock);
		com.esrx.ref.account.GetShippingAddressResponse cardResponse = accountServiceImpl.getShippingAddress(cardRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(cardResponse);
	}

	@Test
	public void testCreateCreditCard() throws com.express_scripts.inf.types.InvalidRequest, InvalidRequest, ProcessFailed, ResourceUnavailable{
		CreateCreditCardRequest cardRequest = new CreateCreditCardRequest();
		cardRequest.setAccountId("1");
		cardRequest.setCreditCard(buildCreditCard());
		CreateCreditCardResponse cardResponse1 = new CreateCreditCardResponse();
		cardResponse1.setCreditCardId("1");
		EasyMock.expect(
				accountBoMock.createCreditCard(EasyMock
						.anyObject(com.esrx.ref.account.bo.CreateCreditCardRequest.class)))
				.andReturn(cardResponse1);
		EasyMock.replay(accountBoMock);
		com.esrx.ref.account.CreateCreditCardResponse cardResponse = accountServiceImpl.createCreditCard(cardRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(cardResponse);
		assertEquals("1", cardResponse.getCreditCardId());
	}
	
	@Test
	public void testUpdateCreditCard() throws com.express_scripts.inf.types.InvalidRequest, InvalidRequest, ProcessFailed, ResourceUnavailable{
		UpdateCreditCardRequest cardRequest = new UpdateCreditCardRequest();
		cardRequest.setAccountId("1");
		cardRequest.setCreditCard(buildCreditCard());
		com.esrx.ref.account.bo.UpdateCreditCardResponse cardResponse1 = new com.esrx.ref.account.bo.UpdateCreditCardResponse();
		cardResponse1.setCreditCardId("1");
		EasyMock.expect(
				accountBoMock.updateCreditCard(EasyMock
						.anyObject(com.esrx.ref.account.bo.UpdateCreditCardRequest.class)))
				.andReturn(cardResponse1);
		EasyMock.replay(accountBoMock);
		UpdateCreditCardResponse cardResponse = accountServiceImpl.updateCreditCard(cardRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(cardResponse);
		assertEquals("1", cardResponse.getCreditCardId());
	}
	
	@Test
	public void testCreateShippingAddress() throws com.express_scripts.inf.types.InvalidRequest, InvalidRequest, ProcessFailed, ResourceUnavailable{
		CreateShippingAddressRequest cardRequest = new CreateShippingAddressRequest();
		cardRequest.setAccountId("1");
		cardRequest.setAddress(buildAddress(null, "63043"));
		CreateShippingAddressResponse cardResponse1 = new CreateShippingAddressResponse();
		cardResponse1.setAddressId("1");
		EasyMock.expect(
				accountBoMock.createShippingAddress(EasyMock
						.anyObject(com.esrx.ref.account.bo.CreateShippingAddressRequest.class)))
				.andReturn(cardResponse1);
		EasyMock.replay(accountBoMock);
		com.esrx.ref.account.CreateShippingAddressResponse cardResponse = accountServiceImpl.createShippingAddress(cardRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(cardResponse);
		assertEquals("1", cardResponse.getAddressId());
	}
	
	@Test
	public void testUpdateShippingAddress() throws com.express_scripts.inf.types.InvalidRequest, InvalidRequest, ProcessFailed, ResourceUnavailable, NotFound{
		UpdateShippingAddressRequest cardRequest = new UpdateShippingAddressRequest();
		cardRequest.setAccountId("1");
		cardRequest.setAddress(buildAddress(null, "63043"));
		UpdateShippingAddressResponse cardResponse1 = new UpdateShippingAddressResponse();
		cardResponse1.setAddressId("2");
		EasyMock.expect(
				accountBoMock.updateShippingAddress(EasyMock
						.anyObject(com.esrx.ref.account.bo.UpdateShippingAddressRequest.class)))
				.andReturn(cardResponse1);
		EasyMock.replay(accountBoMock);
		com.esrx.ref.account.UpdateShippingAddressResponse cardResponse = accountServiceImpl.updateShippingAddress(cardRequest);
		EasyMock.verify(accountBoMock);
		assertNotNull(cardResponse);
		assertEquals("2", cardResponse.getAddressId());
	}

	private CreditCard buildCreditCard() {
		CreditCard card = new CreditCard();
		card.setAlias("TEST");
		card.setBillingAddress(buildAddress("2", "63042"));
		card.setCreditCardNumber("123564789");
		card.setCreditCardType(CreditCardType.VIS);
		card.setExpirationMonth("01");
		card.setExpirationYear("2012");
		card.setNameOnCard("TEST");
		card.setStatus(Status.ACTIVE);
		return card;
	}
	private com.esrx.ref.account.Address buildAddress(String addressId, String zip) {
		com.esrx.ref.account.Address address = new com.esrx.ref.account.Address();
		address.setAddressId(addressId);
		address.setCity("LA");
		address.setLine1("Line 1");
		address.setName("Test");
		address.setState("CA");
		address.setStatus(Status.ACTIVE);
		address.setZip4("");
		address.setZip5(zip);
		
		return address;
	}

	private FindCreditCardResponse buildCreditCardResponse() {
		FindCreditCardResponse cardResponse = new FindCreditCardResponse();
		return cardResponse;
	}

	private CreateAccountResponse buildCreateAccountResponse() {
		CreateAccountResponse accountResponse = new CreateAccountResponse();
		accountResponse.setAccountId("2");
		return accountResponse;
	}

	private GetAccountResponse buildGetAccountResponse() {
		GetAccountResponse accountResponse = new GetAccountResponse();
		accountResponse.setAccount(buildAccount("1", "Test"));
		return accountResponse;
	}

	private com.esrx.ref.account.bo.FindAccountResponse buildFindAccountResponse() {
		com.esrx.ref.account.bo.FindAccountResponse accountResponse = new com.esrx.ref.account.bo.FindAccountResponse();
		accountResponse.setTotalCount(10);
		accountResponse.setAccountList(buildListAccounts());
		return accountResponse;
	}

	private List<Account> buildListAccounts() {
		List<Account> accounts = new ArrayList<Account>();
		accounts.add(buildAccount("1", " Test"));
		return accounts;
	}

	private Account buildAccount(String accountId, String firstName) {
		Account account = new Account();
		account.setAccountId(accountId);
		account.setAccountNumber("1234");
		account.setDateOfBirth("2012-02-01");
		account.setEmailAddress("a.b@c.com");
		account.setFirstName(firstName);
		account.setLastName("lastName");
		account.setUsername("p02222");
		return account;
	}
	private com.esrx.ref.account.Account buildAccountReq(String accountId, String firstName) {
		com.esrx.ref.account.Account account = new com.esrx.ref.account.Account();
		account.setAccountId(accountId);
		account.setAccountNumber("1234");
		account.setDateOfBirth("2012-02-01");
		account.setEmailAddress("a.b@c.com");
		account.setFirstName(firstName);
		account.setLastName("lastName");
		account.setUsername("p02222");
		return account;
	}

}
