/**
 * 
 */
package com.esrx.ref.account.jaxws.impl;

import javax.jws.WebService;

import org.hibernate.QueryTimeoutException;

import com.esrx.ref.account.CreateAccountRequest;
import com.esrx.ref.account.CreateAccountResponse;
import com.esrx.ref.account.CreateCreditCardRequest;
import com.esrx.ref.account.CreateCreditCardResponse;
import com.esrx.ref.account.CreateShippingAddressRequest;
import com.esrx.ref.account.CreateShippingAddressResponse;
import com.esrx.ref.account.FindAccountRequest;
import com.esrx.ref.account.FindAccountResponse;
import com.esrx.ref.account.FindCreditCardRequest;
import com.esrx.ref.account.FindCreditCardResponse;
import com.esrx.ref.account.FindShippingAddressRequest;
import com.esrx.ref.account.FindShippingAddressResponse;
import com.esrx.ref.account.GetAccountRequest;
import com.esrx.ref.account.GetAccountResponse;
import com.esrx.ref.account.GetAddressRequest;
import com.esrx.ref.account.GetAddressResponse;
import com.esrx.ref.account.GetCreditCardRequest;
import com.esrx.ref.account.GetCreditCardResponse;
import com.esrx.ref.account.GetShippingAddressRequest;
import com.esrx.ref.account.GetShippingAddressResponse;
import com.esrx.ref.account.UpdateAccountRequest;
import com.esrx.ref.account.UpdateAccountResponse;
import com.esrx.ref.account.UpdateCreditCardRequest;
import com.esrx.ref.account.UpdateCreditCardResponse;
import com.esrx.ref.account.UpdateShippingAddressRequest;
import com.esrx.ref.account.UpdateShippingAddressResponse;
import com.esrx.ref.account.bo.AccountBo;
import com.esrx.ref.account.bo.impl.Constants;
import com.esrx.ref.account.bo.impl.ErrorCodes;
import com.esrx.ref.account.ws.AccountService;
import com.esrx.ref.account.ws.InvalidRequest;
import com.esrx.ref.account.ws.NotFound;
import com.esrx.ref.account.ws.ProcessFailed;
import com.esrx.ref.account.ws.ResourceUnavailable;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;

/**
 * @author p043459 Service impl class responsible for contacting the business
 *         module.
 */
@WebService(serviceName = "AccountService", portName = "AccountService", targetNamespace = "http://ws.account.ref.esrx.com", endpointInterface = "com.esrx.ref.account.ws.AccountService")
public class AccountServiceImpl implements AccountService {

	private AccountBo accountImpl;
	
	/**
	 * Method used to search for an account.
	 */
	public FindAccountResponse findAccount(FindAccountRequest request)
			throws InvalidRequest, ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		
		FindAccountResponse findAccountResponse = null;
		try {
			
			com.esrx.ref.account.bo.FindAccountRequest accountRequest = RequestTransformer
					.convertToBoFindAccountRequest(request);

			com.esrx.ref.account.bo.FindAccountResponse accountResponse = accountImpl
					.findAccount(accountRequest);

			findAccountResponse = ResponseTransformer
					.convertToFindAccountResponse(accountResponse);

		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		}catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}

		return findAccountResponse;
	}

	/**
	 * Method used to create enter a new credit card information.
	 */
	public CreateCreditCardResponse createCreditCard(
			CreateCreditCardRequest request) throws InvalidRequest,
			ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		CreateCreditCardResponse creditCardResponse = null;
		try {
			
			com.esrx.ref.account.bo.CreateCreditCardRequest createCreditCardRequest = RequestTransformer
					.convertToCreateCreditCardRequest(request);
			com.esrx.ref.account.bo.CreateCreditCardResponse createCreditCardResponse = accountImpl
					.createCreditCard(createCreditCardRequest);

			creditCardResponse = ResponseTransformer
					.convertToCreateCreditCardResponse(createCreditCardResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}

		return creditCardResponse;
	}

	/**
	 * Method used to update the shipping address.
	 * 
	 */
	public UpdateShippingAddressResponse updateShippingAddress(
			UpdateShippingAddressRequest request) throws InvalidRequest,
			ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		UpdateShippingAddressResponse addressResponse = null;
		try {
			
			com.esrx.ref.account.bo.UpdateShippingAddressRequest shippingAddressRequest = RequestTransformer
					.convertToUpdateShippingAddressRequest(request);
			com.esrx.ref.account.bo.UpdateShippingAddressResponse shippingAddressResponse = accountImpl
					.updateShippingAddress(shippingAddressRequest);

			addressResponse = ResponseTransformer
					.convertToUpdateShippingAddressResponse(shippingAddressResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}

		return addressResponse;
	}

	/**
	 * Method used to look for a shipping address.
	 */
	public FindShippingAddressResponse findShippingAddress(
			FindShippingAddressRequest request) throws InvalidRequest,
			ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		
		FindShippingAddressResponse addressResponse = null;
		try {
			
			com.esrx.ref.account.bo.FindShippingAddressRequest findShippingAddressRequest = RequestTransformer
					.convertToFindShippingAddressRequest(request);
			com.esrx.ref.account.bo.FindShippingAddressResponse findShippingAddressResponse = accountImpl
					.findShippingAddress(findShippingAddressRequest);
			addressResponse = ResponseTransformer
					.convertToFindShippingAddressResponse(findShippingAddressResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}
		return addressResponse;
	}

	/**
	 * Method used to enter a new shipping address.
	 */
	public CreateShippingAddressResponse createShippingAddress(
			CreateShippingAddressRequest request) throws InvalidRequest,
			ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		CreateShippingAddressResponse addressResponse = null;
		try {
			
			com.esrx.ref.account.bo.CreateShippingAddressRequest createShippingAddressRequest = RequestTransformer
					.convertToCreateShippingAddressRequest(request);
			com.esrx.ref.account.bo.CreateShippingAddressResponse createShippingAddressResponse = accountImpl
					.createShippingAddress(createShippingAddressRequest);
			addressResponse = ResponseTransformer
					.convertToCreateShippingAddressResponse(createShippingAddressResponse);

		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}
		return addressResponse;
	}

	/**
	 * Method used to search for a Credit Card.
	 */
	public FindCreditCardResponse findCreditCard(FindCreditCardRequest request)
			throws InvalidRequest, ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		
		FindCreditCardResponse cardResponse = null;
		try {
			
			com.esrx.ref.account.bo.FindCreditCardRequest findCreditCardRequest = RequestTransformer
					.convertToFindCreditCardRequest(request);
			com.esrx.ref.account.bo.FindCreditCardResponse findCreditCardResponse = accountImpl
					.findCreditCard(findCreditCardRequest);
			cardResponse = ResponseTransformer
					.convertToFindCreditCardResponse(findCreditCardResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}
		return cardResponse;
	}

	/**
	 * method used to update the account information.
	 */
	public UpdateAccountResponse updateAccount(UpdateAccountRequest request)
			throws InvalidRequest, ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		UpdateAccountResponse response = null;
		try {
			
			com.esrx.ref.account.bo.UpdateAccountRequest accountRequest = RequestTransformer
					.convertToUpdateAccountRequest(request);
			accountImpl.updateAccount(accountRequest);
			response = new UpdateAccountResponse();
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}
		return response;
	}

	/**
	 * Method used to update the credit card information.
	 */
	public UpdateCreditCardResponse updateCreditCard(
			UpdateCreditCardRequest request) throws InvalidRequest,
			ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		UpdateCreditCardResponse response = null;
		try {
			
			com.esrx.ref.account.bo.UpdateCreditCardRequest accountRequest = RequestTransformer
					.convertToUpdateCreditCardRequest(request);
			com.esrx.ref.account.bo.UpdateCreditCardResponse creditCardResponse = accountImpl
					.updateCreditCard(accountRequest);
			response = ResponseTransformer
					.convertToUpdateCreditCardResponse(creditCardResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}

		return response;
	}

	/**
	 * Method used to get the account information.
	 */
	public GetAccountResponse getAccount(GetAccountRequest request)
			throws InvalidRequest, NotFound, ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		GetAccountResponse response = null;
		try {
			

			com.esrx.ref.account.bo.GetAccountRequest accountRequest = RequestTransformer
					.convertToBoGetAccountRequest(request);

			com.esrx.ref.account.bo.GetAccountResponse accountResponse = accountImpl
					.getAccount(accountRequest);

			response = ResponseTransformer
					.convertToGetAccountresponse(accountResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.NotFound e) {
			throw AccountUtil.buildNotFound(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}

		return response;
	}

	/**
	 * Method used create an account.
	 */
	public CreateAccountResponse createAccount(CreateAccountRequest request)
			throws InvalidRequest, ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		CreateAccountResponse accountResponse = null;
		try {
			
			com.esrx.ref.account.bo.CreateAccountRequest createAccountRequest = RequestTransformer
					.convertToCreateAccountRequest(request);
			com.esrx.ref.account.bo.CreateAccountResponse createAccountResponse = accountImpl
					.createAccount(createAccountRequest);

			accountResponse = ResponseTransformer
					.convertToCreateAccountResponse(createAccountResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		}catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}

		return accountResponse;
	}

	/**
	 * Method used to get a shipping address information.
	 */
	public GetShippingAddressResponse getShippingAddress(
			GetShippingAddressRequest request) throws InvalidRequest, NotFound,
			ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		GetShippingAddressResponse addressResponse = null;
		try {
			
			com.esrx.ref.account.bo.GetShippingAddressRequest shippingAddressRequest = RequestTransformer
					.convertToGetShippingAddressRequest(request);
			com.esrx.ref.account.bo.GetShippingAddressResponse shippingAddressResponse = accountImpl
					.getShippingAddress(shippingAddressRequest);

			addressResponse = ResponseTransformer
					.convertToGetShippingAddressResponse(shippingAddressResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.NotFound e) {
			throw AccountUtil.buildNotFound(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}

		return addressResponse;
	}

	/**
	 * Method used to get a credit card information.
	 */
	public GetCreditCardResponse getCreditCard(GetCreditCardRequest request)
			throws InvalidRequest, NotFound, ProcessFailed, ResourceUnavailable {
		ProcessTimer.startTimer();
		GetCreditCardResponse getCreditCardResponse = null;
		try {
			com.esrx.ref.account.bo.GetCreditCardRequest creditCardRequest = RequestTransformer
					.convertToGetCreditCardRequest(request);
			com.esrx.ref.account.bo.GetCreditCardResponse creditCardResponse = accountImpl
					.getCreditCard(creditCardRequest);

			getCreditCardResponse = ResponseTransformer
					.convertToGetCreditCardResponse(creditCardResponse);
		} catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.NotFound e) {
			throw AccountUtil.buildNotFound(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		}catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			if( e instanceof QueryTimeoutException){
				throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
			}
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}

		return getCreditCardResponse;
	}
	

	@Override
	public GetAddressResponse getAddress(GetAddressRequest getAddressRequest)
			throws ProcessFailed, InvalidRequest, ResourceUnavailable, NotFound {
		ProcessTimer.startTimer();
		GetAddressResponse addressResponse = null;
		try{
			com.esrx.ref.account.bo.GetAddressRequest addressRequest = RequestTransformer.convettoGetAddressRequest(getAddressRequest);
			com.esrx.ref.account.bo.GetAddressResponse getAddressResponse = accountImpl.getAddress(addressRequest);
			addressResponse = ResponseTransformer.convertToGetAddressResponse(getAddressResponse);
		}catch (com.express_scripts.inf.types.InvalidRequest e) {
			throw AccountUtil.buildInvalidRequest(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.NotFound e) {
			throw AccountUtil.buildNotFound(e.getMessage(), e.getCode(), e.getId(), null);
		}catch (ProcessTimeoutException e) {
			throw AccountUtil.buildResourceUnavailable(Constants.TIMED_OUT, ErrorCodes.RESOURCE_UNAVAILABLE, null, null);
		} catch (com.express_scripts.inf.types.ResourceUnavailable e) {
			throw AccountUtil.buildResourceUnavailable(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (com.express_scripts.inf.types.ProcessFailed e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), e.getCode(), e.getId(), null);
		} catch (Exception e) {
			throw AccountUtil.buildProcessFailed(e.getMessage(), ErrorCodes.UNEXPECTED_ERROR, null, null);
		}
		return addressResponse;
	}
	

	/**
	 * @param accountImpl
	 *            the accountImpl to set
	 */
	public void setAccountImpl(AccountBo accountImpl) {
		this.accountImpl = accountImpl;
	}
}
