<?xml version="1.0" encoding="UTF-8"?>
<con:soapui-project activeEnvironment="Default" name="AccountService2" resourceRoot="" soapui-version="4.5.1" abortOnError="false" runType="SEQUENTIAL" xmlns:con="http://eviware.com/soapui/config"><con:settings/><con:interface xsi:type="con:WsdlInterface" wsaVersion="NONE" name="AccountServiceSoapEndpointBinding" type="wsdl" bindingName="{http://ws.account.ref.esrx.com}AccountServiceSoapEndpointBinding" soapVersion="1_1" anonymous="optional" definition="file:/C:/esi/ws/ReferenceAcrh/account-mule/src/main/resources/wsdl/AccountService.wsdl" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><con:settings/><con:definitionCache type="TEXT" rootPart="file:\C:\esi\ws\ReferenceAcrh\account-mule\src\main\resources\wsdl\AccountService.wsdl"><con:part><con:url>file:\C:\esi\ws\ReferenceAcrh\account-mule\src\main\resources\wsdl\AccountService.wsdl</con:url><con:content><![CDATA[<definitions name="AccountService" targetNamespace="http://ws.account.ref.esrx.com" xmlns="http://schemas.xmlsoap.org/wsdl/" xmlns:ns="http://schemas.xmlsoap.org/soap/encoding/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:tns="http://ws.account.ref.esrx.com" xmlns:types="http://account.ref.esrx.com" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <documentation>Service: Account
		Version: 1.0
		Description: Account WSDL.
		Create Date : 03/20/2012</documentation>
  <types>
    <xsd:schema>
      <xsd:import namespace="http://account.ref.esrx.com" schemaLocation="AccountService.xsd"/>
    </xsd:schema>
  </types>
  <message name="FindAccountRequest">
    <part name="request" element="types:FindAccountRequest"/>
  </message>
  <message name="GetAccountRequest">
    <part name="request" element="types:GetAccountRequest"/>
  </message>
  <message name="CreateAccountRequest">
    <part name="request" element="types:CreateAccountRequest"/>
  </message>
  <message name="UpdateAccountRequest">
    <part name="request" element="types:UpdateAccountRequest"/>
  </message>
  <message name="FindCreditCardRequest">
    <part name="request" element="types:FindCreditCardRequest"/>
  </message>
  <message name="GetCreditCardRequest">
    <part name="request" element="types:GetCreditCardRequest"/>
  </message>
  <message name="CreateCreditCardRequest">
    <part name="request" element="types:CreateCreditCardRequest"/>
  </message>
  <message name="UpdateCreditCardRequest">
    <part name="request" element="types:UpdateCreditCardRequest"/>
  </message>
  <message name="FindShippingAddressRequest">
    <part name="request" element="types:FindShippingAddressRequest"/>
  </message>
  <message name="GetShippingAddressRequest">
    <part name="request" element="types:GetShippingAddressRequest"/>
  </message>
  <message name="CreateShippingAddressRequest">
    <part name="request" element="types:CreateShippingAddressRequest"/>
  </message>
  <message name="UpdateShippingAddressRequest">
    <part name="request" element="types:UpdateShippingAddressRequest"/>
  </message>
  <message name="FindAccountResponse">
    <part name="response" element="types:FindAccountResponse"/>
  </message>
  <message name="GetAccountResponse">
    <part name="response" element="types:GetAccountResponse"/>
  </message>
  <message name="CreateAccountResponse">
    <part name="response" element="types:CreateAccountResponse"/>
  </message>
  <message name="UpdateAccountResponse">
    <part name="response" element="types:UpdateAccountResponse"/>
  </message>
  <message name="FindCreditCardResponse">
    <part name="response" element="types:FindCreditCardResponse"/>
  </message>
  <message name="GetCreditCardResponse">
    <part name="response" element="types:GetCreditCardResponse"/>
  </message>
  <message name="CreateCreditCardResponse">
    <part name="response" element="types:CreateCreditCardResponse"/>
  </message>
  <message name="UpdateCreditCardResponse">
    <part name="response" element="types:UpdateCreditCardResponse"/>
  </message>
  <message name="FindShippingAddressResponse">
    <part name="response" element="types:FindShippingAddressResponse"/>
  </message>
  <message name="GetShippingAddressResponse">
    <part name="response" element="types:GetShippingAddressResponse"/>
  </message>
  <message name="CreateShippingAddressResponse">
    <part name="response" element="types:CreateShippingAddressResponse"/>
  </message>
  <message name="UpdateShippingAddressResponse">
    <part name="response" element="types:UpdateShippingAddressResponse"/>
  </message>
  <message name="InvalidRequest">
    <part name="exception" element="types:InvalidRequest"/>
  </message>
  <message name="ProcessFailed">
    <part name="exception" element="types:ProcessFailed"/>
  </message>
  <message name="NotFound">
    <part name="exception" element="types:NotFound"/>
  </message>
  <message name="ResourceUnavailable">
    <part name="exception" element="types:ResourceUnavailable"/>
  </message>
  <portType name="AccountService">
    <operation name="findAccount">
      <documentation>This method is used to find the account information</documentation>
      <input message="tns:FindAccountRequest"/>
      <output message="tns:FindAccountResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified.</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable.</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates a error occurred.</documentation>
      </fault>
    </operation>
    <operation name="getAccount">
      <documentation>Get Account information based on id</documentation>
      <input message="tns:GetAccountRequest"/>
      <output message="tns:GetAccountResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
      <fault name="NotFound" message="tns:NotFound">
        <documentation>Indicates an searched item is not found..</documentation>
      </fault>
    </operation>
    <operation name="createAccount">
      <documentation>Method used to create a new account.</documentation>
      <input message="tns:CreateAccountRequest"/>
      <output message="tns:CreateAccountResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
    </operation>
    <operation name="updateAccount">
      <documentation>Method used to update an account information.</documentation>
      <input message="tns:UpdateAccountRequest"/>
      <output message="tns:UpdateAccountResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
    </operation>
    <operation name="findCreditCard">
      <documentation>Method used for look up for a credit card.</documentation>
      <input message="tns:FindCreditCardRequest"/>
      <output message="tns:FindCreditCardResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
    </operation>
    <operation name="getCreditCard">
      <documentation>Method used to get a credit card request based on a credit card id.</documentation>
      <input message="tns:GetCreditCardRequest"/>
      <output message="tns:GetCreditCardResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
      <fault name="NotFound" message="tns:NotFound">
        <documentation>Indicates an searched item is not found.</documentation>
      </fault>
    </operation>
    <operation name="createCreditCard">
      <documentation>Method used to update or add a new credit card information.</documentation>
      <input message="tns:CreateCreditCardRequest"/>
      <output message="tns:CreateCreditCardResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
    </operation>
    <operation name="updateCreditCard">
      <documentation>Method used to update or add a new credit card information.</documentation>
      <input message="tns:UpdateCreditCardRequest"/>
      <output message="tns:UpdateCreditCardResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
    </operation>
    <operation name="findShippingAddress">
      <documentation>Method to find a shipping address for an account.</documentation>
      <input message="tns:FindShippingAddressRequest"/>
      <output message="tns:FindShippingAddressResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
    </operation>
    <operation name="getShippingAddress">
      <documentation>Method to retrieve the shipping address</documentation>
      <input message="tns:GetShippingAddressRequest"/>
      <output message="tns:GetShippingAddressResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
      <fault name="NotFound" message="tns:NotFound">
        <documentation>Indicates an searched item is not found.</documentation>
      </fault>
    </operation>
    <operation name="createShippingAddress">
      <documentation>Method to update or add shipping address</documentation>
      <input message="tns:CreateShippingAddressRequest"/>
      <output message="tns:CreateShippingAddressResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
    </operation>
    <operation name="updateShippingAddress">
      <documentation>Method to update or add shipping address</documentation>
      <input message="tns:UpdateShippingAddressRequest"/>
      <output message="tns:UpdateShippingAddressResponse"/>
      <fault name="InvalidRequest" message="tns:InvalidRequest">
        <documentation>Indicates insufficient or incorrect parameters were specified</documentation>
      </fault>
      <fault name="ProcessFailed" message="tns:ProcessFailed">
        <documentation>Indicates an unexpected error was encountered</documentation>
      </fault>
      <fault name="ResourceUnavailable" message="tns:ResourceUnavailable">
        <documentation>Indicates a dependent system is unavailable</documentation>
      </fault>
    </operation>
  </portType>
  <binding name="AccountServiceSoapEndpointBinding" type="tns:AccountService">
    <soap:binding style="document" transport="http://schemas.xmlsoap.org/soap/http"/>
    <operation name="findAccount">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/findAccount" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
    </operation>
    <operation name="getAccount">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/getAccount" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
      <fault name="NotFound">
        <soap:fault name="NotFound" use="literal"/>
      </fault>
    </operation>
    <operation name="createAccount">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/createAccount" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
    </operation>
    <operation name="updateAccount">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/updateAccount" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
    </operation>
    <operation name="findCreditCard">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/findCreditCard" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
    </operation>
    <operation name="getCreditCard">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/getCreditCard" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
      <fault name="NotFound">
        <soap:fault name="NotFound" use="literal"/>
      </fault>
    </operation>
    <operation name="createCreditCard">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/createCreditCard" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
    </operation>
    <operation name="updateCreditCard">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/updateCreditCard" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
    </operation>
    <operation name="findShippingAddress">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/findShippingAddress" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
    </operation>
    <operation name="getShippingAddress">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/getShippingAddress" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
      <fault name="NotFound">
        <soap:fault name="NotFound" use="literal"/>
      </fault>
    </operation>
    <operation name="createShippingAddress">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/createShippingAddress" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
    </operation>
    <operation name="updateShippingAddress">
      <soap:operation soapAction="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/updateShippingAddress" style="document"/>
      <input>
        <soap:body parts="request" use="literal"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
      <fault name="InvalidRequest">
        <soap:fault name="InvalidRequest" use="literal"/>
      </fault>
      <fault name="ProcessFailed">
        <soap:fault name="ProcessFailed" use="literal"/>
      </fault>
      <fault name="ResourceUnavailable">
        <soap:fault name="ResourceUnavailable" use="literal"/>
      </fault>
    </operation>
  </binding>
  <service name="AccountService">
    <port name="AccountService" binding="tns:AccountServiceSoapEndpointBinding">
      <soap:address location="https://localhost:29002/AccountService/1.0"/>
    </port>
  </service>
</definitions>]]></con:content><con:type>http://schemas.xmlsoap.org/wsdl/</con:type></con:part><con:part><con:url>file:\C:\esi\ws\ReferenceAcrh\account-mule\src\main\resources\wsdl\AccountService.xsd</con:url><con:content><![CDATA[<!--edited with XMLSpy v2010 rel. 3 (http://www.altova.com) by Express Scripts, 
	Inc. (Express Scripts, Inc.)-->
<schema targetNamespace="http://account.ref.esrx.com" elementFormDefault="qualified" attributeFormDefault="unqualified" xmlns="http://www.w3.org/2001/XMLSchema" xmlns:tns="http://account.ref.esrx.com">
  <annotation>
    <documentation>Schema: Account Service
			Version: 1.0
			Description: Schema for Account Service</documentation>
  </annotation>
  <simpleType name="STATUS">
    <annotation>
      <documentation>Identifies the type of credit card.</documentation>
    </annotation>
    <restriction base="string">
      <enumeration value="ACTIVE"/>
      <enumeration value="INACTIVE"/>
    </restriction>
  </simpleType>
  <simpleType name="CreditCardtype">
    <annotation>
      <documentation>Identifies the type of credit card.</documentation>
    </annotation>
    <restriction base="string">
      <enumeration value="MASTERCARD" id="MST"/>
      <enumeration value="VISA" id="VIS"/>
      <enumeration value="DISCOVER" id="DIS"/>
    </restriction>
  </simpleType>
  <simpleType name="SortOrder">
    <annotation>
      <documentation>Specifies the directions for sorting.</documentation>
    </annotation>
    <restriction base="string">
      <enumeration value="ASC"/>
      <enumeration value="DESC"/>
    </restriction>
  </simpleType>
  <complexType name="ArrayOfString">
    <sequence>
      <element name="value" type="string" minOccurs="0" maxOccurs="unbounded"/>
    </sequence>
  </complexType>
  <complexType name="SortOption">
    <sequence>
      <element name="fieldName" type="string"/>
      <element name="order" type="tns:SortOrder"/>
    </sequence>
  </complexType>
  <complexType name="ArrayOfSortOption">
    <sequence>
      <element name="sortOption" type="tns:SortOption" minOccurs="0" maxOccurs="unbounded"/>
    </sequence>
  </complexType>
  <complexType name="ArrayOfStatus">
    <sequence>
      <element name="status" type="tns:STATUS" minOccurs="0" maxOccurs="unbounded"/>
    </sequence>
  </complexType>
  <complexType name="Account">
    <sequence>
      <element name="accountId" type="string">
        <annotation>
          <documentation>selected Account ID</documentation>
        </annotation>
      </element>
      <element name="accountNumber" type="string">
        <annotation>
          <documentation>selected account number</documentation>
        </annotation>
      </element>
      <element name="firstName" type="string">
        <annotation>
          <documentation>selected first name</documentation>
        </annotation>
      </element>
      <element name="lastName" type="string">
        <annotation>
          <documentation>selected last name</documentation>
        </annotation>
      </element>
      <element name="emailAddress" type="string">
        <annotation>
          <documentation>selected last name</documentation>
        </annotation>
      </element>
      <element name="dateOfBirth" type="string" minOccurs="0">
        <annotation>
          <documentation>selected last name</documentation>
        </annotation>
      </element>
      <element name="username" type="string">
        <annotation>
          <documentation>selected user name.</documentation>
        </annotation>
      </element>
      <element name="creditCardList" type="tns:ArrayOfString">
        <annotation>
          <documentation>selected list of credit cards</documentation>
        </annotation>
      </element>
      <element name="shippingAddressList" type="tns:ArrayOfString">
        <annotation>
          <documentation>selected list of shipping addresses</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="ArrayOfAccount">
    <sequence>
      <element name="account" type="tns:Account" minOccurs="0" maxOccurs="unbounded"/>
    </sequence>
  </complexType>
  <complexType name="Address">
    <sequence>
      <element name="addressId" type="string">
        <annotation>
          <documentation>selected address id</documentation>
        </annotation>
      </element>
      <element name="name" type="string">
        <annotation>
          <documentation>selected name</documentation>
        </annotation>
      </element>
      <element name="line1" type="string">
        <annotation>
          <documentation>address line 1</documentation>
        </annotation>
      </element>
      <element name="line2" type="string" minOccurs="0">
        <annotation>
          <documentation>address line 2</documentation>
        </annotation>
      </element>
      <element name="line3" type="string" minOccurs="0">
        <annotation>
          <documentation>address line 3</documentation>
        </annotation>
      </element>
      <element name="line4" type="string" minOccurs="0">
        <annotation>
          <documentation>address line 4</documentation>
        </annotation>
      </element>
      <element name="city" type="string">
        <annotation>
          <documentation>address city</documentation>
        </annotation>
      </element>
      <element name="state" type="string">
        <annotation>
          <documentation>address state</documentation>
        </annotation>
      </element>
      <element name="zip5" type="string">
        <annotation>
          <documentation>address zip 5</documentation>
        </annotation>
      </element>
      <element name="zip4" type="string" minOccurs="0">
        <annotation>
          <documentation>address zip 4</documentation>
        </annotation>
      </element>
      <element name="active" type="boolean" minOccurs="0">
        <annotation>
          <documentation>address active or not</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="ArrayOfAddress">
    <sequence>
      <element name="address" type="tns:Address" minOccurs="0" maxOccurs="unbounded"/>
    </sequence>
  </complexType>
  <complexType name="CreditCard">
    <sequence>
      <element name="creditCardId" type="string">
        <annotation>
          <documentation>selected credit card id</documentation>
        </annotation>
      </element>
      <element name="alias" type="string">
        <annotation>
          <documentation>selected alias</documentation>
        </annotation>
      </element>
      <element name="creditCardNumber" type="string">
        <annotation>
          <documentation>selected credit card number</documentation>
        </annotation>
      </element>
      <element name="expirationMonth" type="string">
        <annotation>
          <documentation>selected expiration month</documentation>
        </annotation>
      </element>
      <element name="expirationYear" type="string">
        <annotation>
          <documentation>selected expiration year</documentation>
        </annotation>
      </element>
      <element name="nameOnCard" type="string">
        <annotation>
          <documentation>selected name on card</documentation>
        </annotation>
      </element>
      <element name="active" type="boolean" minOccurs="0">
        <annotation>
          <documentation>selected status</documentation>
        </annotation>
      </element>
      <element name="creditCardType" type="tns:CreditCardtype">
        <annotation>
          <documentation>selected credit card type.</documentation>
        </annotation>
      </element>
      <element name="billingAddress" type="tns:Address">
        <annotation>
          <documentation>selected billing address.</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="ArrayOfCreditCard">
    <sequence>
      <element name="creditCard" type="tns:CreditCard" minOccurs="0" maxOccurs="unbounded"/>
    </sequence>
  </complexType>
  <complexType name="FindAccountRequest">
    <sequence>
      <element name="firstName" type="string" minOccurs="0">
        <annotation>
          <documentation>First name to search</documentation>
        </annotation>
      </element>
      <element name="lastName" type="string" minOccurs="0">
        <annotation>
          <documentation>Last Name to search.</documentation>
        </annotation>
      </element>
      <element name="emailAddress" type="string" minOccurs="0">
        <annotation>
          <documentation>Email Address</documentation>
        </annotation>
      </element>
      <element name="dateOfBirth" type="string" minOccurs="0">
        <annotation>
          <documentation>Date of Birth</documentation>
        </annotation>
      </element>
      <element name="matchCase" type="boolean" default="false">
        <annotation>
          <documentation>Match case for the search fields.</documentation>
        </annotation>
      </element>
      <element name="sortOptions" type="tns:ArrayOfSortOption">
        <annotation>
          <documentation>Sorting order</documentation>
        </annotation>
      </element>
      <element name="offset" type="int">
        <annotation>
          <documentation>Start of the count. Used for Pagination</documentation>
        </annotation>
      </element>
      <element name="count" type="int">
        <annotation>
          <documentation>Number of records to be fetched.</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="FindAccountResponse">
    <sequence>
      <element name="accountList" type="tns:ArrayOfAccount">
        <annotation>
          <documentation>list of accounts</documentation>
        </annotation>
      </element>
      <element name="totalCount" type="int">
        <annotation>
          <documentation>Total number of records</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="GetAccountRequest">
    <sequence>
      <element name="accountId" type="string">
        <annotation>
          <documentation>accountId to retreive</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="GetAccountResponse">
    <sequence>
      <element name="account" type="tns:Account">
        <annotation>
          <documentation>account information</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="CreateAccountRequest">
    <sequence>
      <element name="account" type="tns:Account">
        <annotation>
          <documentation>account information</documentation>
        </annotation>
      </element>
      <element name="password" type="base64Binary">
        <annotation>
          <documentation>selected password.</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="CreateAccountResponse">
    <sequence>
      <element name="accountId" type="string">
        <annotation>
          <documentation>account id created</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="UpdateAccountRequest">
    <sequence>
      <element name="account" type="tns:Account">
        <annotation>
          <documentation>account information</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="UpdateAccountResponse"/>
  <!--find Credit card opertaion-->
  <complexType name="FindCreditCardRequest">
    <sequence>
      <element name="accountId" type="string">
        <annotation>
          <documentation>id to be searched</documentation>
        </annotation>
      </element>
      <element name="active" type="tns:ArrayOfStatus" minOccurs="0">
        <annotation>
          <documentation>status for credit card thats needs to be searched. Default will be active.</documentation>
        </annotation>
      </element>
      <element name="matchCase" type="boolean" default="false">
        <annotation>
          <documentation>Match case for the search fields.</documentation>
        </annotation>
      </element>
      <element name="sortOptions" type="tns:ArrayOfSortOption">
        <annotation>
          <documentation>Sorting order</documentation>
        </annotation>
      </element>
      <element name="offset" type="int">
        <annotation>
          <documentation>Start of the count. Used for Pagination</documentation>
        </annotation>
      </element>
      <element name="count" type="int">
        <annotation>
          <documentation>Number of records to be fetched.</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="FindCreditCardResponse">
    <sequence>
      <element name="creditCardList" type="tns:ArrayOfCreditCard">
        <annotation>
          <documentation>list of credit cards</documentation>
        </annotation>
      </element>
      <element name="totalCount" type="int">
        <annotation>
          <documentation>Total number of records</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="GetCreditCardRequest">
    <sequence>
      <element name="creditCardId" type="string">
        <annotation>
          <documentation>credit card to retrieve</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="GetCreditCardResponse">
    <sequence>
      <element name="creditCard" type="tns:CreditCard">
        <annotation>
          <documentation>credit card  information</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="CreateCreditCardRequest">
    <sequence>
      <element name="accountId" type="string">
        <annotation>
          <documentation>account id information</documentation>
        </annotation>
      </element>
      <element name="creditCard" type="tns:CreditCard">
        <annotation>
          <documentation>credit card information</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="UpdateCreditCardRequest">
    <sequence>
      <element name="accountId" type="string">
        <annotation>
          <documentation>account id information</documentation>
        </annotation>
      </element>
      <element name="creditCard" type="tns:CreditCard">
        <annotation>
          <documentation>credit card information</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="CreateCreditCardResponse">
    <sequence>
      <element name="creditCardId" type="string">
        <annotation>
          <documentation>credit id created</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="UpdateCreditCardResponse">
    <sequence>
      <element name="creditCardId" type="string">
        <annotation>
          <documentation>credit id created</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <!--address operation-->
  <complexType name="FindShippingAddressRequest">
    <sequence>
      <element name="accountId" type="string">
        <annotation>
          <documentation>id to be searched</documentation>
        </annotation>
      </element>
      <element name="active" type="boolean" minOccurs="0">
        <annotation>
          <documentation>status for credit card thats needs to be searched. Default will be active.</documentation>
        </annotation>
      </element>
      <element name="matchCase" type="boolean" default="false">
        <annotation>
          <documentation>Match case for the search fields.</documentation>
        </annotation>
      </element>
      <element name="sortOptions" type="tns:ArrayOfSortOption">
        <annotation>
          <documentation>Sorting order</documentation>
        </annotation>
      </element>
      <element name="offset" type="int">
        <annotation>
          <documentation>Start of the count. Used for Pagination</documentation>
        </annotation>
      </element>
      <element name="count" type="int">
        <annotation>
          <documentation>Number of records to be fetched.</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="FindShippingAddressResponse">
    <sequence>
      <element name="addressList" type="tns:ArrayOfAddress">
        <annotation>
          <documentation>list of address</documentation>
        </annotation>
      </element>
      <element name="totalCount" type="int">
        <annotation>
          <documentation>Total number of records</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="GetShippingAddressRequest">
    <sequence>
      <element name="addressId" type="string">
        <annotation>
          <documentation>address to retrieve</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="GetShippingAddressResponse">
    <sequence>
      <element name="address" type="tns:Address">
        <annotation>
          <documentation>address  information</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="CreateShippingAddressRequest">
    <sequence>
      <element name="accountId" type="string">
        <annotation>
          <documentation>account id information</documentation>
        </annotation>
      </element>
      <element name="address" type="tns:Address">
        <annotation>
          <documentation>address information</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="CreateShippingAddressResponse">
    <sequence>
      <element name="addressId" type="string">
        <annotation>
          <documentation>address id created</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="UpdateShippingAddressRequest">
    <sequence>
      <element name="accountId" type="string">
        <annotation>
          <documentation>account id information</documentation>
        </annotation>
      </element>
      <element name="address" type="tns:Address">
        <annotation>
          <documentation>address information</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="UpdateShippingAddressResponse">
    <sequence>
      <element name="addressId" type="string">
        <annotation>
          <documentation>address id created</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="InvalidRequest">
    <sequence>
      <element name="message" type="string" minOccurs="0">
        <annotation>
          <documentation>incorrect input provided to the service.</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="NotFound">
    <sequence>
      <element name="message" type="string" minOccurs="0">
        <annotation>
          <documentation>Thrown once the searched item is not found..</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="ProcessFailed">
    <sequence>
      <element name="message" type="string" minOccurs="0">
        <annotation>
          <documentation>Thrown once unexpected error occurs in the service.</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <complexType name="ResourceUnavailable">
    <sequence>
      <element name="message" type="string" minOccurs="0">
        <annotation>
          <documentation>Thrown once the called resource is unavailable.</documentation>
        </annotation>
      </element>
    </sequence>
  </complexType>
  <element name="FindAccountRequest" type="tns:FindAccountRequest"/>
  <element name="FindAccountResponse" type="tns:FindAccountResponse"/>
  <element name="GetAccountRequest" type="tns:GetAccountRequest"/>
  <element name="GetAccountResponse" type="tns:GetAccountResponse"/>
  <element name="CreateAccountRequest" type="tns:CreateAccountRequest"/>
  <element name="CreateAccountResponse" type="tns:CreateAccountResponse"/>
  <element name="UpdateAccountRequest" type="tns:UpdateAccountRequest"/>
  <element name="UpdateAccountResponse" type="tns:UpdateAccountResponse"/>
  <element name="FindCreditCardRequest" type="tns:FindCreditCardRequest"/>
  <element name="FindCreditCardResponse" type="tns:FindCreditCardResponse"/>
  <element name="GetCreditCardRequest" type="tns:GetCreditCardRequest"/>
  <element name="GetCreditCardResponse" type="tns:GetCreditCardResponse"/>
  <element name="CreateCreditCardRequest" type="tns:CreateCreditCardRequest"/>
  <element name="CreateCreditCardResponse" type="tns:CreateCreditCardResponse"/>
  <element name="UpdateCreditCardRequest" type="tns:UpdateCreditCardRequest"/>
  <element name="UpdateCreditCardResponse" type="tns:UpdateCreditCardResponse"/>
  <element name="FindShippingAddressRequest" type="tns:FindShippingAddressRequest"/>
  <element name="FindShippingAddressResponse" type="tns:FindShippingAddressResponse"/>
  <element name="GetShippingAddressRequest" type="tns:GetShippingAddressRequest"/>
  <element name="GetShippingAddressResponse" type="tns:GetShippingAddressResponse"/>
  <element name="CreateShippingAddressRequest" type="tns:CreateShippingAddressRequest"/>
  <element name="CreateShippingAddressResponse" type="tns:CreateShippingAddressResponse"/>
  <element name="UpdateShippingAddressRequest" type="tns:UpdateShippingAddressRequest"/>
  <element name="UpdateShippingAddressResponse" type="tns:UpdateShippingAddressResponse"/>
  <element name="InvalidRequest" type="tns:InvalidRequest"/>
  <element name="NotFound" type="tns:NotFound"/>
  <element name="ProcessFailed" type="tns:ProcessFailed"/>
  <element name="ResourceUnavailable" type="tns:ResourceUnavailable"/>
</schema>]]></con:content><con:type>http://www.w3.org/2001/XMLSchema</con:type></con:part></con:definitionCache><con:endpoints><con:endpoint>https://localhost:2001</con:endpoint><con:endpoint>https://services-dev-fl1.express-scripts.com/accountservice/1/</con:endpoint></con:endpoints><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/createAccount" name="createAccount" bindingOperationName="createAccount" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1" wssPasswordType=""><con:settings><con:setting id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment/></con:setting></con:settings><con:encoding>UTF-8</con:encoding><con:endpoint>https://services-dev-fl1.express-scripts.com/accountservice/1/</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:CreateAccountRequest>
         <acc:account>
            <acc:accountId>1</acc:accountId>
            <acc:accountNumber>1</acc:accountNumber>
            <acc:firstName>Chad</acc:firstName>
            <acc:lastName>Sturtz</acc:lastName>
            <acc:emailAddress>csturtz@express-scripts.com</acc:emailAddress>
            <!--Optional:-->
            <acc:dateOfBirth>1980-03-29</acc:dateOfBirth>
            <acc:username>csturtz</acc:username>
            <!--<acc:creditCardList>-->
               <!--Zero or more repetitions:-->
               <!--<acc:value>?</acc:value>
            </acc:creditCardList>
            <acc:shippingAddressList>-->
               <!--Zero or more repetitions:-->
               <!--<acc:value>?</acc:value>
            </acc:shippingAddressList>-->
         </acc:account>
         <!--<acc:password>cid:296293247105</acc:password>-->
      </acc:CreateAccountRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:credentials><con:username>regsvc_dev1</con:username><con:password>*Asd#Poi</con:password><con:authType>Global HTTP Settings</con:authType></con:credentials><con:jmsConfig JMSDeliveryMode="PERSISTENT"/><con:jmsPropertyConfig/><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/createAccount"/><con:wsrmConfig version="1.2"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/createCreditCard" name="createCreditCard" bindingOperationName="createCreditCard" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings><con:setting id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment/></con:setting><con:setting id="com.eviware.soapui.impl.support.AbstractHttpRequest@follow-redirects">true</con:setting></con:settings><con:encoding>UTF-8</con:encoding><con:endpoint>https://services-dev-fl1.express-scripts.com/accountservice/1/</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:CreateCreditCardRequest>
         <acc:accountId>181</acc:accountId>
         <acc:creditCard>
            <acc:creditCardId></acc:creditCardId>
            <acc:alias>SECONDARY</acc:alias>
            <acc:creditCardNumber>4444224444</acc:creditCardNumber>
            <acc:expirationMonth>05</acc:expirationMonth>
            <acc:expirationYear>2014</acc:expirationYear>
            <acc:nameOnCard>Sturtz Charles</acc:nameOnCard>
            <!--Optional:-->
            <acc:creditCardType>VIS</acc:creditCardType>
            <acc:billingAddress>
               <acc:addressId></acc:addressId>
               <acc:name>BILLING ADDRESS</acc:name>
               <acc:line1>1399 TEST LOCATION</acc:line1>
               <!--Optional:-->
               <acc:line2></acc:line2>
               <!--Optional:-->
               <acc:line3></acc:line3>
               <!--Optional:-->
               <acc:line4></acc:line4>
               <acc:city>CITY</acc:city>
               <acc:state>MO</acc:state>
               <acc:zip5>12345</acc:zip5>
               <!--Optional:-->
               <acc:zip4>111</acc:zip4>
               <!--Optional:-->
            </acc:billingAddress>
         </acc:creditCard>
      </acc:CreateCreditCardRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:credentials><con:username>regsvc_dev1</con:username><con:password>*Asd#Poi</con:password><con:authType>Global HTTP Settings</con:authType></con:credentials><con:jmsConfig JMSDeliveryMode="PERSISTENT"/><con:jmsPropertyConfig/><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/createCreditCard"/><con:wsrmConfig version="1.2"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/createShippingAddress" name="createShippingAddress" bindingOperationName="createShippingAddress" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings><con:setting id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment/></con:setting><con:setting id="com.eviware.soapui.impl.support.AbstractHttpRequest@follow-redirects">true</con:setting></con:settings><con:encoding>UTF-8</con:encoding><con:endpoint>https://services-dev-fl1.express-scripts.com/accountservice/1/</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:CreateShippingAddressRequest>
         <acc:accountId>181</acc:accountId>
         <acc:address>
            <acc:addressId>1</acc:addressId>
            <acc:name>Home</acc:name>
            <acc:line1>123 Express Way</acc:line1>
            <!--Optional:-->
            <!--<acc:line2>?</acc:line2>-->
            <!--Optional:-->
            <!--<acc:line3>?</acc:line3>-->
            <!--Optional:-->
            <!--<acc:line4>?</acc:line4>-->
            <acc:city>St Louis</acc:city>
            <acc:state>MO</acc:state>
            <acc:zip5>63136</acc:zip5>
            <!--Optional:-->
            <!--<acc:zip4>?</acc:zip4>-->
            <!--Optional:-->
            <!--<acc:active>Y</acc:active>-->
         </acc:address>
      </acc:CreateShippingAddressRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:credentials><con:username>ref_account_dev1</con:username><con:password>*Wyu#Poi</con:password><con:authType>Global HTTP Settings</con:authType></con:credentials><con:jmsConfig JMSDeliveryMode="PERSISTENT"/><con:jmsPropertyConfig/><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/createShippingAddress"/><con:wsrmConfig version="1.2"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/findAccount" name="findAccount" bindingOperationName="findAccount" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings><con:setting id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment xmlns:con="http://eviware.com/soapui/config">
  &lt;con:entry key="ESI_CALLER_ID" value="IsAwesome"/>
  &lt;con:entry key="ESI_ORIG_CALLER_ID" value="Chad"/>
&lt;/xml-fragment></con:setting><con:setting id="com.eviware.soapui.impl.support.AbstractHttpRequest@follow-redirects">true</con:setting></con:settings><con:encoding>UTF-8</con:encoding><con:endpoint>https://localhost:2001</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:FindAccountRequest>
         <!--Optional:-->
         <acc:firstName>C*</acc:firstName>
         <!--Optional:-->
         <acc:lastName></acc:lastName>
         <!--Optional:-->
         <acc:emailAddress></acc:emailAddress>
         <!--Optional:-->
         <acc:dateOfBirth></acc:dateOfBirth>
         <acc:matchCase>false</acc:matchCase>
         <acc:offset>0</acc:offset>
         <acc:count>2</acc:count>
         <acc:timeout>30000</acc:timeout>
      </acc:FindAccountRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:credentials><con:username>regsvc_dev1</con:username><con:password>*Asd#Poi</con:password><con:authType>Global HTTP Settings</con:authType></con:credentials><con:jmsConfig JMSDeliveryMode="PERSISTENT"/><con:jmsPropertyConfig/><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/findAccount"/><con:wsrmConfig version="1.2"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/findCreditCard" name="findCreditCard" bindingOperationName="findCreditCard" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings><con:setting id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment/></con:setting></con:settings><con:encoding>UTF-8</con:encoding><con:endpoint>https://localhost:2001</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:FindCreditCardRequest>
         <acc:accountId>1</acc:accountId>
         <!--Optional:-->
         <acc:active>
            <!--Zero or more repetitions:-->
            <acc:status>ACTIVE</acc:status>
         </acc:active>
         <acc:matchCase>false</acc:matchCase>
         <acc:sortOptions>
            <!--Zero or more repetitions:-->
            <acc:sortOption>
               <acc:fieldName>firstName</acc:fieldName>
               <acc:order>ASC</acc:order>
            </acc:sortOption>
         </acc:sortOptions>
         <acc:offset>0</acc:offset>
         <acc:count>1</acc:count>
      </acc:FindCreditCardRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:credentials><con:username>p043459</con:username><con:password>apr-2013</con:password></con:credentials><con:jmsConfig JMSDeliveryMode="PERSISTENT"/><con:jmsPropertyConfig/><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/findCreditCard"/><con:wsrmConfig version="1.2"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/findShippingAddress" name="findShippingAddress" bindingOperationName="findShippingAddress" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings/><con:encoding>UTF-8</con:encoding><con:endpoint>https://localhost:2001</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:FindShippingAddressRequest>
         <acc:accountId>?</acc:accountId>
         <!--Optional:-->
         <acc:active>?</acc:active>
         <acc:matchCase>false</acc:matchCase>
         <acc:sortOptions>
            <!--Zero or more repetitions:-->
            <acc:sortOption>
               <acc:fieldName>?</acc:fieldName>
               <acc:order>?</acc:order>
            </acc:sortOption>
         </acc:sortOptions>
         <acc:offset>?</acc:offset>
         <acc:count>?</acc:count>
      </acc:FindShippingAddressRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/findShippingAddress"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/getAccount" name="getAccount" bindingOperationName="getAccount" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings><con:setting id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment/></con:setting></con:settings><con:encoding>UTF-8</con:encoding><con:endpoint>https://localhost:2001</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:GetAccountRequest>
         <acc:accountId>261</acc:accountId>
         <acc:timeout>30000</acc:timeout>
      </acc:GetAccountRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:credentials><con:username>ref_account_dev1</con:username><con:password>*Wyu#Poi</con:password><con:authType>Global HTTP Settings</con:authType></con:credentials><con:jmsConfig JMSDeliveryMode="PERSISTENT"/><con:jmsPropertyConfig/><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/getAccount"/><con:wsrmConfig version="1.2"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/getCreditCard" name="getCreditCard" bindingOperationName="getCreditCard" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings><con:setting id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment/></con:setting></con:settings><con:encoding>UTF-8</con:encoding><con:endpoint>https://localhost:2001</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:GetCreditCardRequest>
         <acc:creditCardId>1160</acc:creditCardId>
         <acc:accountId>181</acc:accountId>
      </acc:GetCreditCardRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:credentials><con:username>ref_account_dev1</con:username><con:password>*Wyu#Poi</con:password><con:authType>Global HTTP Settings</con:authType></con:credentials><con:jmsConfig JMSDeliveryMode="PERSISTENT"/><con:jmsPropertyConfig/><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/getCreditCard"/><con:wsrmConfig version="1.2"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/getShippingAddress" name="getShippingAddress" bindingOperationName="getShippingAddress" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings><con:setting id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment/></con:setting></con:settings><con:encoding>UTF-8</con:encoding><con:endpoint>https://localhost:2001</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:GetShippingAddressRequest>
         <acc:addressId>2241</acc:addressId>
         <acc:accountId>181</acc:accountId>
      </acc:GetShippingAddressRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:credentials><con:username>ref_account_dev1</con:username><con:password>*Wyu#Poi</con:password><con:authType>Global HTTP Settings</con:authType></con:credentials><con:jmsConfig JMSDeliveryMode="PERSISTENT"/><con:jmsPropertyConfig/><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/getShippingAddress"/><con:wsrmConfig version="1.2"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/updateAccount" name="updateAccount" bindingOperationName="updateAccount" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings/><con:encoding>UTF-8</con:encoding><con:endpoint>https://localhost:2001</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:UpdateAccountRequest>
         <acc:account>
            <acc:accountId>?</acc:accountId>
            <acc:accountNumber>?</acc:accountNumber>
            <acc:firstName>?</acc:firstName>
            <acc:lastName>?</acc:lastName>
            <acc:emailAddress>?</acc:emailAddress>
            <!--Optional:-->
            <acc:dateOfBirth>?</acc:dateOfBirth>
            <acc:username>?</acc:username>
            <acc:creditCardList>
               <!--Zero or more repetitions:-->
               <acc:value>?</acc:value>
            </acc:creditCardList>
            <acc:shippingAddressList>
               <!--Zero or more repetitions:-->
               <acc:value>?</acc:value>
            </acc:shippingAddressList>
         </acc:account>
      </acc:UpdateAccountRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/updateAccount"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/updateCreditCard" name="updateCreditCard" bindingOperationName="updateCreditCard" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings><con:setting id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment/></con:setting></con:settings><con:encoding>UTF-8</con:encoding><con:endpoint>https://services-dev-fl1.express-scripts.com/accountservice/1/</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:UpdateCreditCardRequest>
         <acc:accountId>181</acc:accountId>
         <acc:creditCard>
            <acc:creditCardId>1200</acc:creditCardId>
            <acc:alias>PRIMARY</acc:alias>
            <acc:creditCardNumber>1234567890</acc:creditCardNumber>
            <acc:expirationMonth>10</acc:expirationMonth>
            <acc:expirationYear>2015</acc:expirationYear>
            <acc:nameOnCard>BuschB</acc:nameOnCard>
            <acc:status>ACTIVE</acc:status>
            <!--Optional:-->
            <acc:creditCardType>DIS</acc:creditCardType>
            <acc:billingAddress>
               <acc:addressId>2006</acc:addressId>
               <acc:name>HOME</acc:name>
               <acc:line1>TEST</acc:line1>
               <!--Optional:-->
               <acc:line2></acc:line2>
               <!--Optional:-->
               <acc:line3></acc:line3>
               <!--Optional:-->
               <acc:line4></acc:line4>
               <acc:city>MO</acc:city>
               <acc:state>MO</acc:state>
               <acc:zip5>12345</acc:zip5>
               <!--Optional:-->
               <acc:zip4>1111</acc:zip4>
               <!--Optional:-->
               <acc:status>ACTIVE</acc:status>
            </acc:billingAddress>
         </acc:creditCard>
      </acc:UpdateCreditCardRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:credentials><con:username>ref_account_dev1</con:username><con:password>*Wyu#Poi</con:password><con:authType>Global HTTP Settings</con:authType></con:credentials><con:jmsConfig JMSDeliveryMode="PERSISTENT"/><con:jmsPropertyConfig/><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/updateCreditCard"/><con:wsrmConfig version="1.2"/></con:call></con:operation><con:operation isOneWay="false" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/updateShippingAddress" name="updateShippingAddress" bindingOperationName="updateShippingAddress" type="Request-Response" inputName="" receivesAttachments="false" sendsAttachments="false" anonymous="optional"><con:settings/><con:call name="Request 1"><con:settings/><con:encoding>UTF-8</con:encoding><con:endpoint>https://localhost:2001</con:endpoint><con:request><![CDATA[<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:acc="http://account.ref.esrx.com">
   <soapenv:Header/>
   <soapenv:Body>
      <acc:UpdateShippingAddressRequest>
         <acc:accountId>?</acc:accountId>
         <acc:address>
            <acc:addressId>?</acc:addressId>
            <acc:name>?</acc:name>
            <acc:line1>?</acc:line1>
            <!--Optional:-->
            <acc:line2>?</acc:line2>
            <!--Optional:-->
            <acc:line3>?</acc:line3>
            <!--Optional:-->
            <acc:line4>?</acc:line4>
            <acc:city>?</acc:city>
            <acc:state>?</acc:state>
            <acc:zip5>?</acc:zip5>
            <!--Optional:-->
            <acc:zip4>?</acc:zip4>
            <!--Optional:-->
            <acc:active>?</acc:active>
         </acc:address>
      </acc:UpdateShippingAddressRequest>
   </soapenv:Body>
</soapenv:Envelope>]]></con:request><con:wsaConfig mustUnderstand="NONE" version="200508" action="/Services/SOAP/AccountServiceService.serviceagent/AccountServiceEndpoint1/updateShippingAddress"/></con:call></con:operation></con:interface><con:properties/><con:wssContainer/></con:soapui-project>