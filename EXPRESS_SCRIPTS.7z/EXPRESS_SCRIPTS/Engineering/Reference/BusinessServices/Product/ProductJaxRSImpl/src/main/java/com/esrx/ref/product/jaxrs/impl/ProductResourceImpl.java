package com.esrx.ref.product.jaxrs.impl;

import com.esrx.ref.product.CreateProductRequest;
import com.esrx.ref.product.CreateProductResponse;
import com.esrx.ref.product.FindProductRequest;
import com.esrx.ref.product.FindProductResponse;
import com.esrx.ref.product.GetImageRequest;
import com.esrx.ref.product.GetImageResponse;
import com.esrx.ref.product.GetProductRequest;
import com.esrx.ref.product.GetProductResponse;
import com.esrx.ref.product.SaveImageRequest;
import com.esrx.ref.product.UpdateProductRequest;
import com.esrx.ref.product.UpdateProductResponse;
import com.esrx.ref.product.bo.ProductBo;
import com.esrx.ref.product.bo.SaveImageResponse;
import com.esrx.ref.product.bo.impl.Constants;
import com.esrx.ref.product.jaxrs.ProductResource;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;
import com.express_scripts.inf.types.ResourceUnavailable;

/**
 * @author p043459
 * 
 */
public class ProductResourceImpl implements ProductResource {

	private ProductBo productBo;

	/**
	 * Method used to find a product information using the search criteria's.
	 */
	public FindProductResponse findProduct(FindProductRequest productRequest) {
		ProcessTimer.startTimer();
		FindProductResponse productResponse = null;

		try {
			com.esrx.ref.product.bo.FindProductRequest findProductRequest = RequestTransformer
					.convertToFindProductRequest(productRequest);

			com.esrx.ref.product.bo.FindProductResponse findProductResponse = productBo
					.findProduct(findProductRequest);

			productResponse = ResponseTransformer
					.convertToFindProductResponse(findProductResponse);
		} catch (InvalidRequest e) {
			throw new com.express_scripts.inf.types.jaxb.support.InvalidRequest(e);
		} catch (ProcessTimeoutException e) {
			throw new com.express_scripts.inf.types.jaxb.support.ResourceUnavailable(Constants.TIMED_OUT);
		} catch (ResourceUnavailable e) {
			throw new com.express_scripts.inf.types.jaxb.support.ResourceUnavailable(e);
		} catch (ProcessFailed e) {
			throw new com.express_scripts.inf.types.jaxb.support.ProcessFailed(e);
		} catch (Exception e) {
			throw new com.express_scripts.inf.types.jaxb.support.ProcessFailed();
		}

		return productResponse;
	}

	/**
	 * Method to get a product information using the product id.
	 * 
	 * @throws NotFound
	 */
	public GetProductResponse getProduct(GetProductRequest productRequest) {
		ProcessTimer.startTimer();
		GetProductResponse productResponse = null;
		try {
			com.esrx.ref.product.bo.GetProductRequest getProductRequest = RequestTransformer
					.convertToGetProductRequest(productRequest);

			com.esrx.ref.product.bo.GetProductResponse getProductResponse = productBo
					.getProduct(getProductRequest);

			productResponse = ResponseTransformer
					.convertToGetProductResponse(getProductResponse);
		} catch (Exception e) {
			catchAndThrow(e);
		}

		return productResponse;
	}

	/**
	 * Method used for creating a product.
	 */
	public CreateProductResponse createProduct(
			CreateProductRequest productRequest) {
		ProcessTimer.startTimer();
		CreateProductResponse response = null;
		try {
			com.esrx.ref.product.bo.CreateProductRequest createProductRequest = RequestTransformer
					.convertToCreateProductRequest(productRequest);

			com.esrx.ref.product.bo.CreateProductResponse createProductResponse = productBo
					.createProduct(createProductRequest);

			response = ResponseTransformer
					.convertToCreateProductResponse(createProductResponse);
		} catch (Exception e) {
			catchAndThrow(e);
		}

		return response;
	}

	/**
	 * Method used to update a product information.
	 */
	public UpdateProductResponse updateProduct(
			UpdateProductRequest productRequest) {
		ProcessTimer.startTimer();
		UpdateProductResponse response = null;
		try {
			com.esrx.ref.product.bo.UpdateProductRequest updateProductRequest = RequestTransformer
					.convertToUpdateProductRequest(productRequest);

			com.esrx.ref.product.bo.UpdateProductResponse updateProductResponse = productBo
					.updateProduct(updateProductRequest);

			response = ResponseTransformer
					.convertToUpdateProductResponse(updateProductResponse);
		} catch (Exception e) {
			catchAndThrow(e);
		}

		return response;
	}

	/**
	 * Method used to get an image using the image id.
	 */
	public GetImageResponse getImage(GetImageRequest imageRequest) {
		ProcessTimer.startTimer();
		GetImageResponse imageResponse = null;
		try {
			com.esrx.ref.product.bo.GetImageRequest getImageRequest = RequestTransformer
					.convertToGetImageRequest(imageRequest);

			com.esrx.ref.product.bo.GetImageResponse getImageResponse = productBo
					.getImage(getImageRequest);

			imageResponse = ResponseTransformer
					.convertToGetImageResponse(getImageResponse);

		} catch (Exception e) {
			catchAndThrow(e);
		}

		return imageResponse;
	}

	/**
	 * Method used to store an image.
	 */
	public com.esrx.ref.product.SaveImageResponse saveImage(
			SaveImageRequest imageRequest) {
		ProcessTimer.startTimer();
		com.esrx.ref.product.SaveImageResponse saveImageResponse = null;
		try {
			com.esrx.ref.product.bo.SaveImageRequest saveImageRequest = RequestTransformer
					.convertToSaveImageRequest(imageRequest);

			SaveImageResponse imageResponse = productBo
					.saveImage(saveImageRequest);

			saveImageResponse = ResponseTransformer
					.covertToSaveImageResponse(imageResponse);

		} catch (Exception e) {
			catchAndThrow(e);
		}

		return saveImageResponse;
	}
	
	private void catchAndThrow(Exception ex) {
		try {
			throw ex;
		} catch (InvalidRequest e) {
			throw new com.express_scripts.inf.types.jaxb.support.InvalidRequest(e);
		} catch (NotFound e) {
			throw new com.express_scripts.inf.types.jaxb.support.NotFound(e);
		} catch (ProcessTimeoutException e) {
			throw new com.express_scripts.inf.types.jaxb.support.ResourceUnavailable(Constants.TIMED_OUT);
		} catch (ResourceUnavailable e) {
			throw new com.express_scripts.inf.types.jaxb.support.ResourceUnavailable(e);
		} catch (ProcessFailed e) {
			throw new com.express_scripts.inf.types.jaxb.support.ProcessFailed(e);
		} catch (Exception e) {
			throw new com.express_scripts.inf.types.jaxb.support.ProcessFailed();
		}
	}

	/**
	 * @param productBo
	 *            the productBo to set
	 */
	public void setProductBo(ProductBo productBo) {
		this.productBo = productBo;
	}

}
