package com.esrx.ref.product.jaxrs.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.esrx.ref.product.ArrayOfCategory;
import com.esrx.ref.product.ArrayOfProductAttribute;
import com.esrx.ref.product.ArrayOfProductSummary;
import com.esrx.ref.product.CreateProductResponse;
import com.esrx.ref.product.FindProductResponse;
import com.esrx.ref.product.GetImageResponse;
import com.esrx.ref.product.GetProductResponse;
import com.esrx.ref.product.Image;
import com.esrx.ref.product.Price;
import com.esrx.ref.product.Product;
import com.esrx.ref.product.UpdateProductResponse;
import com.esrx.ref.product.bo.Category;
import com.esrx.ref.product.bo.ProductAttribute;
import com.esrx.ref.product.bo.ProductSummary;
import com.esrx.ref.product.bo.SaveImageResponse;

public class ResponseTransformer {

	public static FindProductResponse convertToFindProductResponse(
			com.esrx.ref.product.bo.FindProductResponse findProductResponse) {
		FindProductResponse productResponse = null;
		
		if(findProductResponse != null){
			productResponse = new FindProductResponse();
			productResponse.setTotalCount(findProductResponse.getTotalCount());
			productResponse.setProductSummaryList(convertToProductSummary(findProductResponse.getProductSummaryList()));
		}
		
		return productResponse;
	}

	public static GetProductResponse convertToGetProductResponse(
			com.esrx.ref.product.bo.GetProductResponse getProductResponse) {
		GetProductResponse productResponse = null;
		
		if(getProductResponse != null){
			productResponse = new GetProductResponse();
			if(getProductResponse.getProduct() != null){
				Product product = new Product();
				product.setProductAttributeList(convertToArrayOfAttributes(getProductResponse.getProduct().getAttributes()));
				product.setCategoryList(convertToArrayOfCatgories(getProductResponse.getProduct().getCategories()));
				product.setDescription(getProductResponse.getProduct().getDescription());
				product.setInventoryCount(getProductResponse.getProduct().getInventoryCount());
				product.setPrice(convertToPrice(getProductResponse.getProduct().getPrice()));
				product.setProductId(getProductResponse.getProduct().getProductId());
				product.setProductName(getProductResponse.getProduct().getProductName());
				product.setUpc(getProductResponse.getProduct().getUpc());
				productResponse.setProduct(product);
			}
		}
		return productResponse;
	}

	public static GetImageResponse convertToGetImageResponse(
			com.esrx.ref.product.bo.GetImageResponse getImageResponse) {
		
		GetImageResponse imageResponse = null;
		if(getImageResponse != null){
			imageResponse = new GetImageResponse();
			if(getImageResponse.getImage() != null){
				Image image = new Image();
				image.setData(getImageResponse.getImage().getData());
				image.setMimeType(getImageResponse.getImage().getMimeType());
				imageResponse.setImage(image);
			}
		}
		return imageResponse;
	}
	
	private static ArrayOfProductSummary convertToProductSummary(
			List<ProductSummary> productSummaryList) {
		ArrayOfProductSummary arrayOfProductSummary = null;
		
		if(CollectionUtils.isNotEmpty(productSummaryList)){
			arrayOfProductSummary = new ArrayOfProductSummary();
			for(ProductSummary productSummary : productSummaryList){
				com.esrx.ref.product.ProductSummary summary = new com.esrx.ref.product.ProductSummary();
				summary.setPrice(convertToPrice(productSummary.getPrice()));
				summary.setProductId(productSummary.getProductId());
				summary.setProductName(productSummary.getProductName());
				summary.setImageId(productSummary.getImageId());
				arrayOfProductSummary.getProducts().add(summary);
			}
			
			
			
		}
		return arrayOfProductSummary;
	}

	private static Price convertToPrice(com.esrx.ref.product.bo.Price price) {
		Price price2 = null;
		if(price != null){
			price2 = new Price();
			price2.setAmount(price.getAmount());
			price2.setCurrency(price.getCurrency());
			price2.setFormattedAmount(price.getFormattedAmount());
		}
		
		return price2;
	}

	private static ArrayOfCategory convertToArrayOfCatgories(
			List<Category> categories) {
		ArrayOfCategory arrayOfCategory = null;
		if(CollectionUtils.isNotEmpty(categories)){
			arrayOfCategory = new ArrayOfCategory();
			for(Category category : categories){
				if (category != null) {
					com.esrx.ref.product.Category category2 = new com.esrx.ref.product.Category();
					category2.setCategoryId(category.getCategoryId());
					category2.setCategoryName(category.getCategoryName());
					arrayOfCategory.getCategories().add(category2);
				}
			}
			
		}
		return arrayOfCategory;
	}
	
	private static ArrayOfProductAttribute convertToArrayOfAttributes(
			List<ProductAttribute> attributes) {
		ArrayOfProductAttribute arrayOfProductAttribute = null;
		if(CollectionUtils.isNotEmpty(attributes)){
			arrayOfProductAttribute = new ArrayOfProductAttribute();
			for(ProductAttribute productAttribute : attributes){
				if (productAttribute != null) {
					com.esrx.ref.product.ProductAttribute productAttribute2 = new com.esrx.ref.product.ProductAttribute();
					productAttribute2.setAttributeName(productAttribute
							.getAttributeName());
					productAttribute2.setAttributeValue(productAttribute
							.getAttributeValue());
					arrayOfProductAttribute.getProductAttributes().add(
							productAttribute2);
				}
			}
			
		}
		return arrayOfProductAttribute;
	}

	public static UpdateProductResponse convertToUpdateProductResponse(
			com.esrx.ref.product.bo.UpdateProductResponse productResponse) {
		
		UpdateProductResponse response = null;
		if(productResponse != null){
			response = new UpdateProductResponse();
			response.setProductId(productResponse.getProductId());
		}
		
		return response;
	}

	public static CreateProductResponse convertToCreateProductResponse(
			com.esrx.ref.product.bo.CreateProductResponse productResponse) {
		
		CreateProductResponse response = null;
		if(productResponse != null){
			response = new CreateProductResponse();
			response.setProductId(productResponse.getProductId());
		}
		return response;
	}

	public static com.esrx.ref.product.SaveImageResponse covertToSaveImageResponse(
			SaveImageResponse imageResponse) {
		com.esrx.ref.product.SaveImageResponse response = null;
		if(imageResponse != null){
			response = new com.esrx.ref.product.SaveImageResponse();
			response.setProductId(imageResponse.getId());
		}
		return response;
	}



}
