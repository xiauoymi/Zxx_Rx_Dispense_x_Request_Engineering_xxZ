package com.esrx.ref.product.jaxrs.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.StringUtils;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.esrx.ref.product.ArrayOfCategory;
import com.esrx.ref.product.ArrayOfProductAttribute;
import com.esrx.ref.product.CreateProductRequest;
import com.esrx.ref.product.FindProductRequest;
import com.esrx.ref.product.FindProductResponse;
import com.esrx.ref.product.GetImageRequest;
import com.esrx.ref.product.GetProductRequest;
import com.esrx.ref.product.SaveImageRequest;
import com.esrx.ref.product.UpdateProductRequest;
import com.esrx.ref.product.bo.Category;
import com.esrx.ref.product.bo.CreateProductResponse;
import com.esrx.ref.product.bo.GetImageResponse;
import com.esrx.ref.product.bo.Image;
import com.esrx.ref.product.bo.Price;
import com.esrx.ref.product.bo.Product;
import com.esrx.ref.product.bo.ProductAttribute;
import com.esrx.ref.product.bo.ProductBo;
import com.esrx.ref.product.bo.ProductSummary;
import com.esrx.ref.product.bo.SaveImageResponse;
import com.esrx.ref.product.bo.UpdateProductResponse;
import com.esrx.ref.product.bo.impl.Constants;
import com.esrx.ref.product.bo.impl.ErrorCodes;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;
import com.express_scripts.inf.types.jaxb.ArrayOfSortOption;
import com.express_scripts.inf.types.jaxb.ErrorInfo;


public class ProductResourceImplTest {
	
	 private ProductResourceImpl impl;
	 
	 private ProductBo productBoMock = EasyMock.createMock(ProductBo.class);
	
	@Before
	public void setuUp(){
		impl = new ProductResourceImpl();
		impl.setProductBo(productBoMock);
	}

	@Test
	public void testFindProduct() throws InvalidRequest{
		FindProductRequest findProductRequest = new FindProductRequest();
		findProductRequest.setCategoryId("1");
		findProductRequest.setProductAttributeList(new ArrayOfProductAttribute());
		findProductRequest.setCount(10);
		findProductRequest.setInStock(true);
		findProductRequest.setMatchCase(true);
		findProductRequest.setOffset(0);
		findProductRequest.setKeywords(StringUtils.EMPTY);
		findProductRequest.setUpc("0");
		findProductRequest.setSortOptionList(new ArrayOfSortOption());
		findProductRequest.setTimeout(30000L);
		EasyMock.expect(productBoMock.findProduct(EasyMock.anyObject(com.esrx.ref.product.bo.FindProductRequest.class))).andReturn(buildFindProductResponse(10));
		EasyMock.replay(productBoMock);
		FindProductResponse findProductResponse = impl.findProduct(findProductRequest);
		assertNotNull(findProductResponse);
		assertNotNull(findProductResponse.getProductSummaryList());
		assertNotNull(findProductResponse.getProductSummaryList().getProducts().get(0));
		assertNotNull(findProductResponse.getProductSummaryList().getProducts().get(0).getPrice());
		assertEquals(10, findProductResponse.getTotalCount());
		assertEquals(1, findProductResponse.getProductSummaryList().getProducts().size());
		assertEquals("1", findProductResponse.getProductSummaryList().getProducts().get(0).getProductId());
		assertEquals("Bat", findProductResponse.getProductSummaryList().getProducts().get(0).getProductName());
		assertEquals("$", findProductResponse.getProductSummaryList().getProducts().get(0).getPrice().getCurrency());
		assertEquals(new BigDecimal("55.25"), findProductResponse.getProductSummaryList().getProducts().get(0).getPrice().getAmount());
		assertEquals("$55.25", findProductResponse.getProductSummaryList().getProducts().get(0).getPrice().getFormattedAmount());
		
	}

	@Test(expected=com.express_scripts.inf.types.jaxb.support.InvalidRequest.class)
	public void testFindProductInvalidRequest() throws InvalidRequest {
		FindProductRequest findProductRequest = new FindProductRequest();
		EasyMock.expect(productBoMock.findProduct(EasyMock.anyObject(com.esrx.ref.product.bo.FindProductRequest.class))).andThrow(buildInvalidRequest());
		EasyMock.replay(productBoMock);
		impl.findProduct(findProductRequest);
	}
	
	@Test(expected=com.express_scripts.inf.types.jaxb.support.InvalidRequest.class)
	public void testFindProductInvalidRequestNoRequest() throws InvalidRequest {
		EasyMock.expect(productBoMock.findProduct(EasyMock.anyObject(com.esrx.ref.product.bo.FindProductRequest.class))).andThrow(buildInvalidRequest());
		EasyMock.replay(productBoMock);
		impl.findProduct(null);
	}
	
	@Test(expected=com.express_scripts.inf.types.jaxb.support.ProcessFailed.class)
	public void testFindProductProcessFailed() throws InvalidRequest {
		EasyMock.expect(productBoMock.findProduct(EasyMock.anyObject(com.esrx.ref.product.bo.FindProductRequest.class))).andThrow(new ProcessFailed());
		EasyMock.replay(productBoMock);
		impl.findProduct(null);
	}

	@Test
	public void testGetProduct() throws InvalidRequest, NotFound {
		EasyMock.expect(productBoMock.getProduct(EasyMock.anyObject(com.esrx.ref.product.bo.GetProductRequest.class))).andReturn(buildProductResponse());
		EasyMock.replay(productBoMock);
		/*GetProductResponse response = impl.getProduct(request);
		assertNotNull(response);
		assertNotNull(response.getProduct());*/
	}
	
	@Test(expected=com.express_scripts.inf.types.jaxb.support.InvalidRequest.class)
	public void testGetProductInvalidRequest() throws InvalidRequest, NotFound {
		EasyMock.expect(productBoMock.getProduct(EasyMock.anyObject(com.esrx.ref.product.bo.GetProductRequest.class))).andThrow(buildInvalidRequest());
		EasyMock.replay(productBoMock);
		impl.getProduct(null);
	}
	
	@Test(expected=com.express_scripts.inf.types.jaxb.support.InvalidRequest.class)
	public void testGetProductInvalidRequestNoProductId() throws InvalidRequest, NotFound {
		GetProductRequest request = new GetProductRequest();
		request.setTimeout(8000L);
		EasyMock.expect(productBoMock.getProduct(EasyMock.anyObject(com.esrx.ref.product.bo.GetProductRequest.class))).andThrow(buildInvalidRequest());
		EasyMock.replay(productBoMock);
		impl.getProduct(request);
	}
	
	@Test(expected=com.express_scripts.inf.types.jaxb.support.InvalidRequest.class)
	public void testGetProductInvalidRequestProductIdNotANumber() throws InvalidRequest, NotFound {
		GetProductRequest request = new GetProductRequest();
		request.setProductId("A");
		request.setTimeout(8000L);
		EasyMock.expect(productBoMock.getProduct(EasyMock.anyObject(com.esrx.ref.product.bo.GetProductRequest.class))).andThrow(buildInvalidRequest());
		EasyMock.replay(productBoMock);
		impl.getProduct(request);
	}
	
	@Test
	public void testCreateProduct() throws InvalidRequest {
		CreateProductRequest request = new CreateProductRequest();
		request.setProduct(buildProduct());
		request.setTimeout(3000L);
		EasyMock.expect(productBoMock.createProduct(EasyMock.anyObject(com.esrx.ref.product.bo.CreateProductRequest.class))).andReturn(new CreateProductResponse());
		EasyMock.replay(productBoMock);
		impl.createProduct(request);
		EasyMock.verify(productBoMock);
	}
	
	@Test(expected=com.express_scripts.inf.types.jaxb.support.InvalidRequest.class)
	public void testCreateProductInvalidRequest() throws Exception {
		CreateProductRequest request = new CreateProductRequest();
		request.setProduct(buildProduct());
		request.setTimeout(3000L);
		productBoMock.createProduct(EasyMock.anyObject(com.esrx.ref.product.bo.CreateProductRequest.class));
		EasyMock.expectLastCall().andThrow(buildInvalidRequest());
		EasyMock.replay(productBoMock);
		try {
			impl.createProduct(null);
			
		} catch (Exception e) {
			EasyMock.verify(productBoMock);
			throw(e);
		}
	}
	
	@Test
	public void testUpdateProduct() throws InvalidRequest {
		UpdateProductRequest request = new UpdateProductRequest();
		request.setProduct(buildProduct());
		request.setTimeout(3000L);
		EasyMock.expect(productBoMock.updateProduct(EasyMock.anyObject(com.esrx.ref.product.bo.UpdateProductRequest.class))).andReturn(new UpdateProductResponse());
		EasyMock.replay(productBoMock);
		impl.updateProduct(request);
		EasyMock.verify(productBoMock);
	}
	
	@Test(expected=com.express_scripts.inf.types.jaxb.support.InvalidRequest.class)
	public void testUpdateProductInvalidRequest() throws Exception {
		UpdateProductRequest request = new UpdateProductRequest();
		request.setProduct(buildProduct());
		request.setTimeout(3000L);
		productBoMock.updateProduct(EasyMock.anyObject(com.esrx.ref.product.bo.UpdateProductRequest.class));
		EasyMock.expectLastCall().andThrow(buildInvalidRequest());
		EasyMock.replay(productBoMock);
		try {
			impl.updateProduct(null);
			
		} catch (Exception e) {
			EasyMock.verify(productBoMock);
			throw e;
		}
	}
	
	@Test
	public void testGetImage() throws NotFound, InvalidRequest {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("1");
		EasyMock.expect(productBoMock.getImage(EasyMock.anyObject(com.esrx.ref.product.bo.GetImageRequest.class))).andReturn(buildImageResponse());
		EasyMock.replay(productBoMock);
		com.esrx.ref.product.GetImageResponse response = impl.getImage(request);
		assertNotNull(response);
		assertNotNull(response.getImage());
		assertEquals("image/png", response.getImage().getMimeType());
	}
	
	@Test(expected=com.express_scripts.inf.types.jaxb.support.InvalidRequest.class)
	public void testGetImageInvalidRequest() throws NotFound, InvalidRequest {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("1");
		EasyMock.expect(productBoMock.getImage(EasyMock.anyObject(com.esrx.ref.product.bo.GetImageRequest.class))).andThrow(buildInvalidRequest());
		EasyMock.replay(productBoMock);
		impl.getImage(request);
	}
	
	@Test(expected=com.express_scripts.inf.types.jaxb.support.NotFound.class)
	public void testGetImageNotFound() throws NotFound, InvalidRequest {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("1");
		EasyMock.expect(productBoMock.getImage(EasyMock.anyObject(com.esrx.ref.product.bo.GetImageRequest.class))).andThrow(new NotFound());
		EasyMock.replay(productBoMock);
		impl.getImage(request);
	}
	
	@Test
	public void testSaveImage() throws InvalidRequest {
		SaveImageRequest createImageRequest = new SaveImageRequest();
		com.esrx.ref.product.Image value = new com.esrx.ref.product.Image();
		value.setData(new byte[0]);
		value.setMimeType("image/jpeg");
		createImageRequest.setImage(value);
		createImageRequest.setProductId("1");
		EasyMock.expect(productBoMock.saveImage(EasyMock.anyObject(com.esrx.ref.product.bo.SaveImageRequest.class))).andReturn(new SaveImageResponse());
		EasyMock.replay(productBoMock);
		impl.saveImage(createImageRequest);
		EasyMock.verify(productBoMock);
	}
	@Test(expected=com.express_scripts.inf.types.jaxb.support.InvalidRequest.class)
	public void testSaveImageInvalidRequest() throws Exception {
		SaveImageRequest createImageRequest = new SaveImageRequest();
		createImageRequest.setImage(null);
		createImageRequest.setProductId("1");
		productBoMock.saveImage(EasyMock.anyObject(com.esrx.ref.product.bo.SaveImageRequest.class));
		EasyMock.expectLastCall().andThrow(buildInvalidRequest());
		EasyMock.replay(productBoMock);
		try {
			impl.saveImage(createImageRequest);
		} catch (Exception e) {
			EasyMock.verify(productBoMock);
			throw e;
		}
		
	}
	
	private GetImageResponse buildImageResponse() {
		GetImageResponse getImageResponse = new GetImageResponse();
		Image image = new Image();
		image.setData(new byte[0]);
		image.setMimeType("image/png");
		getImageResponse.setImage(image);
		return getImageResponse;
	}

	/*

	

	/**
	 * @return
	 */
	private InvalidRequest buildInvalidRequest() {
		return new InvalidRequest();
	}
	
	private com.esrx.ref.product.Product buildProduct() {
		com.esrx.ref.product.Product product = new com.esrx.ref.product.Product();
		product.setProductAttributeList(buildArrayOfAttributes());
		product.setCategoryList(buildArrayOfCategories());
		product.setDescription("Description");
		product.setInventoryCount(10);
		product.setPrice(buildRefPrice("$", "90.00"));
		product.setProductId("1");
		product.setProductName("Ball");
		product.setUpc("1234?");
		return product;
	}
	
	private com.esrx.ref.product.Price buildRefPrice(String currency,
			String amount) {
		com.esrx.ref.product.Price price = new com.esrx.ref.product.Price();
		price.setCurrency(currency);
		price.setAmount(new BigDecimal(amount));
		price.setFormattedAmount(currency+amount);
		return price;
	}

	private ArrayOfCategory buildArrayOfCategories() {
		ArrayOfCategory arrayOfCategory = new ArrayOfCategory();
		com.esrx.ref.product.Category category = new com.esrx.ref.product.Category();
		category.setCategoryId("2");
		category.setCategoryName("Test");
		arrayOfCategory.getCategories().add(category);
		return arrayOfCategory;
	}

	private ArrayOfProductAttribute buildArrayOfAttributes() {
		ArrayOfProductAttribute arrayOfProductAttribute = new ArrayOfProductAttribute();
		com.esrx.ref.product.ProductAttribute attribute = new com.esrx.ref.product.ProductAttribute();
		attribute.setAttributeValue("TEster");
		attribute.setAttributeName("Test");
		arrayOfProductAttribute.getProductAttributes().add(attribute);
		return arrayOfProductAttribute;
	}

	private com.esrx.ref.product.bo.GetProductResponse buildProductResponse() {
		com.esrx.ref.product.bo.GetProductResponse getProductResponse = new com.esrx.ref.product.bo.GetProductResponse();
		Product product = new Product();
		product.setAttributes(buildListOfAttributes());
		product.setCategories(buildListOfCategories());
		product.setDescription("Description");
		product.setInventoryCount(10);
		product.setPrice(buildPrice("$", "90.00"));
		product.setProductId("1");
		product.setProductName("Ball");
		product.setUpc("1234?");
		getProductResponse.setProduct(product);
		return getProductResponse;
	}

	private List<ProductAttribute> buildListOfAttributes() {
		List<ProductAttribute> attributes = new ArrayList<ProductAttribute>();
		attributes.add(new ProductAttribute());
		return attributes;
	}

	private com.esrx.ref.product.bo.FindProductResponse buildFindProductResponse(
			int count) {
		com.esrx.ref.product.bo.FindProductResponse findProductResponse = new com.esrx.ref.product.bo.FindProductResponse();
		findProductResponse.setTotalCount(count);
		List<ProductSummary> productSummaries = new ArrayList<ProductSummary>();
		ProductSummary productSummary = new ProductSummary();
		productSummary.setProductId("1");
		productSummary.setProductName("Bat");
		productSummary.setPrice(buildPrice("$","55.25"));
		productSummary.setImageId("1");
		productSummaries.add(productSummary);
		
		findProductResponse.setProductSummaryList(productSummaries);
		return findProductResponse;
	}
	
	private List<Category> buildListOfCategories() {
		List<Category> categories = new ArrayList<Category>();
		categories.add(new Category());
		return categories;
	}

	private Price buildPrice(String currency, String amount) {
		Price price = new Price();
		price.setCurrency(currency);
		price.setAmount(new BigDecimal(amount));
		price.setFormattedAmount(currency+amount);
		return price;
	}

	/**
	 * @param e
	 * @param message 
	 * @param errorCode 
	 * @param expectedStatus
	 */
	private void testErrorInfo(Exception e, String errorCode, String message, Status expectedStatus) {
		Response response = ((WebApplicationException)e).getResponse();
		assertNotNull(response);
		assertEquals(expectedStatus.getStatusCode(), response.getStatus());
		ErrorInfo errorInfo = (ErrorInfo)response.getEntity();
		assertEquals(message, errorInfo.getMessage());
		assertEquals(errorCode, errorInfo.getCode());
		assertNull(errorInfo.getData());
	}

}
