package com.esrx.ref.product.jaxrs.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.esrx.ref.product.ArrayOfCategory;
import com.esrx.ref.product.ArrayOfProductAttribute;
import com.esrx.ref.product.CreateProductRequest;
import com.esrx.ref.product.FindProductRequest;
import com.esrx.ref.product.GetImageRequest;
import com.esrx.ref.product.GetProductRequest;
import com.esrx.ref.product.Product;
import com.esrx.ref.product.ProductAttribute;
import com.esrx.ref.product.SaveImageRequest;
import com.esrx.ref.product.UpdateProductRequest;
import com.esrx.ref.product.bo.Category;
import com.esrx.ref.product.bo.Image;
import com.esrx.ref.product.bo.Price;
import com.express_scripts.inf.types.jaxb.support.SortOptionsUtils;

public class RequestTransformer {

	public static com.esrx.ref.product.bo.FindProductRequest convertToFindProductRequest(
			FindProductRequest productRequest) {
		
		com.esrx.ref.product.bo.FindProductRequest findProductRequest = null;
		
		if(productRequest != null){
			findProductRequest = new com.esrx.ref.product.bo.FindProductRequest();
			findProductRequest.setCategoryId(productRequest.getCategoryId());
			findProductRequest.setCount(productRequest.getCount());
			findProductRequest.setInStock(productRequest.isInStock());
			findProductRequest.setMatchCase(productRequest.isMatchCase());
			findProductRequest.setOffset(productRequest.getOffset());
			findProductRequest.setQuery(productRequest.getKeywords());
			findProductRequest.setUpc(productRequest.getUpc());
			findProductRequest.setAttributes(convertToBoAttributes(productRequest.getProductAttributeList()));
			findProductRequest.setSortOptions(SortOptionsUtils.convertToListSortOptions(productRequest.getSortOptionList()));
			findProductRequest.setTimeout(productRequest.getTimeout());
		}
		
		return findProductRequest;
	}

	public static com.esrx.ref.product.bo.GetProductRequest convertToGetProductRequest(
			GetProductRequest productRequest) {
		
		com.esrx.ref.product.bo.GetProductRequest getProductRequest = null;
		
		if(productRequest != null){
			getProductRequest = new com.esrx.ref.product.bo.GetProductRequest();
			getProductRequest.setProductId(productRequest.getProductId());
			getProductRequest.setTimeout(productRequest.getTimeout());
		}
		
		return getProductRequest;
	}

	public static com.esrx.ref.product.bo.CreateProductRequest convertToCreateProductRequest(
			CreateProductRequest productRequest) {
		com.esrx.ref.product.bo.CreateProductRequest createProductRequest = null;
		
		if(productRequest != null){
			createProductRequest = new com.esrx.ref.product.bo.CreateProductRequest();
			createProductRequest.setProduct(convertToBoProduct(productRequest.getProduct()));
			createProductRequest.setTimeout(productRequest.getTimeout());
			
		}
		
		return createProductRequest;
	}

	public static com.esrx.ref.product.bo.UpdateProductRequest convertToUpdateProductRequest(
			UpdateProductRequest productRequest) {
		com.esrx.ref.product.bo.UpdateProductRequest updateProductRequest = null;
		
		if(productRequest != null){
			updateProductRequest = new com.esrx.ref.product.bo.UpdateProductRequest();
			updateProductRequest.setProduct(convertToBoProduct(productRequest.getProduct()));
			updateProductRequest.setTimeout(productRequest.getTimeout());
		}
		
		return updateProductRequest;
	}

	public static com.esrx.ref.product.bo.GetImageRequest convertToGetImageRequest(
			GetImageRequest imageRequest) {
		com.esrx.ref.product.bo.GetImageRequest getImageRequest = null;
		
		if(imageRequest != null){
			getImageRequest = new com.esrx.ref.product.bo.GetImageRequest();
			getImageRequest.setProductId(imageRequest.getProductId());
			getImageRequest.setTimeout(imageRequest.getTimeout());
		}
		return getImageRequest;
	}

	public static com.esrx.ref.product.bo.SaveImageRequest convertToSaveImageRequest(
			SaveImageRequest imageRequest) {
		com.esrx.ref.product.bo.SaveImageRequest saveImageRequest = null;
		
		if(imageRequest != null){
			saveImageRequest = new com.esrx.ref.product.bo.SaveImageRequest();
			saveImageRequest.setImage(convertToBoImage(imageRequest.getImage()));
			saveImageRequest.setProductId(imageRequest.getProductId());
			saveImageRequest.setTimeout(imageRequest.getTimeout());
		}
		return saveImageRequest;
	}

	

	private static List<com.esrx.ref.product.bo.ProductAttribute> convertToBoAttributes(
			ArrayOfProductAttribute attributes) {
		List<com.esrx.ref.product.bo.ProductAttribute> productAttributes = null;
		
		if(attributes != null && CollectionUtils.isNotEmpty(attributes.getProductAttributes())){
			productAttributes = new ArrayList<com.esrx.ref.product.bo.ProductAttribute>();
			for(ProductAttribute attribute : attributes.getProductAttributes()){
				com.esrx.ref.product.bo.ProductAttribute productAttribute = new com.esrx.ref.product.bo.ProductAttribute();
				productAttribute.setAttributeName(attribute.getAttributeName());
				productAttribute.setAttributeValue(attribute.getAttributeValue());
				productAttributes.add(productAttribute);
			}
		}
		return productAttributes;
	}
	
	private static com.esrx.ref.product.bo.Product convertToBoProduct(
			Product product) {
		com.esrx.ref.product.bo.Product product2 = null;
		if(product != null){
			product2 = new com.esrx.ref.product.bo.Product();
			product2.setAttributes(convertToBoAttributes(product.getProductAttributeList()));
			product2.setCategories(covertToBoCategories(product.getCategoryList()));
			product2.setDescription(product.getDescription());
			product2.setInventoryCount(product.getInventoryCount());
			product2.setPrice(convertToBoPrice(product.getPrice()));
			product2.setProductId(product.getProductId());
			product2.setProductName(product.getProductName());
			product2.setUpc(product.getUpc());
			
		}
		return product2;
	}

	private static Price convertToBoPrice(com.esrx.ref.product.Price price) {
		Price price2 = null;
		if(price != null){
			price2 = new Price();
			price2.setAmount(price.getAmount());
			price2.setCurrency(price.getCurrency());
			price2.setFormattedAmount(price.getFormattedAmount());
		}
		return price2;
	}

	private static List<Category> covertToBoCategories(
			ArrayOfCategory categories) {
		List<Category> categories2 = null;
		if(categories != null && CollectionUtils.isNotEmpty(categories.getCategories())){
			categories2 = new ArrayList<Category>();
			for(com.esrx.ref.product.Category category : categories.getCategories()){
				Category category2 = new Category();
				category2.setCategoryId(category.getCategoryId());
				category2.setCategoryName(category.getCategoryName());
				categories2.add(category2);
			}
		}
		return categories2;
	}
	
	private static Image convertToBoImage(com.esrx.ref.product.Image image) {
		Image image2 = null;
		if(image != null){
			image2 = new Image();
			image2.setData(image.getData());
			image2.setMimeType(image.getMimeType());
			
		}
		return image2;
	}
	
}
