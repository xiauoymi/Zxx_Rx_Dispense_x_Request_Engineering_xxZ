package com.esrx.ref.product.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.carbonfive.testutils.spring.dbunit.DataSet;
import com.esrx.ref.product.BaseTest;
import com.esrx.ref.product.dao.ProductDao;
import com.esrx.ref.product.domain.Category;
import com.esrx.ref.product.domain.Product;
import com.esrx.ref.product.domain.ProductAttribute;
import com.esrx.ref.product.domain.ProductAttributeKey;
import com.esrx.ref.product.domain.ProductResponse;
import com.express_scripts.inf.types.SortOption;
import com.express_scripts.inf.types.SortOrder;

public class ProductDaoImplTest extends BaseTest{

	@Autowired
	private ProductDao productDao;
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testGet() throws Exception {
		Product product = productDao.findById("1");
		validateProduct(product, "1");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByQuery() throws Exception {
		ProductResponse resp = productDao.findProduct(false, null, null, null, "%DeSc%", null, 0, 0, null, 10000);
		Assert.assertEquals(2, resp.getTotalCount());
		Assert.assertEquals(2, resp.getProductList().size());
		validateProduct(resp.getProductList().get(0), "1");
		validateProduct(resp.getProductList().get(1), "2");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByQueryMatchCase() throws Exception {
		ProductResponse resp = productDao.findProduct(true, null, null, null, "%desc%", null, 0, 0, null, 10000);
		Assert.assertEquals(2, resp.getTotalCount());
		Assert.assertEquals(2, resp.getProductList().size());
		validateProduct(resp.getProductList().get(0), "1");
		validateProduct(resp.getProductList().get(1), "2");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByQueryMatchCaseNotFound() throws Exception {
		ProductResponse resp = productDao.findProduct(true, null, null, null, "%DeSc%", null, 0, 0, null, 10000);
		Assert.assertEquals(0, resp.getTotalCount());
		Assert.assertEquals(0, resp.getProductList().size());
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByInStock() throws Exception {
		ProductResponse resp = productDao.findProduct(false, null, null, Boolean.TRUE, null, null, 0, 0, null, 10000);
		Assert.assertEquals(2, resp.getTotalCount());
		Assert.assertEquals(2, resp.getProductList().size());
		validateProduct(resp.getProductList().get(0), "1");
		validateProduct(resp.getProductList().get(1), "2");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByCategory() throws Exception {
		ProductResponse resp = productDao.findProduct(false, "1", null, null, null, null, 0, 0, null, 10000);
		Assert.assertEquals(1, resp.getTotalCount());
		Assert.assertEquals(1, resp.getProductList().size());
		validateProduct(resp.getProductList().get(0), "1");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByUpc() throws Exception {
		ProductResponse resp = productDao.findProduct(false, null, "2", null, null, null, 0, 0, null, 10000);
		Assert.assertEquals(1, resp.getTotalCount());
		Assert.assertEquals(1, resp.getProductList().size());
		validateProduct(resp.getProductList().get(0), "2");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindSort() throws Exception {
		List<SortOption> sortOptions = new ArrayList<SortOption>();
		SortOption so1 = new SortOption();
		so1.setFieldName("upc");
		so1.setSortOrder(SortOrder.DESC);
		sortOptions.add(so1);
		
		ProductResponse resp = productDao.findProduct(false, null, null, null, null, null, 0, 0, sortOptions, 10000);
		Assert.assertEquals(2, resp.getTotalCount());
		Assert.assertEquals(2, resp.getProductList().size());
		validateProduct(resp.getProductList().get(0), "2");
		validateProduct(resp.getProductList().get(1), "1");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindPage1() throws Exception {
		ProductResponse resp = productDao.findProduct(false, null, null, null, null, null, 0, 1, null, 10000);
		Assert.assertEquals(2, resp.getTotalCount());
		Assert.assertEquals(1, resp.getProductList().size());
		validateProduct(resp.getProductList().get(0), "1");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindPage2() throws Exception {
		ProductResponse resp = productDao.findProduct(false, null, null, null, null, null, 1, 1, null, 10000);
		Assert.assertEquals(2, resp.getTotalCount());
		Assert.assertEquals(1, resp.getProductList().size());
		validateProduct(resp.getProductList().get(0), "2");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testCreate() throws Exception {
		Product product = createProduct("3");
		productDao.persist(product);
		Product response = productDao.findById("3");
		validateProduct(response, "3");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testUpdate() throws Exception {
		Product product = createProduct("3");
		productDao.persist(product);
		Product response = productDao.findById("3");
		updateProduct(response);
		productDao.flushSession();
		response = productDao.findById("3");
		validateUpdatedProduct(response, "3");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testDelete() throws Exception {
		Product response = productDao.findById("1");
		productDao.delete(response);
		productDao.flushSession();
		response = productDao.findById("1");
		Assert.assertNull(response);
	}
	
	private void validateProduct(Product product, String productId) {
		Assert.assertEquals(productId, product.getProductId());
		Assert.assertEquals("product-" + productId, product.getProductName());
		Assert.assertEquals("product-desc-" + productId, product.getDescription());
		Assert.assertEquals(productId, product.getUpc());
		Assert.assertEquals(100, product.getInventoryCount());
		Assert.assertEquals(new BigDecimal("1.00"), product.getPrice());
		Assert.assertEquals(1, product.getCategories().size());
		Assert.assertEquals(productId, product.getCategories().get(0).getCategoryId());
		Assert.assertEquals("category-" + productId, product.getCategories().get(0).getCategoryName());
		Assert.assertEquals(2, product.getAttributes().size());
		Assert.assertEquals(productId, product.getAttributes().get(0).getKey().getProductId());
		Assert.assertEquals("name-" + productId + "-0", product.getAttributes().get(0).getKey().getAttributeName());
		Assert.assertEquals("value-" + productId + "-0", product.getAttributes().get(0).getAttributeValue());
		Assert.assertEquals(productId, product.getAttributes().get(1).getKey().getProductId());
		Assert.assertEquals("name-" + productId + "-1", product.getAttributes().get(1).getKey().getAttributeName());
		Assert.assertEquals("value-" + productId + "-1", product.getAttributes().get(1).getAttributeValue());
	}
	
	private void validateUpdatedProduct(Product product, String productId) {
		Assert.assertEquals(productId, product.getProductId());
		Assert.assertEquals("xproduct-" + productId, product.getProductName());
		Assert.assertEquals("xproduct-desc-" + productId, product.getDescription());
		Assert.assertEquals(productId, product.getUpc());
		Assert.assertEquals(200, product.getInventoryCount());
		Assert.assertEquals(new BigDecimal("2.00"), product.getPrice());
		Assert.assertEquals(1, product.getCategories().size());
		Assert.assertEquals(productId, product.getCategories().get(0).getCategoryId());
		Assert.assertEquals("category-" + productId, product.getCategories().get(0).getCategoryName());
		Assert.assertEquals(3, product.getAttributes().size());
		Assert.assertEquals(productId, product.getAttributes().get(0).getKey().getProductId());
		Assert.assertEquals("name-" + productId + "-0", product.getAttributes().get(0).getKey().getAttributeName());
		Assert.assertEquals("value-" + productId + "-0", product.getAttributes().get(0).getAttributeValue());
		Assert.assertEquals(productId, product.getAttributes().get(1).getKey().getProductId());
		Assert.assertEquals("name-" + productId + "-1", product.getAttributes().get(1).getKey().getAttributeName());
		Assert.assertEquals("value-" + productId + "-1", product.getAttributes().get(1).getAttributeValue());
		Assert.assertEquals(productId, product.getAttributes().get(2).getKey().getProductId());
		Assert.assertEquals("name-" + productId + "-2", product.getAttributes().get(2).getKey().getAttributeName());
		Assert.assertEquals("value-" + productId + "-2", product.getAttributes().get(2).getAttributeValue());
	}
	
	private void updateProduct(Product product) {
		product.setProductName("xproduct-" + product.getProductId());
		product.setDescription("xproduct-desc-" + product.getProductId());
		product.setUpc(product.getProductId());
		product.setInventoryCount(200);
		product.setPrice(new BigDecimal("2.00"));
		product.setCurrency("USD");
		product.getAttributes().add(createProductAttribute(product.getProductId(), 2));
	}
	
	private Product createProduct(String productId) {
		Product product = new Product();
		product.setProductId(productId);
		product.setProductName("product-" + productId);
		product.setDescription("product-desc-" + productId);
		product.setUpc(productId);
		product.setInventoryCount(100);
		product.setPrice(new BigDecimal("1.00"));
		product.setCurrency("USD");
		product.setCategories(createCategoryList(productId));	
		product.setAttributes(createProductAttributeList(productId));
		return product;
	}
	
	private List<Category> createCategoryList(String productId) {
		Category category = new Category();
		category.setCategoryId(productId);
		category.setCategoryName("category-" + productId);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		return categoryList;
	}
	
	private List<ProductAttribute> createProductAttributeList(String productId) {
		List<ProductAttribute> attrList = new ArrayList<ProductAttribute>();
		attrList.add(createProductAttribute(productId, 0));
		attrList.add(createProductAttribute(productId, 1));
		return attrList;
	}
	
	private ProductAttribute createProductAttribute(String productId, int order) {
		ProductAttribute attr = new ProductAttribute();
		ProductAttributeKey key = new ProductAttributeKey();
		key.setProductId(productId);
		key.setAttributeName("name-" + productId + "-" + order);
		attr.setKey(key);
		attr.setAttributeValue("value-" + productId + "-" + order);
		attr.setOrder(order);
		return attr;
	}


}
