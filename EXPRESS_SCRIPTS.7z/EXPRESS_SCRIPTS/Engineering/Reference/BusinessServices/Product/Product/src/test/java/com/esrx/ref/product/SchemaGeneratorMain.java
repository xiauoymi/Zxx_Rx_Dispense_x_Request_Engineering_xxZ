package com.esrx.ref.product;


import javax.sql.DataSource;

import org.junit.Assert;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.express_scripts.inf.test.schema.generator.DatabaseDialect;
import com.express_scripts.inf.test.schema.generator.SchemaGenerator;
import com.express_scripts.inf.test.schema.generator.SchemaGeneratorRequest;

/**
 * Generates a xsd schema from the database configured from the datasource.
 * This program requires a full path to the directory where this project resides(e.g: C:\project\Customer)
 * @author p045685
 *
 */
public class SchemaGeneratorMain {
    private static final String XSD_DIR_LOCATION = "\\src\\test\\resources\\schemagen\\xsd";
    private static final String DATA_SOURCE_BEAN_NAME = "dataSource";
    private static final String SCHEMA_GENERATOR_BEAN_NAME = "schemaGenerator";

    public static void main(String[] args) throws Exception {
       // if ((args != null) && (args.length == 1)) {
            String xsdDirFullPath = "C:\\esi\\ws\\ReferenceAcrh\\product" + XSD_DIR_LOCATION;
            ApplicationContext context = getApplicationContext();
            Assert.assertTrue("XSD directory[" + xsdDirFullPath + "] doesn't exist", context.getResource("file:" + xsdDirFullPath).exists());

            DataSource dataSource = getDataSource(context);
            SchemaGeneratorRequest request = new SchemaGeneratorRequest(DatabaseDialect.ORACLE, dataSource, "REFSYS", xsdDirFullPath);
            getSchemaGenerator(context).generateSchema(request);
        /*} else {
            throw new IllegalArgumentException("Requires one argument specifying the full path to the xsd dir location");
        }*/
    }

    private static SchemaGenerator getSchemaGenerator(ApplicationContext context) {
        SchemaGenerator schemaGen = (SchemaGenerator) context.getBean(SCHEMA_GENERATOR_BEAN_NAME);
        Assert.assertNotNull(schemaGen);

        return schemaGen;
    }

    private static DataSource getDataSource(ApplicationContext context) {
        DataSource dataSource = (DataSource) context.getBean(DATA_SOURCE_BEAN_NAME);
        Assert.assertNotNull(dataSource);

        return dataSource;
    }

    private static ApplicationContext getApplicationContext() {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:/schemagen/SchemaGeneratorApplicationContext.xml");
        Assert.assertNotNull(context);

        return context;
    }
}