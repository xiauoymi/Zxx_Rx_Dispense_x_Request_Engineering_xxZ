package com.esrx.ref.product.bo;

import java.io.Serializable;

public class GetProductRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3266431111151729243L;
	private String productId;
	private Long timeout;

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}

	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}

}
