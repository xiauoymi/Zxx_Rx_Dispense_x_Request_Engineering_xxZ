package com.esrx.ref.product.bo.impl;

public class Constants {

	public static final String MIME_TYPE_UNSUPPORTED = "Mime type unsupported";
	public static final String TIMED_OUT = "Timed out";
	public static final String NO_INPUT = "No input provided.";
	public static final String YES = "Y";
	public static final String XML = "XML";
	public static final String TEST = "TEST";

}
