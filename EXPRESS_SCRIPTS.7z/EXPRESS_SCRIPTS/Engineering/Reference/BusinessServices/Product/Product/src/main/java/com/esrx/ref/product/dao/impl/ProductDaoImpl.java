package com.esrx.ref.product.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.esrx.ref.product.dao.ProductDao;
import com.esrx.ref.product.domain.Product;
import com.esrx.ref.product.domain.ProductAttribute;
import com.esrx.ref.product.domain.ProductResponse;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.SortOption;

public class ProductDaoImpl extends GenericDaoHibernate<Product> implements ProductDao{
	
	public ProductDaoImpl(SessionFactory sf) {
		super(Product.class, sf);
	}

	public void flushSession() {
		getSession(false).flush();
	}

	@Override
	public ProductResponse findProduct(boolean matchCase, String categoryId, String upc, 
			Boolean inStock, String query, List<ProductAttribute> attributes,
			int offset, int count, List<SortOption> sortOptions, long timeout) throws InvalidRequest {

		ProductResponse response = new ProductResponse();
		
		// Do the total count
		Criteria projCriteria = createBaseCriteria(matchCase, categoryId, upc, inStock, query, attributes);
		projCriteria.setProjection(Projections.rowCount());
		Long totalCount = (Long) projCriteria.list().get(0);
		
		if (totalCount.longValue() == 0) {
			response.setProductList(new ArrayList<Product>());
			return response;
		}
		response.setTotalCount(totalCount.intValue());
		
		// Do the main query
		Criteria criteria = createBaseCriteria(matchCase, categoryId, upc, inStock, query, attributes);
		criteria = sortAndCount(offset, count, sortOptions, criteria, timeout);
		List<Product> products = criteria.list();
		response.setProductList(products);
		
		return response;
	}
	
	private Criteria createBaseCriteria(boolean matchCase, String categoryId, String upc, 
			Boolean inStock, String query, List<ProductAttribute> attributes) {
		Criteria criteria = getSession().createCriteria(Product.class);
		
		if(StringUtils.isNotBlank(upc)) {
			criteria.add(Restrictions.eq("upc", upc));
		}
		
		if (StringUtils.isNotBlank(categoryId)) {
			criteria.createCriteria("categories").add(Restrictions.eq("categoryId", categoryId));
		}
		
		if (inStock != null) {
			if (inStock) {
				criteria.add(Restrictions.gt("inventoryCount", 0));
			} else {
				criteria.add(Restrictions.le("inventoryCount", 0));
			}
		}
		
		// TODO: Add support for attributes
		
		if (StringUtils.isNotBlank(query)) {
			if (matchCase) {
				Disjunction d = Restrictions.disjunction();
				d.add(Restrictions.like("productName", query));
				d.add(Restrictions.like("description", query));
				criteria.add(d);
			} else {
				Disjunction d = Restrictions.disjunction();
				d.add(Restrictions.ilike("productName", query));
				d.add(Restrictions.ilike("description", query));
				criteria.add(d);
			}
		}
		
		return criteria;
	}
	
	private Criteria sortAndCount(int start, int count,
			List<SortOption> sortOptions, Criteria criteria, Long timeout) {
		
		if(start>0){
			criteria.setFirstResult(start);
		}
		
		if(count>0){
			criteria.setMaxResults(count);
		}
		criteria.setTimeout(timeout.intValue());
		if(!CollectionUtils.isEmpty(sortOptions)){
			for(SortOption sortOption : sortOptions){
				String sortBy = sortOption.getFieldName();
				String order = sortOption.getSortOrder().value();
				if(StringUtils.equalsIgnoreCase(order, "asc")){
					criteria.addOrder(Order.asc(sortBy));
					}else{
						criteria.addOrder(Order.desc(sortBy));
					}
			}
		}else{
			criteria.addOrder(Order.asc("productId"));
		}
		return criteria;
	}
	
}
