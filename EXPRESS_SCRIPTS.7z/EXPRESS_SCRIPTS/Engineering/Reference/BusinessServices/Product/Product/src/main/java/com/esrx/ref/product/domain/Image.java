package com.esrx.ref.product.domain;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="IMAGE")
public class Image implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4978588197929391568L;
	
	private Integer productId;
	
	private String mimeType;
	
	private byte[] data;

	/**
	 * @return the productId
	 */
	@Id
	@Column(name="PRODUCT_ID")
	public Integer getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return the mimeType
	 */
	@Column(name="MIME_TYPE")
	public String getMimeType() {
		return mimeType;
	}

	/**
	 * @param mimeType the mimeType to set
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	/**
	 * @return the data
	 */
	@Column(name="DATA")
	@Lob	
	public byte[] getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(data);
		result = prime * result
				+ ((mimeType == null) ? 0 : mimeType.hashCode());
		result = prime * result
				+ ((productId == null) ? 0 : productId.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Image other = (Image) obj;
		if (!Arrays.equals(data, other.data))
			return false;
		if (mimeType == null || other.mimeType != null){
				return false;
		} else if (!mimeType.equals(other.mimeType))
			return false;
		if (productId == null || other.productId != null){
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		return true;
	}



}
