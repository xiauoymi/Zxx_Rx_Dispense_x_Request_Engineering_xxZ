package com.esrx.ref.product.bo;

import java.io.Serializable;

public class ProductAttribute implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5632359855913707412L;
	private String attributeName;
	private String attributeValue;

	/**
	 * @return the attributeName
	 */
	public String getAttributeName() {
		return attributeName;
	}

	/**
	 * @param attributeName
	 *            the attributeName to set
	 */
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	/**
	 * @return the attributeValue
	 */
	public String getAttributeValue() {
		return attributeValue;
	}

	/**
	 * @param attributeValue
	 *            the attributeValue to set
	 */
	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

}
