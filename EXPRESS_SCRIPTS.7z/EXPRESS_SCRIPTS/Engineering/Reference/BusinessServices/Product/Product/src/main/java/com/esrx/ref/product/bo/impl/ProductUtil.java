package com.esrx.ref.product.bo.impl;

import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.ProcessFailed;


/**
 * @author p043459
 *
 */
public class ProductUtil {
	
	private static Set<String> supportedMimeTypes ;
	
	
	public static InvalidRequest buildInvalidRequest(String code, String message, String id, String data){
		InvalidRequest invalidRequest = new InvalidRequest(code, message, id, data);
		return invalidRequest;
	}

	public static ProcessFailed buildProcessFailed(String code, String message,
			String id, String data, Exception exception) {
		ProcessFailed processFailed = new ProcessFailed(code, message, id, data, exception);
		return processFailed;
	}

	public static NotFound buildNotFound(String message,
			String id, String data) {
		NotFound notFound = new NotFound(message, id, data);
		return notFound;
	}
	
	public static String getMimeOrFileType(String fileType) {
		if(supportedMimeTypes.contains(fileType.toLowerCase())){
			return fileType.toLowerCase();
		}
		return StringUtils.EMPTY;
	}

	/**
	 * @param supportedMimeTypes the supportedMimeTypes to set
	 */
	public static void setSupportedMimeTypes(Set<String> supportedMimeTypes) {
		ProductUtil.supportedMimeTypes = supportedMimeTypes;
	}

}
