package com.esrx.ref.product.bo.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.carbonfive.testutils.spring.dbunit.DataSet;
import com.esrx.ref.product.BaseTest;
import com.esrx.ref.product.bo.Category;
import com.esrx.ref.product.bo.CreateProductRequest;
import com.esrx.ref.product.bo.CreateProductResponse;
import com.esrx.ref.product.bo.FindProductRequest;
import com.esrx.ref.product.bo.FindProductResponse;
import com.esrx.ref.product.bo.GetImageRequest;
import com.esrx.ref.product.bo.GetImageResponse;
import com.esrx.ref.product.bo.GetProductRequest;
import com.esrx.ref.product.bo.GetProductResponse;
import com.esrx.ref.product.bo.Price;
import com.esrx.ref.product.bo.Product;
import com.esrx.ref.product.bo.ProductAttribute;
import com.esrx.ref.product.bo.ProductBo;
import com.esrx.ref.product.bo.ProductSummary;
import com.esrx.ref.product.bo.SaveImageRequest;
import com.esrx.ref.product.bo.SaveImageResponse;
import com.esrx.ref.product.bo.UpdateProductRequest;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;
import com.express_scripts.inf.types.SortOption;
import com.express_scripts.inf.types.SortOrder;

public class ProductBoImplIntTest extends BaseTest{
	@Autowired
	private ProductBo productBo;
	
	@Before
	public void setUp() throws Exception {
		ProcessTimer.startTimer();
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testGet() throws Exception {
		GetProductRequest request = new GetProductRequest();
		request.setProductId("1");
		GetProductResponse response = productBo.getProduct(request);
		validateProduct(response.getProduct(), "1");
	}
	
	
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByQuery() throws Exception {
		FindProductRequest request = new FindProductRequest();
		request.setQuery("*DeSc*");
		FindProductResponse response = productBo.findProduct(request);
		Assert.assertEquals(2, response.getTotalCount());
		Assert.assertEquals(2, response.getProductSummaryList().size());
		validateProductSummary(response.getProductSummaryList().get(0), "1");
		validateProductSummary(response.getProductSummaryList().get(1), "2");
	}
	
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByQueryMatchCase() throws Exception {
		FindProductRequest request = new FindProductRequest();
		request.setMatchCase(true);
		request.setQuery("*desc*");
		FindProductResponse response = productBo.findProduct(request);
		Assert.assertEquals(2, response.getTotalCount());
		Assert.assertEquals(2, response.getProductSummaryList().size());
		validateProductSummary(response.getProductSummaryList().get(0), "1");
		validateProductSummary(response.getProductSummaryList().get(1), "2");
	}
	
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByQueryMatchCaseNotFound() throws Exception {
		FindProductRequest request = new FindProductRequest();
		request.setMatchCase(true);
		request.setQuery("*DeSc*");
		FindProductResponse response = productBo.findProduct(request);
		Assert.assertEquals(0, response.getTotalCount());
		Assert.assertEquals(0, response.getProductSummaryList().size());
	}
	
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByInStock() throws Exception {
		FindProductRequest request = new FindProductRequest();
		request.setQuery("*desc*");
		request.setInStock(false);
		FindProductResponse response = productBo.findProduct(request);
		Assert.assertEquals(0, response.getTotalCount());
		Assert.assertEquals(0, response.getProductSummaryList().size());
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByCategory() throws Exception {
		FindProductRequest request = new FindProductRequest();
		request.setQuery("*desc*");
		request.setCategoryId("1");
		FindProductResponse response = productBo.findProduct(request);
		Assert.assertEquals(1, response.getTotalCount());
		Assert.assertEquals(1, response.getProductSummaryList().size());
		validateProductSummary(response.getProductSummaryList().get(0), "1");
	}
	
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindByUpc() throws Exception {
		FindProductRequest request = new FindProductRequest();
		request.setUpc("2");
		FindProductResponse response = productBo.findProduct(request);
		Assert.assertEquals(1, response.getTotalCount());
		Assert.assertEquals(1, response.getProductSummaryList().size());
		validateProductSummary(response.getProductSummaryList().get(0), "2");
	}

	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindSort() throws Exception {
		List<SortOption> sortOptions = new ArrayList<SortOption>();
		SortOption so1 = new SortOption();
		so1.setFieldName("upc");
		so1.setSortOrder(SortOrder.DESC);
		sortOptions.add(so1);
		
		FindProductRequest request = new FindProductRequest();
		request.setQuery("*desc*");
		request.setSortOptions(sortOptions);
		FindProductResponse response = productBo.findProduct(request);
		Assert.assertEquals(2, response.getTotalCount());
		Assert.assertEquals(2, response.getProductSummaryList().size());
		validateProductSummary(response.getProductSummaryList().get(0), "2");
		validateProductSummary(response.getProductSummaryList().get(1), "1");
	}

	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindPage1() throws Exception {
		FindProductRequest request = new FindProductRequest();
		request.setQuery("*DeSc*");
		request.setCount(1);
		FindProductResponse response = productBo.findProduct(request);
		Assert.assertEquals(2, response.getTotalCount());
		Assert.assertEquals(1, response.getProductSummaryList().size());
		validateProductSummary(response.getProductSummaryList().get(0), "1");
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testFindPage2() throws Exception {
		FindProductRequest request = new FindProductRequest();
		request.setQuery("*DeSc*");
		request.setCount(1);
		request.setOffset(1);
		FindProductResponse response = productBo.findProduct(request);
		Assert.assertEquals(2, response.getTotalCount());
		Assert.assertEquals(1, response.getProductSummaryList().size());
		validateProductSummary(response.getProductSummaryList().get(0), "2");
	}
	

	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testCreate() throws Exception {		
		CreateProductRequest createRequest = new CreateProductRequest();
		createRequest.setProduct(createProduct("3"));
		CreateProductResponse createResponse = productBo.createProduct(createRequest);
		
		GetProductRequest request = new GetProductRequest();
		request.setProductId(createResponse.getProductId());
		GetProductResponse response = productBo.getProduct(request);
		validateProduct(response.getProduct(), createResponse.getProductId());
	}
	
	@Test
	@DataSet("classpath:/testdata/Product.xml")
	public void testUpdate() throws Exception {		
		CreateProductRequest createRequest = new CreateProductRequest();
		createRequest.setProduct(createProduct("3"));
		CreateProductResponse createResponse = productBo.createProduct(createRequest);
		
		GetProductRequest request = new GetProductRequest();
		request.setProductId(createResponse.getProductId());
		GetProductResponse response = productBo.getProduct(request);
		validateProduct(response.getProduct(), createResponse.getProductId());
		
		updateProduct(response.getProduct());
		UpdateProductRequest updateRequest = new UpdateProductRequest();
		updateRequest.setProduct(response.getProduct());
		productBo.updateProduct(updateRequest);
		
		GetProductRequest request2 = new GetProductRequest();
		request.setProductId(createResponse.getProductId());
		GetProductResponse response2 = productBo.getProduct(request);
		validateUpdatedProduct(response2.getProduct(), response2.getProduct().getProductId());
	}

	
	@Test(expected=InvalidRequest.class)
	public void testFindProductNullRequest() throws Exception {
		productBo.findProduct(null);
	}
	
	@Test
	public void testFindProductNoRequest() {
		try {
			productBo.findProduct(new FindProductRequest());
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
			InvalidRequest invalidRequest = (InvalidRequest)e;
			assertEquals(Constants.NO_INPUT, invalidRequest.getMessage());
			assertEquals(ErrorCodes.NO_INPUT, invalidRequest.getCode());
		}
	}
	
	@Test
	@DataSet("classpath:/testdata/GetImage.xml")
	public void testGetImage() throws NotFound, InvalidRequest {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("1");
		request.setTimeout(30000L);
		GetImageResponse response = productBo.getImage(request);
		assertNotNull(response);
		assertNotNull(response.getImage());
		assertNotNull(response.getImage().getData());
		assertEquals("image/jpeg", response.getImage().getMimeType());
	}
	@Test
	public void testGetImageNotFound() {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("2");
		request.setTimeout(30000L);
		try {
			productBo.getImage(request);
		} catch (Exception e) {
			assertTrue(e instanceof NotFound);
		}
		
	}
	@Test
	public void testGetImageNullRequest() {
	
		try {
			productBo.getImage(null);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	@Test
	public void testGetImageInvalidId() {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("A");
		request.setTimeout(3000L);
		try {
			productBo.getImage(request);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testGetImageTimedOut() {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("1");
		request.setTimeout(1L);
		try {
			productBo.getImage(request);
		} catch (Exception e) {
			assertTrue(e instanceof ProcessTimeoutException);
		}
	}

	
	@Test
	@DataSet("classpath:/testdata/GetImage.xml")
	public void testCreateImage() throws InvalidRequest, NotFound {
		SaveImageRequest imageRequest = new SaveImageRequest();
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType("IMAGE/PNG");
		imageRequest.setImage(image);
		imageRequest.setProductId("2");
		imageRequest.setTimeout(30000L);
		
		SaveImageResponse imageResponse = productBo.saveImage(imageRequest);
		assertNotNull(imageResponse);
		
		GetImageRequest getImageRequest = new GetImageRequest();
		getImageRequest.setProductId("2");
		getImageRequest.setTimeout(30000L);
		
		GetImageResponse response = productBo.getImage(getImageRequest);
		assertNotNull(response);
		assertNotNull(response.getImage());
		assertEquals(image.getMimeType().toLowerCase(), response.getImage().getMimeType());
	}
	
	@Test
	@DataSet("classpath:/testdata/GetImage.xml")
	public void testUpdateImage() throws InvalidRequest {
		SaveImageRequest imageRequest = new SaveImageRequest();
		Set<String> mimeTypes = new HashSet<String>();
		mimeTypes.add("image/png");
		ProductUtil.setSupportedMimeTypes(mimeTypes);
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType("IMAGE/PNG");
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);
		
		SaveImageResponse imageResponse = productBo.saveImage(imageRequest);
		assertNotNull(imageResponse);
		assertEquals(imageRequest.getProductId(), imageResponse.getId());
	}
	
	@Test
	public void testSaveImageInvalidRequestNullRequest() {
				
		try {
			productBo.saveImage(null);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	@Test
	public void testSaveImageInvalidRequestNullImage() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(null);
		image.setMimeType("IMAGE/PNG");
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	@Test
	public void testSaveImageInvalidRequestNoMimeType() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType(null);
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testSaveImageInvalidRequestIncorrectMimeType() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType("application/pdf");
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
			InvalidRequest invalidRequest = (InvalidRequest)e;
			assertEquals(Constants.MIME_TYPE_UNSUPPORTED, invalidRequest.getMessage());
			assertEquals(ErrorCodes.MIME_TYPE_UNSUPPORTED, invalidRequest.getCode());
		}
	}
	
	@Test
	public void testSaveImageInvalidRequestNullData() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		
		imageRequest.setImage(null);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testSaveImageInvalidRequestNoProductId() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		
		imageRequest.setImage(null);
		imageRequest.setProductId("");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testSaveImageInvalidRequestInvalidProductId() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		
		imageRequest.setImage(null);
		imageRequest.setProductId("A");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testSaveImageTimedOut() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType("IMAGE/PNG");
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(1L);
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof ProcessTimeoutException);
		}
	}
	
	
	private void validateProductSummary(ProductSummary product, String productId) {
		Assert.assertEquals(productId, product.getProductId());
		Assert.assertEquals("product-" + productId, product.getProductName());
		Assert.assertEquals(new BigDecimal("1.00"), product.getPrice().getAmount());
		Assert.assertEquals("USD", product.getPrice().getCurrency());
		Assert.assertEquals("$1.00", product.getPrice().getFormattedAmount());
	}
	
	private void validateProduct(Product product, String productId) {
		Assert.assertEquals(productId, product.getProductId());
		Assert.assertEquals("product-" + productId, product.getProductName());
		Assert.assertEquals("product-desc-" + productId, product.getDescription());
		Assert.assertEquals(productId, product.getUpc());
		Assert.assertEquals(100, product.getInventoryCount());
		Assert.assertEquals(new BigDecimal("1.00"), product.getPrice().getAmount());
		Assert.assertEquals("USD", product.getPrice().getCurrency());
		Assert.assertEquals("$1.00", product.getPrice().getFormattedAmount());
		Assert.assertEquals(1, product.getCategories().size());
		Assert.assertEquals(productId, product.getCategories().get(0).getCategoryId());
		Assert.assertEquals("category-" + productId, product.getCategories().get(0).getCategoryName());
		Assert.assertEquals(2, product.getAttributes().size());
		Assert.assertEquals("name-" + productId + "-0", product.getAttributes().get(0).getAttributeName());
		Assert.assertEquals("value-" + productId + "-0", product.getAttributes().get(0).getAttributeValue());
		Assert.assertEquals("name-" + productId + "-1", product.getAttributes().get(1).getAttributeName());
		Assert.assertEquals("value-" + productId + "-1", product.getAttributes().get(1).getAttributeValue());
	}
	
	private void validateUpdatedProduct(Product product, String productId) {
		Assert.assertEquals(productId, product.getProductId());
		Assert.assertEquals("xproduct-" + productId, product.getProductName());
		Assert.assertEquals("xproduct-desc-" + productId, product.getDescription());
		Assert.assertEquals(productId, product.getUpc());
		Assert.assertEquals(200, product.getInventoryCount());
		Assert.assertEquals(new BigDecimal("2.00"), product.getPrice().getAmount());
		Assert.assertEquals("USD", product.getPrice().getCurrency());
		Assert.assertEquals("$2.00", product.getPrice().getFormattedAmount());
		Assert.assertEquals(1, product.getCategories().size());
		Assert.assertEquals(productId, product.getCategories().get(0).getCategoryId());
		Assert.assertEquals("category-" + productId, product.getCategories().get(0).getCategoryName());
		Assert.assertEquals(3, product.getAttributes().size());
		Assert.assertEquals("name-" + productId + "-0", product.getAttributes().get(0).getAttributeName());
		Assert.assertEquals("value-" + productId + "-0", product.getAttributes().get(0).getAttributeValue());
		Assert.assertEquals("name-" + productId + "-1", product.getAttributes().get(1).getAttributeName());
		Assert.assertEquals("value-" + productId + "-1", product.getAttributes().get(1).getAttributeValue());
		Assert.assertEquals("name-" + productId + "-2", product.getAttributes().get(2).getAttributeName());
		Assert.assertEquals("value-" + productId + "-2", product.getAttributes().get(2).getAttributeValue());
	}
	
	private void updateProduct(Product product) {
		product.setProductName("xproduct-" + product.getProductId());
		product.setDescription("xproduct-desc-" + product.getProductId());
		product.setUpc(product.getProductId());
		product.setInventoryCount(200);
		Price p = new Price();
		p.setAmount(new BigDecimal("2.00"));
		p.setCurrency("USD");
		product.setPrice(p);
		product.getAttributes().add(createProductAttribute(product.getProductId(), 2));
	}
	
	private Product createProduct(String productId) {
		Product product = new Product();
		product.setProductName("product-" + productId);
		product.setDescription("product-desc-" + productId);
		product.setUpc(productId);
		product.setInventoryCount(100);
		Price p = new Price();
		p.setAmount(new BigDecimal("1.00"));
		p.setCurrency("USD");
		product.setPrice(p);
		product.setCategories(createCategoryList(productId));	
		product.setAttributes(createProductAttributeList(productId));
		return product;
	}
	
	private List<Category> createCategoryList(String productId) {
		Category category = new Category();
		category.setCategoryId(productId);
		category.setCategoryName("category-" + productId);
		List<Category> categoryList = new ArrayList<Category>();
		categoryList.add(category);
		return categoryList;
	}
	
	private List<ProductAttribute> createProductAttributeList(String productId) {
		List<ProductAttribute> attrList = new ArrayList<ProductAttribute>();
		attrList.add(createProductAttribute(productId, 0));
		attrList.add(createProductAttribute(productId, 1));
		return attrList;
	}
	
	private ProductAttribute createProductAttribute(String productId, int order) {
		ProductAttribute attr = new ProductAttribute();
		attr.setAttributeName("name-" + productId + "-" + order);
		attr.setAttributeValue("value-" + productId + "-" + order);
		return attr;
	}
}
