package com.esrx.ref.product.bo.impl;

public class ErrorCodes {

//	public static final String REQUEST_REQUIRED = "REQUEST_REQUIRED";
//	public static final String UNEXPECTED_ERROR = "UNEXPECTED_ERROR";
//	public static final String PRODUCT_ID_REQUIRED = "PRODUCT_ID_REQUIRED";
//	public static final String NOT_FOUND = "NOT_FOUND";
//	public static final String PRODUCT_REQUIRED = "PRODUCT_REQUIRED";
//	public static final String MIME_TYPE_REQUIRED = "MIME_TYPE_REQUIRED";
//	public static final String IMAGE_REQUIRED = "IMAGE_REQUIRED";
	public static final String MIME_TYPE_UNSUPPORTED = "MIME_TYPE_UNSUPPORTED";
//	public static final String PRODUCT_ID_INVALID = "PRODUCT_ID_INVALID";
//	public static final String RESOURCE_UNAVAILABLE = "RESOURCE_UNAVAILABLE";
	public static final String NO_INPUT = "NO_INPUT";

}
