package com.esrx.ref.product.management;

public interface SleepTimeMBean {
	long getSleepTimeMS();
	void setSleepTimeMS(long sleepTimeMS);
}
