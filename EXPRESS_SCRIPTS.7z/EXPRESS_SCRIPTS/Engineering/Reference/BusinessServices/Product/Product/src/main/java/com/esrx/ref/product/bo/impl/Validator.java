package com.esrx.ref.product.bo.impl;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.esrx.ref.product.bo.CreateProductRequest;
import com.esrx.ref.product.bo.FindProductRequest;
import com.esrx.ref.product.bo.GetImageRequest;
import com.esrx.ref.product.bo.GetProductRequest;
import com.esrx.ref.product.bo.SaveImageRequest;
import com.esrx.ref.product.bo.UpdateProductRequest;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.SortOption;
import com.express_scripts.inf.types.support.SortOptionListValidator;
import com.express_scripts.inf.validator.NullValidator;
import com.express_scripts.inf.validator.NumberValidator;

public class Validator {
	private static String[] VALID_PRODUCT_SORT_FIELDS = new String[] {"productId","productName","description","price","upc","inventoryCount"};

	public static void validateGetImageRequest(GetImageRequest imageRequest) throws InvalidRequest {
		NullValidator.assertNotNull("REQUEST", imageRequest);
		NullValidator.assertNotNull("PRODUCT_ID", imageRequest.getProductId());
		NumberValidator.assertNumber("PRODUCT_ID", imageRequest.getProductId());
	}
	
	public static void validateCreateProductRequest(
			CreateProductRequest createProductRequest) throws InvalidRequest {
		
		NullValidator.assertNotNull("REQUEST", createProductRequest);
		NullValidator.assertNotNull("PRODUCT", createProductRequest.getProduct());
		NullValidator.assertNull("PRODUCT_ID", createProductRequest.getProduct().getProductId());
		NullValidator.assertNotNull("PRODUCT_NAME", createProductRequest.getProduct().getProductName());
		NullValidator.assertNotNull("DESCRIPTION", createProductRequest.getProduct().getDescription());
		NullValidator.assertNotNull("UPC", createProductRequest.getProduct().getUpc());
		NumberValidator.assertGreaterThanOrEqualTo("INVENTORY_COUNT", 
				new BigDecimal(createProductRequest.getProduct().getInventoryCount()), new BigDecimal(0));
		NullValidator.assertNotNull("PRICE", createProductRequest.getProduct().getPrice());
		NumberValidator.assertGreaterThanOrEqualTo("PRICE_AMOUNT", 
				createProductRequest.getProduct().getPrice().getAmount(), new BigDecimal(0));
		NullValidator.assertNotNull("CURRENCY", createProductRequest.getProduct().getPrice().getCurrency());
		if (!createProductRequest.getProduct().getPrice().getCurrency().equals("USD")) {
			throw new InvalidRequest("INVLAID_CURRENCY", "Invalid currency.  Must be USD.", null, createProductRequest.getProduct().getUpc());
		}
	}

	public static void validateUpdateProductRequest(
			UpdateProductRequest updateProductRequest) throws InvalidRequest {
		
		NullValidator.assertNotNull("REQUEST", updateProductRequest);
		NullValidator.assertNotNull("PRODUCT", updateProductRequest.getProduct());
		NullValidator.assertNotNull("PRODUCT_ID", updateProductRequest.getProduct().getProductId());
		NumberValidator.assertNumber("PRODUCT_ID", updateProductRequest.getProduct().getProductId());
		NullValidator.assertNotNull("PRODUCT_NAME", updateProductRequest.getProduct().getProductName());
		NullValidator.assertNotNull("DESCRIPTION", updateProductRequest.getProduct().getDescription());
		NullValidator.assertNotNull("UPC", updateProductRequest.getProduct().getUpc());
		if (!updateProductRequest.getProduct().getUpc().equals(updateProductRequest.getProduct().getProductId())) {
			throw new InvalidRequest("INVLAID_UPC", "Invalid UPC.  Must match product ID.", null, updateProductRequest.getProduct().getUpc());
		}
		NumberValidator.assertGreaterThanOrEqualTo("INVENTORY_COUNT", 
				new BigDecimal(updateProductRequest.getProduct().getInventoryCount()), new BigDecimal(0));
		NullValidator.assertNotNull("PRICE", updateProductRequest.getProduct().getPrice());
		NumberValidator.assertGreaterThanOrEqualTo("PRICE_AMOUNT", 
				updateProductRequest.getProduct().getPrice().getAmount(), new BigDecimal(0));
		NullValidator.assertNotNull("CURRENCY", updateProductRequest.getProduct().getPrice().getCurrency());
		if (!updateProductRequest.getProduct().getPrice().getCurrency().equals("USD")) {
			throw new InvalidRequest("INVLAID_CURRENCY", "Invalid currency.  Must be USD.", null, updateProductRequest.getProduct().getUpc());
		}
	}

	public static void validateSaveImageRequest(
			SaveImageRequest imageRequest) throws InvalidRequest {
		NullValidator.assertNotNull("REQUEST", imageRequest);
		NullValidator.assertNotNull("PRODUCT_ID", imageRequest.getProductId());
		NumberValidator.assertNumber("PRODUCT_ID", imageRequest.getProductId());
		NullValidator.assertNotNull("IMAGE", imageRequest.getImage());
		NullValidator.assertNotNull("MIME_TYPE", imageRequest.getImage().getMimeType());
		if(StringUtils.isNotBlank(imageRequest.getImage().getMimeType())){
			String mimeType = ProductUtil.getMimeOrFileType(imageRequest.getImage().getMimeType());
			if(StringUtils.isBlank(mimeType)){
				throw ProductUtil.buildInvalidRequest(ErrorCodes.MIME_TYPE_UNSUPPORTED, Constants.MIME_TYPE_UNSUPPORTED, null, null);
			}
		}
		
	}

	public static void validateGetProductRequest(
			GetProductRequest getProductRequest) throws InvalidRequest {
		NullValidator.assertNotNull("REQUEST", getProductRequest);
		NullValidator.assertNotNull("PRODUCT_ID", getProductRequest.getProductId());
		NumberValidator.assertNumber("PRODUCT_ID", getProductRequest.getProductId());
	}

	public static void validateFindProductRequest(
			FindProductRequest findProductRequest) throws InvalidRequest {
		NullValidator.assertNotNull("REQUEST", findProductRequest);
		if(StringUtils.isBlank(findProductRequest.getQuery()) && StringUtils.isBlank(findProductRequest.getUpc()) && CollectionUtils.isEmpty(findProductRequest.getAttributes())) {
			throw ProductUtil.buildInvalidRequest(ErrorCodes.NO_INPUT, Constants.NO_INPUT, null, null);
		}
		
		List<SortOption> sortOptions = findProductRequest.getSortOptions();
		if (CollectionUtils.isNotEmpty(sortOptions)) {
			SortOptionListValidator.assertValidSortOptionList(sortOptions, Arrays.asList(VALID_PRODUCT_SORT_FIELDS));
		}
	}

}
