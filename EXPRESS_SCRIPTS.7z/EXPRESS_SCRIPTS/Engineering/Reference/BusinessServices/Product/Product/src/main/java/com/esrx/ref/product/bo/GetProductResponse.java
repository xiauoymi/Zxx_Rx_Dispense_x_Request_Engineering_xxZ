package com.esrx.ref.product.bo;

import java.io.Serializable;

public class GetProductResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2768924719084351246L;
	private Product product;

	/**
	 * @return the product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * @param product
	 *            the product to set
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

}
