package com.esrx.ref.product.bo.impl;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.esrx.ref.product.bo.Category;
import com.esrx.ref.product.bo.Price;
import com.esrx.ref.product.bo.Product;
import com.esrx.ref.product.bo.ProductAttribute;
import com.esrx.ref.product.bo.ProductSummary;

public class ResponseTransformer {
	
	public static List<ProductSummary> transformProductList(List<com.esrx.ref.product.domain.Product> in) {
		List<ProductSummary> out = new ArrayList<ProductSummary>();
		for (com.esrx.ref.product.domain.Product p: in) {
			out.add(transformProductSummary(p));
		}
		return out;
	}
	
	public static ProductSummary transformProductSummary(com.esrx.ref.product.domain.Product in) {
		ProductSummary out = new ProductSummary();
		out.setProductId(in.getProductId());
		out.setProductName(in.getProductName());
		Price price = new Price();
		price.setAmount(in.getPrice());
		price.setCurrency(in.getCurrency());
		price.setFormattedAmount(NumberFormat.getCurrencyInstance(Locale.US).format(in.getPrice()));
		out.setPrice(price);
		return out;
	}
	
	public static Product transformProduct(com.esrx.ref.product.domain.Product in) {
		Product out = new Product();
		out.setProductId(in.getProductId());
		out.setProductName(in.getProductName());
		out.setDescription(in.getDescription());
		Price price = new Price();
		price.setAmount(in.getPrice());
		price.setCurrency(in.getCurrency());
		price.setFormattedAmount(NumberFormat.getCurrencyInstance(Locale.US).format(in.getPrice()));
		out.setPrice(price);
		out.setInventoryCount(in.getInventoryCount());
		out.setUpc(in.getUpc());
		out.setCategories(transformCategoryList(in.getCategories()));
		out.setAttributes(transformProductAttributeList(in.getAttributes()));
		return out;
	}

	private static List<ProductAttribute> transformProductAttributeList(List<com.esrx.ref.product.domain.ProductAttribute> in) {
		List<ProductAttribute> out = new ArrayList<ProductAttribute>();
		for (com.esrx.ref.product.domain.ProductAttribute p: in) {
			out.add(transformProductAttribute(p));
		}
		return out;
	}

	private static ProductAttribute transformProductAttribute(com.esrx.ref.product.domain.ProductAttribute in) {
		ProductAttribute out = new ProductAttribute();
		out.setAttributeName(in.getKey().getAttributeName());
		out.setAttributeValue(in.getAttributeValue());
		return out;
	}

	private static List<Category> transformCategoryList(List<com.esrx.ref.product.domain.Category> in) {
		List<Category> out = new ArrayList<Category>();
		for (com.esrx.ref.product.domain.Category c: in) {
			out.add(transformCategory(c));
		}
		return out;
	}

	private static Category transformCategory(com.esrx.ref.product.domain.Category in) {
		Category out = new Category();
		out.setCategoryId(in.getCategoryId());
		out.setCategoryName(in.getCategoryName());
		return out;
	}

}
