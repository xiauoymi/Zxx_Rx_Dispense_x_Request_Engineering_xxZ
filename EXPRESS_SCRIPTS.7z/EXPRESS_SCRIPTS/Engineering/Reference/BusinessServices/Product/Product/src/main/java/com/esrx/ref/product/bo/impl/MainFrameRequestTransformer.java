package com.esrx.ref.product.bo.impl;

import org.apache.commons.lang.StringUtils;

import com.esrx.ref.mainframe.request.createProduct.Request;
import com.esrx.ref.mainframe.request.createProduct.Request.ControlArea;
import com.esrx.ref.mainframe.request.createProduct.Request.CreateProduct;
import com.esrx.ref.product.bo.CreateProductRequest;

public class MainFrameRequestTransformer {

	public static Request buildCreateProductRequest(
			CreateProductRequest createProductRequest) {
		Request request = new Request();
		request.setControlArea(buildControlArea());
		CreateProduct createProduct = new CreateProduct();
		createProduct.setCurrencyType(createProductRequest.getProduct().getPrice().getCurrency());
		createProduct.setDescription(createProductRequest.getProduct().getDescription());
		createProduct.setInventory(String.valueOf(createProductRequest.getProduct().getInventoryCount()));
		createProduct.setPrice(String.valueOf(createProductRequest.getProduct().getPrice().getAmount()));
		createProduct.setProductName(createProductRequest.getProduct().getProductName());
		//createProduct.setSku(arg0)
		if(createProductRequest.getProduct().getUpc().length() >= 8){
			createProduct.setUpc(StringUtils.substring(createProductRequest.getProduct().getUpc(), 0, 7));
			createProduct.setUpc(StringUtils.substring(createProductRequest.getProduct().getUpc(), 8, createProductRequest.getProduct().getUpc().length()-1));
		}else{
			createProduct.setUpc(createProductRequest.getProduct().getUpc());
		}
		
		return request;
	}

	private static ControlArea buildControlArea() {
		ControlArea controlArea = new ControlArea();
		controlArea.setTestMode(Constants.YES);
		controlArea.setFormat(Constants.XML);
		controlArea.setChannel(Constants.TEST);
		controlArea.setOrgId(Constants.TEST);
		controlArea.setUserId(Constants.TEST);
		controlArea.setRole(Constants.TEST);
		return controlArea;
	}

}
