package com.esrx.ref.product.bo.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.esrx.ref.product.bo.CreateProductRequest;
import com.esrx.ref.product.bo.FindProductRequest;
import com.esrx.ref.product.bo.FindProductResponse;
import com.esrx.ref.product.bo.GetImageRequest;
import com.esrx.ref.product.bo.GetImageResponse;
import com.esrx.ref.product.bo.Product;
import com.esrx.ref.product.bo.SaveImageRequest;
import com.esrx.ref.product.bo.SaveImageResponse;
import com.esrx.ref.product.bo.UpdateProductRequest;
import com.esrx.ref.product.dao.ImageDao;
import com.esrx.ref.product.domain.Image;
import com.esrx.ref.product.management.SleepTimeMBeanImpl;
import com.express_scripts.inf.concurrent.ProcessTimeoutException;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;

public class ProductBoImplTest {
	
	private ProductBoImpl productBo;
	
	private ImageDao daoMock = EasyMock.createMock(ImageDao.class);
	
	@Before
	public void setUp() throws Exception {
		productBo = new ProductBoImpl();
		productBo.setImageDao(daoMock);
		productBo.setBufferTime(1000L);
		productBo.setDefaultTimeout(30000L);
		productBo.setSleepTimeMBean(new SleepTimeMBeanImpl());
		ProcessTimer.startTimer();
	}
	
	@Test
	public void testFindProductNullRequest() {
		try {
			productBo.findProduct(null);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testFindProductNoRequest() {
		try {
			productBo.findProduct(new FindProductRequest());
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testGetImage() throws NotFound, InvalidRequest {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("1");
		request.setTimeout(30000L);
		EasyMock.expect(daoMock.findById(EasyMock.anyInt())).andReturn(buildImage(request.getProductId()));
		EasyMock.replay(daoMock);
		GetImageResponse response = productBo.getImage(request);
		assertNotNull(response);
		assertNotNull(response.getImage());
		assertNotNull(response.getImage().getData());
		assertEquals("IMAGE/PNG", response.getImage().getMimeType());
	}
	@Test
	public void testGetImageNotFound() {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("1");
		request.setTimeout(3000L);
		EasyMock.expect(daoMock.findById(EasyMock.anyInt())).andReturn(null);
		EasyMock.replay(daoMock);
		try {
			productBo.getImage(request);
		} catch (Exception e) {
			assertTrue(e instanceof NotFound);
		}
		
	}
	@Test
	public void testGetImageNullRequest() {
	
		try {
			productBo.getImage(null);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	@Test
	public void testGetImageInvalidId() {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("A");
		request.setTimeout(3000L);
		try {
			productBo.getImage(request);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testGetImageTimedOut() {
		GetImageRequest request = new GetImageRequest();
		request.setProductId("1");
		request.setTimeout(1L);
		try {
			productBo.getImage(request);
		} catch (Exception e) {
			assertTrue(e instanceof ProcessTimeoutException);
		}
	}

	private Image buildImage(String productId) {
		Image image = new Image();
		image.setData(productId.getBytes());
		image.setMimeType("IMAGE/PNG");
		image.setProductId(Integer.parseInt(productId));
		return image;
	}
	
	@Test
	public void testCreateImage() throws InvalidRequest {
		SaveImageRequest imageRequest = new SaveImageRequest();
		Set<String> mimeTypes = new HashSet<String>();
		mimeTypes.add("image/png");
		ProductUtil.setSupportedMimeTypes(mimeTypes);
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType("IMAGE/PNG");
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);
		EasyMock.expect(daoMock.findById(EasyMock.anyInt())).andReturn(null);
		daoMock.persist(EasyMock.anyObject(Image.class));
		EasyMock.expectLastCall();
		daoMock.flushSession();
		EasyMock.expectLastCall();
		EasyMock.replay(daoMock);
		
		SaveImageResponse imageResponse = productBo.saveImage(imageRequest);
		assertNotNull(imageResponse);
		
		assertEquals(imageRequest.getProductId(), imageResponse.getId());
	}
	
	@Test
	public void testUpdateImage() throws InvalidRequest {
		SaveImageRequest imageRequest = new SaveImageRequest();
		Set<String> mimeTypes = new HashSet<String>();
		mimeTypes.add("image/png");
		ProductUtil.setSupportedMimeTypes(mimeTypes);
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType("IMAGE/PNG");
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);
		EasyMock.expect(daoMock.findById(EasyMock.anyInt())).andReturn(buildImage(imageRequest.getProductId()));
		daoMock.flushSession();
		EasyMock.expectLastCall();
		EasyMock.replay(daoMock);
		
		SaveImageResponse imageResponse = productBo.saveImage(imageRequest);
		assertNotNull(imageResponse);
		assertEquals(imageRequest.getProductId(), imageResponse.getId());
	}
	
	@Test
	public void testSaveImageInvalidRequestNullRequest() {
				
		try {
			productBo.saveImage(null);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	@Test
	public void testSaveImageInvalidRequestNullImage() {
		Set<String> mimeTypes = new HashSet<String>();
		mimeTypes.add("image/jpg");
		ProductUtil.setSupportedMimeTypes(mimeTypes);
		SaveImageRequest imageRequest = new SaveImageRequest();
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(null);
		image.setMimeType("IMAGE/PNG");
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			e.printStackTrace();
			assertTrue(e instanceof InvalidRequest);
		}
	}
	@Test
	public void testSaveImageInvalidRequestNoMimeType() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		Set<String> mimeTypes = new HashSet<String>();
		mimeTypes.add("image/png");
		ProductUtil.setSupportedMimeTypes(mimeTypes);
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType(null);
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testSaveImageInvalidRequestIncorrectMimeType() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType("application/pdf");
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
			InvalidRequest invalidRequest = (InvalidRequest)e;
			assertEquals(Constants.MIME_TYPE_UNSUPPORTED, invalidRequest.getMessage());
			assertEquals(ErrorCodes.MIME_TYPE_UNSUPPORTED, invalidRequest.getCode());
		}
	}
	
	@Test
	public void testSaveImageInvalidRequestNullData() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		
		imageRequest.setImage(null);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testSaveImageInvalidRequestNoProductId() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		
		imageRequest.setImage(null);
		imageRequest.setProductId("");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testSaveImageInvalidRequestInvalidProductId() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		
		imageRequest.setImage(null);
		imageRequest.setProductId("A");
		imageRequest.setTimeout(30000L);	
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof InvalidRequest);
		}
	}
	
	@Test
	public void testSaveImageTimedOut() {
		SaveImageRequest imageRequest = new SaveImageRequest();
		Set<String> mimeTypes = new HashSet<String>();
		mimeTypes.add("image/png");
		ProductUtil.setSupportedMimeTypes(mimeTypes);
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(new byte[1]);
		image.setMimeType("IMAGE/PNG");
		imageRequest.setImage(image);
		imageRequest.setProductId("1");
		imageRequest.setTimeout(1L);
		try {
			productBo.saveImage(imageRequest);
		} catch (Exception e) {
			assertTrue(e instanceof ProcessTimeoutException);
		}
	}
	
	
	
	//@Test
	public void testCreateProduct() throws InvalidRequest {
		CreateProductRequest request = new CreateProductRequest();
		request.setProduct(new Product());
		request.setTimeout(30000L);
		productBo.createProduct(request);
	}

	

	//@Test
	public void testUpdateProduct() throws InvalidRequest {
		UpdateProductRequest productRequest = new UpdateProductRequest();
		Product product = new Product();
		product.setProductId("1");
		productRequest.setProduct(product);
		productRequest.setTimeout(30000L);
		productBo.updateProduct(productRequest);
	}
	

}
