package com.esrx.ref.product.dao;

import java.util.List;

import com.esrx.ref.product.domain.Product;
import com.esrx.ref.product.domain.ProductAttribute;
import com.esrx.ref.product.domain.ProductResponse;
import com.express_scripts.inf.dao.GenericDao;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.SortOption;

public interface ProductDao extends GenericDao<Product> {

	ProductResponse findProduct(boolean matchCase, String categoryId, String upc, Boolean inStock, String query, 
			List<ProductAttribute> attributes, int offset, int count, List<SortOption> sortOptions, long timeout) throws InvalidRequest;
	
	void flushSession();

}
