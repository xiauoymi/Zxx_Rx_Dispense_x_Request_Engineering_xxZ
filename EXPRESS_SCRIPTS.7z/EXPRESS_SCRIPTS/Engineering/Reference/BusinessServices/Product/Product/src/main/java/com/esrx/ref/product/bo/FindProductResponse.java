package com.esrx.ref.product.bo;

import java.io.Serializable;
import java.util.List;

public class FindProductResponse
    implements Serializable
{

    /**
	 * 
	 */
	private static final long serialVersionUID = -836354347204663261L;
	private List<ProductSummary> productSummaryList;
    private int totalCount;
	/**
	 * @return the productSummaryList
	 */
	public List<ProductSummary> getProductSummaryList() {
		return productSummaryList;
	}
	/**
	 * @param productSummaryList the productSummaryList to set
	 */
	public void setProductSummaryList(List<ProductSummary> productSummaryList) {
		this.productSummaryList = productSummaryList;
	}
	/**
	 * @return the totalCount
	 */
	public int getTotalCount() {
		return totalCount;
	}
	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
    
    

    

}
