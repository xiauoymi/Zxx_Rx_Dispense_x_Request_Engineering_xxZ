package com.esrx.ref.product.bo;

import java.io.Serializable;

public class UpdateProductRequest implements Serializable {

	private static final long serialVersionUID = 5936141499995428004L;
	private Product product;
	private Long timeout;

	/**
	 * @return the product
	 */
	public Product getProduct() {
		return product;
	}

	/**
	 * @param product
	 *            the product to set
	 */
	public void setProduct(Product product) {
		this.product = product;
	}

	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}

	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}


}
