package com.esrx.ref.product.bo;

import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;

public interface ProductBo {

	public FindProductResponse findProduct(FindProductRequest findProductRequest)throws InvalidRequest;

	public GetProductResponse getProduct(GetProductRequest getProductRequest)throws InvalidRequest, NotFound;

	public CreateProductResponse createProduct(CreateProductRequest createProductRequest) throws InvalidRequest;
	
	public UpdateProductResponse updateProduct(UpdateProductRequest updateProductRequest) throws InvalidRequest;

	public GetImageResponse getImage(GetImageRequest imageRequest) throws NotFound, InvalidRequest;

	public SaveImageResponse saveImage(SaveImageRequest imageRequest) throws InvalidRequest;


}
