package com.esrx.ref.product.dao.impl;

import org.hibernate.SessionFactory;

import com.esrx.ref.product.dao.ImageDao;
import com.esrx.ref.product.domain.Image;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class ImageDaoImpl extends GenericDaoHibernate<Image> implements ImageDao{

	public ImageDaoImpl(SessionFactory sf) {
		super(Image.class, sf);
	}

	public void flushSession() {
		getSession(false).flush();
		
	}
	
}
