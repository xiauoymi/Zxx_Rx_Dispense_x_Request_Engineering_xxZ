package com.esrx.ref.product.bo;

import java.io.Serializable;

public class CreateProductResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5467444802580115682L;
	private String productId;

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	

}
