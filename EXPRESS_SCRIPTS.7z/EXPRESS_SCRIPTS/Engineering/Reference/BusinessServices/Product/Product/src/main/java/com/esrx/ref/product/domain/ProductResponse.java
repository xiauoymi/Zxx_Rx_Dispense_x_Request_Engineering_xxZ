package com.esrx.ref.product.domain;

import java.util.List;

public class ProductResponse {

	private List<Product> productList;
	private int totalCount;
	public List<Product> getProductList() {
		return productList;
	}
	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	
	
}
