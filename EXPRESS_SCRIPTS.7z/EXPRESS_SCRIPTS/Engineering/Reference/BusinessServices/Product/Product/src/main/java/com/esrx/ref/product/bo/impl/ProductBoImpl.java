package com.esrx.ref.product.bo.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.esrx.ref.product.bo.CreateProductRequest;
import com.esrx.ref.product.bo.CreateProductResponse;
import com.esrx.ref.product.bo.FindProductRequest;
import com.esrx.ref.product.bo.FindProductResponse;
import com.esrx.ref.product.bo.GetImageRequest;
import com.esrx.ref.product.bo.GetImageResponse;
import com.esrx.ref.product.bo.GetProductRequest;
import com.esrx.ref.product.bo.GetProductResponse;
import com.esrx.ref.product.bo.ProductBo;
import com.esrx.ref.product.bo.SaveImageRequest;
import com.esrx.ref.product.bo.SaveImageResponse;
import com.esrx.ref.product.bo.UpdateProductRequest;
import com.esrx.ref.product.bo.UpdateProductResponse;
import com.esrx.ref.product.dao.ImageDao;
import com.esrx.ref.product.dao.ProductDao;
import com.esrx.ref.product.domain.Image;
import com.esrx.ref.product.domain.ProductResponse;
import com.esrx.ref.product.management.SleepTimeMBean;
import com.express_scripts.inf.concurrent.ProcessTimer;
import com.express_scripts.inf.types.InvalidRequest;
import com.express_scripts.inf.types.NotFound;

public class ProductBoImpl implements ProductBo {
	
	private ImageDao imageDao;
	private ProductDao productDao;
	private SleepTimeMBean sleepTimeMBean;

	private Long defaultTimeout = 30000L;
	private Long bufferTime = 100L;
	
	public FindProductResponse findProduct(FindProductRequest findProductRequest) throws InvalidRequest {
		Validator.validateFindProductRequest(findProductRequest);
		
		delay(); // For testing purposes only
		
		String query = findProductRequest.getQuery();
		if (StringUtils.isNotBlank(query)) {
			query = query.replace('*', '%');
		}
		List<com.esrx.ref.product.domain.ProductAttribute> attributeList = 
			RequestTransformer.transformProductAttributeList(findProductRequest.getAttributes(), "");
		
		long timeRemaining = ProcessTimer.assertTimeRemaining(findProductRequest.getTimeout(), defaultTimeout, bufferTime);
		ProductResponse daoResp = productDao.findProduct(findProductRequest.isMatchCase(), findProductRequest.getCategoryId(), 
				findProductRequest.getUpc(), findProductRequest.getInStock(), query, 
				attributeList, findProductRequest.getOffset(), findProductRequest.getCount(), 
				findProductRequest.getSortOptions(), timeRemaining);
		
		FindProductResponse response = new FindProductResponse();
		response.setProductSummaryList(ResponseTransformer.transformProductList(daoResp.getProductList()));
		response.setTotalCount(daoResp.getTotalCount());
		return response;
	}

	public GetProductResponse getProduct(GetProductRequest getProductRequest) throws InvalidRequest, NotFound {
		Validator.validateGetProductRequest(getProductRequest);

		delay(); // For testing purposes only
		
		ProcessTimer.assertTimeRemaining(getProductRequest.getTimeout(), defaultTimeout, bufferTime);
		
		com.esrx.ref.product.domain.Product domainProduct = productDao.findById(getProductRequest.getProductId());
		if (domainProduct == null) {
			throw new NotFound();
		}
		
		GetProductResponse response = new GetProductResponse();
		response.setProduct(ResponseTransformer.transformProduct(domainProduct));
		return response;
	}

	public CreateProductResponse createProduct(CreateProductRequest createProductRequest) throws InvalidRequest {
		Validator.validateCreateProductRequest(createProductRequest);
		
		delay(); // For testing purposes only
		
		ProcessTimer.assertTimeRemaining(createProductRequest.getTimeout(), defaultTimeout, bufferTime);
		
		createProductRequest.getProduct().setProductId(createProductRequest.getProduct().getUpc());
		com.esrx.ref.product.domain.Product domainProduct = 
			RequestTransformer.transformProduct(createProductRequest.getProduct());
		productDao.persist(domainProduct);
		
		CreateProductResponse response = new CreateProductResponse();
		response.setProductId(domainProduct.getProductId());
		return response;
	}

	public GetImageResponse getImage(GetImageRequest imageRequest) throws NotFound, InvalidRequest {
		Validator.validateGetImageRequest(imageRequest);
		ProcessTimer.assertTimeRemaining(imageRequest.getTimeout(), defaultTimeout, bufferTime);
		
		delay(); // For testing purposes only
		
		Image domainImage = imageDao.findById(Integer.parseInt(imageRequest.getProductId()));
		GetImageResponse getImageResponse = null;
		if(domainImage != null){
			getImageResponse = new GetImageResponse();
			com.esrx.ref.product.bo.Image image = DomainTransformer.convertToBoImage(domainImage);
			getImageResponse.setImage(image);
		}else{
			throw ProductUtil.buildNotFound(StringUtils.EMPTY, null, null);
			
		}
		return getImageResponse;
	}

	public SaveImageResponse saveImage(SaveImageRequest imageRequest) throws InvalidRequest {
		Validator.validateSaveImageRequest(imageRequest);
		ProcessTimer.assertTimeRemaining(imageRequest.getTimeout(), defaultTimeout, bufferTime);
		
		delay(); // For testing purposes only
		
		Image domainImage = imageDao.findById(Integer.parseInt(imageRequest.getProductId()));
		if(domainImage == null){
			domainImage = new Image();
			domainImage.setData(imageRequest.getImage().getData());
			domainImage.setProductId(Integer.parseInt(imageRequest.getProductId()));
			domainImage.setMimeType(imageRequest.getImage().getMimeType().toLowerCase());
			imageDao.persist(domainImage);
		}else{
			domainImage.setData(imageRequest.getImage().getData());
			domainImage.setMimeType(imageRequest.getImage().getMimeType().toLowerCase());
		}
		
		imageDao.flushSession();
		
		SaveImageResponse imageResponse = new SaveImageResponse();
		imageResponse.setId(String.valueOf(domainImage.getProductId()));
		
		return imageResponse;
	}

	public UpdateProductResponse updateProduct(UpdateProductRequest updateProductRequest) throws InvalidRequest {
		Validator.validateUpdateProductRequest(updateProductRequest);
		
		delay(); // For testing purposes only
		
		ProcessTimer.assertTimeRemaining(updateProductRequest.getTimeout(), defaultTimeout, bufferTime);
		
		com.esrx.ref.product.domain.Product domainProduct = 
			productDao.findById(updateProductRequest.getProduct().getProductId());
		if (domainProduct == null) {
			throw new InvalidRequest("INVALID_PRODUCT_ID", "Invalid product ID.", null, updateProductRequest.getProduct().getProductId());
		}
		
		RequestTransformer.updateProduct(updateProductRequest.getProduct(), domainProduct);
		
		UpdateProductResponse response = new UpdateProductResponse();
		response.setProductId(domainProduct.getProductId());
		return response;
	}
	
	public ProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	/**
	 * @param imageDao the imageDao to set
	 */
	public void setImageDao(ImageDao imageDao) {
		this.imageDao = imageDao;
	}

	/**
	 * @param defaultTimeout the defaultTimeout to set
	 */
	public void setDefaultTimeout(Long defaultTimeout) {
		this.defaultTimeout = defaultTimeout;
	}

	/**
	 * @param bufferTime the bufferTime to set
	 */
	public void setBufferTime(Long bufferTime) {
		this.bufferTime = bufferTime;
	}
	
	public void setSleepTimeMBean(SleepTimeMBean sleepTimeMBean) {
		this.sleepTimeMBean = sleepTimeMBean;
	}

	private void delay() {
		long delayTime = sleepTimeMBean.getSleepTimeMS();
		if (delayTime > 0) {
			try {
				Thread.sleep(delayTime);
			} catch (Exception e) {
				// do nothing
			}
		}
	}
	
	
	
}
