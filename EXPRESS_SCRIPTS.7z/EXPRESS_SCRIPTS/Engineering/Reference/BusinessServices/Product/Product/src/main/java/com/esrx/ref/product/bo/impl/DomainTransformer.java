package com.esrx.ref.product.bo.impl;

import com.esrx.ref.product.domain.Image;

public class DomainTransformer {

	public static com.esrx.ref.product.bo.Image convertToBoImage(
			Image domainImage){
		com.esrx.ref.product.bo.Image image = new com.esrx.ref.product.bo.Image();
		image.setData(domainImage.getData());
		image.setMimeType(domainImage.getMimeType());
		return image;
	}

}
