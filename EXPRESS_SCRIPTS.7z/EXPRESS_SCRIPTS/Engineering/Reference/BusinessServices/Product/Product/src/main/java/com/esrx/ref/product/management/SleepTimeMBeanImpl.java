package com.esrx.ref.product.management;

public class SleepTimeMBeanImpl implements SleepTimeMBean {

	private long sleepTimeMS = 200;
	
	@Override
	public long getSleepTimeMS() {
		return this.sleepTimeMS;
	}

	@Override
	public void setSleepTimeMS(long sleepTimeMS) {
		this.sleepTimeMS = sleepTimeMS;
	}

}
