package com.esrx.ref.product.bo;

import java.io.Serializable;

public class UpdateProductResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7527342531656322926L;
	/**
	 * 
	 */
	private String productId;

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	

}
