package com.esrx.ref.product.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="PRODUCT_ATTRIBUTE")
public class ProductAttribute implements Serializable {

	private static final long serialVersionUID = -4824272080850334957L;
	private ProductAttributeKey key;
	private String attributeValue;
	private int order;

	@EmbeddedId
	public ProductAttributeKey getKey() {
		return key;
	}

	public void setKey(ProductAttributeKey key) {
		this.key = key;
	}

	@Column(name="ATTR_VALUE")
	public String getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(String attributeValue) {
		this.attributeValue = attributeValue;
	}

	@Column(name="ATTR_ORDER")
	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductAttribute other = (ProductAttribute) obj;
		if (key == null || other.key != null) {
			return false;
		} else if (!key.equals(other.key))
			return false;
		return true;
	}
	
}
