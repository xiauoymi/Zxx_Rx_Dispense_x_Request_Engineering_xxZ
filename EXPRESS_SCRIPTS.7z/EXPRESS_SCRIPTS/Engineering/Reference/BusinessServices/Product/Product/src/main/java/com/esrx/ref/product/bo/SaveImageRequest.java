package com.esrx.ref.product.bo;

import java.io.Serializable;

public class SaveImageRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8909379786589288060L;
	private String productId;
	private Image image;
	private Long timeout;
	
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the image
	 */
	public Image getImage() {
		return image;
	}
	/**
	 * @param image the image to set
	 */
	public void setImage(Image image) {
		this.image = image;
	}
	/**
	 * @return the timeout
	 */
	public Long getTimeout() {
		return timeout;
	}
	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(Long timeout) {
		this.timeout = timeout;
	}
}
