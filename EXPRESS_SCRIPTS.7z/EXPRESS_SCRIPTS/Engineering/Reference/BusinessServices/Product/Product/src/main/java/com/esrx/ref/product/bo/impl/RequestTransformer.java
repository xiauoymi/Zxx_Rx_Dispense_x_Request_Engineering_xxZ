package com.esrx.ref.product.bo.impl;

import java.util.ArrayList;
import java.util.List;

import com.esrx.ref.product.domain.Category;
import com.esrx.ref.product.domain.Product;
import com.esrx.ref.product.domain.ProductAttribute;
import com.esrx.ref.product.domain.ProductAttributeKey;

public class RequestTransformer {
	
	public static void updateProduct(com.esrx.ref.product.bo.Product in, Product out) {
		out.setProductName(in.getProductName());
		out.setDescription(in.getDescription());
		out.setUpc(in.getUpc());
		out.setInventoryCount(in.getInventoryCount());
		out.setPrice(in.getPrice().getAmount());
		out.setCurrency(in.getPrice().getCurrency());
		out.setAttributes(transformProductAttributeList(in.getAttributes(), out.getProductId()));
		out.setCategories(transformCategoryList(in.getCategories()));
	}
		
	public static Product transformProduct(com.esrx.ref.product.bo.Product in) {
		Product out = new Product();
		out.setProductId(in.getProductId());
		out.setProductName(in.getProductName());
		out.setDescription(in.getDescription());
		out.setUpc(in.getUpc());
		out.setInventoryCount(in.getInventoryCount());
		out.setPrice(in.getPrice().getAmount());
		out.setCurrency(in.getPrice().getCurrency());
		out.setAttributes(transformProductAttributeList(in.getAttributes(), out.getProductId()));
		out.setCategories(transformCategoryList(in.getCategories()));
		return out;
	}

	private static List<Category> transformCategoryList(List<com.esrx.ref.product.bo.Category> in) {
		List<Category> out = new ArrayList<Category>();
		if (in == null) {
			return out;
		}
		for (com.esrx.ref.product.bo.Category c: in) {
			out.add(transformCategory(c));
		}
		return out;
	}

	private static Category transformCategory(com.esrx.ref.product.bo.Category in) {
		Category out = new Category();
		out.setCategoryId(in.getCategoryId());
		out.setCategoryName(in.getCategoryName());
		return out;
	}

	public static List<ProductAttribute> transformProductAttributeList(List<com.esrx.ref.product.bo.ProductAttribute> in, String productId) {
		List<ProductAttribute> out = new ArrayList<ProductAttribute>();
		if (in == null) {
			return out; 
		}
		int i = 0;
		for (com.esrx.ref.product.bo.ProductAttribute inAttr: in) {
			out.add(transformProductAttribute(inAttr, i, productId));
			i++;
		}
		return out;
	}
	
	public static com.esrx.ref.product.domain.ProductAttribute transformProductAttribute(com.esrx.ref.product.bo.ProductAttribute in, int index, String productId) {
		ProductAttribute out = new ProductAttribute();
		ProductAttributeKey key = new ProductAttributeKey();
		key.setProductId(productId);
		key.setAttributeName(in.getAttributeName());
		out.setKey(key);
		out.setAttributeValue(in.getAttributeValue());
		out.setOrder(index);
		return out;
	}
	
}
