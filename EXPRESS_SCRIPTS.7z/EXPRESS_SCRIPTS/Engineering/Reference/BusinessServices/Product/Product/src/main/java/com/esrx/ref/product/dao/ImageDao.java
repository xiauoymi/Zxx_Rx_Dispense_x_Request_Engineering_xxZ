package com.esrx.ref.product.dao;

import com.esrx.ref.product.domain.Image;
import com.express_scripts.inf.dao.GenericDao;

public interface ImageDao extends GenericDao<Image> {

	void flushSession();

}
