package com.esrx.ref.product.bo;

import java.io.Serializable;

public class GetImageResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -598508606418720465L;
	private Image image;

	/**
	 * @return the image
	 */
	public Image getImage() {
		return image;
	}

	/**
	 * @param image
	 *            the image to set
	 */
	public void setImage(Image image) {
		this.image = image;
	}

}
