package com.esrx.ref.product.jaxrs;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.esrx.ref.product.CreateProductRequest;
import com.esrx.ref.product.CreateProductResponse;
import com.esrx.ref.product.FindProductRequest;
import com.esrx.ref.product.FindProductResponse;
import com.esrx.ref.product.GetImageRequest;
import com.esrx.ref.product.GetImageResponse;
import com.esrx.ref.product.GetProductRequest;
import com.esrx.ref.product.GetProductResponse;
import com.esrx.ref.product.SaveImageRequest;
import com.esrx.ref.product.SaveImageResponse;
import com.esrx.ref.product.UpdateProductRequest;
import com.esrx.ref.product.UpdateProductResponse;

/**
 * @author p043459
 *
 */
@Path("/")

public interface ProductResource {
	@POST
	@Path("findProduct")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public FindProductResponse findProduct(FindProductRequest productRequest);
	
	@POST
	@Path("getProduct")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public GetProductResponse getProduct(GetProductRequest productRequest);
	
	@POST
	@Path("createProduct")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public CreateProductResponse createProduct(CreateProductRequest productRequest);
	
	@POST
	@Path("updateProduct")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public UpdateProductResponse updateProduct(UpdateProductRequest productRequest);
	
	@POST
	@Path("getImage")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public GetImageResponse getImage(GetImageRequest imageRequest);
	
	@POST
	@Path("saveImage")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public SaveImageResponse saveImage(SaveImageRequest saveImageRequest);
	
}
