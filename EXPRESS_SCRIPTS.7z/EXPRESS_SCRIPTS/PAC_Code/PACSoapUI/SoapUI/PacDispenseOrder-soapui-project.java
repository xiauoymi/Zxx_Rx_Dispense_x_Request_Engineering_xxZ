<?xml version="1.0" encoding="UTF-8"?>
<con:soapui-project activeEnvironment="Default" name="PacDispenseOrder" resourceRoot="" soapui-version="3.0.1" abortOnError="false" runType="SEQUENTIAL" xmlns:con="http://eviware.com/soapui/config">
	<con:settings/>
	<con:interface xsi:type="con:RestService" wadlVersion="http://wadl.dev.java.net/2009/02" name="PacDispenseOrder" type="rest" basePath="/pacdispenseorder" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
		<con:settings/>
		<con:definitionCache/>
		<con:endpoints>
			<con:endpoint>https://localhost:4001</con:endpoint>
		</con:endpoints>
		<con:resource name="processpacdispenseorder" path="/processpacdispenseorder">
			<con:settings/>
			<con:parameters/>
			<con:method name="processPacDispenseOrderList" method="POST">
				<con:settings/>
				<con:parameters/>
				<!-- <con:representation type="FAULT"> -->
				<!-- <con:mediaType>application/xml</con:mediaType> -->
				<!-- <con:status>400 500</con:status> -->
				<!-- <con:params /> -->
				<!-- </con:representation> -->
				<!-- <con:representation type="REQUEST"> -->
				<!-- <con:mediaType>application/xml</con:mediaType> -->
				<!-- <con:params /> -->
				<!-- <con:element>AddProductRequest</con:element> -->
				<!-- </con:representation> -->
				<!-- <con:representation type="RESPONSE"> -->
				<!-- <con:mediaType>application/xml</con:mediaType> -->
				<!-- <con:status>200</con:status> -->
				<!-- <con:params /> -->
				<!-- <con:element xmlns:cart="http://cart.ref.esrx.com">cart:AddProductResponse -->
				<!-- </con:element> -->
				<!-- </con:representation> -->
				<con:representation type="REQUEST"><con:mediaType>application/xml</con:mediaType><con:params/></con:representation><con:representation type="FAULT"><con:mediaType>application/xml</con:mediaType><con:status>401 500</con:status><con:params/></con:representation><con:representation type="RESPONSE"><con:mediaType>text/plain</con:mediaType><con:status>204</con:status><con:params/><con:element>data</con:element></con:representation><con:representation type="RESPONSE"><con:mediaType>application/xml</con:mediaType><con:status>200</con:status><con:params/><con:element>Response</con:element></con:representation><con:request name="Request 1" postQueryString="false" mediaType="application/xml">
<!-- 				    mediaType="application/xml" -->
					
<!-- 					<con:settings> -->
<!-- 						<con:setting -->
<!-- 							id="com.eviware.soapui.impl.wsdl.WsdlRequest@request-headers">&lt;xml-fragment/></con:setting> -->
<!-- 					</con:settings> -->
					<con:settings><con:setting id="com.eviware.soapui.impl.support.AbstractHttpRequest@follow-redirects">false</con:setting></con:settings><con:endpoint>https://localhost:4001</con:endpoint>
<!-- 					<con:request> -->
<!-- <![CDATA[<AddProductRequest xmlns="http://cart.ref.esrx.com"> -->
<!-- 	<accountId>1</accountId> -->
<!-- 	<storeId>1</storeId> -->
<!-- 		<cartProduct> -->
<!-- 			<productId>1</productId> -->
<!-- 			<quantity>5</quantity> -->
<!-- 		</cartProduct> -->
<!-- 	<timeout>30000</timeout> -->
<!-- </AddProductRequest>]]> -->
<!-- 					</con:request> -->
					<con:request/><con:credentials>
<!-- 						<con:username>p043459</con:username> -->
<!-- 						<con:password>jun-2013</con:password> -->
						<con:username>extordwsdev</con:username>
						<con:password>*Drt#Fty</con:password>
					</con:credentials>
					<con:jmsConfig JMSDeliveryMode="PERSISTENT"/>
					<con:jmsPropertyConfig/>
					<con:parameters/>
				</con:request>
			</con:method>
		</con:resource>
	</con:interface>
	<con:properties/>
	<con:wssContainer/>
</con:soapui-project>