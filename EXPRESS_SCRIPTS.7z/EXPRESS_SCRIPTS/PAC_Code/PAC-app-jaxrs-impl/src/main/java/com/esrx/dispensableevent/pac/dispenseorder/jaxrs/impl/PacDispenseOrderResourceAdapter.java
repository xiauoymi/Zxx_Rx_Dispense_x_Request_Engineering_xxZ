package com.esrx.dispensableevent.pac.dispenseorder.jaxrs.impl;

import generated.Request;
import generated.Response;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import com.esrx.dispensableevent.pac.dispenseorder.jaxrs.NRxPacDispenseOrderResource;
//import com.esrx.dispensableevent.pac.domain.jaxb.bo.Response;
//import com.esrx.dispensableevent.pac.domain.jaxb.bo.Request;

public class PacDispenseOrderResourceAdapter {

	private NRxPacDispenseOrderResource pacDispenseOrderRemoteResource;

	/**
	 * @return the pacDispenseOrderRemoteResource
	 */
	public NRxPacDispenseOrderResource getPacDispenseOrderRemoteResource() {
		return pacDispenseOrderRemoteResource;
	}

	/**
	 * @param pacDispenseOrderRemoteResource the pacDispenseOrderRemoteResource to set
	 */
	public void setPacDispenseOrderRemoteResource(
			NRxPacDispenseOrderResource pacDispenseOrderRemoteResource) {
		this.pacDispenseOrderRemoteResource = pacDispenseOrderRemoteResource;
	}
	
	
	public Response callPac(Request pacRequest) {
		Response response  = null;
		try {
			
			response = pacDispenseOrderRemoteResource.processNRxToPacDispenseOrder(pacRequest);

			System.out.println("response is : "+response);
		}catch (Exception e) {
			System.out.println("What is exception getMessage : "+e.getMessage());
			System.out.println("What is exception getCause : "+e.getCause());
			System.out.println("What is exception getLocalizedMessage : "+e.getLocalizedMessage());

		}
		
		return response;
	}
}
