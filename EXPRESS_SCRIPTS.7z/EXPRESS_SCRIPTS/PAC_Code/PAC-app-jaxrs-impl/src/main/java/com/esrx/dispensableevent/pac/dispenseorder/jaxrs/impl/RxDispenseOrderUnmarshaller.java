/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.pac.dispenseorder.jaxrs.impl;

import generated.Request;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
//import com.esrx.dispensableevent.pac.domain.jaxb.bo.Response;
//import com.esrx.dispensableevent.pac.domain.jaxb.bo.Request;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.pac.dispenseorder.bo.impl.PacDispenseOrderBoImpl;

/**
 * The Class RxDispenseOrderUnmarshaller.
 */
public class RxDispenseOrderUnmarshaller {

	/** The Constant log. */
//	private static final Logger log = LoggerFactory
//	.getLogger(PacDispenseOrderBoImpl.class);

	/** The Constant rxDispenseJAXBContext. */
	private static final JAXBContext rxDispenseJAXBContext = initResponseJAXBContext();

	/**
	 * Inits the response jaxb context.
	 *
	 * @return the jAXB context
	 */
	private static JAXBContext initResponseJAXBContext() {
		try {
			return JAXBContext.newInstance(Request.class);
		} catch (JAXBException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * String to un marshall.
	 *
	 * @param xmlString the xml string
	 * @return the rx dispense request
	 * @throws JAXBException the jAXB exception
	 */
	public static Request stringToUnMarshall(String xmlString)
			throws JAXBException {

		Request request = null;
		Unmarshaller unmarshaller = null;
		InputStream inputStream = null;

//		log.info("Method stringToUnMarshall Entered : ");
		if (xmlString != null) {
			unmarshaller = rxDispenseJAXBContext.createUnmarshaller();
			inputStream = new ByteArrayInputStream(xmlString.getBytes());

			request = (Request) unmarshaller
					.unmarshal(inputStream);
		}
//		log.info("Method stringToUnMarshall Exited");
		return request;
	}

}
