package com.esrx.dispensableevent.pac.dispenseorder.jaxrs.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.bind.JAXBException;

import com.esrx.dispensableevent.pac.dispenseorder.bo.PacDispenseOrderBo;
//import static com.esrx.dispensableevent.pac.dispenseorder.jaxrs.PACDispenseOrderRes.Response;

import com.esrx.dispensableevent.pac.dispenseorder.jaxrs.PacDispenseOrderResource;
import com.esrx.dispensableevent.pac.dispenseorder.jaxrs.NRxPacDispenseOrderResource;
//import com.esrx.dispensableevent.pac.domain.jaxb.bo.Request;
//import com.esrx.dispensableevent.pac.domain.jaxb.bo.Response;
import static com.esrx.dispensableevent.pac.dispenseorder.jaxrs.impl.RxDispenseOrderUnmarshaller.stringToUnMarshall;

import generated.Request;
import generated.Response;
public class PacDispenseOrderResourceImpl implements PacDispenseOrderResource{

	private PacDispenseOrderBo pacDispenseOrderBo;
	private NRxPacDispenseOrderResource pacDispenseOrderRemoteResource;
	private PacDispenseOrderResourceAdapter pacDispenseOrderResourceAdapter; 
	
	
    /**
	 * @return the pacDispenseOrderBo
	 */
	public PacDispenseOrderBo getPacDispenseOrderBo() {
		return pacDispenseOrderBo;
	}

	/**
	 * @param pacDispenseOrderBo the pacDispenseOrderBo to set
	 */
	public void setPacDispenseOrderBo(PacDispenseOrderBo pacDispenseOrderBo) {
		this.pacDispenseOrderBo = pacDispenseOrderBo;
	}

	


/**
	 * @return the pacDispenseOrderRemoteResource
	 */
	public NRxPacDispenseOrderResource getPacDispenseOrderRemoteResource() {
		return pacDispenseOrderRemoteResource;
	}

	/**
	 * @param pacDispenseOrderRemoteResource the pacDispenseOrderRemoteResource to set
	 */
	public void setPacDispenseOrderRemoteResource(
			NRxPacDispenseOrderResource pacDispenseOrderRemoteResource) {
		this.pacDispenseOrderRemoteResource = pacDispenseOrderRemoteResource;
	}

/**
	 * @return the pacDispenseOrderResourceAdapter
	 */
	public PacDispenseOrderResourceAdapter getPacDispenseOrderResourceAdapter() {
		return pacDispenseOrderResourceAdapter;
	}

	/**
	 * @param pacDispenseOrderResourceAdapter the pacDispenseOrderResourceAdapter to set
	 */
	public void setPacDispenseOrderResourceAdapter(
			PacDispenseOrderResourceAdapter pacDispenseOrderResourceAdapter) {
		this.pacDispenseOrderResourceAdapter = pacDispenseOrderResourceAdapter;
	}


	private static final String testXML2 = "<Request>\r\n" + 
	"  <TestMode>Y</TestMode>\r\n" + 
	"  <OrgId>OrgId1</OrgId>\r\n" + 
	"  <Channel>Channel1</Channel>\r\n" + 
	"  <Role>Role1</Role>\r\n" + 
	"  <Format>Format1</Format>\r\n" + 
	"  <UserId>UserId1</UserId>\r\n" + 
	"  <InvoiceNumber>InvoiceNumber1</InvoiceNumber>\r\n" + 
	"  <InvoiceSub>InvoiceSub1</InvoiceSub>\r\n" + 
	"  <Location>Location1</Location>\r\n" + 
	"  <OrderNum>OrderNum1</OrderNum>\r\n" + 
	"</Request>"; 

	@Override
	public Response processPacDispenseOrderList() {
		
		InputStream is=null;
		Request pacRequest =null;
		
		try {
			is = getClass().getResource("Input1.xml").openStream();
	        int readByte;       
	        StringWriter strWriter = new StringWriter();

		    while ((readByte = is.read()) != -1 ) {
		    	strWriter.write(readByte);
		    }
		    System.out.println("what is strWriter "+strWriter );
			 pacRequest = stringToUnMarshall(String.valueOf(strWriter));
			 
			 
		} 
		catch (Exception e) {
			e.printStackTrace();
		} 
		
		System.out.println("YES we wre at PacDispenseOrderResourceImpl");
		Response response = pacDispenseOrderResourceAdapter.callPac(pacRequest);
			 
		System.out.println("YES RES RECIEVED");
		
		System.out.println(response.getStatusCode());
		System.out.println(response.getStatusMessage());
		
		return null;
	}
	
}
