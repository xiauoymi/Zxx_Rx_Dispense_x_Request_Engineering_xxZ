package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.DispPharmList;

import java.util.Date;

public class OrderRecordMappingHelper {

//	private String replInd;
	private String modifiedFlag;
	private String brandId;
//	private String langFlag;
	private String guarDelvFlag;
	private String qsiOptions;
	private String qsiDelivInstr;
	private String qsiDelivDate;
	private String cstScrubFlag;
	private DispPharmList dispPharmList;

//	/**
//	 * @return the replInd
//	 */
//	public String getReplInd() {
//		return replInd;
//	}
//	/**
//	 * @param replInd the replInd to set
//	 */
//	public void setReplInd(String replInd) {
//		this.replInd = replInd;
//	}
	/**
	 * @return the modifiedFlag
	 */
	public String getModifiedFlag() {
		return modifiedFlag;
	}
	/**
	 * @param modifiedFlag the modifiedFlag to set
	 */
	public void setModifiedFlag(String modifiedFlag) {
		this.modifiedFlag = modifiedFlag;
	}
	/**
	 * @return the brandId
	 */
	public String getBrandId() {
		return brandId;
	}
	/**
	 * @param brandId the brandId to set
	 */
	public void setBrandId(String brandId) {
		this.brandId = brandId;
	}
//	/**
//	 * @return the langFlag
//	 */
//	public String getLangFlag() {
//		return langFlag;
//	}
//	/**
//	 * @param langFlag the langFlag to set
//	 */
//	public void setLangFlag(String langFlag) {
//		this.langFlag = langFlag;
//	}
	/**
	 * @return the guarDelvFlag
	 */
	public String getGuarDelvFlag() {
		return guarDelvFlag;
	}
	/**
	 * @param guarDelvFlag the guarDelvFlag to set
	 */
	public void setGuarDelvFlag(String guarDelvFlag) {
		this.guarDelvFlag = guarDelvFlag;
	}
	/**
	 * @return the qsiOptions
	 */
	public String getQsiOptions() {
		return qsiOptions;
	}
	/**
	 * @param qsiOptions the qsiOptions to set
	 */
	public void setQsiOptions(String qsiOptions) {
		this.qsiOptions = qsiOptions;
	}
	/**
	 * @return the qsiDelivInstr
	 */
	public String getQsiDelivInstr() {
		return qsiDelivInstr;
	}
	/**
	 * @param qsiDelivInstr the qsiDelivInstr to set
	 */
	public void setQsiDelivInstr(String qsiDelivInstr) {
		this.qsiDelivInstr = qsiDelivInstr;
	}
	/**
	 * @return the cstScrubFlag
	 */
	public String getCstScrubFlag() {
		return cstScrubFlag;
	}
	/**
	 * @param cstScrubFlag the cstScrubFlag to set
	 */
	public void setCstScrubFlag(String cstScrubFlag) {
		this.cstScrubFlag = cstScrubFlag;
	}
	/**
	 * @return the dispPharmList
	 */
	public DispPharmList getDispPharmList() {
		return dispPharmList;
	}
	/**
	 * @param dispPharmList the dispPharmList to set
	 */
	public void setDispPharmList(DispPharmList dispPharmList) {
		this.dispPharmList = dispPharmList;
	}
	/**
	 * @return the qsiDelivDate
	 */
	public String getQsiDelivDate() {
		return qsiDelivDate;
	}
	/**
	 * @param qsiDelivDate the qsiDelivDate to set
	 */
	public void setQsiDelivDate(String qsiDelivDate) {
		this.qsiDelivDate = qsiDelivDate;
	}
}
