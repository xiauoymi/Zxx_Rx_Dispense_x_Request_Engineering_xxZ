/**
 * Author : Guru Krishnan
 */
package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "AUXRXS00", uniqueConstraints = {})
public class NRxRxFinancial implements Serializable {

	private static final long serialVersionUID = 6614001612370128736L;
	private NRxRxFinancialId id;
	private String cardholderId;
	private String clientId;
	private String phctCheckId;
	private String phctCheckDte;
	private String phctCheckTim;
	private String fillPhctId;
	private String fillDte;
	private String fillTim;
	private String adCarrOpId;
	private String adContOpId;
	private Date adjudTms;
	private int phcyAcctNbr;
	private Date billableTms;
	private double awpUcAmt;
	private double acqUcAmt;
	private double agpUcAmt;
	private double fulUcAmt;
	private String extTranId;
	private double bIngCostAmt;
	private double bDispFeeAmt;
	private String bProdSvcId;
	private Date billDte;
	private int packageQty;
	private String noChargeInd;
	private int bDawCde;
	private String brndGnrcCde;
	private int daySupplyQty;
	private int medcoDrugNbr;
	private String drugLotNbr;
	private int drugLotSeq;
	private int drugCtrQty;
	private int fillQty;
	private int payeePhcyId;
	private String medicareCde;
	private int phcyFillSeq;
	private double delivFeeAmt;
	private String patAddr1Txt;
	private String patAddr2Txt;
	private String patCityNme;
	private String patStCde;
	private int patZip5Cde;
	private int patZip4Cde;
	private String patFirstNme;
	private String patLastNme;
	private String patMiddleNme;
	private String patSexCde;
	private int patDependNbr;
	private Date patBirthDte;
	private int dailyDoseQty;
	private Date rxIssuedDte;
	private double patPayAmt;
	private double salesTaxAmt;
	private Date insertTms;
	private String drFirstNme;
	private String drLastNme;
	private String drDeaNbr;
	private String drDeaSfxTxt;
	private String drAddr1Txt;
	private String drCityNme;
	private String drStCde;
	private int drZip9Cde;
	private Date issueDte;
	private double doctorDawCde;
	private double patDawCde;
	private String primCovrgCde;
	private String physNpiNbr;
	private String phyStLicNbr;
	private String stRxSerNbr;

	// Default Constructor
	public NRxRxFinancial() {

	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "erxPartNbr", column = @Column(name = "ERX_PART_NBR")),
			@AttributeOverride(name = "erxFillNo", column = @Column(name = "ERX_FILL_NO")),
			@AttributeOverride(name = "erxExtInvno", column = @Column(name = "ERX_EXT_INVNO")),
			@AttributeOverride(name = "erxInvnoSub", column = @Column(name = "ERX_INVNO_SUB")),
			@AttributeOverride(name = "erxLocaNo", column = @Column(name = "ERX_LOCA_NO")),
			@AttributeOverride(name = "erxExtRxno", column = @Column(name = "ERX_EXT_RXNO")),
			@AttributeOverride(name = "erxRefillNo", column = @Column(name = "ERX_REFILL_NO")) })
	public NRxRxFinancialId getId() {
		return id;
	}

	public void setId(NRxRxFinancialId id) {
		this.id = id;
	}

	@Column(name = "ERX_CARDHOLDER_ID")
	public String getCardholderId() {
		return cardholderId;
	}

	public void setCardholderId(String cardholderId) {
		this.cardholderId = cardholderId;
	}

	@Column(name = "ERX_CLIENT_ID")
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	@Column(name = "ERX_PHCT_CHECK_ID")
	public String getPhctCheckId() {
		return phctCheckId;
	}

	public void setPhctCheckId(String phctCheckId) {
		this.phctCheckId = phctCheckId;
	}

	@Column(name = "ERX_PHCT_CHECK_DTE")
	public String getPhctCheckDte() {
		return phctCheckDte;
	}

	public void setPhctCheckDte(String phctCheckDte) {
		this.phctCheckDte = phctCheckDte;
	}

	@Column(name = "ERX_PHCT_CHECK_TIM")
	public String getPhctCheckTim() {
		return phctCheckTim;
	}

	public void setPhctCheckTim(String phctCheckTim) {
		this.phctCheckTim = phctCheckTim;
	}

	@Column(name = "ERX_FILL_PHCT_ID")
	public String getFillPhctId() {
		return fillPhctId;
	}

	public void setFillPhctId(String fillPhctId) {
		this.fillPhctId = fillPhctId;
	}

	@Column(name = "ERX_FILL_DTE")
	public String getFillDte() {
		return fillDte;
	}

	public void setFillDte(String fillDte) {
		this.fillDte = fillDte;
	}

	@Column(name = "ERX_FILL_TIM")
	public String getFillTim() {
		return fillTim;
	}

	public void setFillTim(String fillTim) {
		this.fillTim = fillTim;
	}

	@Column(name = "ERX_AD_CARR_OP_ID")
	public String getAdCarrOpId() {
		return adCarrOpId;
	}

	public void setAdCarrOpId(String adCarrOpId) {
		this.adCarrOpId = adCarrOpId;
	}

	@Column(name = "ERX_AD_CONT_OP_ID")
	public String getAdContOpId() {
		return adContOpId;
	}

	public void setAdContOpId(String adContOpId) {
		this.adContOpId = adContOpId;
	}

	@Column(name = "ERX_ADJUD_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getAdjudTms() {
		return adjudTms;
	}

	public void setAdjudTms(Date adjudTms) {
		this.adjudTms = adjudTms;
	}

	@Column(name = "ERX_PHCY_ACCT_NBR")
	public int getPhcyAcctNbr() {
		return phcyAcctNbr;
	}

	public void setPhcyAcctNbr(int phcyAcctNbr) {
		this.phcyAcctNbr = phcyAcctNbr;
	}

	@Column(name = "ERX_BILLABLE_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getBillableTms() {
		return billableTms;
	}

	public void setBillableTms(Date billableTms) {
		this.billableTms = billableTms;
	}

	@Column(name = "ERX_AWP_UC_AMT")
	public double getAwpUcAmt() {
		return awpUcAmt;
	}

	public void setAwpUcAmt(double awpUcAmt) {
		this.awpUcAmt = awpUcAmt;
	}

	@Column(name = "ERX_ACQ_UC_AMT")
	public double getAcqUcAmt() {
		return acqUcAmt;
	}

	public void setAcqUcAmt(double acqUcAmt) {
		this.acqUcAmt = acqUcAmt;
	}

	@Column(name = "ERX_AGP_UC_AMT")
	public double getAgpUcAmt() {
		return agpUcAmt;
	}

	public void setAgpUcAmt(double agpUcAmt) {
		this.agpUcAmt = agpUcAmt;
	}

	@Column(name = "ERX_FUL_UC_AMT")
	public double getFulUcAmt() {
		return fulUcAmt;
	}

	public void setFulUcAmt(double fulUcAmt) {
		this.fulUcAmt = fulUcAmt;
	}

	@Column(name = "ERX_EXT_TRAN_ID")
	public String getExtTranId() {
		return extTranId;
	}

	public void setExtTranId(String extTranId) {
		this.extTranId = extTranId;
	}

	@Column(name = "ERX_B_ING_COST_AMT")
	public double getbIngCostAmt() {
		return bIngCostAmt;
	}

	public void setbIngCostAmt(double bIngCostAmt) {
		this.bIngCostAmt = bIngCostAmt;
	}

	@Column(name = "ERX_B_DISP_FEE_AMT")
	public double getbDispFeeAmt() {
		return bDispFeeAmt;
	}

	public void setbDispFeeAmt(double bDispFeeAmt) {
		this.bDispFeeAmt = bDispFeeAmt;
	}

	@Column(name = "ERX_B_PROD_SVC_ID")
	public String getbProdSvcId() {
		return bProdSvcId;
	}

	public void setbProdSvcId(String bProdSvcId) {
		this.bProdSvcId = bProdSvcId;
	}

	@Column(name = "ERX_BILL_DTE")
	@Temporal(TemporalType.DATE)
	public Date getBillDte() {
		return billDte;
	}

	public void setBillDte(Date billDte) {
		this.billDte = billDte;
	}

	@Column(name = "ERX_PACKAGE_QTY")
	public int getPackageQty() {
		return packageQty;
	}

	public void setPackageQty(int packageQty) {
		this.packageQty = packageQty;
	}

	@Column(name = "ERX_NO_CHARGE_IND")
	public String getNoChargeInd() {
		return noChargeInd;
	}

	public void setNoChargeInd(String noChargeInd) {
		this.noChargeInd = noChargeInd;
	}

	@Column(name = "ERX_B_DAW_CDE")
	public int getbDawCde() {
		return bDawCde;
	}

	public void setbDawCde(int bDawCde) {
		this.bDawCde = bDawCde;
	}

	@Column(name = "ERX_BRND_GNRC_CDE")
	public String getBrndGnrcCde() {
		return brndGnrcCde;
	}

	public void setBrndGnrcCde(String brndGnrcCde) {
		this.brndGnrcCde = brndGnrcCde;
	}

	@Column(name = "ERX_DAY_SUPPLY_QTY")
	public int getDaySupplyQty() {
		return daySupplyQty;
	}

	public void setDaySupplyQty(int daySupplyQty) {
		this.daySupplyQty = daySupplyQty;
	}

	@Column(name = "ERX_MEDCO_DRUG_NBR")
	public int getMedcoDrugNbr() {
		return medcoDrugNbr;
	}

	public void setMedcoDrugNbr(int medcoDrugNbr) {
		this.medcoDrugNbr = medcoDrugNbr;
	}

	@Column(name = "ERX_DRUG_LOT_NBR")
	public String getDrugLotNbr() {
		return drugLotNbr;
	}

	public void setDrugLotNbr(String drugLotNbr) {
		this.drugLotNbr = drugLotNbr;
	}

	@Column(name = "ERX_DRUG_LOT_SEQ")
	public int getDrugLotSeq() {
		return drugLotSeq;
	}

	public void setDrugLotSeq(int drugLotSeq) {
		this.drugLotSeq = drugLotSeq;
	}

	@Column(name = "ERX_DRUG_CTR_QTY")
	public int getDrugCtrQty() {
		return drugCtrQty;
	}

	public void setDrugCtrQty(int drugCtrQty) {
		this.drugCtrQty = drugCtrQty;
	}

	@Column(name = "ERX_FILL_QTY")
	public int getFillQty() {
		return fillQty;
	}

	public void setFillQty(int fillQty) {
		this.fillQty = fillQty;
	}

	@Column(name = "ERX_PAYEE_PHCY_ID")
	public int getPayeePhcyId() {
		return payeePhcyId;
	}

	public void setPayeePhcyId(int payeePhcyId) {
		this.payeePhcyId = payeePhcyId;
	}

	@Column(name = "ERX_MEDICARE_CDE")
	public String getMedicareCde() {
		return medicareCde;
	}

	public void setMedicareCde(String medicareCde) {
		this.medicareCde = medicareCde;
	}

	@Column(name = "ERX_PHCY_FILL_SEQ")
	public int getPhcyFillSeq() {
		return phcyFillSeq;
	}

	public void setPhcyFillSeq(int phcyFillSeq) {
		this.phcyFillSeq = phcyFillSeq;
	}

	@Column(name = "ERX_DELIV_FEE_AMT")
	public double getDelivFeeAmt() {
		return delivFeeAmt;
	}

	public void setDelivFeeAmt(double delivFeeAmt) {
		this.delivFeeAmt = delivFeeAmt;
	}

	@Column(name = "ERX_PAT_ADDR1_TXT")
	public String getPatAddr1Txt() {
		return patAddr1Txt;
	}

	public void setPatAddr1Txt(String patAddr1Txt) {
		this.patAddr1Txt = patAddr1Txt;
	}

	@Column(name = "ERX_PAT_ADDR2_TXT")
	public String getPatAddr2Txt() {
		return patAddr2Txt;
	}

	public void setPatAddr2Txt(String patAddr2Txt) {
		this.patAddr2Txt = patAddr2Txt;
	}

	@Column(name = "ERX_PAT_CITY_NME")
	public String getPatCityNme() {
		return patCityNme;
	}

	public void setPatCityNme(String patCityNme) {
		this.patCityNme = patCityNme;
	}

	@Column(name = "ERX_PAT_ST_CDE")
	public String getPatStCde() {
		return patStCde;
	}

	public void setPatStCde(String patStCde) {
		this.patStCde = patStCde;
	}

	@Column(name = "ERX_PAT_ZIP5_CDE")
	public int getPatZip5Cde() {
		return patZip5Cde;
	}

	public void setPatZip5Cde(int patZip5Cde) {
		this.patZip5Cde = patZip5Cde;
	}

	@Column(name = "ERX_PAT_ZIP4_CDE")
	public int getPatZip4Cde() {
		return patZip4Cde;
	}

	public void setPatZip4Cde(int patZip4Cde) {
		this.patZip4Cde = patZip4Cde;
	}

	@Column(name = "ERX_PAT_FIRST_NME")
	public String getPatFirstNme() {
		return patFirstNme;
	}

	public void setPatFirstNme(String patFirstNme) {
		this.patFirstNme = patFirstNme;
	}

	@Column(name = "ERX_PAT_LAST_NME")
	public String getPatLastNme() {
		return patLastNme;
	}

	public void setPatLastNme(String patLastNme) {
		this.patLastNme = patLastNme;
	}

	@Column(name = "ERX_PAT_MIDDLE_NME")
	public String getPatMiddleNme() {
		return patMiddleNme;
	}

	public void setPatMiddleNme(String patMiddleNme) {
		this.patMiddleNme = patMiddleNme;
	}

	@Column(name = "ERX_PAT_SEX_CDE")
	public String getPatSexCde() {
		return patSexCde;
	}

	public void setPatSexCde(String patSexCde) {
		this.patSexCde = patSexCde;
	}

	@Column(name = "ERX_PAT_DEPEND_NBR")
	public int getPatDependNbr() {
		return patDependNbr;
	}

	public void setPatDependNbr(int patDependNbr) {
		this.patDependNbr = patDependNbr;
	}

	@Column(name = "ERX_PAT_BIRTH_DTE")
	@Temporal(TemporalType.DATE)
	public Date getPatBirthDte() {
		return patBirthDte;
	}

	public void setPatBirthDte(Date patBirthDte) {
		this.patBirthDte = patBirthDte;
	}

	@Column(name = "ERX_DAILY_DOSE_QTY")
	public int getDailyDoseQty() {
		return dailyDoseQty;
	}

	public void setDailyDoseQty(int dailyDoseQty) {
		this.dailyDoseQty = dailyDoseQty;
	}

	@Column(name = "ERX_RX_ISSUED_DTE")
	@Temporal(TemporalType.DATE)
	public Date getRxIssuedDte() {
		return rxIssuedDte;
	}

	public void setRxIssuedDte(Date rxIssuedDte) {
		this.rxIssuedDte = rxIssuedDte;
	}

	@Column(name = "ERX_PAT_PAY_AMT")
	public double getPatPayAmt() {
		return patPayAmt;
	}

	public void setPatPayAmt(double patPayAmt) {
		this.patPayAmt = patPayAmt;
	}

	@Column(name = "ERX_SALES_TAX_AMT")
	public double getSalesTaxAmt() {
		return salesTaxAmt;
	}

	public void setSalesTaxAmt(double salesTaxAmt) {
		this.salesTaxAmt = salesTaxAmt;
	}

	@Column(name = "ERX_INSERT_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getInsertTms() {
		return insertTms;
	}

	public void setInsertTms(Date insertTms) {
		this.insertTms = insertTms;
	}

	@Column(name = "ERX_DR_FIRST_NME")
	public String getDrFirstNme() {
		return drFirstNme;
	}

	public void setDrFirstNme(String drFirstNme) {
		this.drFirstNme = drFirstNme;
	}

	@Column(name = "ERX_DR_LAST_NME")
	public String getDrLastNme() {
		return drLastNme;
	}

	public void setDrLastNme(String drLastNme) {
		this.drLastNme = drLastNme;
	}

	@Column(name = "ERX_DR_DEA_NBR")
	public String getDrDeaNbr() {
		return drDeaNbr;
	}

	public void setDrDeaNbr(String drDeaNbr) {
		this.drDeaNbr = drDeaNbr;
	}

	@Column(name = "ERX_DR_DEA_SFX_TXT")
	public String getDrDeaSfxTxt() {
		return drDeaSfxTxt;
	}

	public void setDrDeaSfxTxt(String drDeaSfxTxt) {
		this.drDeaSfxTxt = drDeaSfxTxt;
	}

	@Column(name = "ERX_DR_ADDR1_TXT")
	public String getDrAddr1Txt() {
		return drAddr1Txt;
	}

	public void setDrAddr1Txt(String drAddr1Txt) {
		this.drAddr1Txt = drAddr1Txt;
	}

	@Column(name = "ERX_DR_CITY_NME")
	public String getDrCityNme() {
		return drCityNme;
	}

	public void setDrCityNme(String drCityNme) {
		this.drCityNme = drCityNme;
	}

	@Column(name = "ERX_DR_ST_CDE")
	public String getDrStCde() {
		return drStCde;
	}

	public void setDrStCde(String drStCde) {
		this.drStCde = drStCde;
	}

	@Column(name = "ERX_DR_ZIP9_CDE")
	public int getDrZip9Cde() {
		return drZip9Cde;
	}

	public void setDrZip9Cde(int drZip9Cde) {
		this.drZip9Cde = drZip9Cde;
	}

	@Column(name = "ERX_ISSUE_DTE")
	@Temporal(TemporalType.DATE)
	public Date getIssueDte() {
		return issueDte;
	}

	public void setIssueDte(Date issueDte) {
		this.issueDte = issueDte;
	}

	@Column(name = "ERX_DOCTOR_DAW_CDE")
	public double getDoctorDawCde() {
		return doctorDawCde;
	}

	public void setDoctorDawCde(double doctorDawCde) {
		this.doctorDawCde = doctorDawCde;
	}

	@Column(name = "ERX_PAT_DAW_CDE")
	public double getPatDawCde() {
		return patDawCde;
	}

	public void setPatDawCde(double patDawCde) {
		this.patDawCde = patDawCde;
	}

	@Column(name = "ERX_PRIM_COVRG_CDE")
	public String getPrimCovrgCde() {
		return primCovrgCde;
	}

	public void setPrimCovrgCde(String primCovrgCde) {
		this.primCovrgCde = primCovrgCde;
	}

	@Column(name = "ERX_PHYS_NPI_NBR")
	public String getPhysNpiNbr() {
		return physNpiNbr;
	}

	public void setPhysNpiNbr(String physNpiNbr) {
		this.physNpiNbr = physNpiNbr;
	}

	@Column(name = "ERX_PHY_ST_LIC_NBR")
	public String getPhyStLicNbr() {
		return phyStLicNbr;
	}

	public void setPhyStLicNbr(String phyStLicNbr) {
		this.phyStLicNbr = phyStLicNbr;
	}

	@Column(name = "ERX_ST_RX_SER_NBR")
	public String getStRxSerNbr() {
		return stRxSerNbr;
	}

	public void setStRxSerNbr(String stRxSerNbr) {
		this.stRxSerNbr = stRxSerNbr;
	}
}