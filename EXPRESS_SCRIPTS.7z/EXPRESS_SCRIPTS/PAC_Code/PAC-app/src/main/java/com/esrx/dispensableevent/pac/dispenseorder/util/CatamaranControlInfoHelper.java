package com.esrx.dispensableevent.pac.dispenseorder.util;

public class CatamaranControlInfoHelper {

	private String fillNo;
	private String locaNo;
	private String group;
	private String subGroup;
	private String carrier;
	private String memberNumber;
	private String eligBnftGroup;
	private String clntContNo;
	private Integer dispPharm1;
	private Integer dispPharm2;
	private Integer dispPharm3;
	private Integer dispPharm4;
	private Integer dispPharm5;
	private String nonDispState01;
	private String nonDispState02;
	private String nonDispState03;
	private String nonDispState04;
	private String nonDispState05;
	private String nonDispState06;
	private String nonDispState07;
	private String nonDispState08;
	private String nonDispState09;
	private String nonDispState10;
	private Integer brandId;
	/**
	 * @return the fillNo
	 */
	public String getFillNo() {
		return fillNo;
	}
	/**
	 * @param fillNo the fillNo to set
	 */
	public void setFillNo(String fillNo) {
		this.fillNo = fillNo;
	}
	/**
	 * @return the locaNo
	 */
	public String getLocaNo() {
		return locaNo;
	}
	/**
	 * @param locaNo the locaNo to set
	 */
	public void setLocaNo(String locaNo) {
		this.locaNo = locaNo;
	}
	/**
	 * @return the group
	 */
	public String getGroup() {
		return group;
	}
	/**
	 * @param group the group to set
	 */
	public void setGroup(String group) {
		this.group = group;
	}
	/**
	 * @return the subGroup
	 */
	public String getSubGroup() {
		return subGroup;
	}
	/**
	 * @param subGroup the subGroup to set
	 */
	public void setSubGroup(String subGroup) {
		this.subGroup = subGroup;
	}
	/**
	 * @return the carrier
	 */
	public String getCarrier() {
		return carrier;
	}
	/**
	 * @param carrier the carrier to set
	 */
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	/**
	 * @return the memberNumber
	 */
	public String getMemberNumber() {
		return memberNumber;
	}
	/**
	 * @param memberNumber the memberNumber to set
	 */
	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}
	/**
	 * @return the eligBnftGroup
	 */
	public String getEligBnftGroup() {
		return eligBnftGroup;
	}
	/**
	 * @param eligBnftGroup the eligBnftGroup to set
	 */
	public void setEligBnftGroup(String eligBnftGroup) {
		this.eligBnftGroup = eligBnftGroup;
	}
	/**
	 * @return the clntContNo
	 */
	public String getClntContNo() {
		return clntContNo;
	}
	/**
	 * @param clntContNo the clntContNo to set
	 */
	public void setClntContNo(String clntContNo) {
		this.clntContNo = clntContNo;
	}
	/**
	 * @return the dispPharm1
	 */
	public Integer getDispPharm1() {
		return dispPharm1;
	}
	/**
	 * @param dispPharm1 the dispPharm1 to set
	 */
	public void setDispPharm1(Integer dispPharm1) {
		this.dispPharm1 = dispPharm1;
	}
	/**
	 * @return the dispPharm2
	 */
	public Integer getDispPharm2() {
		return dispPharm2;
	}
	/**
	 * @param dispPharm2 the dispPharm2 to set
	 */
	public void setDispPharm2(Integer dispPharm2) {
		this.dispPharm2 = dispPharm2;
	}
	/**
	 * @return the dispPharm3
	 */
	public Integer getDispPharm3() {
		return dispPharm3;
	}
	/**
	 * @param dispPharm3 the dispPharm3 to set
	 */
	public void setDispPharm3(Integer dispPharm3) {
		this.dispPharm3 = dispPharm3;
	}
	/**
	 * @return the dispPharm4
	 */
	public Integer getDispPharm4() {
		return dispPharm4;
	}
	/**
	 * @param dispPharm4 the dispPharm4 to set
	 */
	public void setDispPharm4(Integer dispPharm4) {
		this.dispPharm4 = dispPharm4;
	}
	/**
	 * @return the dispPharm5
	 */
	public Integer getDispPharm5() {
		return dispPharm5;
	}
	/**
	 * @param dispPharm5 the dispPharm5 to set
	 */
	public void setDispPharm5(Integer dispPharm5) {
		this.dispPharm5 = dispPharm5;
	}
	/**
	 * @return the nonDispState01
	 */
	public String getNonDispState01() {
		return nonDispState01;
	}
	/**
	 * @param nonDispState01 the nonDispState01 to set
	 */
	public void setNonDispState01(String nonDispState01) {
		this.nonDispState01 = nonDispState01;
	}
	/**
	 * @return the nonDispState02
	 */
	public String getNonDispState02() {
		return nonDispState02;
	}
	/**
	 * @param nonDispState02 the nonDispState02 to set
	 */
	public void setNonDispState02(String nonDispState02) {
		this.nonDispState02 = nonDispState02;
	}
	/**
	 * @return the nonDispState03
	 */
	public String getNonDispState03() {
		return nonDispState03;
	}
	/**
	 * @param nonDispState03 the nonDispState03 to set
	 */
	public void setNonDispState03(String nonDispState03) {
		this.nonDispState03 = nonDispState03;
	}
	/**
	 * @return the nonDispState04
	 */
	public String getNonDispState04() {
		return nonDispState04;
	}
	/**
	 * @param nonDispState04 the nonDispState04 to set
	 */
	public void setNonDispState04(String nonDispState04) {
		this.nonDispState04 = nonDispState04;
	}
	/**
	 * @return the nonDispState05
	 */
	public String getNonDispState05() {
		return nonDispState05;
	}
	/**
	 * @param nonDispState05 the nonDispState05 to set
	 */
	public void setNonDispState05(String nonDispState05) {
		this.nonDispState05 = nonDispState05;
	}
	/**
	 * @return the nonDispState06
	 */
	public String getNonDispState06() {
		return nonDispState06;
	}
	/**
	 * @param nonDispState06 the nonDispState06 to set
	 */
	public void setNonDispState06(String nonDispState06) {
		this.nonDispState06 = nonDispState06;
	}
	/**
	 * @return the nonDispState07
	 */
	public String getNonDispState07() {
		return nonDispState07;
	}
	/**
	 * @param nonDispState07 the nonDispState07 to set
	 */
	public void setNonDispState07(String nonDispState07) {
		this.nonDispState07 = nonDispState07;
	}
	/**
	 * @return the nonDispState08
	 */
	public String getNonDispState08() {
		return nonDispState08;
	}
	/**
	 * @param nonDispState08 the nonDispState08 to set
	 */
	public void setNonDispState08(String nonDispState08) {
		this.nonDispState08 = nonDispState08;
	}
	/**
	 * @return the nonDispState09
	 */
	public String getNonDispState09() {
		return nonDispState09;
	}
	/**
	 * @param nonDispState09 the nonDispState09 to set
	 */
	public void setNonDispState09(String nonDispState09) {
		this.nonDispState09 = nonDispState09;
	}
	/**
	 * @return the nonDispState10
	 */
	public String getNonDispState10() {
		return nonDispState10;
	}
	/**
	 * @param nonDispState10 the nonDispState10 to set
	 */
	public void setNonDispState10(String nonDispState10) {
		this.nonDispState10 = nonDispState10;
	}
	/**
	 * @return the brandId
	 */
	public Integer getBrandId() {
		return brandId;
	}
	/**
	 * @param brandId the brandId to set
	 */
	public void setBrandId(Integer brandId) {
		this.brandId = brandId;
	}
	
	
}
