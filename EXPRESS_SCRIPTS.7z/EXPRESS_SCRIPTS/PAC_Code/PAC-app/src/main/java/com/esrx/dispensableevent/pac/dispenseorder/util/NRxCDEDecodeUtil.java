package com.esrx.dispensableevent.pac.dispenseorder.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class NRxCDEDecodeUtil {

	private static final Logger log = LoggerFactory
	.getLogger(NRxCDEDecodeUtil.class);

	public static List<String> getNRxCDEDecode(String nrxCDEDecode) {
		
		List<String> nrxCDEDecodeList = null; 
		if(nrxCDEDecode != null) {
			try {
				nrxCDEDecodeList = new ArrayList<String>();
				nrxCDEDecodeList.add(nrxCDEDecode.substring(0, 8));
				nrxCDEDecodeList.add(nrxCDEDecode.substring(9, nrxCDEDecode.length()));

			} catch(StringIndexOutOfBoundsException exception) { 
				log.error("StringIndexOutOfBoundsException thrown for nrxCDEDecode : ", nrxCDEDecode);
				log.info("StringIndexOutOfBoundsException Ignored");
			}
		}
		return nrxCDEDecodeList;
	}

}
