package com.esrx.dispensableevent.pac.dispenseorder.dao;


public interface PacOrderDao {

	 
	 
	
//	void updateStatusInfoDdoStatus(StatusInfoDdo statusInfoDdo, RxDispenseOrderStatusCode statusType, RxDispenseOrderSubStatusCode subStatusType);

//	void addRxDispenseOrder(RxDispenseRequestDdo rxDispenseRequest) throws DataAccessException;
//	
//	RxDispenseRequestDdo retrievexDispenseOrder(RxDispenseRequestIdDdo rxDispenseRequestId);
//	
//	boolean duplicateCheckRequest(RxDispenseRequestIdDdo rxDispenseRequestId);
//	
//	void updateRxDispenseRequestStatus(RxDispenseRequestDdo rxDispenseRequest, RxDispenseOrderStatusCode statusType);

}
