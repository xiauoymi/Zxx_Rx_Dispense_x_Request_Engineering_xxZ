package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;

public class NDPManagedCareLetterMappingHelper {

	private int mclRecCount;
	private int mclLetterNo;
	private int mclRxNo;
	private boolean dummyLetterFlag;
	private String additionalVarText1;
	private String endOfMCPText;
	private String endOfMCPDelim;
	private String fstPosOfMCPtext;
	private String midOfMCPDelim;
	private List<NRxMclInfo> managedCareLetterList;
	
	/**
	 * @return the endOfMCPText
	 */
	public String getEndOfMCPText() {
		return endOfMCPText;
	}

	/**
	 * @param endOfMCPText the endOfMCPText to set
	 */
	public void setEndOfMCPText(String endOfMCPText) {
		this.endOfMCPText = endOfMCPText;
	}

	/**
	 * @return the endOfMCPDelim
	 */
	public String getEndOfMCPDelim() {
		return endOfMCPDelim;
	}

	/**
	 * @param endOfMCPDelim the endOfMCPDelim to set
	 */
	public void setEndOfMCPDelim(String endOfMCPDelim) {
		this.endOfMCPDelim = endOfMCPDelim;
	}

	/**
	 * @return the fstPosOfMCPtext
	 */
	public String getFstPosOfMCPtext() {
		return fstPosOfMCPtext;
	}

	/**
	 * @param fstPosOfMCPtext the fstPosOfMCPtext to set
	 */
	public void setFstPosOfMCPtext(String fstPosOfMCPtext) {
		this.fstPosOfMCPtext = fstPosOfMCPtext;
	}

	/**
	 * @return the midOfMCPDelim
	 */
	public String getMidOfMCPDelim() {
		return midOfMCPDelim;
	}

	/**
	 * @param midOfMCPDelim the midOfMCPDelim to set
	 */
	public void setMidOfMCPDelim(String midOfMCPDelim) {
		this.midOfMCPDelim = midOfMCPDelim;
	}

	/**
	 * @return the mclRecCount
	 */
	public int getMclRecCount() {
		return mclRecCount;
	}

	/**
	 * @param mclRecCount the mclRecCount to set
	 */
	public void setMclRecCount(int mclRecCount) {
		this.mclRecCount = mclRecCount;
	}

	/**
	 * @return the mclLetterNo
	 */
	public int getMclLetterNo() {
		return mclLetterNo;
	}

	/**
	 * @param mclLetterNo the mclLetterNo to set
	 */
	public void setMclLetterNo(int mclLetterNo) {
		this.mclLetterNo = mclLetterNo;
	}

	/**
	 * @return the dummyLetterFlag
	 */
	public boolean isDummyLetterFlag() {
		return dummyLetterFlag;
	}

	/**
	 * @param dummyLetterFlag the dummyLetterFlag to set
	 */
	public void setDummyLetterFlag(boolean dummyLetterFlag) {
		this.dummyLetterFlag = dummyLetterFlag;
	}

	/**
	 * @return the mclRxNo
	 */
	public int getMclRxNo() {
		return mclRxNo;
	}

	/**
	 * @param mclRxNo the mclRxNo to set
	 */
	public void setMclRxNo(int mclRxNo) {
		this.mclRxNo = mclRxNo;
	}

	/**
	 * @return the additionalVarText1
	 */
	public String getAdditionalVarText1() {
		return additionalVarText1;
	}

	/**
	 * @param additionalVarText1 the additionalVarText1 to set
	 */
	public void setAdditionalVarText1(String additionalVarText1) {
		this.additionalVarText1 = additionalVarText1;
	}

	/**
	 * @return the managedCareLetterList
	 */
	public List<NRxMclInfo> getManagedCareLetterList() {
		return managedCareLetterList;
	}

	/**
	 * @param managedCareLetterList the managedCareLetterList to set
	 */
	public void setManagedCareLetterList(List<NRxMclInfo> managedCareLetterList) {
		this.managedCareLetterList = managedCareLetterList;
	}

	
	
}
