package com.esrx.dispensableevent.pac.dispenseorder.dao;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfoId;

public interface NRxRxInfoDao {

	NRxRxInfo getNRxRxInfoRecord(NRxRxInfoId nrxRxInfoId);
	
	List<NRxRxInfo> getN004PrescriptionRecordList(NRxRxInfoId nrxRxInfoId); 
	
	boolean getCountForPackagePACData(NRxRxInfoId nrxRxInfoId);
	
	List<NRxRxInfo>  getN004RxRecordList(NRxRxInfoId nrxRxInfoId);
	
	void updateNDXNoMcLetters(Integer versionNum, NRxRxInfoId nrxRxInfoId);
	
	boolean getCountForNRxRxInfoViolation(NRxRxInfo nrxRxInfoDdo);
	
	void updateNDXSendTimeStamp(NRxRxInfo nrxRxInfoDdo);
}
