package com.esrx.dispensableevent.nrxupdate.domain;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Nrxexpeditedshipmentinfo
 */
@Entity
@Table(name = "NRXQSI00", uniqueConstraints = {})
public class NRxExpeditedShipmentInfo implements java.io.Serializable {

	private static final long serialVersionUID = -8715724344297920900L;

	private NRxExpeditedShipmentInfoId id;
	private Date nrxqsiKeypDate;
	private Date nrxqsiKeypTime;
	private String nrxqsiUserId;
	private Date nrxqsiQsoerDate;
	private Date nrxqsiQsoerTime;
	private Date nrxqsiPrintTs;
	private Date nrxqsiCheckDate;
	private Date nrxqsiCheckTime;
	private Date nrxqsiMailDate;
	private Date nrxqsiMailTime;
	private char nrxqsiShpMode;
	private char nrxqsiShpClass;
	private char nrxqsiShpChgInd;
	private char nrxqsiShpInsur;
	private BigDecimal nrxqsiShpCharge;
	private char nrxqsiCusChgInd;
	private char nrxqsiCusSigInd;
	private String nrxqsiClassSrvc;
	private String nrxqsiOptionCde;
	private String nrxqsiShpClsNew;
	private Date nrxqsiDelivryDte;
	private String nrxqsiDelivryTxt;

	/** default constructor */
	public NRxExpeditedShipmentInfo() {
	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "nrxqsiCustno", column = @Column(name = "NRXQSI_CUSTNO", unique = false, nullable = false, insertable = true, updatable = true, length = 18)),
			@AttributeOverride(name = "nrxqsiFillNo", column = @Column(name = "NRXQSI_FILL_NO", unique = false, nullable = false, insertable = true, updatable = true, precision = 5, scale = 0)),
			@AttributeOverride(name = "nrxqsiInvno", column = @Column(name = "NRXQSI_INVNO", unique = false, nullable = false, insertable = true, updatable = true, precision = 10, scale = 0)) })
	public NRxExpeditedShipmentInfoId getId() {
		return this.id;
	}

	public void setId(NRxExpeditedShipmentInfoId id) {
		this.id = id;
	}

	@Column(name = "NRXQSI_KEYP_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Date getNrxqsiKeypDate() {
		return this.nrxqsiKeypDate;
	}

	public void setNrxqsiKeypDate(Date nrxqsiKeypDate) {
		this.nrxqsiKeypDate = nrxqsiKeypDate;
	}

	@Column(name = "NRXQSI_KEYP_TIME", unique = false, nullable = false, insertable = true, updatable = true, length = 11)
	public Date getNrxqsiKeypTime() {
		return this.nrxqsiKeypTime;
	}

	public void setNrxqsiKeypTime(Date nrxqsiKeypTime) {
		this.nrxqsiKeypTime = nrxqsiKeypTime;
	}

	@Column(name = "NRXQSI_USER_ID", unique = false, nullable = false, insertable = true, updatable = true, length = 8)
	public String getNrxqsiUserId() {
		return this.nrxqsiUserId;
	}

	public void setNrxqsiUserId(String nrxqsiUserId) {
		this.nrxqsiUserId = nrxqsiUserId;
	}

	@Column(name = "NRXQSI_QSOER_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Date getNrxqsiQsoerDate() {
		return this.nrxqsiQsoerDate;
	}

	public void setNrxqsiQsoerDate(Date nrxqsiQsoerDate) {
		this.nrxqsiQsoerDate = nrxqsiQsoerDate;
	}

	@Column(name = "NRXQSI_QSOER_TIME", unique = false, nullable = false, insertable = true, updatable = true, length = 11)
	public Date getNrxqsiQsoerTime() {
		return this.nrxqsiQsoerTime;
	}

	public void setNrxqsiQsoerTime(Date nrxqsiQsoerTime) {
		this.nrxqsiQsoerTime = nrxqsiQsoerTime;
	}

	@Column(name = "NRXQSI_PRINT_TS", unique = false, nullable = false, insertable = true, updatable = true, length = 11)
	public Date getNrxqsiPrintTs() {
		return this.nrxqsiPrintTs;
	}

	public void setNrxqsiPrintTs(Date nrxqsiPrintTs) {
		this.nrxqsiPrintTs = nrxqsiPrintTs;
	}

	@Column(name = "NRXQSI_CHECK_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Date getNrxqsiCheckDate() {
		return this.nrxqsiCheckDate;
	}

	public void setNrxqsiCheckDate(Date nrxqsiCheckDate) {
		this.nrxqsiCheckDate = nrxqsiCheckDate;
	}

	@Column(name = "NRXQSI_CHECK_TIME", unique = false, nullable = false, insertable = true, updatable = true, length = 11)
	public Date getNrxqsiCheckTime() {
		return this.nrxqsiCheckTime;
	}

	public void setNrxqsiCheckTime(Date nrxqsiCheckTime) {
		this.nrxqsiCheckTime = nrxqsiCheckTime;
	}

	@Column(name = "NRXQSI_MAIL_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Date getNrxqsiMailDate() {
		return this.nrxqsiMailDate;
	}

	public void setNrxqsiMailDate(Date nrxqsiMailDate) {
		this.nrxqsiMailDate = nrxqsiMailDate;
	}

	@Column(name = "NRXQSI_MAIL_TIME", unique = false, nullable = false, insertable = true, updatable = true, length = 11)
	public Date getNrxqsiMailTime() {
		return this.nrxqsiMailTime;
	}

	public void setNrxqsiMailTime(Date nrxqsiMailTime) {
		this.nrxqsiMailTime = nrxqsiMailTime;
	}

	@Column(name = "NRXQSI_SHP_MODE", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public char getNrxqsiShpMode() {
		return this.nrxqsiShpMode;
	}

	public void setNrxqsiShpMode(char nrxqsiShpMode) {
		this.nrxqsiShpMode = nrxqsiShpMode;
	}

	@Column(name = "NRXQSI_SHP_CLASS", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public char getNrxqsiShpClass() {
		return this.nrxqsiShpClass;
	}

	public void setNrxqsiShpClass(char nrxqsiShpClass) {
		this.nrxqsiShpClass = nrxqsiShpClass;
	}

	@Column(name = "NRXQSI_SHP_CHG_IND", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public char getNrxqsiShpChgInd() {
		return this.nrxqsiShpChgInd;
	}

	public void setNrxqsiShpChgInd(char nrxqsiShpChgInd) {
		this.nrxqsiShpChgInd = nrxqsiShpChgInd;
	}

	@Column(name = "NRXQSI_SHP_INSUR", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public char getNrxqsiShpInsur() {
		return this.nrxqsiShpInsur;
	}

	public void setNrxqsiShpInsur(char nrxqsiShpInsur) {
		this.nrxqsiShpInsur = nrxqsiShpInsur;
	}

	@Column(name = "NRXQSI_SHP_CHARGE", unique = false, nullable = false, insertable = true, updatable = true, precision = 7)
	public BigDecimal getNrxqsiShpCharge() {
		return this.nrxqsiShpCharge;
	}

	public void setNrxqsiShpCharge(BigDecimal nrxqsiShpCharge) {
		this.nrxqsiShpCharge = nrxqsiShpCharge;
	}

	@Column(name = "NRXQSI_CUS_CHG_IND", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public char getNrxqsiCusChgInd() {
		return this.nrxqsiCusChgInd;
	}

	public void setNrxqsiCusChgInd(char nrxqsiCusChgInd) {
		this.nrxqsiCusChgInd = nrxqsiCusChgInd;
	}

	@Column(name = "NRXQSI_CUS_SIG_IND", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public char getNrxqsiCusSigInd() {
		return this.nrxqsiCusSigInd;
	}

	public void setNrxqsiCusSigInd(char nrxqsiCusSigInd) {
		this.nrxqsiCusSigInd = nrxqsiCusSigInd;
	}

	@Column(name = "NRXQSI_CLASS_SRVC", unique = false, nullable = false, insertable = true, updatable = true, length = 2)
	public String getNrxqsiClassSrvc() {
		return this.nrxqsiClassSrvc;
	}

	public void setNrxqsiClassSrvc(String nrxqsiClassSrvc) {
		this.nrxqsiClassSrvc = nrxqsiClassSrvc;
	}

	@Column(name = "NRXQSI_OPTION_CDE", unique = false, nullable = false, insertable = true, updatable = true, length = 10)
	public String getNrxqsiOptionCde() {
		return this.nrxqsiOptionCde;
	}

	public void setNrxqsiOptionCde(String nrxqsiOptionCde) {
		this.nrxqsiOptionCde = nrxqsiOptionCde;
	}

	@Column(name = "NRXQSI_SHP_CLS_NEW", unique = false, nullable = false, insertable = true, updatable = true, length = 2)
	public String getNrxqsiShpClsNew() {
		return this.nrxqsiShpClsNew;
	}

	public void setNrxqsiShpClsNew(String nrxqsiShpClsNew) {
		this.nrxqsiShpClsNew = nrxqsiShpClsNew;
	}

	@Column(name = "NRXQSI_DELIVRY_DTE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Date getNrxqsiDelivryDte() {
		return this.nrxqsiDelivryDte;
	}

	public void setNrxqsiDelivryDte(Date nrxqsiDelivryDte) {
		this.nrxqsiDelivryDte = nrxqsiDelivryDte;
	}

	@Column(name = "NRXQSI_DELIVRY_TXT", unique = false, nullable = false, insertable = true, updatable = true, length = 20)
	public String getNrxqsiDelivryTxt() {
		return this.nrxqsiDelivryTxt;
	}

	public void setNrxqsiDelivryTxt(String nrxqsiDelivryTxt) {
		this.nrxqsiDelivryTxt = nrxqsiDelivryTxt;
	}

}
