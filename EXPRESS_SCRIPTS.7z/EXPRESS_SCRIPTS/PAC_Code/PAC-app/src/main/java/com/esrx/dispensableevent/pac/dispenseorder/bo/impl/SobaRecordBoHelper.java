package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import generated.NDPSobaRecord;

import java.util.ArrayList;
import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxSobaInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPSobaRecordMapping;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPSobaRecordMappingHelper;

public class SobaRecordBoHelper {

	private NRxSobaInfoDao nrxSobaInfoDao;
	private NDPSobaRecordMapping ndpSobaRecordMapping;
	private SendN153BoHelper sendN153BoHelper;
	
	/**
	 * @return the nrxSobaInfoDao
	 */
	public NRxSobaInfoDao getNrxSobaInfoDao() {
		return nrxSobaInfoDao;
	}
	/**
	 * @param nrxSobaInfoDao the nrxSobaInfoDao to set
	 */
	public void setNrxSobaInfoDao(NRxSobaInfoDao nrxSobaInfoDao) {
		this.nrxSobaInfoDao = nrxSobaInfoDao;
	}


	/**
	 * @return the ndpSobaRecordMapping
	 */
	public NDPSobaRecordMapping getNdpSobaRecordMapping() {
		return ndpSobaRecordMapping;
	}


	/**
	 * @param ndpSobaRecordMapping the ndpSobaRecordMapping to set
	 */
	public void setNdpSobaRecordMapping(NDPSobaRecordMapping ndpSobaRecordMapping) {
		this.ndpSobaRecordMapping = ndpSobaRecordMapping;
	}


	/**
	 * @return the sendN153BoHelper
	 */
	public SendN153BoHelper getSendN153BoHelper() {
		return sendN153BoHelper;
	}
	/**
	 * @param sendN153BoHelper the sendN153BoHelper to set
	 */
	public void setSendN153BoHelper(SendN153BoHelper sendN153BoHelper) {
		this.sendN153BoHelper = sendN153BoHelper;
	}
	public NDPSobaRecordMappingHelper  packagePacSobaRecordData(NRxInvoice nrxInvoiceDdo, NDPSobaRecordMappingHelper ndpSobaRecordMappingHelper) {
		NRxSobaInfoId nrxSobaInfoId = null;
		List<NDPSobaRecord> ndpSobaRecordList = null;
//		NDPSobaRecordMappingHelper ndpSobaRecordMappingHelper = null; 
		
		if(nrxInvoiceDdo != null){
			nrxSobaInfoId = new NRxSobaInfoId();
			nrxSobaInfoId.setNdsFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
			nrxSobaInfoId.setNdsInvno(nrxInvoiceDdo.getId().getNdiInvno());
			nrxSobaInfoId.setNdsInvnoSub(nrxInvoiceDdo.getId().getNdiInvnoSub());

			List<NRxSobaInfo> sobaRecordList = nrxSobaInfoDao.getSOBARecordList(nrxSobaInfoId);
			if(sobaRecordList != null) {
				ndpSobaRecordList = new ArrayList<NDPSobaRecord>();
				for(NRxSobaInfo nrxSobaInfoDdo : sobaRecordList) {
					NDPSobaRecord ndpSobaRecordBdo = new NDPSobaRecord();
					ndpSobaRecordMapping.mapDatabaseToBusinessDomain(ndpSobaRecordBdo, nrxSobaInfoDdo);
					ndpSobaRecordList.add(ndpSobaRecordBdo);
				}
				ndpSobaRecordMappingHelper.setNdpSobaRecordList(ndpSobaRecordList);
				ndpSobaRecordMappingHelper.setNrxSobaRecordList(sobaRecordList);
			} else {
				// send N153    
				sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
			}
		}
		return ndpSobaRecordMappingHelper;
	}
}
