/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import java.math.BigDecimal;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * DoctorInfoDdo.
 */
@Entity
@Table(name="TBL_DOCTOR_INFO"
, uniqueConstraints = {  }
)

public class DoctorInfoDdo  implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

     /** The dr npi num. */
     private String drNpiNum;
     
     /** The dea num. */
     private String deaNum;
     
     /** The dr first name. */
     private String drFirstName;
     
     /** The dr last name. */
     private String drLastName;
     
     /** The dr middle initial. */
     private String drMiddleInitial;
     
     /** The dea suffix. */
     private String deaSuffix;
     
     /** The dr address name. */
     private String drAddressName;
     
     /** The dr street1. */
     private String drStreet1;
     
     /** The dr street2. */
     private String drStreet2;
     
     /** The dr city. */
     private String drCity;
     
     /** The dr state. */
     private String drState;
     
     /** The dr zipcode. */
     private String drZipcode;
     
     /** The dr phone num. */
     private Long drPhoneNum;
     
     /** The dr fax num. */
     private Long drFaxNum;
     
     /** The dr country. */
     private String drCountry;
     
     /** The dr degree. */
     private String drDegree;
     
     /** The dr fee. */
     private BigDecimal drFee;


    /**
     * default constructor.
     */
    public DoctorInfoDdo() {
    }

	/** The id. */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, precision = 30, scale = 0)),
			@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, length = 15)),
			@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, precision = 9, scale = 0)),
			@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, length = 1))})
	private RxDispenseRequestIdDdo id;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public RxDispenseRequestIdDdo getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(RxDispenseRequestIdDdo id) {
		this.id = id;
	}

    /**
     * Gets the dr npi num.
     *
     * @return the dr npi num
     */
    @Id
    @Column(name="DR_NPI_NUM", unique=true, nullable=false, insertable=true, updatable=true, length=10)

    public String getDrNpiNum() {
        return this.drNpiNum;
    }
    
    /**
     * Sets the dr npi num.
     *
     * @param drNpiNum the new dr npi num
     */
    public void setDrNpiNum(String drNpiNum) {
        this.drNpiNum = drNpiNum;
    }

	/** The rx dispense request. */
	private RxDispenseRequestDdo rxDispenseRequest;

	/**
	 * Gets the rx dispense request.
	 *
	 * @return the rx dispense request
	 */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumns({
			@JoinColumn(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "TRANS_ID"),
			@JoinColumn(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "CLIENT_ID"),
			@JoinColumn(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "ORDER_NUM"),
			@JoinColumn(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "SUBORDER_IND")})
	public RxDispenseRequestDdo getRxDispenseRequest() {
		return this.rxDispenseRequest;
	}

	/**
	 * Sets the rx dispense request.
	 *
	 * @param rxDispenseRequest the new rx dispense request
	 */
	public void setRxDispenseRequest(RxDispenseRequestDdo rxDispenseRequest) {
		this.rxDispenseRequest = rxDispenseRequest;
	}

        
    /**
     * Gets the dea num.
     *
     * @return the dea num
     */
    @Column(name="DEA_NUM", unique=false, nullable=true, insertable=true, updatable=true, length=16)
    public String getDeaNum() {
        return this.deaNum;
    }
    
    /**
     * Sets the dea num.
     *
     * @param deaNum the new dea num
     */
    public void setDeaNum(String deaNum) {
        this.deaNum = deaNum;
    }
    
    /**
     * Gets the dr first name.
     *
     * @return the dr first name
     */
    @Column(name="DR_FIRST_NAME", unique=false, nullable=true, insertable=true, updatable=true, length=20)

    public String getDrFirstName() {
        return this.drFirstName;
    }
    
    /**
     * Sets the dr first name.
     *
     * @param drFirstName the new dr first name
     */
    public void setDrFirstName(String drFirstName) {
        this.drFirstName = drFirstName;
    }
    
    /**
     * Gets the dr last name.
     *
     * @return the dr last name
     */
    @Column(name="DR_LAST_NAME", unique=false, nullable=true, insertable=true, updatable=true, length=20)

    public String getDrLastName() {
        return this.drLastName;
    }
    
    /**
     * Sets the dr last name.
     *
     * @param drLastName the new dr last name
     */
    public void setDrLastName(String drLastName) {
        this.drLastName = drLastName;
    }
    
    /**
     * Gets the dr middle initial.
     *
     * @return the dr middle initial
     */
    @Column(name="DR_MIDDLE_INITIAL", unique=false, nullable=true, insertable=true, updatable=true, length=5)

    public String getDrMiddleInitial() {
        return this.drMiddleInitial;
    }
    
    /**
     * Sets the dr middle initial.
     *
     * @param drMiddleInitial the new dr middle initial
     */
    public void setDrMiddleInitial(String drMiddleInitial) {
        this.drMiddleInitial = drMiddleInitial;
    }
    
    /**
     * Gets the dea suffix.
     *
     * @return the dea suffix
     */
    @Column(name="DEA_SUFFIX", unique=false, nullable=true, insertable=true, updatable=true, length=5)

    public String getDeaSuffix() {
        return this.deaSuffix;
    }
    
    /**
     * Sets the dea suffix.
     *
     * @param deaSuffix the new dea suffix
     */
    public void setDeaSuffix(String deaSuffix) {
        this.deaSuffix = deaSuffix;
    }
    
    /**
     * Gets the dr address name.
     *
     * @return the dr address name
     */
    @Column(name="DR_ADDRESS_NAME", unique=false, nullable=true, insertable=true, updatable=true, length=40)

    public String getDrAddressName() {
        return this.drAddressName;
    }
    
    /**
     * Sets the dr address name.
     *
     * @param drAddressName the new dr address name
     */
    public void setDrAddressName(String drAddressName) {
        this.drAddressName = drAddressName;
    }
    
    /**
     * Gets the dr street1.
     *
     * @return the dr street1
     */
    @Column(name="DR_STREET1", unique=false, nullable=true, insertable=true, updatable=true, length=20)

    public String getDrStreet1() {
        return this.drStreet1;
    }
    
    /**
     * Sets the dr street1.
     *
     * @param drStreet1 the new dr street1
     */
    public void setDrStreet1(String drStreet1) {
        this.drStreet1 = drStreet1;
    }
    
    /**
     * Gets the dr street2.
     *
     * @return the dr street2
     */
    @Column(name="DR_STREET2", unique=false, nullable=true, insertable=true, updatable=true, length=20)

    public String getDrStreet2() {
        return this.drStreet2;
    }
    
    /**
     * Sets the dr street2.
     *
     * @param drStreet2 the new dr street2
     */
    public void setDrStreet2(String drStreet2) {
        this.drStreet2 = drStreet2;
    }
    
    /**
     * Gets the dr city.
     *
     * @return the dr city
     */
    @Column(name="DR_CITY", unique=false, nullable=true, insertable=true, updatable=true, length=20)

    public String getDrCity() {
        return this.drCity;
    }
    
    /**
     * Sets the dr city.
     *
     * @param drCity the new dr city
     */
    public void setDrCity(String drCity) {
        this.drCity = drCity;
    }
    
    /**
     * Gets the dr state.
     *
     * @return the dr state
     */
    @Column(name="DR_STATE", unique=false, nullable=true, insertable=true, updatable=true, length=2)

    public String getDrState() {
        return this.drState;
    }
    
    /**
     * Sets the dr state.
     *
     * @param drState the new dr state
     */
    public void setDrState(String drState) {
        this.drState = drState;
    }
    
    /**
     * Gets the dr zipcode.
     *
     * @return the dr zipcode
     */
    @Column(name="DR_ZIPCODE", unique=false, nullable=true, insertable=true, updatable=true, length=10)

    public String getDrZipcode() {
        return this.drZipcode;
    }
    
    /**
     * Sets the dr zipcode.
     *
     * @param drZipcode the new dr zipcode
     */
    public void setDrZipcode(String drZipcode) {
        this.drZipcode = drZipcode;
    }
    
    /**
     * Gets the dr phone num.
     *
     * @return the dr phone num
     */
    @Column(name="DR_PHONE_NUM", unique=false, nullable=true, insertable=true, updatable=true, precision=10, scale=0)

    public Long getDrPhoneNum() {
        return this.drPhoneNum;
    }
    
    /**
     * Sets the dr phone num.
     *
     * @param drPhoneNum the new dr phone num
     */
    public void setDrPhoneNum(Long drPhoneNum) {
        this.drPhoneNum = drPhoneNum;
    }
    
    /**
     * Gets the dr fax num.
     *
     * @return the dr fax num
     */
    @Column(name="DR_FAX_NUM", unique=false, nullable=true, insertable=true, updatable=true, precision=10, scale=0)

    public Long getDrFaxNum() {
        return this.drFaxNum;
    }
    
    /**
     * Sets the dr fax num.
     *
     * @param drFaxNum the new dr fax num
     */
    public void setDrFaxNum(Long drFaxNum) {
        this.drFaxNum = drFaxNum;
    }
    
    /**
     * Gets the dr country.
     *
     * @return the dr country
     */
    @Column(name="DR_COUNTRY", unique=false, nullable=true, insertable=true, updatable=true, length=40)

    public String getDrCountry() {
        return this.drCountry;
    }
    
    /**
     * Sets the dr country.
     *
     * @param drCountry the new dr country
     */
    public void setDrCountry(String drCountry) {
        this.drCountry = drCountry;
    }
    
    /**
     * Gets the dr degree.
     *
     * @return the dr degree
     */
    @Column(name="DR_DEGREE", unique=false, nullable=true, insertable=true, updatable=true, length=10)

    public String getDrDegree() {
        return this.drDegree;
    }
    
    /**
     * Sets the dr degree.
     *
     * @param drDegree the new dr degree
     */
    public void setDrDegree(String drDegree) {
        this.drDegree = drDegree;
    }
    
    /**
     * Gets the dr fee.
     *
     * @return the dr fee
     */
    @Column(name="DR_FEE", unique=false, nullable=true, insertable=true, updatable=true, precision=7)

    public BigDecimal getDrFee() {
        return this.drFee;
    }
    
    /**
     * Sets the dr fee.
     *
     * @param drFee the new dr fee
     */
    public void setDrFee(BigDecimal drFee) {
        this.drFee = drFee;
    }
   








}
