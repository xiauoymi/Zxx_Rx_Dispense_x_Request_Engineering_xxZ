/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import java.math.BigDecimal;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * ShippingAddressInfoDdo.
 */
@Entity
@Table(name = "TBL_SHIPPING_ADDRESS_INFO")
public class ShippingAddressInfoDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

    /** The shipping identifier. */
    private String shippingIdentifier;
	
	/** The first name. */
	private String firstName;
	
	/** The last name. */
	private String lastName;
	
	/** The street1. */
	private String street1;
	
	/** The street2. */
	private String street2;
	
	/** The city. */
	private String city;
	
	/** The state. */
	private String state;
	
	/** The zip5. */
	private Integer zip5;
	
	/** The zip4. */
	private short zip4;
	
	/** The phone number day. */
	private long phoneNumberDay;
	
	/** The phne number night. */
	private long phneNumberNight;
	
	/** The country. */
	private String country;
	
	/** The ship method. */
	private String shipMethod;
	
	/** The shipping carrier. */
	private String shippingCarrier;
	
	/** The cod. */
	private String cod;
	
	/** The cost. */
	private BigDecimal cost;
	
	/** The address by pass ind. */
	private String addressByPassInd;
	
	/**
	 * default constructor.
	 */
	public ShippingAddressInfoDdo() {
	}

	/** The id. */
	@EmbeddedId
	@AttributeOverrides({
		@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, precision = 30, scale = 0)),
		@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, length = 15)),
		@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, precision = 9, scale = 0)),
		@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, length = 1))})
	private RxDispenseRequestIdDdo id;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public RxDispenseRequestIdDdo getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(RxDispenseRequestIdDdo id) {
		this.id = id;
	}

	/** The rx dispense request. */
	private RxDispenseRequestDdo rxDispenseRequest;

	/**
	 * Gets the rx dispense request.
	 *
	 * @return the rx dispense request
	 */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumns({
		@JoinColumn(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="TRANS_ID"),
		@JoinColumn(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="CLIENT_ID"),
		@JoinColumn(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="ORDER_NUM"),
		@JoinColumn(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="SUBORDER_IND")})
	public RxDispenseRequestDdo getRxDispenseRequest() {
		return this.rxDispenseRequest;
	}

	/**
	 * Sets the rx dispense request.
	 *
	 * @param rxDispenseRequest the new rx dispense request
	 */
	public void setRxDispenseRequest(RxDispenseRequestDdo rxDispenseRequest) {
		this.rxDispenseRequest = rxDispenseRequest;
	}

    /**
     * Gets the shipping identifier.
     *
     * @return the shipping identifier
     */
    @Id
    @Column(name="SHIPPING_IDENTIFIER", unique=true, nullable=false, insertable=true, updatable=true, length=20)
    public String getShippingIdentifier() {
        return this.shippingIdentifier;
    }
    
    /**
     * Sets the shipping identifier.
     *
     * @param shippingIdentifier the new shipping identifier
     */
    public void setShippingIdentifier(String shippingIdentifier) {
        this.shippingIdentifier = shippingIdentifier;
    }

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	@Column(name = "FIRST_NAME", unique = false, nullable = false, insertable = true, updatable = true, length = 20)
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	@Column(name = "LAST_NAME", unique = false, nullable = false, insertable = true, updatable = true, length = 20)
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the street1.
	 *
	 * @return the street1
	 */
	@Column(name = "STREET1", unique = false, nullable = false, insertable = true, updatable = true, length = 25)
	public String getStreet1() {
		return this.street1;
	}

	/**
	 * Sets the street1.
	 *
	 * @param street1 the new street1
	 */
	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	/**
	 * Gets the street2.
	 *
	 * @return the street2
	 */
	@Column(name = "STREET2", unique = false, nullable = false, insertable = true, updatable = true, length = 25)
	public String getStreet2() {
		return this.street2;
	}

	/**
	 * Sets the street2.
	 *
	 * @param street2 the new street2
	 */
	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	/**
	 * Gets the city.
	 *
	 * @return the city
	 */
	@Column(name = "CITY", unique = false, nullable = false, insertable = true, updatable = true, length = 25)
	public String getCity() {
		return this.city;
	}

	/**
	 * Sets the city.
	 *
	 * @param city the new city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Gets the state.
	 *
	 * @return the state
	 */
	@Column(name = "STATE", unique = false, nullable = false, insertable = true, updatable = true, length = 2)
	public String getState() {
		return this.state;
	}

	/**
	 * Sets the state.
	 *
	 * @param state the new state
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Gets the zip5.
	 *
	 * @return the zip5
	 */
	@Column(name = "ZIP5", unique = false, nullable = false, insertable = true, updatable = true, precision = 5, scale = 0)
	public Integer getZip5() {
		return this.zip5;
	}

	/**
	 * Sets the zip5.
	 *
	 * @param zip5 the new zip5
	 */
	public void setZip5(Integer zip5) {
		this.zip5 = zip5;
	}

	/**
	 * Gets the zip4.
	 *
	 * @return the zip4
	 */
	@Column(name = "ZIP4", unique = false, nullable = false, insertable = true, updatable = true, precision = 4, scale = 0)
	public short getZip4() {
		return this.zip4;
	}

	/**
	 * Sets the zip4.
	 *
	 * @param zip4 the new zip4
	 */
	public void setZip4(short zip4) {
		this.zip4 = zip4;
	}

	/**
	 * Gets the phone number day.
	 *
	 * @return the phone number day
	 */
	@Column(name = "PHONE_NUMBER_DAY", unique = false, nullable = false, insertable = true, updatable = true, precision = 10, scale = 0)
	public long getPhoneNumberDay() {
		return this.phoneNumberDay;
	}

	/**
	 * Sets the phone number day.
	 *
	 * @param phoneNumberDay the new phone number day
	 */
	public void setPhoneNumberDay(long phoneNumberDay) {
		this.phoneNumberDay = phoneNumberDay;
	}

	/**
	 * Gets the phne number night.
	 *
	 * @return the phne number night
	 */
	@Column(name = "PHONE_NUMBER_NIGHT", unique = false, nullable = false, insertable = true, updatable = true, precision = 10, scale = 0)
	public long getPhneNumberNight() {
		return this.phneNumberNight;
	}

	/**
	 * Sets the phne number night.
	 *
	 * @param phneNumberNight the new phne number night
	 */
	public void setPhneNumberNight(long phneNumberNight) {
		this.phneNumberNight = phneNumberNight;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	@Column(name = "COUNTRY", unique = false, nullable = false, insertable = true, updatable = true, length = 40)
	public String getCountry() {
		return this.country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country the new country
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Gets the ship method.
	 *
	 * @return the ship method
	 */
	@Column(name = "SHIP_METHOD", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getShipMethod() {
		return this.shipMethod;
	}

	/**
	 * Sets the ship method.
	 *
	 * @param shipMethod the new ship method
	 */
	public void setShipMethod(String shipMethod) {
		this.shipMethod = shipMethod;
	}

	/**
	 * Gets the shipping carrier.
	 *
	 * @return the shipping carrier
	 */
	@Column(name = "SHIPPING_CARRIER", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getShippingCarrier() {
		return this.shippingCarrier;
	}

	/**
	 * Sets the shipping carrier.
	 *
	 * @param shippingCarrier the new shipping carrier
	 */
	public void setShippingCarrier(String shippingCarrier) {
		this.shippingCarrier = shippingCarrier;
	}

	/**
	 * Gets the cod.
	 *
	 * @return the cod
	 */
	@Column(name = "COD", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getCod() {
		return this.cod;
	}

	/**
	 * Sets the cod.
	 *
	 * @param cod the new cod
	 */
	public void setCod(String cod) {
		this.cod = cod;
	}

	/**
	 * Gets the cost.
	 *
	 * @return the cost
	 */
	@Column(name = "COST", unique = false, nullable = true, insertable = true, updatable = true, precision = 7)
	public BigDecimal getCost() {
		return this.cost;
	}

	/**
	 * Sets the cost.
	 *
	 * @param cost the new cost
	 */
	public void setCost(BigDecimal cost) {
		this.cost = cost;
	}

	/**
	 * Gets the address by pass ind.
	 *
	 * @return the address by pass ind
	 */
	@Column(name = "ADDRESS_BY_PASS_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getAddressByPassInd() {
		return this.addressByPassInd;
	}

	/**
	 * Sets the address by pass ind.
	 *
	 * @param addressByPassInd the new address by pass ind
	 */
	public void setAddressByPassInd(String addressByPassInd) {
		this.addressByPassInd = addressByPassInd;
	}

}
