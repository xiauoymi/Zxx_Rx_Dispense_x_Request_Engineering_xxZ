package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NRxInvoiceId implements Serializable{

	private static final long serialVersionUID = 5422853729188082460L;
	private Integer ndiFillNo; 
	private Integer ndiInvno;
	private String ndiInvnoSub;

	// Default Constructor
	public NRxInvoiceId() {
		
	}

	@Column(name = "NDI_FILL_NO")
	public Integer getNdiFillNo() {
		return ndiFillNo;
	}


	public void setNdiFillNo(Integer ndiFillNo) {
		this.ndiFillNo = ndiFillNo;
	}

	@Column(name = "NDI_INVNO")
	public Integer getNdiInvno() {
		return ndiInvno;
	}

	public void setNdiInvno(Integer ndiInvno) {
		this.ndiInvno = ndiInvno;
	}

	@Column(name = "NDI_INVNO_SUB")
	public String getNdiInvnoSub() {
		return ndiInvnoSub;
	}

	public void setNdiInvnoSub(String ndiInvnoSub) {
		this.ndiInvnoSub = ndiInvnoSub;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ndiFillNo == null) ? 0 : ndiFillNo.hashCode());
		result = prime * result
				+ ((ndiInvno == null) ? 0 : ndiInvno.hashCode());
		result = prime * result
				+ ((ndiInvnoSub == null) ? 0 : ndiInvnoSub.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NRxInvoiceId other = (NRxInvoiceId) obj;
		if (ndiFillNo == null) {
			if (other.ndiFillNo != null)
				return false;
		} else if (!ndiFillNo.equals(other.ndiFillNo))
			return false;
		if (ndiInvno == null) {
			if (other.ndiInvno != null)
				return false;
		} else if (!ndiInvno.equals(other.ndiInvno))
			return false;
		if (ndiInvnoSub == null) {
			if (other.ndiInvnoSub != null)
				return false;
		} else if (!ndiInvnoSub.equals(other.ndiInvnoSub))
			return false;
		return true;
	}
}