package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderStatusCode;
import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderSubStatusCode;
import com.esrx.dispensableevent.pac.dispenseorder.dao.StatusInfoPacDao;
import com.esrx.dispensableevent.rxdispense.domain.StatusInfoDdo;

public class WorkTableOrderBoHelper {

	private static final Logger log = LoggerFactory
	.getLogger(WorkTableOrderBoHelper.class);

	private StatusInfoPacDao statusInfoPacDao;
	private SendN153BoHelper sendN153BoHelper;

	
	/**
	 * @return the sendN153BoHelper
	 */
	public SendN153BoHelper getSendN153BoHelper() {
		return sendN153BoHelper;
	}
	/**
	 * @param sendN153BoHelper the sendN153BoHelper to set
	 */
	public void setSendN153BoHelper(SendN153BoHelper sendN153BoHelper) {
		this.sendN153BoHelper = sendN153BoHelper;
	}
	/**
	 * @return the statusInfoPacDao
	 */
	public StatusInfoPacDao getStatusInfoPacDao() {
		return statusInfoPacDao;
	}
	/**
	 * @param statusInfoPacDao
	 *            the statusInfoPacDao to set
	 */
	public void setStatusInfoPacDao(StatusInfoPacDao statusInfoPacDao) {
		this.statusInfoPacDao = statusInfoPacDao;
	}

	public List<StatusInfoDdo> getWorkTableORADBOrder(RxDispenseOrderStatusCode statusCode,
			RxDispenseOrderSubStatusCode subStatusCode) {
		List<StatusInfoDdo> statusInfoDdoList = null;
		
		try {
				statusInfoDdoList = statusInfoPacDao.getStatusInfoDdoList(statusCode, subStatusCode);
		} catch (DataAccessException exception) {
			log.error("While processing getWorkTableORADBOrder DataAccessException thrown : ");
			log.info("DataAccessException Root Cause :", exception.getRootCause());
			//send N153 on data access error
//			sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
			// no need to send the N153......but oracle status info table nneds to be updated ..that's all
		}
		return statusInfoDdoList;
	}
}
