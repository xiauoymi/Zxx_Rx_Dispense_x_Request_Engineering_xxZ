package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NRxInvoiceControlId implements Serializable {

	private static final long serialVersionUID = 439143668593817018L;
	private String nrxcdeTableNo;
	private String nrxcdeCodeVlu;
	
	// Default Constructor
	public NRxInvoiceControlId() {
		
	}

	@Column(name = "NRXCDE_TABLE_NO")
	public String getNrxcdeTableNo() {
		return nrxcdeTableNo;
	}

	public void setNrxcdeTableNo(String nrxcdeTableNo) {
		this.nrxcdeTableNo = nrxcdeTableNo;
	}

	@Column(name = "NRXCDE_CODE_VLU")
	public String getNrxcdeCodeVlu() {
		return nrxcdeCodeVlu;
	}

	public void setNrxcdeCodeVlu(String nrxcdeCodeVlu) {
		this.nrxcdeCodeVlu = nrxcdeCodeVlu;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((nrxcdeCodeVlu == null) ? 0 : nrxcdeCodeVlu.hashCode());
		result = prime * result
				+ ((nrxcdeTableNo == null) ? 0 : nrxcdeTableNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NRxInvoiceControlId other = (NRxInvoiceControlId) obj;
		if (nrxcdeCodeVlu == null) {
			if (other.nrxcdeCodeVlu != null)
				return false;
		} else if (!nrxcdeCodeVlu.equals(other.nrxcdeCodeVlu))
			return false;
		if (nrxcdeTableNo == null) {
			if (other.nrxcdeTableNo != null)
				return false;
		} else if (!nrxcdeTableNo.equals(other.nrxcdeTableNo))
			return false;
		return true;
	}	
}