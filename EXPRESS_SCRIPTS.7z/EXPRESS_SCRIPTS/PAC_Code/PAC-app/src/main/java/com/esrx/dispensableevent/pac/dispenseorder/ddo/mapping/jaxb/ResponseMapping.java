package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.NDPRxRecord;

import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;

public class ResponseMapping {

	public void mapDatabaseToBusinessDomain(NDPRxRecord ndpRxRecordBdo, NRxRxInfo nrxRxInfoDdo) {
		
	}
}
