/**
 * Author : Guru Krishnan
 */
package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="NCUNDS00", uniqueConstraints = {})
public class NRxSobaInfo implements Serializable{
	
	private static final long serialVersionUID = -1343717707977411095L;
	private NRxSobaInfoId id;
	private String status;
	private String messCodeNo;
	private String replFlag;
	private String messParm1;
	private String messParm2;
	private Date tmpstp;
	private Date sendTms;
	
	// Default Constructor
	public NRxSobaInfo() {
		
	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "ndsFillNO", column = @Column(name = "NDS_FILL_NO")),
			@AttributeOverride(name = "ndsInvno", column = @Column(name = "NDS_INVNO")),
			@AttributeOverride(name = "ndsInvnoSub", column = @Column(name = "NDS_INVNO_SUB")),
			@AttributeOverride(name = "ndsLocaNo", column = @Column(name = "NDS_LOCA_NO")),
			@AttributeOverride(name = "ndsRxno", column = @Column(name = "NDS_RXNO")),
			@AttributeOverride(name = "ndsSeqNo", column = @Column(name = "NDS_SEQ_NO"))
	})
	public NRxSobaInfoId getId() {
		return id;
	}

	public void setId(NRxSobaInfoId id) {
		this.id = id;
	}

	@Column(name="NDS_STATUS")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name="NDS_MESS_CODE_NO")
	public String getMessCodeNo() {
		return messCodeNo;
	}

	public void setMessCodeNo(String messCodeNo) {
		this.messCodeNo = messCodeNo;
	}

	@Column(name="NDS_REPL_FLAG")
	public String getReplFlag() {
		return replFlag;
	}

	public void setReplFlag(String replFlag) {
		this.replFlag = replFlag;
	}

	@Column(name="NDS_MESS_PARM_1")
	public String getMessParm1() {
		return messParm1;
	}

	public void setMessParm1(String messParm1) {
		this.messParm1 = messParm1;
	}

	@Column(name="NDS_MESS_PARM_2")
	public String getMessParm2() {
		return messParm2;
	}

	public void setMessParm2(String messParm2) {
		this.messParm2 = messParm2;
	}

	@Column(name="NDS_TMPSTP")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getTmpstp() {
		return tmpstp;
	}

	public void setTmpstp(Date tmpstp) {
		this.tmpstp = tmpstp;
	}

	@Column(name="NDS_SEND_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getSendTms() {
		return sendTms;
	}

	public void setSendTms(Date sendTms) {
		this.sendTms = sendTms;
	}
}