package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_TRUE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.MCL_RX_NO;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NDP_MANAGED_CARE_PARAMETER_ENDDELIM;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NRX_CDE_CODE_VLU;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NRX_INVOICE_CONTROL_NMC;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ONE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.PAC_ALLOWED_RX_MAX_LIMIT;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import static com.esrx.dispensableevent.pac.dispenseorder.util.NRxCDEDecodeUtil.getNRxCDEDecode;
import generated.NDPManagedCareLetter;
import generated.NDPManagedCareLetterList;
import generated.NDPManagedCareParameter;
import generated.NDPManagedCareParameterList;
import generated.OrderRecord;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceControl;
import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfoId;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceControlDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxMclInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPManagedCareLetterMapping;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPManagedCareLetterMappingHelper;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPManagedCareParameterMapping;
import com.esrx.dispensableevent.pac.dispenseorder.util.NRxCDEDecodeUtil;

public class ManagedCareBoHelper {

	private static final Logger log = LoggerFactory
	.getLogger(ManagedCareBoHelper.class);

	private NRxMclInfoDao nrxMclInfoDao;
	private NRxInvoiceControlDao nrxInvoiceControlDao;
	
//	private NDPManagedCareLetterMappingHelper  ndpManagedCareLetterMappingHelper;
	private NRxMclInfo nrxMclInfoDdo;
	private NRxInvoiceControl nrxInvoiceControlDdo;
	
	private NDPManagedCareLetterMapping ndpManagedCareLetterMapping;
	private NDPManagedCareParameterMapping ndpManagedCareParameterMapping;
	
	
	/**
	 * @return the ndpManagedCareLetterMapping
	 */
	public NDPManagedCareLetterMapping getNdpManagedCareLetterMapping() {
		return ndpManagedCareLetterMapping;
	}


	/**
	 * @param ndpManagedCareLetterMapping the ndpManagedCareLetterMapping to set
	 */
	public void setNdpManagedCareLetterMapping(
			NDPManagedCareLetterMapping ndpManagedCareLetterMapping) {
		this.ndpManagedCareLetterMapping = ndpManagedCareLetterMapping;
	}


	/**
	 * @return the ndpManagedCareParameterMapping
	 */
	public NDPManagedCareParameterMapping getNdpManagedCareParameterMapping() {
		return ndpManagedCareParameterMapping;
	}


	/**
	 * @param ndpManagedCareParameterMapping the ndpManagedCareParameterMapping to set
	 */
	public void setNdpManagedCareParameterMapping(
			NDPManagedCareParameterMapping ndpManagedCareParameterMapping) {
		this.ndpManagedCareParameterMapping = ndpManagedCareParameterMapping;
	}


	/**
	 * @return the nrxMclInfoDao
	 */
	public NRxMclInfoDao getNrxMclInfoDao() {
		return nrxMclInfoDao;
	}


	/**
	 * @param nrxMclInfoDao the nrxMclInfoDao to set
	 */
	public void setNrxMclInfoDao(NRxMclInfoDao nrxMclInfoDao) {
		this.nrxMclInfoDao = nrxMclInfoDao;
	}

	/**
	 * @return the nrxInvoiceControlDao
	 */
	public NRxInvoiceControlDao getNrxInvoiceControlDao() {
		return nrxInvoiceControlDao;
	}


	/**
	 * @param nrxInvoiceControlDao the nrxInvoiceControlDao to set
	 */
	public void setNrxInvoiceControlDao(NRxInvoiceControlDao nrxInvoiceControlDao) {
		this.nrxInvoiceControlDao = nrxInvoiceControlDao;
	}


	public void packagePacManagedCareData(NRxRxInfo nrxRxInfoDdo, OrderRecord orderRecordBdo, NDPManagedCareLetterMappingHelper  ndpManagedCareLetterMappingHelper) {
		
		NDPManagedCareLetter ndpManagedCareLetterBdo = null;
		NDPManagedCareParameter ndpManagedCareParameterBdo = null;
		if(nrxRxInfoDdo !=  null) {
			NRxRxInfoId nrxRxInfoId = nrxRxInfoDdo.getId();
			NRxMclInfoId nrxMclInfoId = new NRxMclInfoId();
			nrxMclInfoId.setNdmFillNo(nrxRxInfoId.getNdxFillNo());
			nrxMclInfoId.setNdmInvno(nrxRxInfoId.getNdxInvno());
			nrxMclInfoId.setNdmInvnoSub(nrxRxInfoId.getNdxInvnoSub());
//			nrxMclInfoId.setNdmLetterNo(nrxRxInfoId.get);
			nrxMclInfoId.setNdmLocaNo(nrxRxInfoId.getNdxLocaNo());
			nrxMclInfoId.setNdmRxno(nrxRxInfoId.getNdxRxno());
//			nrxMclInfoId.setNdmSeqNo(nrxRxInfoId);

			List<NRxMclInfo> managedCareLetterList =  nrxMclInfoDao.getManagedCareLetterOrderByLetterNum(nrxMclInfoId);
			if(managedCareLetterList != null) {
				ndpManagedCareLetterMappingHelper.setMclRecCount(managedCareLetterList.size());
				List<NRxInvoiceControl> nrxInvoiceControlList = nrxInvoiceControlDao.getNRxInvoiceControlListByNMC(NRX_INVOICE_CONTROL_NMC);

				NDPManagedCareLetterList ndpManagedCareLetterList = new NDPManagedCareLetterList();
				List<NDPManagedCareLetter> ndpManagedCareLetters = ndpManagedCareLetterList.getNDPManagedCareLetters();

				NDPManagedCareParameterList ndpManagedCareParameterList = new NDPManagedCareParameterList();
				List<NDPManagedCareParameter> ndpManagedCareParameters = ndpManagedCareParameterList.getNDPManagedCareParameters();

				for(NRxMclInfo nrxMclInfoDdo : managedCareLetterList) {
					ndpManagedCareLetterMappingHelper.setMclLetterNo(nrxMclInfoDdo.getId().getNdmLetterNo());
					if(managedCareLetterList.size() > PAC_ALLOWED_RX_MAX_LIMIT) {
						// send N153
					} else {
						if(nrxInvoiceControlList != null) {
							for(NRxInvoiceControl nrxInvoiceControlDdo : nrxInvoiceControlList) {
								String nrxCDEDecode = nrxInvoiceControlDdo.getDecode();
								List<String> nrxCDEDecodeList = getNRxCDEDecode(nrxCDEDecode);
								String mclLetterNo  = String.valueOf(ndpManagedCareLetterMappingHelper.getMclLetterNo());
								
								int indexedMCLLetterNo = ZERO;
								
								try {
									indexedMCLLetterNo = Integer.valueOf(mclLetterNo.substring(0, 8));
								} catch(StringIndexOutOfBoundsException exception) {   
									log.error("StringIndexOutOfBoundsException thrown for indexedMCLLetterNo : ", indexedMCLLetterNo);
									log.info("StringIndexOutOfBoundsException Ignored");
								}

//								int indexedMCLLetterNo = Integer.valueOf(mclLetterNo.substring(0, 8));
								try{
									if(indexedMCLLetterNo > Integer.valueOf(nrxCDEDecodeList.get(ZERO)) &&
											   indexedMCLLetterNo < Integer.valueOf(nrxCDEDecodeList.get(ONE))) {
												ndpManagedCareLetterMappingHelper.setDummyLetterFlag(BOOLEAN_TRUE_FLAG);
												ndpManagedCareLetterMappingHelper.setMclRxNo(Integer.valueOf(MCL_RX_NO));
											}
											if(!(nrxInvoiceControlDdo.getId().getNrxcdeCodeVlu().equals(NRX_CDE_CODE_VLU)|| 
													ndpManagedCareLetterMappingHelper.isDummyLetterFlag())) {
												break;
											}
								} catch(NumberFormatException exception) {  
									log.error("NumberFormatException thrown for nrxCDEDecodeList : ", nrxCDEDecodeList.get(ZERO),nrxCDEDecodeList.get(ONE));
									log.info("NumberFormatException Ignored");
								}
							}
						}
					}		
					if(nrxMclInfoDdo.getVarText1() != null) {
						ndpManagedCareLetterMappingHelper.setAdditionalVarText1(nrxMclInfoDdo.getVarText1());
					} else {
						ndpManagedCareLetterMappingHelper.setAdditionalVarText1(EMPTY_STRING);
					}
					if(nrxMclInfoDdo.getVarLen() > ZERO) {
						if(nrxMclInfoDdo.getVarLen() > ndpManagedCareLetterMappingHelper.getAdditionalVarText1().length()) { 
							ndpManagedCareLetterMappingHelper.setMidOfMCPDelim(NDP_MANAGED_CARE_PARAMETER_ENDDELIM);
						} else {
							if(nrxMclInfoDdo.getVarLen() == ndpManagedCareLetterMappingHelper.getAdditionalVarText1().length()) {
								ndpManagedCareLetterMappingHelper.setMidOfMCPDelim(NDP_MANAGED_CARE_PARAMETER_ENDDELIM);
							} else {
								ndpManagedCareLetterMappingHelper.setEndOfMCPText(NDP_MANAGED_CARE_PARAMETER_ENDDELIM);
							}
						}
					} else {
						if(ndpManagedCareLetterMappingHelper.getAdditionalVarText1() == null) {
							ndpManagedCareLetterMappingHelper.setFstPosOfMCPtext(NDP_MANAGED_CARE_PARAMETER_ENDDELIM);
						} else {
							if(ndpManagedCareLetterMappingHelper.getAdditionalVarText1().substring(ZERO) != null) {
								ndpManagedCareLetterMappingHelper.setEndOfMCPDelim(NDP_MANAGED_CARE_PARAMETER_ENDDELIM);
							}else {
								ndpManagedCareLetterMappingHelper.setEndOfMCPText(NDP_MANAGED_CARE_PARAMETER_ENDDELIM);
							}
						}
					}
					ndpManagedCareLetterBdo = new NDPManagedCareLetter();
					ndpManagedCareLetterMapping.mapDatabaseToBusinessDomain(ndpManagedCareLetterBdo, nrxMclInfoDdo);

					ndpManagedCareParameterBdo = new NDPManagedCareParameter();
					ndpManagedCareParameterMapping.mapDatabaseToBusinessDomain(ndpManagedCareParameterBdo, nrxMclInfoDdo);
					
//					NDPManagedCareLetterList ndpManagedCareLetterList = new NDPManagedCareLetterList();
//					List<NDPManagedCareLetter> ndpManagedCareLetters = ndpManagedCareLetterList.getNDPManagedCareLetters();
//
//					NDPManagedCareParameterList ndpManagedCareParameterList = new NDPManagedCareParameterList();
//					List<NDPManagedCareParameter> ndpManagedCareParameters = ndpManagedCareParameterList.getNDPManagedCareParameters();

					
					ndpManagedCareParameters.add(ndpManagedCareParameterBdo);
					ndpManagedCareLetterBdo.setNDPManagedCareParameterList(ndpManagedCareParameterList);
					
					///last one 
					ndpManagedCareLetters.add(ndpManagedCareLetterBdo);
					
					orderRecordBdo.setNDPManagedCareLetterList(ndpManagedCareLetterList);
					ndpManagedCareLetterMappingHelper.setManagedCareLetterList(managedCareLetterList);
				}
			} else {
				// send N153
			}
			 
		}
	}
}

