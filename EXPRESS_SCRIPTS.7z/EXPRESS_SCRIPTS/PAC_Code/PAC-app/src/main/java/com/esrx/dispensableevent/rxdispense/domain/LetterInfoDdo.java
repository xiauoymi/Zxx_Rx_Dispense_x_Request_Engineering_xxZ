/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * LetterInfoDdo.
 */
@Entity
@Table(name = "TBL_LETTER_INFO", uniqueConstraints = {})
public class LetterInfoDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

	/** The id. */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, precision = 30, scale = 0)),
			@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, length = 15)),
			@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, precision = 9, scale = 0)),
			@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, length = 1))})
	private RxDispenseRequestIdDdo id;

	/** The pod num. */
	private Integer podNum;
	
	/** The pod name. */
	private String podName;
	
	/** The pod value. */
	private String podValue;

	/**
	 * default constructor.
	 */
	public LetterInfoDdo() {
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public RxDispenseRequestIdDdo getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(RxDispenseRequestIdDdo id) {
		this.id = id;
	}

	/**
	 * Gets the pod num.
	 *
	 * @return the pod num
	 */
	@Id
	@Column(name = "POD_NUM", unique = true, nullable = false, insertable = true, updatable = true, precision = 8, scale = 0)
	public Integer getPodNum() {
		return this.podNum;
	}

	/**
	 * Sets the pod num.
	 *
	 * @param podNum the new pod num
	 */
	public void setPodNum(Integer podNum) {
		this.podNum = podNum;
	}

	/** The rx dispense request. */
	private RxDispenseRequestDdo rxDispenseRequest;

	/**
	 * Gets the rx dispense request.
	 *
	 * @return the rx dispense request
	 */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumns({
			@JoinColumn(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "TRANS_ID"),
			@JoinColumn(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "CLIENT_ID"),
			@JoinColumn(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "ORDER_NUM"),
			@JoinColumn(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "SUBORDER_IND")})
	public RxDispenseRequestDdo getRxDispenseRequest() {
		return this.rxDispenseRequest;
	}

	/**
	 * Sets the rx dispense request.
	 *
	 * @param rxDispenseRequest the new rx dispense request
	 */
	public void setRxDispenseRequest(RxDispenseRequestDdo rxDispenseRequest) {
		this.rxDispenseRequest = rxDispenseRequest;
	}

	/**
	 * Gets the pod name.
	 *
	 * @return the pod name
	 */
	@Column(name = "POD_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 8)
	public String getPodName() {
		return this.podName;
	}

	/**
	 * Sets the pod name.
	 *
	 * @param podName the new pod name
	 */
	public void setPodName(String podName) {
		this.podName = podName;
	}

	/**
	 * Gets the pod value.
	 *
	 * @return the pod value
	 */
	@Column(name = "POD_VALUE", unique = false, nullable = true, insertable = true, updatable = true, length = 81)
	public String getPodValue() {
		return this.podValue;
	}

	/**
	 * Sets the pod value.
	 *
	 * @param podValue the new pod value
	 */
	public void setPodValue(String podValue) {
		this.podValue = podValue;
	}

}
