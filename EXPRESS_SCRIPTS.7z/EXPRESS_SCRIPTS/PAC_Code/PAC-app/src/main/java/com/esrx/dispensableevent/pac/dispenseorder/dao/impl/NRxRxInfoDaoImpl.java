package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxRxInfoDao;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_FALSE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_TRUE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;

public class NRxRxInfoDaoImpl extends GenericDaoHibernate<NRxRxInfo> implements
		NRxRxInfoDao {

	private static final Logger log = LoggerFactory
			.getLogger(NRxMclInfoDaoImpl.class);

	public NRxRxInfoDaoImpl(SessionFactory sf) {
		super(NRxRxInfo.class, sf);
	}

	public NRxRxInfo getNRxRxInfoRecord(NRxRxInfoId nrxRxInfoId) {
		NRxRxInfo nrxRxInfo = null;
		if(nrxRxInfoId !=null ) {
			nrxRxInfo = findById(nrxRxInfoId);
		}
		return nrxRxInfo;
	}

	public List<NRxRxInfo> getN004PrescriptionRecordList(NRxRxInfoId nrxRxInfoId) {
		List<NRxRxInfo> prescriptionRecordList = null;

		if (nrxRxInfoId != null) {
			DetachedCriteria prescriptionRecordCriteria = DetachedCriteria
					.forClass(NRxRxInfo.class);

			prescriptionRecordCriteria.add(Restrictions.eq("id", nrxRxInfoId));

			List<?> prescriptionList = getHibernateTemplate().findByCriteria(
					prescriptionRecordCriteria);

			prescriptionRecordList = new ArrayList<NRxRxInfo>();
			for (Object nrxRxInfoObj : prescriptionList) {
				NRxRxInfo nrxRxInfo = (NRxRxInfo) nrxRxInfoObj;
				prescriptionRecordList.add(nrxRxInfo);
			}
		}
		return prescriptionRecordList;
	}

	public boolean getCountForPackagePACData(NRxRxInfoId nrxRxInfoId) {

		int nrxRxInfoCount = ZERO;
		boolean nrxRxInfoCountExists = BOOLEAN_FALSE_FLAG;

		if (nrxRxInfoId != null) {
			DetachedCriteria countNRxRxInfoCriteria = DetachedCriteria
					.forClass(NRxRxInfo.class);
			countNRxRxInfoCriteria
					.setProjection(Projections.rowCount())
					.add(Restrictions.eq("id.ndxFillNo",nrxRxInfoId.getNdxFillNo()))
					.add(Restrictions.eq("id.ndxInvno", nrxRxInfoId.getNdxInvno()))
					.add(Restrictions.eq("id.ndxInvnoSub",""))
//					.add(Restrictions.eq("rcvRxStatus",""));
					.add(Restrictions.ge("rcvRxStatus",""));

			nrxRxInfoCount = ((Long) getHibernateTemplate().findByCriteria(
					countNRxRxInfoCriteria).get(0)).intValue();

			if (nrxRxInfoCount != ZERO) {
				nrxRxInfoCountExists = BOOLEAN_TRUE_FLAG;
			}
		}
		return nrxRxInfoCountExists;
	}

	public List<NRxRxInfo> getN004RxRecordList(NRxRxInfoId nrxRxInfoId) {
		List<NRxRxInfo> prescriptionRecordList = null;

		if (nrxRxInfoId != null) {
			DetachedCriteria prescriptionRecordCriteria = DetachedCriteria
					.forClass(NRxRxInfo.class);

			prescriptionRecordCriteria
			.add(Restrictions.eq("id.ndxFillNo", nrxRxInfoId.getNdxFillNo()))
			.add(Restrictions.eq("id.ndxInvno", nrxRxInfoId.getNdxInvno()))
			.add(Restrictions.eq("id.ndxInvnoSub", nrxRxInfoId.getNdxInvnoSub()))
			.addOrder(Order.asc("id.ndxRxno"));

			List<?> prescriptionList = getHibernateTemplate().findByCriteria(
					prescriptionRecordCriteria);

			prescriptionRecordList = new ArrayList<NRxRxInfo>();
			for (Object nrxRxInfoObj : prescriptionList) {
				NRxRxInfo nrxRxInfo = (NRxRxInfo) nrxRxInfoObj;
				prescriptionRecordList.add(nrxRxInfo);
			}
		}
		return prescriptionRecordList;
	}

	public void updateNDXNoMcLetters(Integer mcLettersNo, NRxRxInfoId nrxRxInfoId) {
		
		StringBuilder updateHql = new StringBuilder();
		updateHql.append("update NRxRxInfo set ");
		updateHql.append("noMcLetters=:mcLettersNo");
		updateHql.append(" where ");
		updateHql.append("id=:nrxRxInfoId");

		String updateNDXNoMcLettersHQL = String.valueOf(updateHql);
		
		if (mcLettersNo != null && nrxRxInfoId != null ) {
			Query updateMcLettersNoQuery = getSession().createQuery(updateNDXNoMcLettersHQL);
			updateMcLettersNoQuery.setInteger("mcLettersNo", mcLettersNo);
			updateMcLettersNoQuery.setParameter("nrxRxInfoId", nrxRxInfoId);
			updateMcLettersNoQuery.executeUpdate();
		}
	}

	public boolean getCountForNRxRxInfoViolation(NRxRxInfo nrxRxInfoDdo) {
		int nrxRxInfoCount = ZERO;
		boolean nrxRxInfoCountExists = BOOLEAN_FALSE_FLAG;

		if (nrxRxInfoDdo != null) {
			DetachedCriteria countNRxRxInfoViolation = DetachedCriteria
					.forClass(NRxRxInfo.class);
			countNRxRxInfoViolation
					.setProjection(Projections.rowCount())
					.add(Restrictions.eq("id.ndxFillNo",nrxRxInfoDdo.getId().getNdxFillNo()))
					.add(Restrictions.eq("id.ndxInvno", nrxRxInfoDdo.getId().getNdxInvno()))
					.add(Restrictions.eq("id.ndxRxno", nrxRxInfoDdo.getId().getNdxRxno()))
					.add(Restrictions.eq("id.ndxLocaNo", nrxRxInfoDdo.getId().getNdxLocaNo()))
					.add(Restrictions.ne("id.ndxInvnoSub", nrxRxInfoDdo.getId().getNdxInvnoSub()))
					.add(Restrictions.eq("refillno",nrxRxInfoDdo.getRefillno()));
			
			nrxRxInfoCount = ((Long) getHibernateTemplate().findByCriteria(
					countNRxRxInfoViolation).get(0)).intValue();

			if (nrxRxInfoCount != ZERO) {
				nrxRxInfoCountExists = BOOLEAN_TRUE_FLAG;
			}
		}
		return nrxRxInfoCountExists;
	}

	public void updateNDXSendTimeStamp(NRxRxInfo nrxRxInfoDdo) {
		StringBuilder updateHql = new StringBuilder();
		updateHql.append("update NRxRxInfo set ");
		updateHql.append("sendTms=:sendTms");
		updateHql.append(" where ");
		updateHql.append("id=:nrxRxInfoId");
		
		String updateNDXSendTimeStampHQL = String.valueOf(updateHql);

		if (nrxRxInfoDdo != null) {
			Query updateNDXSendTimeStampQuery = getSession().createQuery(updateNDXSendTimeStampHQL);
			updateNDXSendTimeStampQuery.setTimestamp("sendTms", nrxRxInfoDdo.getSendTms());
			updateNDXSendTimeStampQuery.setParameter("nrxRxInfoId", nrxRxInfoDdo.getId());
			updateNDXSendTimeStampQuery.executeUpdate();
		}
	}
}
