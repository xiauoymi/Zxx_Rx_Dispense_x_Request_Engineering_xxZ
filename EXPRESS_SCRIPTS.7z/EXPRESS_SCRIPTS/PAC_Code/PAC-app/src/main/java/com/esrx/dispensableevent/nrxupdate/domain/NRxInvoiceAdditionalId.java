package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NRxInvoiceAdditionalId implements Serializable {

	private static final long serialVersionUID = -2770403380902294566L;
	private Integer ordPartNbr;
	private Integer ordFillNo;
	private Integer ordExtInvno;
	private String ordInvnoSub;
	
	// Default Constructor
	public NRxInvoiceAdditionalId() {
		
	}

	@Column(name = "ORD_PART_NBR")
	public Integer getOrdPartNbr() {
		return ordPartNbr;
	}

	public void setOrdPartNbr(Integer ordPartNbr) {
		this.ordPartNbr = ordPartNbr;
	}

	@Column(name = "ORD_FILL_NO")
	public Integer getOrdFillNo() {
		return ordFillNo;
	}

	public void setOrdFillNo(Integer ordFillNo) {
		this.ordFillNo = ordFillNo;
	}

	@Column(name = "ORD_EXT_INVNO")
	public Integer getOrdExtInvno() {
		return ordExtInvno;
	}

	public void setOrdExtInvno(Integer ordExtInvno) {
		this.ordExtInvno = ordExtInvno;
	}

	@Column(name = "ORD_INVNO_SUB")
	public String getOrdInvnoSub() {
		return ordInvnoSub;
	}

	public void setOrdInvnoSub(String ordInvnoSub) {
		this.ordInvnoSub = ordInvnoSub;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ordExtInvno == null) ? 0 : ordExtInvno.hashCode());
		result = prime * result
				+ ((ordFillNo == null) ? 0 : ordFillNo.hashCode());
		result = prime * result
				+ ((ordInvnoSub == null) ? 0 : ordInvnoSub.hashCode());
		result = prime * result
				+ ((ordPartNbr == null) ? 0 : ordPartNbr.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NRxInvoiceAdditionalId other = (NRxInvoiceAdditionalId) obj;
		if (ordExtInvno == null) {
			if (other.ordExtInvno != null)
				return false;
		} else if (!ordExtInvno.equals(other.ordExtInvno))
			return false;
		if (ordFillNo == null) {
			if (other.ordFillNo != null)
				return false;
		} else if (!ordFillNo.equals(other.ordFillNo))
			return false;
		if (ordInvnoSub == null) {
			if (other.ordInvnoSub != null)
				return false;
		} else if (!ordInvnoSub.equals(other.ordInvnoSub))
			return false;
		if (ordPartNbr == null) {
			if (other.ordPartNbr != null)
				return false;
		} else if (!ordPartNbr.equals(other.ordPartNbr))
			return false;
		return true;
	}
}