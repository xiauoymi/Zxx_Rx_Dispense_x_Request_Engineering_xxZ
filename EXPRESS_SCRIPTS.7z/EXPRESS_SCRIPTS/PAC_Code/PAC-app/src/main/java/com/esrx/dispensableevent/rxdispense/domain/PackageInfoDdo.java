/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * PackageInfoDdo.
 */
@Entity
@Table(name = "TBL_PACKAGE_INFO", uniqueConstraints = {})
public class PackageInfoDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

	/** The carrier id. */
	private String carrierId;
	
	/** The mail date. */
	private Timestamp mailDate;
	
	/** The mail time. */
	private Timestamp mailTime;
	
	/** The weight. */
	private String weight;
	
	/** The service class. */
	private String serviceClass;
	
	/** The track num. */
	private String trackNum;
	
	/** The ship charge. */
	private BigDecimal shipCharge;
	
	/** The ship option. */
	private String shipOption;

	/** The rx dispense request. */
	private RxDispenseRequestDdo rxDispenseRequest;

	/** The rx dispense request id ddo. */
	private RxDispenseRequestIdDdo rxDispenseRequestIdDdo;
	
	/**
	 * default constructor.
	 */
	public PackageInfoDdo() {
	}

	/**
	 * Gets the rx dispense request id ddo.
	 *
	 * @return the rxDispenseRequestIdDdo
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, precision = 30, scale = 0)),
			@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, length = 15)),
			@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, precision = 9, scale = 0)),
			@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, length = 1))})
	public RxDispenseRequestIdDdo getRxDispenseRequestIdDdo() {
		return this.rxDispenseRequestIdDdo;
	}

	/**
	 * Sets the rx dispense request id ddo.
	 *
	 * @param rxDispenseRequestIdDdo the rxDispenseRequestIdDdo to set
	 */
	public void setRxDispenseRequestIdDdo(
			RxDispenseRequestIdDdo rxDispenseRequestIdDdo) {
		this.rxDispenseRequestIdDdo = rxDispenseRequestIdDdo;
	}

	/**
	 * Gets the rx dispense request.
	 *
	 * @return the rx dispense request
	 */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)	
	@JoinColumns({
			@JoinColumn(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false)})
	public RxDispenseRequestDdo getRxDispenseRequest() {
		return this.rxDispenseRequest;
	}

	/**
	 * Sets the rx dispense request.
	 *
	 * @param rxDispenseRequest the new rx dispense request
	 */
	public void setRxDispenseRequest(RxDispenseRequestDdo rxDispenseRequest) {
		this.rxDispenseRequest = rxDispenseRequest;
	}

	/**
	 * Gets the carrier id.
	 *
	 * @return the carrier id
	 */
	@Id
	@Column(name = "CARRIER_ID", unique = true, nullable = false, insertable = true, updatable = true, length = 1)
	public String getCarrierId() {
		return this.carrierId;
	}

	/**
	 * Sets the carrier id.
	 *
	 * @param carrierId the new carrier id
	 */
	public void setCarrierId(String carrierId) {
		this.carrierId = carrierId;
	}

	/**
	 * Gets the mail date.
	 *
	 * @return the mail date
	 */
	@Column(name = "MAIL_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getMailDate() {
		return this.mailDate;
	}

	/**
	 * Sets the mail date.
	 *
	 * @param mailDate the new mail date
	 */
	public void setMailDate(Timestamp mailDate) {
		this.mailDate = mailDate;
	}

	/**
	 * Gets the mail time.
	 *
	 * @return the mail time
	 */
	@Column(name = "MAIL_TIME", unique = false, nullable = true, insertable = true, updatable = true, length = 11)
	public Timestamp getMailTime() {
		return this.mailTime;
	}

	/**
	 * Sets the mail time.
	 *
	 * @param mailTime the new mail time
	 */
	public void setMailTime(Timestamp mailTime) {
		this.mailTime = mailTime;
	}

	/**
	 * Gets the weight.
	 *
	 * @return the weight
	 */
	@Column(name = "WEIGHT", unique = false, nullable = true, insertable = true, updatable = true, length = 8)
	public String getWeight() {
		return this.weight;
	}

	/**
	 * Sets the weight.
	 *
	 * @param weight the new weight
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}

	/**
	 * Gets the service class.
	 *
	 * @return the service class
	 */
	@Column(name = "SERVICE_CLASS", unique = false, nullable = true, insertable = true, updatable = true, length = 2)
	public String getServiceClass() {
		return this.serviceClass;
	}

	/**
	 * Sets the service class.
	 *
	 * @param serviceClass the new service class
	 */
	public void setServiceClass(String serviceClass) {
		this.serviceClass = serviceClass;
	}

	/**
	 * Gets the track num.
	 *
	 * @return the track num
	 */
	@Column(name = "TRACK_NUM", unique = false, nullable = true, insertable = true, updatable = true, length = 22)
	public String getTrackNum() {
		return this.trackNum;
	}

	/**
	 * Sets the track num.
	 *
	 * @param trackNum the new track num
	 */
	public void setTrackNum(String trackNum) {
		this.trackNum = trackNum;
	}

	/**
	 * Gets the ship charge.
	 *
	 * @return the ship charge
	 */
	@Column(name = "SHIP_CHARGE", unique = false, nullable = true, insertable = true, updatable = true, precision = 5)
	public BigDecimal getShipCharge() {
		return this.shipCharge;
	}

	/**
	 * Sets the ship charge.
	 *
	 * @param shipCharge the new ship charge
	 */
	public void setShipCharge(BigDecimal shipCharge) {
		this.shipCharge = shipCharge;
	}

	/**
	 * Gets the ship option.
	 *
	 * @return the ship option
	 */
	@Column(name = "SHIP_OPTION", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getShipOption() {
		return this.shipOption;
	}

	/**
	 * Sets the ship option.
	 *
	 * @param shipOption the new ship option
	 */
	public void setShipOption(String shipOption) {
		this.shipOption = shipOption;
	}

}
