/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import java.sql.Timestamp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * StatusInfoDdo.
 */
@Entity
@Table(name = "TBL_STATUS_INFO", uniqueConstraints = {})
public class StatusInfoDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

	/** The status code. */
	private int statusCode;
	
	/** The status date. */
	private Timestamp statusDate;
	
	/** The no of retries. */
	private Short noOfRetries;
	
	/** The fe acknowledge. */
	private String feAcknowledge;
	
	/** The status msg. */
	private String statusMsg;
	
	/** The sub status code. */
	private int subStatusCode;

	/** The rx dispense request. */
	private RxDispenseRequestDdo rxDispenseRequest;
	
	/** The rx dispense request id ddo. */
	private RxDispenseRequestIdDdo rxDispenseRequestIdDdo;

	/**
	 * default constructor.
	 */
	public StatusInfoDdo() {
	}

	/**
	 * Gets the rx dispense request id ddo.
	 *
	 * @return the rxDispenseRequestIdDdo
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, precision = 30, scale = 0)),
			@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, length = 15)),
			@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, precision = 9, scale = 0)),
			@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, length = 1))})
	public RxDispenseRequestIdDdo getRxDispenseRequestIdDdo() {
		return rxDispenseRequestIdDdo;
	}

	/**
	 * Sets the rx dispense request id ddo.
	 *
	 * @param rxDispenseRequestIdDdo the rxDispenseRequestIdDdo to set
	 */
	public void setRxDispenseRequestIdDdo(
			RxDispenseRequestIdDdo rxDispenseRequestIdDdo) {
		this.rxDispenseRequestIdDdo = rxDispenseRequestIdDdo;
	}

	/**
	 * Gets the rx dispense request.
	 *
	 * @return the rx dispense request
	 */
	@OneToOne(cascade={}, fetch=FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false)})
	public RxDispenseRequestDdo getRxDispenseRequest() {
		return this.rxDispenseRequest;
	}

	/**
	 * Sets the rx dispense request.
	 *
	 * @param rxDispenseRequest the new rx dispense request
	 */
	public void setRxDispenseRequest(RxDispenseRequestDdo rxDispenseRequest) {
		this.rxDispenseRequest = rxDispenseRequest;
	}
	
	/**
	 * Gets the status code.
	 *
	 * @return the status code
	 */
	@Column(name = "STATUS_CODE", unique = false, nullable = false, insertable = true, updatable = true, precision = 1, scale = 0)
	public int getStatusCode() {
		return this.statusCode;
	}

	/**
	 * Sets the status code.
	 *
	 * @param statusCode the new status code
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Gets the status date.
	 *
	 * @return the status date
	 */
	@Column(name = "STATUS_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 11)
	public Timestamp getStatusDate() {
		return this.statusDate;
	}

	/**
	 * Sets the status date.
	 *
	 * @param statusDate the new status date
	 */
	public void setStatusDate(Timestamp statusDate) {
		this.statusDate = statusDate;
	}

	/**
	 * Gets the no of retries.
	 *
	 * @return the no of retries
	 */
	@Column(name = "NO_OF_RETRIES", unique = false, nullable = true, insertable = true, updatable = true, precision = 3, scale = 0)
	public Short getNoOfRetries() {
		return this.noOfRetries;
	}

	/**
	 * Sets the no of retries.
	 *
	 * @param noOfRetries the new no of retries
	 */
	public void setNoOfRetries(Short noOfRetries) {
		this.noOfRetries = noOfRetries;
	}

	/**
	 * Gets the fe acknowledge.
	 *
	 * @return the fe acknowledge
	 */
	@Column(name = "FE_ACKNOWLEDGE", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getFeAcknowledge() {
		return this.feAcknowledge;
	}

	/**
	 * Sets the fe acknowledge.
	 *
	 * @param feAcknowledge the new fe acknowledge
	 */
	public void setFeAcknowledge(String feAcknowledge) {
		this.feAcknowledge = feAcknowledge;
	}

	/**
	 * Gets the status msg.
	 *
	 * @return the status msg
	 */
	@Column(name = "STATUS_MSG", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getStatusMsg() {
		return this.statusMsg;
	}

	/**
	 * Sets the status msg.
	 *
	 * @param statusMsg the new status msg
	 */
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}

	/**
	 * Gets the sub status code.
	 *
	 * @return the sub status code
	 */
	@Column(name = "SUB_STATUS_CODE", unique = false, nullable = true, insertable = true, updatable = true, precision = 1, scale = 0)
	public int getSubStatusCode() {
		return this.subStatusCode;
	}

	/**
	 * Sets the sub status code.
	 *
	 * @param subStatusCode the new sub status code
	 */
	public void setSubStatusCode(int subStatusCode) {
		this.subStatusCode = subStatusCode;
	}

}
