package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.NDPRxRecord;

import com.esrx.dispensableevent.nrxupdate.domain.NRxRxFinancial;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.TAX;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NO_INDICATOR;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.YES_INDICATOR;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EAST_WEST_FLAG;

public class NDPRxRecordMapping {

	public void mapDatabaseToBusinessDomain(NDPRxRecord ndpRxRecordBdo, NRxRxInfo nrxRxInfoDdo, NRxRxFinancial nrxRxFinancialDdo, NDPRxRecordMappingHelper ndpRxRecordMappingHelper) {
		ndpRxRecordBdo.setActRefills(nrxRxInfoDdo.getOrgRefills());
//		ndpRxRecordBdo.setApdata(nrxRxInfoDdo.get); // Missing in NRx
		ndpRxRecordBdo.setBarcodeCheckDigit(nrxRxInfoDdo.getRflBarcdeCd()); 
		ndpRxRecordBdo.setBarcodeFormat(nrxRxInfoDdo.getRflBarcdeFmt());  
		ndpRxRecordBdo.setBotMsgCd(Integer.parseInt(nrxRxInfoDdo.getBottleMsgCde()));  //Missing in NRx
		ndpRxRecordBdo.setClientAmtDsc(nrxRxInfoDdo.getClientAmtDsc());
//		ndpRxRecordBdo.setCompName(nrxRxInfoDdo.getCo); //Missing in NRx
		ndpRxRecordBdo.setCompoundFlag(nrxRxInfoDdo.getCmpndFlg());
		ndpRxRecordBdo.setCopay(String.valueOf(nrxRxInfoDdo.getCopay()));
		ndpRxRecordBdo.setDateOfServ(String.valueOf(nrxRxInfoDdo.getDteOfServ()));
		ndpRxRecordBdo.setDateWritten(String.valueOf(nrxRxFinancialDdo.getRxIssuedDte()));  //  Missing in NRx
		ndpRxRecordBdo.setDaysSupply(ndpRxRecordMappingHelper.getDaysSupply());  //  Missing in NRx
		ndpRxRecordBdo.setDirections1(ndpRxRecordMappingHelper.getDirections1());   //  need to look into the N150 properly....
		ndpRxRecordBdo.setDirections2(ndpRxRecordMappingHelper.getDirections2());    // Missing in NRx
		ndpRxRecordBdo.setDirections3(ndpRxRecordMappingHelper.getDirections3());     // Missing in NRx
		ndpRxRecordBdo.setDirections4(EMPTY_STRING);   // Missing in NRx
		ndpRxRecordBdo.setDirections5(EMPTY_STRING);   // Missing in NRx
		ndpRxRecordBdo.setDispSvcBranch(ZERO); // Missing in NRx
		ndpRxRecordBdo.setDrugInsertno(nrxRxInfoDdo.getDrgInsrtno());
		ndpRxRecordBdo.setDrugInsertnoPgs(nrxRxInfoDdo.getDrgInsPgs());
		ndpRxRecordBdo.setDrugNum(ndpRxRecordMappingHelper.getDrugNum());
		ndpRxRecordBdo.setEastWestFlag(EAST_WEST_FLAG);  // Missing in NRx
		ndpRxRecordBdo.setExtraLabelcnt(ZERO); // Missing in NRx
//		ndpRxRecordBdo.setLabelRxNum(nrxRxInfoDdo.getL); // Missing in NRx
		ndpRxRecordBdo.setMandPpi(nrxRxInfoDdo.getMandPpi());
		ndpRxRecordBdo.setMandPpiPgs(nrxRxInfoDdo.getMandPpiPgs());
		ndpRxRecordBdo.setMdAdd(nrxRxFinancialDdo.getDrAddr1Txt()); // Missing in NRx
		ndpRxRecordBdo.setMdCity(nrxRxFinancialDdo.getDrCityNme()); // Missing in NRx
//		ndpRxRecordBdo.setMdFaxNum(nrxRxInfoDdo.getF); // Missing in NRx 
//		ndpRxRecordBdo.setMdNameFst(nrxRxInfoDdo.getM);     // Missing in NRx
		ndpRxRecordBdo.setMdNameLst(nrxRxInfoDdo.getMdNameLst());
		ndpRxRecordBdo.setMdPhoneNum(ndpRxRecordMappingHelper.getMdPhoneNum());   // Missing in NRx 
		ndpRxRecordBdo.setMdState(nrxRxFinancialDdo.getDrStCde());    // Missing in NRx
		ndpRxRecordBdo.setMdZip(String.valueOf(nrxRxFinancialDdo.getDrZip9Cde()));     // Missing in NRx
		ndpRxRecordBdo.setNdcNum(EMPTY_STRING); // Missing in NRx
		ndpRxRecordBdo.setNoMcl(ndpRxRecordMappingHelper.getNoMcl()); 
		ndpRxRecordBdo.setNpDrugNum(nrxRxInfoDdo.getBrndSubNo());
//		ndpRxRecordBdo.setNpNdcNum(nrxRxInfoDdo);  // Missing in NRx
//		ndpRxRecordBdo.setOptExpirydate(nrxRxInfoDdo.getO);  // Missing in NRx
//		ndpRxRecordBdo.setPatDob(nrxRxInfoDdo.getD); // Missing in NRx

		ndpRxRecordBdo.setPatNameFst(nrxRxInfoDdo.getPatNmeFst());
		ndpRxRecordBdo.setPatNameLst(nrxRxInfoDdo.getPatNmeLst());
		ndpRxRecordBdo.setPatPayAmount(String.valueOf(nrxRxInfoDdo.getPatPayAmt()));
		ndpRxRecordBdo.setPayAmount1(TAX); // Missing in NRx
		ndpRxRecordBdo.setPayAmount2(TAX);// Missing in NRx
		ndpRxRecordBdo.setPayAmount3(TAX);// Missing in NRx
		ndpRxRecordBdo.setPayAmount4(TAX);// Missing in NRx
		ndpRxRecordBdo.setPayAmount5(TAX);// Missing in NRx
//		ndpRxRecordBdo.setPayName1(nrxRxInfoDdo.getP);// Missing in NRx
//		ndpRxRecordBdo.setPayName2(nrxRxInfoDdo);// Missing in NRx
//		ndpRxRecordBdo.setPayName3(nrxRxInfoDdo);// Missing in NRx
//		ndpRxRecordBdo.setPayName4(nrxRxInfoDdo);// Missing in NRx
//		ndpRxRecordBdo.setPayName5(nrxRxInfoDdo);// Missing in NRx
		ndpRxRecordBdo.setPrice(String.valueOf(nrxRxInfoDdo.getPrice()));

//		ndpRxRecordBdo.setQuantity(nrxRxInfoDdo.getQuantity());
		ndpRxRecordBdo.setQuantity(nrxRxFinancialDdo.getFillQty());

		
		ndpRxRecordBdo.setRefilAftDt(String.valueOf(nrxRxInfoDdo.getRflAftDte()));
		ndpRxRecordBdo.setRefilBefDt(String.valueOf(nrxRxInfoDdo.getRflBefDte()));
		ndpRxRecordBdo.setRefillNumber(nrxRxInfoDdo.getNumRefills());
		ndpRxRecordBdo.setRefillsRemaining(ndpRxRecordMappingHelper.getRefillsRemaining());   //Missing in NRx 
		ndpRxRecordBdo.setRenewalCode(nrxRxInfoDdo.getRenewalCde());
		ndpRxRecordBdo.setRenewalFlag(nrxRxInfoDdo.getRenewalFlg());
		ndpRxRecordBdo.setRetailTrackNum(EMPTY_STRING); // Missing in NRx 
		ndpRxRecordBdo.setRxLocaNo(String.valueOf(nrxRxInfoDdo.getId().getNdxLocaNo()));
		ndpRxRecordBdo.setRxNum(String.valueOf(nrxRxInfoDdo.getId().getNdxRxno()));
//		ndpRxRecordBdo.setRxtype(nrxRxInfoDdo.getR); //Missing in NRx 
//		ndpRxRecordBdo.setSafetyCap(NO_INDICATOR);
		ndpRxRecordBdo.setSafetyCap(nrxRxInfoDdo.getNoSftyCap());
//		ndpRxRecordBdo.setTherapyType(nrxRxInfoDdo); //Missing in NRx 
		ndpRxRecordBdo.setTrackLotnumFlag(YES_INDICATOR); // Missing in NRx 
	}
}
