package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NRxRxInfoId implements Serializable {

	private static final long serialVersionUID = -1656637108070673534L;
	private Integer ndxFillNo; 
	private Integer ndxInvno;
	private String ndxInvnoSub;
	private Integer ndxLocaNo;
	private Double ndxRxno;
	
	// Default Constructor
	public NRxRxInfoId() {
		
	}

	@Column(name = "NDX_FILL_NO")
	public int getNdxFillNo() {
		return ndxFillNo;
	}

	public void setNdxFillNo(int ndxFillNo) {
		this.ndxFillNo = ndxFillNo;
	}

	@Column(name = "NDX_INVNO")
	public int getNdxInvno() {
		return ndxInvno;
	}

	public void setNdxInvno(int ndxInvno) {
		this.ndxInvno = ndxInvno;
	}

	@Column(name = "NDX_INVNO_SUB")
	public String getNdxInvnoSub() {
		return ndxInvnoSub;
	}

	public void setNdxInvnoSub(String ndxInvnoSub) {
		this.ndxInvnoSub = ndxInvnoSub;
	}

	@Column(name = "NDX_LOCA_NO")
	public int getNdxLocaNo() {
		return ndxLocaNo;
	}

	public void setNdxLocaNo(int ndxLocaNo) {
		this.ndxLocaNo = ndxLocaNo;
	}

	@Column(name = "NDX_RXNO")
	public double getNdxRxno() {
		return ndxRxno;
	}

	public void setNdxRxno(double ndxRxno) {
		this.ndxRxno = ndxRxno;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ndxFillNo == null) ? 0 : ndxFillNo.hashCode());
		result = prime * result
				+ ((ndxInvno == null) ? 0 : ndxInvno.hashCode());
		result = prime * result
				+ ((ndxInvnoSub == null) ? 0 : ndxInvnoSub.hashCode());
		result = prime * result
				+ ((ndxLocaNo == null) ? 0 : ndxLocaNo.hashCode());
		result = prime * result + ((ndxRxno == null) ? 0 : ndxRxno.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NRxRxInfoId other = (NRxRxInfoId) obj;
		if (ndxFillNo == null) {
			if (other.ndxFillNo != null)
				return false;
		} else if (!ndxFillNo.equals(other.ndxFillNo))
			return false;
		if (ndxInvno == null) {
			if (other.ndxInvno != null)
				return false;
		} else if (!ndxInvno.equals(other.ndxInvno))
			return false;
		if (ndxInvnoSub == null) {
			if (other.ndxInvnoSub != null)
				return false;
		} else if (!ndxInvnoSub.equals(other.ndxInvnoSub))
			return false;
		if (ndxLocaNo == null) {
			if (other.ndxLocaNo != null)
				return false;
		} else if (!ndxLocaNo.equals(other.ndxLocaNo))
			return false;
		if (ndxRxno == null) {
			if (other.ndxRxno != null)
				return false;
		} else if (!ndxRxno.equals(other.ndxRxno))
			return false;
		return true;
	}
}