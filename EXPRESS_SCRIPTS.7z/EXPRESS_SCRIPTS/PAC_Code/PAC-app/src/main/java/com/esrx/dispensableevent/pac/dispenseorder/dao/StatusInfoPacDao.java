package com.esrx.dispensableevent.pac.dispenseorder.dao;

import java.util.List;

import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderStatusCode;
import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderSubStatusCode;
import com.esrx.dispensableevent.rxdispense.domain.StatusInfoDdo;


public interface StatusInfoPacDao {
	List<StatusInfoDdo> getStatusInfoDdoList(RxDispenseOrderStatusCode statusCode, RxDispenseOrderSubStatusCode subStatusCode);

}
 