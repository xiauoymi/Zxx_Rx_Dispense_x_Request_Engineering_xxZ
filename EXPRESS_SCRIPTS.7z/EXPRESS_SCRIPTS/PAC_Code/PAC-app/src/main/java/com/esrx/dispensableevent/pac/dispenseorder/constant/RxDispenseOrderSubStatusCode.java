/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.pac.dispenseorder.constant;

/**
 * The Enum RxDispenseOrderSubStatusCode.
 */
public enum RxDispenseOrderSubStatusCode {

	/** The sub status for work table. */
	SUB_STATUS_FOR_WORK_TABLE(1),
	
	/** The SU b_ statu s_ fo r_ cod e1. */
	SUB_STATUS_FOR_CODE1(2),
	
	/** The sub status for work table to nrx. */
	SUB_STATUS_FOR_WORK_TABLE_TO_NRX(3), 
	
	/** The sub status for nrx to pac. */
	SUB_STATUS_FOR_NRX_TO_PAC(4),
	
	/** The sub status for pac to client. */
	SUB_STATUS_FOR_PAC_TO_CLIENT(5),
	
	/** The sub status for pac to archive. */
	SUB_STATUS_FOR_PAC_TO_ARCHIVE(6);

	/** The order sub status. */
	int orderSubStatus;

	/**
	 * Instantiates a new rx dispense order sub status code.
	 *
	 * @param orderSubStatus the order sub status
	 */
	private RxDispenseOrderSubStatusCode(int orderSubStatus) {
		this.orderSubStatus = orderSubStatus;
	}

	/**
	 * Gets the order sub status val.
	 *
	 * @return the order sub status val
	 */
	public int getOrderSubStatusVal() {
		return orderSubStatus;
	}

	/**
	 * Gets the order sub status code.
	 *
	 * @param subStatusType the sub status type
	 * @return the order sub status code
	 */
	public static int getOrderSubStatusCode(RxDispenseOrderSubStatusCode subStatusType) {
		return RxDispenseOrderSubStatusCode.valueOf(String.valueOf(subStatusType))
				.getOrderSubStatusVal();
	}	
}
