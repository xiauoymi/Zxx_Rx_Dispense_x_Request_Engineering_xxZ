package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_FALSE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_TRUE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NS_ORD_COMM_RES_IND;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.PAC_ALLOWED_RX_MAX_LIMIT;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ONE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.THREE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.FOUR;
import static com.esrx.dispensableevent.pac.dispenseorder.util.PacDispenseOrderPartNbrUtil.getOrdPartNbr;
import generated.NDPManagedCareLetter;
import generated.NDPRxRecord;
import generated.OrderRecord;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.expression.spel.ast.OpNE;

import com.esrx.dispensableevent.nrxupdate.domain.NRxDrugInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxDrugInfoId;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxFinancial;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxFinancialId;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxDrugInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxRxFinancialDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxRxInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPManagedCareLetterMappingHelper;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPRxRecordMapping;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPRxRecordMappingHelper;
import com.esrx.dispensableevent.rxdispense.domain.DoctorInfoDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxInfoDdo;


public class RxRecordBoHelper {

	private static final Logger log = LoggerFactory
	.getLogger(RxRecordBoHelper.class);

	private NRxRxInfo nrxRxInfoDdo;
	private RxDispenseRequestDdo rxDispenseRequestDdo;

	private NDPRxRecord ndpRxRecordBdo;
	private OrderRecord orderRecordBdo;
	
	private NDPRxRecordMapping ndpRxRecordMapping;
	private NDPRxRecordMappingHelper ndpRxRecordMappingHelper;
	private List<NDPRxRecord> ndpRxRecordBdoList;

	private NRxRxInfoDao nrxRxInfoDao;
	private NRxDrugInfoDao nrxDrugInfoDao;
	private NRxInvoiceDao nrxInvoiceDao;
	private NRxRxFinancialDao nrxRxFinancialDao;
	
	private ManagedCareBoHelper managedCareBoHelper;
	private SendN153BoHelper sendN153BoHelper;
	
	/**
	 * @return the ndpRxRecordMapping
	 */
	public NDPRxRecordMapping getNdpRxRecordMapping() {
		return ndpRxRecordMapping;
	}


	/**
	 * @param ndpRxRecordMapping the ndpRxRecordMapping to set
	 */
	public void setNdpRxRecordMapping(NDPRxRecordMapping ndpRxRecordMapping) {
		this.ndpRxRecordMapping = ndpRxRecordMapping;
	}


	/**
	 * @return the orderRecordBdo
	 */
	public OrderRecord getOrderRecordBdo() {
		return orderRecordBdo;
	}


	/**
	 * @param orderRecordBdo the orderRecordBdo to set
	 */
	public void setOrderRecordBdo(OrderRecord orderRecordBdo) {
		this.orderRecordBdo = orderRecordBdo;
	}


	/**
	 * @return the nrxRxInfoDao
	 */
	public NRxRxInfoDao getNrxRxInfoDao() {
		return nrxRxInfoDao;
	}


	/**
	 * @param nrxRxInfoDao the nrxRxInfoDao to set
	 */
	public void setNrxRxInfoDao(NRxRxInfoDao nrxRxInfoDao) {
		this.nrxRxInfoDao = nrxRxInfoDao;
	}

	/**
	 * @return the nrxInvoiceDao
	 */
	public NRxInvoiceDao getNrxInvoiceDao() {
		return nrxInvoiceDao;
	}


	/**
	 * @param nrxInvoiceDao the nrxInvoiceDao to set
	 */
	public void setNrxInvoiceDao(NRxInvoiceDao nrxInvoiceDao) {
		this.nrxInvoiceDao = nrxInvoiceDao;
	}

	/**
	 * @return the nrxDrugInfoDao
	 */
	public NRxDrugInfoDao getNrxDrugInfoDao() {
		return nrxDrugInfoDao;
	}


	/**
	 * @param nrxDrugInfoDao the nrxDrugInfoDao to set
	 */
	public void setNrxDrugInfoDao(NRxDrugInfoDao nrxDrugInfoDao) {
		this.nrxDrugInfoDao = nrxDrugInfoDao;
	}


	/**
	 * @return the nrxRxFinancialDao
	 */
	public NRxRxFinancialDao getNrxRxFinancialDao() {
		return nrxRxFinancialDao;
	}


	/**
	 * @param nrxRxFinancialDao the nrxRxFinancialDao to set
	 */
	public void setNrxRxFinancialDao(NRxRxFinancialDao nrxRxFinancialDao) {
		this.nrxRxFinancialDao = nrxRxFinancialDao;
	}


	/**
	 * @return the managedCareBoHelper
	 */
	public ManagedCareBoHelper getManagedCareBoHelper() {
		return managedCareBoHelper;
	}


	/**
	 * @param managedCareBoHelper the managedCareBoHelper to set
	 */
	public void setManagedCareBoHelper(ManagedCareBoHelper managedCareBoHelper) {
		this.managedCareBoHelper = managedCareBoHelper;
	}


	/**
	 * @return the sendN153BoHelper
	 */
	public SendN153BoHelper getSendN153BoHelper() {
		return sendN153BoHelper;
	}


	/**
	 * @param sendN153BoHelper the sendN153BoHelper to set
	 */
	public void setSendN153BoHelper(SendN153BoHelper sendN153BoHelper) {
		this.sendN153BoHelper = sendN153BoHelper;
	}


	public NDPRxRecordMappingHelper packagePacRxRecordData(RxDispenseRequestDdo rxDispenseRequestDdo, NRxInvoice nrxInvoiceDdo, OrderRecord orderRecordBdo, NDPManagedCareLetterMappingHelper ndpManagedCareLetterMappingHelper) {
		this.rxDispenseRequestDdo = rxDispenseRequestDdo;
		List<NRxRxInfo> prescriptionRecordList = null;
//		NDPRxRecord ndpRxRecordBdo = null;
		
		if(nrxInvoiceDdo != null && orderRecordBdo!= null) {
			this.orderRecordBdo = orderRecordBdo;
			NRxRxInfoId nrxRxInfoId = new NRxRxInfoId();
			nrxRxInfoId.setNdxFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
			nrxRxInfoId.setNdxInvno(nrxInvoiceDdo.getId().getNdiInvno());
			nrxRxInfoId.setNdxInvnoSub(nrxInvoiceDdo.getId().getNdiInvnoSub());
			prescriptionRecordList = nrxRxInfoDao.getN004RxRecordList(nrxRxInfoId); 
			
			if(prescriptionRecordList != null) {
				if(prescriptionRecordList.size() > PAC_ALLOWED_RX_MAX_LIMIT) {
					// send N153 ...		
					sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
				} else {
					ndpRxRecordBdoList = new ArrayList<NDPRxRecord>();
					
					for(NRxRxInfo nrxRxInfoDdo : prescriptionRecordList) {
						this.nrxRxInfoDdo = nrxRxInfoDdo;
						ndpRxRecordMappingHelper = new NDPRxRecordMappingHelper();
						ndpRxRecordMappingHelper.setNoMcl(ZERO);
						if(orderRecordBdo.getLabelNameFst() != null || orderRecordBdo.getLabelNameLst()!= null) {
							orderRecordBdo.setLabelNameFst(nrxRxInfoDdo.getPatNmeFst());
							orderRecordBdo.setLabelNameLst(nrxRxInfoDdo.getPatNmeLst());
							nrxInvoiceDdo.setMemNameFst(nrxRxInfoDdo.getPatNmeFst());
							nrxInvoiceDdo.setMemNameLst(nrxRxInfoDdo.getPatNmeLst());
							
								nrxInvoiceDao.updateNDIMEMFirstLastName(nrxInvoiceDdo);
							ndpRxRecordBdo = packagePacRxRecordAdditionalData(nrxInvoiceDdo, orderRecordBdo, ndpManagedCareLetterMappingHelper);
						} else {
							ndpRxRecordBdo = packagePacRxRecordAdditionalData(nrxInvoiceDdo, orderRecordBdo, ndpManagedCareLetterMappingHelper);
						}
						ndpRxRecordBdoList.add(ndpRxRecordBdo);  
					}
					ndpRxRecordMappingHelper.setNdpRxRecordBdoList(ndpRxRecordBdoList);
					ndpRxRecordMappingHelper.setPrescriptionRecordList(prescriptionRecordList);
				}
			} else {
				// send N153 ...
				sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
			}
		}
		return ndpRxRecordMappingHelper;
	}
	
	public NDPRxRecord packagePacRxRecordAdditionalData(NRxInvoice nrxInvoiceDdo, OrderRecord orderRecordBdo, NDPManagedCareLetterMappingHelper ndpManagedCareLetterMappingHelper) {
//		private NDPRxRecord ndpRxRecordBdo;
//		ndpRxRecordBdo = new NDPRxRecord();
//		NDPManagedCareLetterMappingHelper ndpManagedCareLetterMappingHelper = null;
//		ndpRxRecordBdo.setMdNameLst(nrxRxInfoDdo.getMdNameLst());
		ArrayList<RxInfoDdo> rxInfoList = null;
		ArrayList<DoctorInfoDdo> doctorInfoList = null;
		int rxIndex =  ZERO;
		
		if(nrxRxInfoDdo.getNdpDrugNo() > ZERO) {
			ndpRxRecordMappingHelper.setDrugNum(nrxRxInfoDdo.getNdpDrugNo());
		} else {
			ndpRxRecordMappingHelper.setDrugNum(nrxRxInfoDdo.getDrugNo());
		}
//		ndpRxRecordBdo.setNpDrugNum(nrxRxInfoDdo.getBrndSubNo());
//		ndpRxRecordBdo.setDrugInsertno(nrxRxInfoDdo.getDrgInsrtno());
		
//		if(nrxRxInfoDdo.getBottleMsgCde() != null){
//			ndpRxRecordMappingHelper.setBotMsgCd(Integer.valueOf(nrxRxInfoDdo.getBottleMsgCde()));
//		}else {
//			ndpRxRecordMappingHelper.setBotMsgCd(Integer.valueOf(ZERO));
//		}
		if(nrxRxInfoDdo.getDirections() == null) {
			//send N153
			sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
		}else {
			getDirections( nrxRxInfoDdo.getDirections(), ndpRxRecordMappingHelper);
		}
		
		NRxDrugInfoId nrxDrugInfoId = new NRxDrugInfoId();
		nrxDrugInfoId.setDrno(ndpRxRecordMappingHelper.getDrugNum());
//		nrxDrugInfoId.setFillNo(Integer.valueOf(orderRecordBdo.getDispNo()));
		nrxDrugInfoId.setFillNo(Integer.valueOf(nrxInvoiceDdo.getDispPhyNo()));

		NRxDrugInfo nrxDrugInfoDdo = nrxDrugInfoDao.getNRxDrugInfoWithUR(nrxDrugInfoId);
		
		if(nrxDrugInfoDdo != null) {
//			ndpRxRecordMappingHelper.setMetricSz(nrxDrugInfoDdo.getMetricSz());
//			ndpRxRecordMappingHelper.setAbuseCd(nrxDrugInfoDdo.getAbuseCd());
//			ndpRxRecordMappingHelper.setDrugNum(EMPTY_STRING);
		}else {
			// send N153
			sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
		}
//		will not be used at all
//		if(Integer.valueOf(nrxDrugInfoDdo.getNdcLab()) > ZERO && 
//		   Integer.valueOf(nrxDrugInfoDdo.getNdcProd()) > ZERO && 
//		   Integer.valueOf(nrxDrugInfoDdo.getNdcSize()) > ZERO) {
//			ndpRxRecordMappingHelper.setMetricSz(nrxDrugInfoDdo.getMetricSz());
//		}
		String ordPartNbr = getOrdPartNbr(nrxInvoiceDdo.getId().getNdiInvno()); 

		NRxRxFinancialId nrxRxFinancialId = new NRxRxFinancialId();
		nrxRxFinancialId.setErxExtInvno(nrxRxInfoDdo.getId().getNdxInvno());
		nrxRxFinancialId.setErxExtRxno(Double.valueOf(nrxRxInfoDdo.getId().getNdxRxno()));
		nrxRxFinancialId.setErxFillNo(nrxRxInfoDdo.getId().getNdxFillNo());
//		nrxRxFinancialId.setErxInvnoSub();
		nrxRxFinancialId.setErxLocaNo(nrxRxInfoDdo.getId().getNdxLocaNo());
		nrxRxFinancialId.setErxPartNbr(Integer.valueOf(ordPartNbr));
		nrxRxFinancialId.setErxRefillNo(nrxRxInfoDdo.getRefillno());

		if(rxIndex == ZERO) {
			rxInfoList = new ArrayList<RxInfoDdo>();
			rxInfoList.addAll(rxDispenseRequestDdo.getRxInfoSet());   // in new PAC ...need to us the directions from the N150 it self
			doctorInfoList = new ArrayList<DoctorInfoDdo>();
			doctorInfoList.addAll(rxDispenseRequestDdo.getDoctorInfos());
		}
		NRxRxFinancial nrxRxFinancialDdo = nrxRxFinancialDao.getNRxRxFinancialInfoWithUR(nrxRxFinancialId);
		if(nrxRxFinancialDdo != null) {
			if(rxInfoList.size() > ZERO && doctorInfoList.size() > ZERO) {
				orderRecordBdo.setMemberId(nrxRxFinancialDdo.getCardholderId());
				ndpRxRecordMappingHelper.setRefillMax(rxInfoList.get(rxIndex).getRefillMax());
				ndpRxRecordMappingHelper.setMdPhoneNum(String.valueOf(doctorInfoList.get(rxIndex).getDrPhoneNum()));
				ndpRxRecordMappingHelper.setDaysSupply(nrxRxFinancialDdo.getDaySupplyQty());
				rxIndex = rxIndex + 1;
				if(rxInfoList.size() == rxIndex || doctorInfoList.size()== rxIndex) {
					
				}
			}
		}else {
			//send N153
			sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
		}
		if(nrxRxInfoDdo.getRefillno() == ZERO) {
//			NS-RX-DATE-LREFILL = 00010101  
//			NS-RX-DATE-FILL = 00010101          // fields not available in PAC  
		} else {
//			NS-RX-DATE-LREFILL (1:4) = ERX-FILL-DTE(1:4)
//			NS-RX-DATE-LREFILL (5:2) = ERX-FILL-DTE(6:2)
//			NS-RX-DATE-LREFILL (7:2) = ERX-FILL-DTE(9:2)     // fields not available in PAC  
			if(nrxRxFinancialDdo.getId().getErxRefillNo() == ZERO) {
				// fields not available in PAC
			} else{
				// fields not available in PAC
			}
		}
		if(nrxInvoiceDdo.getModifiedFlag().equals(NS_ORD_COMM_RES_IND)) {
//			"NS-RX-REPL-INVNO = NS-ORD-INVNO         
//			NS-RX-REPL-INVNO-SUB  = NS-ORD-INVNO-SUB "

		} else {
//			NS-RX-REPL-INVNO = 0
//			NS-RX-REPL-INVNO-SUB = "  "
		}
		ndpRxRecordMappingHelper.setRefillsRemaining(ZERO);					//	********  need to get from the new oracle db table
//		int renewalFlg = Integer.parseInt(nrxRxInfoDdo.getRenewalFlg());
//		if(renewalFlg == ONE || renewalFlg == THREE || renewalFlg == FOUR) {
//			validateEachN150RxWithNRxDB(rxInfoList, nrxRxInfoDdo, ndpRxRecordMappingHelper);
//		}
		ndpRxRecordBdo = new NDPRxRecord();
		
//		PayName1  = N150-PAYNAME1 (ORACLE TABLE FIELD)							********  need to get from the new oracle db table
//		PayAmount1 = N150-PAYAMOUNT1(ORACLE TABLE FIELD)
//		PayName2  = N150-PAYNAME2(ORACLE TABLE FIELD)
//		PayAmount2 = N150-PAYAMOUNT2(ORACLE TABLE FIELD)
//		PayName3  = N150-PAYNAME3 (ORACLE TABLE FIELD)
//		PayAmount3 = N150-PAYAMOUNT3(ORACLE TABLE FIELD)
//		PayName4  = N150-PAYNAME4 (ORACLE TABLE FIELD)
//		PayAmount4 = N150-PAYAMOUNT4(ORACLE TABLE FIELD)
//		PayName5  = N150-PAYNAME5 (ORACLE TABLE FIELD)
//		PayAmount5 = N150-PAYAMOUNT5(ORACLE TABLE FIELD)"

		ndpRxRecordMapping.mapDatabaseToBusinessDomain(ndpRxRecordBdo, nrxRxInfoDdo, nrxRxFinancialDdo, ndpRxRecordMappingHelper);

		/// needs to switch over to the  GET-MANAGED-CARE-RECS
		managedCareBoHelper.packagePacManagedCareData(nrxRxInfoDdo, orderRecordBdo, ndpManagedCareLetterMappingHelper);
//		orderRecordBdo
		if(nrxRxInfoDdo.getNoMcLetters()  != ndpManagedCareLetterMappingHelper.getMclLetterNo()) {
			nrxRxInfoDdo.setNoMcLetters(ndpManagedCareLetterMappingHelper.getMclLetterNo());
			nrxRxInfoDao.updateNDXNoMcLetters(nrxRxInfoDdo.getNoMcLetters(), nrxRxInfoDdo.getId());
		} else {
			//rx records end
		}
		return ndpRxRecordBdo;
	}

//	public void validateEachN150RxWithNRxDB(ArrayList<RxInfoDdo> rxInfoList, NRxRxInfo nrxRxInfoDdo, NDPRxRecordMappingHelper ndpRxRecordMappingHelper) {
//		
//		double ndxRxno = nrxRxInfoDdo.getId().getNdxRxno();
//		int rxRefillsRemaining = 0;
//		boolean RX_FOUND_FLAG = BOOLEAN_FALSE_FLAG;
//		
//		for(RxInfoDdo rxInfoDdo : rxInfoList) {
//			if(rxInfoDdo.getRxNum() == ndxRxno) {
//				rxRefillsRemaining = rxInfoDdo.getRefillMax() - rxInfoDdo.getRxCount();
//				RX_FOUND_FLAG = BOOLEAN_TRUE_FLAG;
//			}
//		}
//		ndpRxRecordMappingHelper.setRefillsRemaining(rxRefillsRemaining);
//	}
	
	// ********************* needs to bring the following from N150 only.........................
	// ********************* needs to bring the following from N150 only.........................
	
	public void getDirections(String directions, NDPRxRecordMappingHelper ndpRxRecordMappingHelper) {

		String directions1 = null, directions2 = null, directions3 = null;

		/**
		 * 	
				NDX-DIRECTIONS FIELD LENGTH IS 144 BYTES. 
				NDX-DIRECTIONS SHOULD BE SPLIT BY 3 WITH 48 BYTES IN EACH FIELD. 
				
				SPLIT SHOULD NOT HAPPEN IN THE MIDDLE OF THE WORD. IF THE SPLIT IS IN THE MIDDLE OF THE WORD, 
				GO BACK TILL PREVIOUS SPACE AND COPY THE CONTENTS TILL PREVIOUS SPACE TO ONE FIELD.
				
				CHECK TO SEE THAT A WORD IS NOT BROKEN IN THE MIDDLE. IF    
				THE END OF THE LINE FALLS WITHIN A WORD THEN FIND WHERE THE 
				WORD BEGINS AND MOVE IT TO THE NEXT LINE.  
				
				TAKE 1 TABLET DAILY                                                                                                                             
				TAKE 1 CAPSULE DAILY                                                                                                                            
				USE ONE INHALATION TWO TIMES A DAY                                                                                                              
				USE 2 SPRAYS IN EACH NOSTRIL DAILY AS NEEDED                                                                                                    
				TAKE 2 CAPSULES DAILY                                                                                                                           
				APPLY AND GENTLY MASSAGE INTO AFFECTED AREA(S) TWICE A DAY                                                                                      
				TAKE 1 TABLET TWICE A DAY                                                                                                                       
				USE AS DIRECTED                                                                                                                                 
				TAKE 1 TABLET EVERY WEEK AS DIRECTED                                                                                                            
				USE 4 PER DAY                                                                                                                                   
				INJECT 72 UNITS IN THE MORNING AND 50 UNITS AT BEDTIME AS DIRECTED                                                                              
				INJECT 60 UNITS IN THE MORNING AND 41 UNITS IN THE EVENING OR AS DIRECTED                                                                       
		 */
		if(directions != null) {
			try {
				directions1 = String.valueOf(directions.subSequence(0, 48));
				directions2 = String.valueOf(directions.subSequence(48, 98));
				directions3 = String.valueOf(directions.subSequence(98, directions.length()));

			} catch(StringIndexOutOfBoundsException exception) { 
				log.error("StringIndexOutOfBoundsException thrown for directions : ", directions);
				log.info("StringIndexOutOfBoundsException Ignored");
			}
			ndpRxRecordMappingHelper.setDirections1(directions1);
			ndpRxRecordMappingHelper.setDirections2(directions2);
			ndpRxRecordMappingHelper.setDirections3(directions3);
		}
	}
}
