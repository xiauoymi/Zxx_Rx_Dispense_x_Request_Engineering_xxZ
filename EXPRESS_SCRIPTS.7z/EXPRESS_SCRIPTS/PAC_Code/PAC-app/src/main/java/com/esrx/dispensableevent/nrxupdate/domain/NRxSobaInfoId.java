package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NRxSobaInfoId implements Serializable{

	private static final long serialVersionUID = 7151751178379424547L;
	private Integer ndsFillNo; 
	private Integer ndsInvno;
	private String ndsInvnoSub;
	private Integer ndsLocaNo;
	private Double ndsRxno;
	private Integer ndsSeqNo;
	
	// Default Constructor
	public NRxSobaInfoId() {
		
	}

	@Column(name = "NDS_FILL_NO")
	public int getNdsFillNo() {
		return ndsFillNo;
	}

	public void setNdsFillNo(int ndsFillNo) {
		this.ndsFillNo = ndsFillNo;
	}

	@Column(name = "NDS_INVNO")
	public int getNdsInvno() {
		return ndsInvno;
	}

	public void setNdsInvno(int ndsInvno) {
		this.ndsInvno = ndsInvno;
	}

	@Column(name = "NDS_INVNO_SUB")
	public String getNdsInvnoSub() {
		return ndsInvnoSub;
	}

	public void setNdsInvnoSub(String ndsInvnoSub) {
		this.ndsInvnoSub = ndsInvnoSub;
	}

	@Column(name = "NDS_LOCA_NO")
	public int getNdsLocaNo() {
		return ndsLocaNo;
	}

	public void setNdsLocaNo(int ndsLocaNo) {
		this.ndsLocaNo = ndsLocaNo;
	}

	@Column(name = "NDS_RXNO")
	public double getNdsRxno() {
		return ndsRxno;
	}

	public void setNdsRxno(double ndsRxno) {
		this.ndsRxno = ndsRxno;
	}

	@Column(name = "NDS_SEQ_NO")
	public int getNdsSeqNo() {
		return ndsSeqNo;
	}

	public void setNdsSeqNo(int ndsSeqNo) {
		this.ndsSeqNo = ndsSeqNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ndsFillNo == null) ? 0 : ndsFillNo.hashCode());
		result = prime * result
				+ ((ndsInvno == null) ? 0 : ndsInvno.hashCode());
		result = prime * result
				+ ((ndsInvnoSub == null) ? 0 : ndsInvnoSub.hashCode());
		result = prime * result
				+ ((ndsLocaNo == null) ? 0 : ndsLocaNo.hashCode());
		result = prime * result + ((ndsRxno == null) ? 0 : ndsRxno.hashCode());
		result = prime * result
				+ ((ndsSeqNo == null) ? 0 : ndsSeqNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NRxSobaInfoId other = (NRxSobaInfoId) obj;
		if (ndsFillNo == null) {
			if (other.ndsFillNo != null)
				return false;
		} else if (!ndsFillNo.equals(other.ndsFillNo))
			return false;
		if (ndsInvno == null) {
			if (other.ndsInvno != null)
				return false;
		} else if (!ndsInvno.equals(other.ndsInvno))
			return false;
		if (ndsInvnoSub == null) {
			if (other.ndsInvnoSub != null)
				return false;
		} else if (!ndsInvnoSub.equals(other.ndsInvnoSub))
			return false;
		if (ndsLocaNo == null) {
			if (other.ndsLocaNo != null)
				return false;
		} else if (!ndsLocaNo.equals(other.ndsLocaNo))
			return false;
		if (ndsRxno == null) {
			if (other.ndsRxno != null)
				return false;
		} else if (!ndsRxno.equals(other.ndsRxno))
			return false;
		if (ndsSeqNo == null) {
			if (other.ndsSeqNo != null)
				return false;
		} else if (!ndsSeqNo.equals(other.ndsSeqNo))
			return false;
		return true;
	}
}