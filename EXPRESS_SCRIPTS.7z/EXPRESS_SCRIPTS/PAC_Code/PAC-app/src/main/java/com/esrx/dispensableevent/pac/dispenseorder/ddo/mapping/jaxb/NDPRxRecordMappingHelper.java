package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.NDPRxRecord;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;

public class NDPRxRecordMappingHelper {

	private int noMcl;						// need to align with N150 and linking to managed care letters also
	private int drugNum;
//	private int botMsgCd;
    private String directions1;
    private String directions2;
    private String directions3;
//    private double metricSz;
//    private String abuseCd;
    private String ndcNum;
    private byte refillMax; 					 /// may not required as such needs to be reviewd once again
    private String mdPhoneNum;                   /// needs to be bring from N150
    private int refillsRemaining;
    private int daysSupply;
    
    private List<NDPRxRecord> ndpRxRecordBdoList;
    private List<NRxRxInfo> prescriptionRecordList;
    
    
	/**
	 * @return the daysSupply
	 */
	public int getDaysSupply() {
		return daysSupply;
	}

	/**
	 * @param daysSupply the daysSupply to set
	 */
	public void setDaysSupply(int daysSupply) {
		this.daysSupply = daysSupply;
	}

	/**
	 * @return the noMcl
	 */
	public int getNoMcl() {
		return noMcl;
	}

	/**
	 * @param noMcl the noMcl to set
	 */
	public void setNoMcl(int noMcl) {
		this.noMcl = noMcl;
	}

	/**
	 * @return the drugNum
	 */
	public int getDrugNum() {
		return drugNum;
	}

	/**
	 * @param drugNum the drugNum to set
	 */
	public void setDrugNum(int drugNum) {
		this.drugNum = drugNum;
	}

//	/**
//	 * @return the botMsgCd
//	 */
//	public int getBotMsgCd() {
//		return botMsgCd;
//	}
//
//	/**
//	 * @param botMsgCd the botMsgCd to set
//	 */
//	public void setBotMsgCd(int botMsgCd) {
//		this.botMsgCd = botMsgCd;
//	}

	/**
	 * @return the directions1
	 */
	public String getDirections1() {
		return directions1;
	}

	/**
	 * @param directions1 the directions1 to set
	 */
	public void setDirections1(String directions1) {
		this.directions1 = directions1;
	}

	/**
	 * @return the directions2
	 */
	public String getDirections2() {
		return directions2;
	}

	/**
	 * @param directions2 the directions2 to set
	 */
	public void setDirections2(String directions2) {
		this.directions2 = directions2;
	}

	/**
	 * @return the directions3
	 */
	public String getDirections3() {
		return directions3;
	}

	/**
	 * @param directions3 the directions3 to set
	 */
	public void setDirections3(String directions3) {
		this.directions3 = directions3;
	}

//	/**
//	 * @return the metricSz
//	 */
//	public double getMetricSz() {
//		return metricSz;
//	}
//
//	/**
//	 * @param metricSz the metricSz to set
//	 */
//	public void setMetricSz(double metricSz) {
//		this.metricSz = metricSz;
//	}

//	/**
//	 * @return the abuseCd
//	 */
//	public String getAbuseCd() {
//		return abuseCd;
//	}
//
//	/**
//	 * @param abuseCd the abuseCd to set
//	 */
//	public void setAbuseCd(String abuseCd) {
//		this.abuseCd = abuseCd;
//	}

	/**
	 * @return the ndcNum
	 */
	public String getNdcNum() {
		return ndcNum;
	}

	/**
	 * @param ndcNum the ndcNum to set
	 */
	public void setNdcNum(String ndcNum) {
		this.ndcNum = ndcNum;
	}

	/**
	 * @return the refillMax
	 */
	public byte getRefillMax() {
		return refillMax;
	}

	/**
	 * @param refillMax the refillMax to set
	 */
	public void setRefillMax(byte refillMax) {
		this.refillMax = refillMax;
	}

	/**
	 * @return the mdPhoneNum
	 */
	public String getMdPhoneNum() {
		return mdPhoneNum;
	}

	/**
	 * @param mdPhoneNum the mdPhoneNum to set
	 */
	public void setMdPhoneNum(String mdPhoneNum) {
		this.mdPhoneNum = mdPhoneNum;
	}

	/**
	 * @return the refillsRemaining
	 */
	public int getRefillsRemaining() {
		return refillsRemaining;
	}

	/**
	 * @param refillsRemaining the refillsRemaining to set
	 */
	public void setRefillsRemaining(int refillsRemaining) {
		this.refillsRemaining = refillsRemaining;
	}

	/**
	 * @return the ndpRxRecordBdoList
	 */
	public List<NDPRxRecord> getNdpRxRecordBdoList() {
		return ndpRxRecordBdoList;
	}

	/**
	 * @param ndpRxRecordBdoList the ndpRxRecordBdoList to set
	 */
	public void setNdpRxRecordBdoList(List<NDPRxRecord> ndpRxRecordBdoList) {
		this.ndpRxRecordBdoList = ndpRxRecordBdoList;
	}

	/**
	 * @return the prescriptionRecordList
	 */
	public List<NRxRxInfo> getPrescriptionRecordList() {
		return prescriptionRecordList;
	}

	/**
	 * @param prescriptionRecordList the prescriptionRecordList to set
	 */
	public void setPrescriptionRecordList(List<NRxRxInfo> prescriptionRecordList) {
		this.prescriptionRecordList = prescriptionRecordList;
	}
	
}
