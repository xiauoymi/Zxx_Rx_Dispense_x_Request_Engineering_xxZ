package com.esrx.dispensableevent.nrxupdate.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * NrxexpeditedshipmentinfoId
 */
@Embeddable
public class NRxExpeditedShipmentInfoId implements java.io.Serializable {

	private static final long serialVersionUID = -8715724344297920900L;

	private String nrxqsiCustno;
	private Integer nrxqsiFillNo;
	private Integer nrxqsiInvno;

	/** default constructor */
	public NRxExpeditedShipmentInfoId() {
	}

	@Column(name = "NRXQSI_CUSTNO", unique = false, nullable = false, insertable = true, updatable = true, length = 18)
	public String getNrxqsiCustno() {
		return this.nrxqsiCustno;
	}

	public void setNrxqsiCustno(String nrxqsiCustno) {
		this.nrxqsiCustno = nrxqsiCustno;
	}

	@Column(name = "NRXQSI_FILL_NO", unique = false, nullable = false, insertable = true, updatable = true, precision = 5, scale = 0)
	public Integer getNrxqsiFillNo() {
		return this.nrxqsiFillNo;
	}

	public void setNrxqsiFillNo(Integer nrxqsiFillNo) {
		this.nrxqsiFillNo = nrxqsiFillNo;
	}

	@Column(name = "NRXQSI_INVNO", unique = false, nullable = false, insertable = true, updatable = true, precision = 10, scale = 0)
	public Integer getNrxqsiInvno() {
		return this.nrxqsiInvno;
	}

	public void setNrxqsiInvno(Integer nrxqsiInvno) {
		this.nrxqsiInvno = nrxqsiInvno;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof NRxExpeditedShipmentInfoId))
			return false;
		NRxExpeditedShipmentInfoId castOther = (NRxExpeditedShipmentInfoId) other;

		return ((this.getNrxqsiCustno() == castOther.getNrxqsiCustno()) || (this
				.getNrxqsiCustno() != null
				&& castOther.getNrxqsiCustno() != null && this
				.getNrxqsiCustno().equals(castOther.getNrxqsiCustno())))
				&& ((this.getNrxqsiFillNo() == castOther.getNrxqsiFillNo()) || (this
						.getNrxqsiFillNo() != null
						&& castOther.getNrxqsiFillNo() != null && this
						.getNrxqsiFillNo().equals(castOther.getNrxqsiFillNo())))
				&& (this.getNrxqsiInvno() == castOther.getNrxqsiInvno());
	}

	public int hashCode() {
		int result = 17;

		result = 37
				* result
				+ (getNrxqsiCustno() == null ? 0 : this.getNrxqsiCustno()
						.hashCode());
		result = 37
				* result
				+ (getNrxqsiFillNo() == null ? 0 : this.getNrxqsiFillNo()
						.hashCode());
		result = 37 * result + (int) this.getNrxqsiInvno();
		return result;
	}

}
