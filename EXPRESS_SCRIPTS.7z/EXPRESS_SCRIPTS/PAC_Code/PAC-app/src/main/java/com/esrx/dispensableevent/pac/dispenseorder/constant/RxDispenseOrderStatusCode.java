/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.pac.dispenseorder.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * The Enum RxDispenseOrderStatusCode.
 */
public enum RxDispenseOrderStatusCode {

	/** The order received. */
	ORDER_RECEIVED(0), 
	
	/** The order system acknowledged. */
	ORDER_SYSTEM_ACKNOWLEDGED(1), 
	
	/** The order processed. */
	ORDER_PROCESSED(2), 
	
	/** The order dispensed. */
	ORDER_DISPENSED(3), 
	
	/** The order duplicate. */
	ORDER_DUPLICATE(5), 
	
	/** The order client acknowledged. */
	ORDER_CLIENT_ACKNOWLEDGED(6), 
	
	/** The order completed. */
	ORDER_COMPLETED(7), 
	
	/** The order abandon. */
	ORDER_ABANDON(8), 
	
	/** The order rejected. */
	ORDER_REJECTED(9);

	/** The order status. */
	int orderStatus;

	/** The Constant statusCodeMap. */
	private static final Map<Integer,RxDispenseOrderStatusCode>  statusCodeMap = new HashMap<Integer,RxDispenseOrderStatusCode>();
	
	static {
		for(RxDispenseOrderStatusCode statusMap : RxDispenseOrderStatusCode.values()) {
			
			statusCodeMap.put(statusMap.orderStatus, statusMap);
		}
	}
	
	/**
	 * Instantiates a new rx dispense order status code.
	 *
	 * @param orderStatus the order status
	 */
	private RxDispenseOrderStatusCode(int orderStatus) {
		this.orderStatus = orderStatus;
	}

	/**
	 * Gets the order status val.
	 *
	 * @return the order status val
	 */
	public int getOrderStatusVal() {
		return orderStatus;
	}

	/**
	 * Gets the order status code.
	 *
	 * @param statusType the status type
	 * @return the order status code
	 */
	public static int getOrderStatusCode(RxDispenseOrderStatusCode statusType) {
		return RxDispenseOrderStatusCode.valueOf(String.valueOf(statusType))
				.getOrderStatusVal();
	}

	/**
	 * Gets the rx dispense order status code.
	 *
	 * @param orderStatus the order status
	 * @return the rx dispense order status code
	 */
	public static RxDispenseOrderStatusCode getRxDispenseOrderStatusCode(int orderStatus) {
		
		return statusCodeMap.get(orderStatus);
	}
	
}
