package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.CORRECTION_SETUP;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.getPacStatusCode;
import static com.esrx.dispensableevent.pac.dispenseorder.util.DateUtil.getCurrentTimestamp;
import static com.esrx.dispensableevent.pac.dispenseorder.util.PacDispenseOrderPartNbrUtil.getOrdPartNbr;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditional;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditionalId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceAdditionalDao;

public class SendN153BoHelper {
	
	private NRxInvoiceAdditionalDao  nrxInvoiceAdditionalDao;
	
	/**
	 * @return the nrxInvoiceAdditionalDao
	 */
	public NRxInvoiceAdditionalDao getNrxInvoiceAdditionalDao() {
		return nrxInvoiceAdditionalDao;
	}




	/**
	 * @param nrxInvoiceAdditionalDao the nrxInvoiceAdditionalDao to set
	 */
	public void setNrxInvoiceAdditionalDao(
			NRxInvoiceAdditionalDao nrxInvoiceAdditionalDao) {
		this.nrxInvoiceAdditionalDao = nrxInvoiceAdditionalDao;
	}




	public void updateNRxInvoiceAdditionalNDPTmsStatusCde(NRxInvoice nrxInvoiceDdo) {
		if(nrxInvoiceDdo != null) {
			NRxInvoiceAdditional nrxInvoiceAdditionalDdo = new NRxInvoiceAdditional();
			NRxInvoiceAdditionalId nrxInvoiceAdditionalId = new NRxInvoiceAdditionalId();
			
			nrxInvoiceAdditionalId.setOrdFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
			nrxInvoiceAdditionalId.setOrdExtInvno(nrxInvoiceDdo.getId().getNdiInvno());
			nrxInvoiceAdditionalId.setOrdPartNbr(Integer.valueOf(getOrdPartNbr(nrxInvoiceDdo.getId().getNdiInvno())));
			nrxInvoiceAdditionalDdo.setStatusCde(String.valueOf(getPacStatusCode(CORRECTION_SETUP)));
			nrxInvoiceAdditionalDdo.setNdpTms(getCurrentTimestamp());
			nrxInvoiceAdditionalDdo.setId(nrxInvoiceAdditionalId);
			
			nrxInvoiceAdditionalDao.updateNDPTmsStatusCde(nrxInvoiceAdditionalDdo);
		}
		
	}
}
