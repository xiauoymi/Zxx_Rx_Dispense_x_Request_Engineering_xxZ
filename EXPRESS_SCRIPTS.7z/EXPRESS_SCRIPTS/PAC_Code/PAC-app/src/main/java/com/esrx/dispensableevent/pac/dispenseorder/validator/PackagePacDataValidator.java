package com.esrx.dispensableevent.pac.dispenseorder.validator;

import java.sql.Timestamp;
import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.INITIAL_SETUP;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.getPacStatusCode;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NDI_VER_NO;

public class PackagePacDataValidator {

	private static final Logger log = LoggerFactory
			.getLogger(PackagePacDataValidator.class);


//	public static NRxInvoice validateNDIVersionNo(boolean ndiVersionNoFlag,
//			NRxInvoice nrxInvoice) {
	public static void validateNDIVersionNo(boolean ndiVersionNoFlag,
			NRxInvoice nrxInvoice) {
		if (!ndiVersionNoFlag) {
			if (nrxInvoice != null) {
				if (nrxInvoice.getVerNo() == NDI_VER_NO) {
					nrxInvoice.setVerNo(getPacStatusCode(INITIAL_SETUP));
				} else {
					int ndiVersionNo = nrxInvoice.getVerNo()
							+ getPacStatusCode(INITIAL_SETUP);
					nrxInvoice.setVerNo(ndiVersionNo);
				}
			}
		}
//		return nrxInvoice;
	}

	public static boolean isNegative(int ndiVersionNo) {
		double ndiVersionNum = ndiVersionNo;
		boolean ndiVersionNoFlag = Double.compare(ndiVersionNum, 0.0) < 0;
		return ndiVersionNoFlag;
	}

}
