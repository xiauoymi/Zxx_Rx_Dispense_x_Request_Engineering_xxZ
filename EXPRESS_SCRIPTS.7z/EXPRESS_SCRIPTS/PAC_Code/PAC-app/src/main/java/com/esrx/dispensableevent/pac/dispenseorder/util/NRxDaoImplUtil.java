package com.esrx.dispensableevent.pac.dispenseorder.util;

import org.hibernate.SessionFactory;
import org.hibernate.engine.SessionFactoryImplementor;

public class NRxDaoImplUtil {

	public static String getDBdefaultSchema(SessionFactory sessionFactory) {
		String dbDefaultSchema = null;
		if(sessionFactory !=null) {
			SessionFactoryImplementor sfi = (SessionFactoryImplementor) sessionFactory;
			dbDefaultSchema = sfi.getSettings().getDefaultSchemaName();
		}
		return dbDefaultSchema;
	}
}
