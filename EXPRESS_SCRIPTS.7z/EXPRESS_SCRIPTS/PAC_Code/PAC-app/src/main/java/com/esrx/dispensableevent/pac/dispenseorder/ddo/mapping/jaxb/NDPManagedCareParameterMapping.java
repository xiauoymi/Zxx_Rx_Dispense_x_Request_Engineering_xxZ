package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.NDPManagedCareParameter;

import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NDP_MANAGED_CARE_PARAMETER_BEGINDELIM;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NDP_MANAGED_CARE_PARAMETER_ENDDELIM;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NDP_MANAGED_CARE_PARAMETER_MIDDELIM;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;

public class NDPManagedCareParameterMapping {

	public void mapDatabaseToBusinessDomain(NDPManagedCareParameter ndpManagedCareParameterBdo, NRxMclInfo nrxMclInfoDdo) {
		ndpManagedCareParameterBdo.setBeginDelim(NDP_MANAGED_CARE_PARAMETER_BEGINDELIM);
		ndpManagedCareParameterBdo.setEndDelim(NDP_MANAGED_CARE_PARAMETER_ENDDELIM);
		ndpManagedCareParameterBdo.setMidDelim(NDP_MANAGED_CARE_PARAMETER_MIDDELIM);
		ndpManagedCareParameterBdo.setParam(EMPTY_STRING);
//		ndpManagedCareParameterBdo.setParamNumber(nrxMclInfoDdo.getS);
		ndpManagedCareParameterBdo.setTag(nrxMclInfoDdo.getVarTag());
		ndpManagedCareParameterBdo.setText(nrxMclInfoDdo.getVarText());
	}
}
