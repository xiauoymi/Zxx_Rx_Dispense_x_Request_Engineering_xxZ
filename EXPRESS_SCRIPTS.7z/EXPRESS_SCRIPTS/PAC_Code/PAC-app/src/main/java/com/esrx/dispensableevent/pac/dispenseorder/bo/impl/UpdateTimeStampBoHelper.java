package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ONE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.QUEUE_DATA_READY;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.getPacStatusCode;
import static com.esrx.dispensableevent.pac.dispenseorder.util.DateUtil.getCurrentTimestamp;
import static com.esrx.dispensableevent.pac.dispenseorder.util.PacDispenseOrderPartNbrUtil.getOrdPartNbr;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditional;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditionalId;
import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceAdditionalDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxMclInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxRxInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxSobaInfoDao;

public class UpdateTimeStampBoHelper {

	private NRxInvoiceDao nrxInvoiceDao;
	private NRxInvoiceAdditionalDao nrxInvoiceAdditionalDao;
	private NRxSobaInfoDao nrxSobaInfoDao;
	private NRxRxInfoDao nrxRxInfoDao;
	private NRxMclInfoDao nrxMclInfoDao;
	/**
	 * @return the nrxInvoiceDao
	 */
	public NRxInvoiceDao getNrxInvoiceDao() {
		return nrxInvoiceDao;
	}


	/**
	 * @param nrxInvoiceDao the nrxInvoiceDao to set
	 */
	public void setNrxInvoiceDao(NRxInvoiceDao nrxInvoiceDao) {
		this.nrxInvoiceDao = nrxInvoiceDao;
	}


	/**
	 * @return the nrxInvoiceAdditionalDao
	 */
	public NRxInvoiceAdditionalDao getNrxInvoiceAdditionalDao() {
		return nrxInvoiceAdditionalDao;
	}


	/**
	 * @param nrxInvoiceAdditionalDao the nrxInvoiceAdditionalDao to set
	 */
	public void setNrxInvoiceAdditionalDao(
			NRxInvoiceAdditionalDao nrxInvoiceAdditionalDao) {
		this.nrxInvoiceAdditionalDao = nrxInvoiceAdditionalDao;
	}


	/**
	 * @return the nrxSobaInfoDao
	 */
	public NRxSobaInfoDao getNrxSobaInfoDao() {
		return nrxSobaInfoDao;
	}


	/**
	 * @param nrxSobaInfoDao the nrxSobaInfoDao to set
	 */
	public void setNrxSobaInfoDao(NRxSobaInfoDao nrxSobaInfoDao) {
		this.nrxSobaInfoDao = nrxSobaInfoDao;
	}


	/**
	 * @return the nrxRxInfoDao
	 */
	public NRxRxInfoDao getNrxRxInfoDao() {
		return nrxRxInfoDao;
	}


	/**
	 * @param nrxRxInfoDao the nrxRxInfoDao to set
	 */
	public void setNrxRxInfoDao(NRxRxInfoDao nrxRxInfoDao) {
		this.nrxRxInfoDao = nrxRxInfoDao;
	}


	/**
	 * @return the nrxMclInfoDao
	 */
	public NRxMclInfoDao getNrxMclInfoDao() {
		return nrxMclInfoDao;
	}


	/**
	 * @param nrxMclInfoDao the nrxMclInfoDao to set
	 */
	public void setNrxMclInfoDao(NRxMclInfoDao nrxMclInfoDao) {
		this.nrxMclInfoDao = nrxMclInfoDao;
	}


	public void updateTimeStampOnPackagePacData(NRxInvoice nrxInvoiceDdo, List<NRxSobaInfo> nrxSobaInfoDdoList, List<NRxRxInfo> nrxRxInfoDdoList, List<NRxMclInfo> nrxMclInfoDdoList) {
		if(nrxInvoiceDdo != null) {
			nrxInvoiceDdo.setRecvErrorCde(ZERO);
			nrxInvoiceDdo.setSendStatus(getPacStatusCode(QUEUE_DATA_READY));
			nrxInvoiceDdo.setSendTms(getCurrentTimestamp());
			
			nrxInvoiceDao.updateNDITimeStatusErrorCode(nrxInvoiceDdo);
			
			NRxInvoiceAdditionalId nrxInvoiceAdditionalId = new NRxInvoiceAdditionalId();
			nrxInvoiceAdditionalId.setOrdFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
			nrxInvoiceAdditionalId.setOrdExtInvno(nrxInvoiceDdo.getId().getNdiInvno());
			nrxInvoiceAdditionalId.setOrdPartNbr(Integer.valueOf(getOrdPartNbr(nrxInvoiceDdo.getId().getNdiInvno())));
			
			NRxInvoiceAdditional nrxInvoiceAdditionalDdo = new NRxInvoiceAdditional();
			nrxInvoiceAdditionalDdo.setId(nrxInvoiceAdditionalId);
			nrxInvoiceAdditionalDdo.setStatusCde(String.valueOf(ONE));
			nrxInvoiceAdditionalDdo.setNdpTms(getCurrentTimestamp());
			nrxInvoiceAdditionalDao.updateNDPTmsStatusCde(nrxInvoiceAdditionalDdo);
			
			if(nrxSobaInfoDdoList != null) {
				for(NRxSobaInfo nrxSobaInfoDdo :  nrxSobaInfoDdoList) {
					nrxSobaInfoDdo.getId().setNdsInvno(nrxInvoiceDdo.getId().getNdiInvno());
					nrxSobaInfoDdo.getId().setNdsFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
					nrxSobaInfoDdo.getId().setNdsInvnoSub(EMPTY_STRING);
					nrxSobaInfoDdo.setSendTms(getCurrentTimestamp());
					nrxSobaInfoDao.updateNDSTimeStamp(nrxSobaInfoDdo);
				}
			}

			if(nrxRxInfoDdoList != null) {
				for(NRxRxInfo nrxRxInfoDdo :  nrxRxInfoDdoList) {
					nrxRxInfoDdo.getId().setNdxInvno(nrxInvoiceDdo.getId().getNdiInvno());
					nrxRxInfoDdo.getId().setNdxFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
					nrxRxInfoDdo.getId().setNdxInvnoSub(nrxInvoiceDdo.getId().getNdiInvnoSub());
					nrxRxInfoDdo.setSendTms(getCurrentTimestamp());
					nrxRxInfoDao.updateNDXSendTimeStamp(nrxRxInfoDdo);
				}
			}

			if(nrxMclInfoDdoList != null) {
				for(NRxMclInfo nrxMclInfoDdo :  nrxMclInfoDdoList) {
					nrxMclInfoDdo.getId().setNdmInvno(nrxInvoiceDdo.getId().getNdiInvno());
					nrxMclInfoDdo.getId().setNdmFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
					nrxMclInfoDdo.getId().setNdmInvnoSub(EMPTY_STRING);
					nrxMclInfoDdo.setSendTms(getCurrentTimestamp());
					nrxMclInfoDao.updateNDMSendTimeStamp(nrxMclInfoDdo);
				}
			}
		}
		
	}
}
