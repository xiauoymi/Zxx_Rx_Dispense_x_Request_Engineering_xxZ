/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * RxDispenseRequestDdo.
 */
@Entity
@Table(name = "TBL_RX_DISPENSE_REQUEST", uniqueConstraints = {})
public class RxDispenseRequestDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

	/** The id. */
	private RxDispenseRequestIdDdo id;
	
	/** The dispense request date. */
	private Timestamp dispenseRequestDate;
	
	/** The bre count. */
	private int breCount;
	
	/** The cre count. */
	private int creCount;
	
	/** The on demand ins1. */
	private int onDemandIns1;
	
	/** The on demand ins2. */
	private int onDemandIns2;
	
	/** The order date. */
	private Timestamp orderDate;
	
	/** The language ind. */
	private String languageInd;
	
	/** The priority ind. */
	private String priorityInd;
	
	/** The cust phone num. */
	private long custPhoneNum;
	
	/** The qa ind. */
	private String qaInd;
	
	/** The qa action code. */
	private Short qaActionCode;
	
	/** The replacement ind. */
	private String replacementInd;
	
	/** The union ind. */
	private String unionInd;
	
	/** The client logo. */
	private String clientLogo;
	
	/** The url ind. */
	private String urlInd;
	
	/** The client url. */
	private String clientUrl;
	
	/** The response url. */
	private String responseUrl;
	
	/** The validate address ind. */
	private String validateAddressInd;
	
	/** The committed ship date. */
	private Timestamp committedShipDate;
	
	/** The dispense txt. */
	private String dispenseTxt;
	
	/** The no charge ind. */
	private String noChargeInd;
	
	/** The client code. */
	private String clientCode;
	
	/** The processing id. */
	private String processingId;
	
	/** The terminal id. */
	private String terminalId;
	
	/** The version number. */
	private String versionNumber;
	
	/** The date of message. */
	private String dateOfMessage;
	
	/** The response flag. */
	private String responseFlag;
	
	/** The character set. */
	private String characterSet;
	
	/** The pl message. */
	private String plMessage;
	
	/** The sending application. */
	private String sendingApplication;
	
	/** The sending facility. */
	private String sendingFacility;
	
	/** The receiving application. */
	private String receivingApplication;
	
	/** The receiving facility. */
	private String receivingFacility;
	
	/** The invoice number. */
	private String invoiceNumber;
	
	/** The order receive date. */
	private Timestamp orderReceiveDate;
	
	/** The order station. */
	private String orderStation;
	
	/** The remit location name. */
	private String remitLocationName;
	
	/** The remit addr line1. */
	private String remitAddrLine1;
	
	/** The remit addr line2. */
	private String remitAddrLine2;
	
	/** The remit city. */
	private String remitCity;
	
	/** The remit state. */
	private String remitState;
	
	/** The remit zip. */
	private String remitZip;
	
	/** The remit country. */
	private String remitCountry;
	
	/** The remit phone num. */
	private Long remitPhoneNum;
	
	/** The summary date. */
	private Timestamp summaryDate;
	
	/** The balance date. */
	private Timestamp balanceDate;
	
	/** The ship charge. */
	private String shipCharge;
	
	/** The summary format. */
	private String summaryFormat;
	
	/** The cc charge. */
	private String ccCharge;
	
	/** The auto charge ind. */
	private String autoChargeInd;
	
	/** The begin balance. */
	private String beginBalance;
	
	/** The payment received. */
	private String paymentReceived;
	
	/** The final balance. */
	private String finalBalance;
	
	/** The total amount due. */
	private BigDecimal totalAmountDue;
	
	/** The credit card type. */
	private String creditCardType;
	
	/** The sub order balance. */
	private BigDecimal subOrderBalance;
	
	/** The sub order total. */
	private Long subOrderTotal;
	
	/** The payment type. */
	private String paymentType;
	
	/** The rx check. */
	private Byte rxCheck;
	
	/** The credit card number. */
	private Long creditCardNumber;
	
	/** The credit card expiration. */
	private Short creditCardExpiration;
	
	/** The credit card approval code. */
	private String creditCardApprovalCode;
	
	/** The manufacturer name. */
	private String manufacturerName;
	
	/** The brand name. */
	private String brandName;
	
	/** The prescribed drug name. */
	private String prescribedDrugName;
	
	/** The generic name. */
	private String genericName;
	
	/** The generic indicator. */
	private String genericIndicator;
	
	/** The drug substitution flag. */
	private String drugSubstitutionFlag;
	
	/** The unit of use. */
	private String unitOfUse;
	
	/** The unit of measure. */
	private String unitOfMeasure;
	
	/** The dosage form. */
	private String dosageForm;
	
	/** The package size. */
	private String packageSize;
	
	/** The upc code. */
	private String upcCode;
	
	/** The pick station. */
	private String pickStation;
	
	/** The location. */
	private String location;
	
	/** The awp. */
	private String awp;
	
	/** The fsahra eligible. */
	private String fsahraEligible;
	
	/** The color. */
	private String color;
	
	/** The pill image. */
	private String pillImage;
	
	/** The shape. */
	private String shape;
	
	/** The imprint. */
	private String imprint;
	
	/** The front imprint. */
	private String frontImprint;
	
	/** The back imprint. */
	private String backImprint;
	
	/** The flavor. */
	private String flavor;
	
	/** The warning message. */
	private String warningMessage;
	
	/** The warning number1. */
	private String warningNumber1;
	
	/** The warning number2. */
	private String warningNumber2;
	
	/** The warning number3. */
	private String warningNumber3;
	
	/** The warning number4. */
	private String warningNumber4;
	
	/** The drug storage condition. */
	private String drugStorageCondition;
	
	/** The drug gpi. */
	private String drugGpi;
	
	/** The drug dea code. */
	private String drugDeaCode;
	
	/** The coverage type. */
	private String coverageType;
	
	/** The patient account. */
	private String patientAccount;
	
	/** The coverage id. */
	private String coverageId;
	
	/** The coverage name. */
	private String coverageName;
	
	/** The coverage plan id. */
	private String coveragePlanId;
	
	/** The cooverage member name. */
	private String cooverageMemberName;
	
	/** The coverage plan group. */
	private String coveragePlanGroup;
	
	/** The coverage priority. */
	private String coveragePriority;
	
	/** The third party amount paid. */
	private BigDecimal thirdPartyAmountPaid;
	
	/** The pharmacy name. */
	private String pharmacyName;
	
	/** The pharmacy addr line1. */
	private String pharmacyAddrLine1;
	
	/** The pharmacy addr line2. */
	private String pharmacyAddrLine2;
	
	/** The pharmacy1. */
	private byte pharmacy1;
	
	/** The pharmacy2. */
	private Byte pharmacy2;
	
	/** The pharmacy3. */
	private Byte pharmacy3;
	
	/** The pharmacy4. */
	private Byte pharmacy4;
	
	/** The pharmacy5. */
	private Byte pharmacy5;
	
	/** The ppharmacy short name. */
	private String ppharmacyShortName;
	
	/** The pharmacy city. */
	private String pharmacyCity;
	
	/** The pharmacy state. */
	private String pharmacyState;
	
	/** The pharmacy country. */
	private String pharmacyCountry;
	
	/** The pharmacy zip. */
	private String pharmacyZip;
	
	/** The pharmacy phone number. */
	private String pharmacyPhoneNumber;
	
	/** The pharmacy nabp. */
	private String pharmacyNabp;
	
	/** The pharmacy dea. */
	private String pharmacyDea;
	
	/** The pharmacy npi. */
	private String pharmacyNpi;
	
	/** The status code. */
	private String statusCode;
	
	/** The status msg. */
	private String statusMsg;
	
	/** The reason code. */
	private String reasonCode;
	
	/** The reason msg. */
	private String reasonMsg;
	
	/** The msg type. */
	private String msgType;
	
	/** The medco trans id. */
	private BigDecimal medcoTransId;
	
	/** The shipping address info set. */
	private Set<ShippingAddressInfoDdo> shippingAddressInfoSet = new HashSet<ShippingAddressInfoDdo>(
			0);
	
	/** The package info set. */
    private Set<PackageInfoDdo> packageInfoSet = new HashSet<PackageInfoDdo>(0);
	
	/** The rx info set. */
	private Set<RxInfoDdo> rxInfoSet = new HashSet<RxInfoDdo>(0);
	
	/** The return address info set. */
	private Set<ReturnAddressInfoDdo> returnAddressInfoSet = new HashSet<ReturnAddressInfoDdo>(
			0);
	
	/** The letter info set. */
	private Set<LetterInfoDdo> letterInfoSet = new HashSet<LetterInfoDdo>(0);
	
	/** The web service info. */
	private WebServiceInfoDdo webServiceInfo;
    
	/** The patient infos. */
	private Set<PatientInfoDdo> patientInfos = new HashSet<PatientInfoDdo>(0);
    
    /** The doctor infos. */
    private Set<DoctorInfoDdo> doctorInfos = new HashSet<DoctorInfoDdo>(0);
	
	/** The status info. */
	private StatusInfoDdo statusInfo;
    
	/**
	 * default constructor.
	 */
	public RxDispenseRequestDdo() {
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = true, updatable = true, precision = 30, scale = 0)),
			@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = true, updatable = true, length = 15)),
			@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = true, updatable = true, precision = 9, scale = 0)),
			@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = true, updatable = true, length = 1))})
	public RxDispenseRequestIdDdo getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(RxDispenseRequestIdDdo id) {
		this.id = id;
	}

	/**
	 * Gets the dispense request date.
	 *
	 * @return the dispense request date
	 */
	@Column(name = "DISPENSE_REQUEST_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 11)
	public Timestamp getDispenseRequestDate() {
		return this.dispenseRequestDate;
	}

	/**
	 * Sets the dispense request date.
	 *
	 * @param dispenseRequestDate the new dispense request date
	 */
	public void setDispenseRequestDate(Timestamp dispenseRequestDate) {
		this.dispenseRequestDate = dispenseRequestDate;
	}

	/**
	 * Gets the bre count.
	 *
	 * @return the bre count
	 */
	@Column(name = "BRE_COUNT", unique = false, nullable = false, insertable = true, updatable = true, precision = 1, scale = 0)
	public int getBreCount() {
		return this.breCount;
	}

	/**
	 * Sets the bre count.
	 *
	 * @param breCount the new bre count
	 */
	public void setBreCount(int breCount) {
		this.breCount = breCount;
	}

	/**
	 * Gets the cre count.
	 *
	 * @return the cre count
	 */
	@Column(name = "CRE_COUNT", unique = false, nullable = false, insertable = true, updatable = true, precision = 1, scale = 0)
	public int getCreCount() {
		return this.creCount;
	}

	/**
	 * Sets the cre count.
	 *
	 * @param creCount the new cre count
	 */
	public void setCreCount(int creCount) {
		this.creCount = creCount;
	}

	/**
	 * Gets the on demand ins1.
	 *
	 * @return the on demand ins1
	 */
	@Column(name = "ON_DEMAND_INS1", unique = false, nullable = true, insertable = true, updatable = true, precision = 1, scale = 0)
	public int getOnDemandIns1() {
		return this.onDemandIns1;
	}

	/**
	 * Sets the on demand ins1.
	 *
	 * @param onDemandIns1 the new on demand ins1
	 */
	public void setOnDemandIns1(int onDemandIns1) {
		this.onDemandIns1 = onDemandIns1;
	}

	/**
	 * Gets the on demand ins2.
	 *
	 * @return the on demand ins2
	 */
	@Column(name = "ON_DEMAND_INS2", unique = false, nullable = true, insertable = true, updatable = true, precision = 1, scale = 0)
	public int getOnDemandIns2() {
		return this.onDemandIns2;
	}

	/**
	 * Sets the on demand ins2.
	 *
	 * @param onDemandIns2 the new on demand ins2
	 */
	public void setOnDemandIns2(int onDemandIns2) {
		this.onDemandIns2 = onDemandIns2;
	}

	/**
	 * Gets the order date.
	 *
	 * @return the order date
	 */
	@Column(name = "ORDER_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Timestamp getOrderDate() {
		return this.orderDate;
	}

	/**
	 * Sets the order date.
	 *
	 * @param orderDate the new order date
	 */
	public void setOrderDate(Timestamp orderDate) {
		this.orderDate = orderDate;
	}

	/**
	 * Gets the language ind.
	 *
	 * @return the language ind
	 */
	@Column(name = "LANGUAGE_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getLanguageInd() {
		return this.languageInd;
	}

	/**
	 * Sets the language ind.
	 *
	 * @param languageInd the new language ind
	 */
	public void setLanguageInd(String languageInd) {
		this.languageInd = languageInd;
	}

	/**
	 * Gets the priority ind.
	 *
	 * @return the priority ind
	 */
	@Column(name = "PRIORITY_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getPriorityInd() {
		return this.priorityInd;
	}

	/**
	 * Sets the priority ind.
	 *
	 * @param priorityInd the new priority ind
	 */
	public void setPriorityInd(String priorityInd) {
		this.priorityInd = priorityInd;
	}

	/**
	 * Gets the cust phone num.
	 *
	 * @return the cust phone num
	 */
	@Column(name = "CUST_PHONE_NUM", unique = false, nullable = false, insertable = true, updatable = true, precision = 10, scale = 0)
	public long getCustPhoneNum() {
		return this.custPhoneNum;
	}

	/**
	 * Sets the cust phone num.
	 *
	 * @param custPhoneNum the new cust phone num
	 */
	public void setCustPhoneNum(long custPhoneNum) {
		this.custPhoneNum = custPhoneNum;
	}

	/**
	 * Gets the qa ind.
	 *
	 * @return the qa ind
	 */
	@Column(name = "QA_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getQaInd() {
		return this.qaInd;
	}

	/**
	 * Sets the qa ind.
	 *
	 * @param qaInd the new qa ind
	 */
	public void setQaInd(String qaInd) {
		this.qaInd = qaInd;
	}

	/**
	 * Gets the qa action code.
	 *
	 * @return the qa action code
	 */
	@Column(name = "QA_ACTION_CODE", unique = false, nullable = true, insertable = true, updatable = true, precision = 4, scale = 0)
	public Short getQaActionCode() {
		return this.qaActionCode;
	}

	/**
	 * Sets the qa action code.
	 *
	 * @param qaActionCode the new qa action code
	 */
	public void setQaActionCode(Short qaActionCode) {
		this.qaActionCode = qaActionCode;
	}

	/**
	 * Gets the replacement ind.
	 *
	 * @return the replacement ind
	 */
	@Column(name = "REPLACEMENT_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getReplacementInd() {
		return this.replacementInd;
	}

	/**
	 * Sets the replacement ind.
	 *
	 * @param replacementInd the new replacement ind
	 */
	public void setReplacementInd(String replacementInd) {
		this.replacementInd = replacementInd;
	}

	/**
	 * Gets the union ind.
	 *
	 * @return the union ind
	 */
	@Column(name = "UNION_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getUnionInd() {
		return this.unionInd;
	}

	/**
	 * Sets the union ind.
	 *
	 * @param unionInd the new union ind
	 */
	public void setUnionInd(String unionInd) {
		this.unionInd = unionInd;
	}

	/**
	 * Gets the client logo.
	 *
	 * @return the client logo
	 */
	@Column(name = "CLIENT_LOGO", unique = false, nullable = false, insertable = true, updatable = true, length = 8)
	public String getClientLogo() {
		return this.clientLogo;
	}

	/**
	 * Sets the client logo.
	 *
	 * @param clientLogo the new client logo
	 */
	public void setClientLogo(String clientLogo) {
		this.clientLogo = clientLogo;
	}

	/**
	 * Gets the url ind.
	 *
	 * @return the url ind
	 */
	@Column(name = "URL_IND", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public String getUrlInd() {
		return this.urlInd;
	}

	/**
	 * Sets the url ind.
	 *
	 * @param urlInd the new url ind
	 */
	public void setUrlInd(String urlInd) {
		this.urlInd = urlInd;
	}

	/**
	 * Gets the client url.
	 *
	 * @return the client url
	 */
	@Column(name = "CLIENT_URL", unique = false, nullable = false, insertable = true, updatable = true, length = 50)
	public String getClientUrl() {
		return this.clientUrl;
	}

	/**
	 * Sets the client url.
	 *
	 * @param clientUrl the new client url
	 */
	public void setClientUrl(String clientUrl) {
		this.clientUrl = clientUrl;
	}

	/**
	 * Gets the response url.
	 *
	 * @return the response url
	 */
	@Column(name = "RESPONSE_URL", unique = false, nullable = true, insertable = true, updatable = true, length = 200)
	public String getResponseUrl() {
		return this.responseUrl;
	}

	/**
	 * Sets the response url.
	 *
	 * @param responseUrl the new response url
	 */
	public void setResponseUrl(String responseUrl) {
		this.responseUrl = responseUrl;
	}

	/**
	 * Gets the validate address ind.
	 *
	 * @return the validate address ind
	 */
	@Column(name = "VALIDATE_ADDRESS_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getValidateAddressInd() {
		return this.validateAddressInd;
	}

	/**
	 * Sets the validate address ind.
	 *
	 * @param validateAddressInd the new validate address ind
	 */
	public void setValidateAddressInd(String validateAddressInd) {
		this.validateAddressInd = validateAddressInd;
	}

	/**
	 * Gets the committed ship date.
	 *
	 * @return the committed ship date
	 */
	@Column(name = "COMMITTED_SHIP_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getCommittedShipDate() {
		return this.committedShipDate;
	}

	/**
	 * Sets the committed ship date.
	 *
	 * @param committedShipDate the new committed ship date
	 */
	public void setCommittedShipDate(Timestamp committedShipDate) {
		this.committedShipDate = committedShipDate;
	}

	/**
	 * Gets the dispense txt.
	 *
	 * @return the dispense txt
	 */
	@Column(name = "DISPENSE_TXT", unique = false, nullable = true, insertable = true, updatable = true, length = 180)
	public String getDispenseTxt() {
		return this.dispenseTxt;
	}

	/**
	 * Sets the dispense txt.
	 *
	 * @param dispenseTxt the new dispense txt
	 */
	public void setDispenseTxt(String dispenseTxt) {
		this.dispenseTxt = dispenseTxt;
	}

	/**
	 * Gets the no charge ind.
	 *
	 * @return the no charge ind
	 */
	@Column(name = "NO_CHARGE_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 2)
	public String getNoChargeInd() {
		return this.noChargeInd;
	}

	/**
	 * Sets the no charge ind.
	 *
	 * @param noChargeInd the new no charge ind
	 */
	public void setNoChargeInd(String noChargeInd) {
		this.noChargeInd = noChargeInd;
	}

	/**
	 * Gets the client code.
	 *
	 * @return the client code
	 */
	@Column(name = "CLIENT_CODE", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getClientCode() {
		return this.clientCode;
	}

	/**
	 * Sets the client code.
	 *
	 * @param clientCode the new client code
	 */
	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	/**
	 * Gets the processing id.
	 *
	 * @return the processing id
	 */
	@Column(name = "PROCESSING_ID", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getProcessingId() {
		return this.processingId;
	}

	/**
	 * Sets the processing id.
	 *
	 * @param processingId the new processing id
	 */
	public void setProcessingId(String processingId) {
		this.processingId = processingId;
	}

	/**
	 * Gets the terminal id.
	 *
	 * @return the terminal id
	 */
	@Column(name = "TERMINAL_ID", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getTerminalId() {
		return this.terminalId;
	}

	/**
	 * Sets the terminal id.
	 *
	 * @param terminalId the new terminal id
	 */
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	/**
	 * Gets the version number.
	 *
	 * @return the version number
	 */
	@Column(name = "VERSION_NUMBER", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getVersionNumber() {
		return this.versionNumber;
	}

	/**
	 * Sets the version number.
	 *
	 * @param versionNumber the new version number
	 */
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}

	/**
	 * Gets the date of message.
	 *
	 * @return the date of message
	 */
	@Column(name = "DATE_OF_MESSAGE", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getDateOfMessage() {
		return this.dateOfMessage;
	}

	/**
	 * Sets the date of message.
	 *
	 * @param dateOfMessage the new date of message
	 */
	public void setDateOfMessage(String dateOfMessage) {
		this.dateOfMessage = dateOfMessage;
	}

	/**
	 * Gets the response flag.
	 *
	 * @return the response flag
	 */
	@Column(name = "RESPONSE_FLAG", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getResponseFlag() {
		return this.responseFlag;
	}

	/**
	 * Sets the response flag.
	 *
	 * @param responseFlag the new response flag
	 */
	public void setResponseFlag(String responseFlag) {
		this.responseFlag = responseFlag;
	}

	/**
	 * Gets the character set.
	 *
	 * @return the character set
	 */
	@Column(name = "CHARACTER_SET", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getCharacterSet() {
		return this.characterSet;
	}

	/**
	 * Sets the character set.
	 *
	 * @param characterSet the new character set
	 */
	public void setCharacterSet(String characterSet) {
		this.characterSet = characterSet;
	}

	/**
	 * Gets the pl message.
	 *
	 * @return the pl message
	 */
	@Column(name = "PL_MESSAGE", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getPlMessage() {
		return this.plMessage;
	}

	/**
	 * Sets the pl message.
	 *
	 * @param plMessage the new pl message
	 */
	public void setPlMessage(String plMessage) {
		this.plMessage = plMessage;
	}

	/**
	 * Gets the sending application.
	 *
	 * @return the sending application
	 */
	@Column(name = "SENDING_APPLICATION", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getSendingApplication() {
		return this.sendingApplication;
	}

	/**
	 * Sets the sending application.
	 *
	 * @param sendingApplication the new sending application
	 */
	public void setSendingApplication(String sendingApplication) {
		this.sendingApplication = sendingApplication;
	}

	/**
	 * Gets the sending facility.
	 *
	 * @return the sending facility
	 */
	@Column(name = "SENDING_FACILITY", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getSendingFacility() {
		return this.sendingFacility;
	}

	/**
	 * Sets the sending facility.
	 *
	 * @param sendingFacility the new sending facility
	 */
	public void setSendingFacility(String sendingFacility) {
		this.sendingFacility = sendingFacility;
	}

	/**
	 * Gets the receiving application.
	 *
	 * @return the receiving application
	 */
	@Column(name = "RECEIVING_APPLICATION", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getReceivingApplication() {
		return this.receivingApplication;
	}

	/**
	 * Sets the receiving application.
	 *
	 * @param receivingApplication the new receiving application
	 */
	public void setReceivingApplication(String receivingApplication) {
		this.receivingApplication = receivingApplication;
	}

	/**
	 * Gets the receiving facility.
	 *
	 * @return the receiving facility
	 */
	@Column(name = "RECEIVING_FACILITY", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getReceivingFacility() {
		return this.receivingFacility;
	}

	/**
	 * Sets the receiving facility.
	 *
	 * @param receivingFacility the new receiving facility
	 */
	public void setReceivingFacility(String receivingFacility) {
		this.receivingFacility = receivingFacility;
	}

	/**
	 * Gets the invoice number.
	 *
	 * @return the invoice number
	 */
	@Column(name = "INVOICE_NUMBER", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getInvoiceNumber() {
		return this.invoiceNumber;
	}

	/**
	 * Sets the invoice number.
	 *
	 * @param invoiceNumber the new invoice number
	 */
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	/**
	 * Gets the order receive date.
	 *
	 * @return the order receive date
	 */
	@Column(name = "ORDER_RECEIVE_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getOrderReceiveDate() {
		return this.orderReceiveDate;
	}

	/**
	 * Sets the order receive date.
	 *
	 * @param orderReceiveDate the new order receive date
	 */
	public void setOrderReceiveDate(Timestamp orderReceiveDate) {
		this.orderReceiveDate = orderReceiveDate;
	}

	/**
	 * Gets the order station.
	 *
	 * @return the order station
	 */
	@Column(name = "ORDER_STATION", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getOrderStation() {
		return this.orderStation;
	}

	/**
	 * Sets the order station.
	 *
	 * @param orderStation the new order station
	 */
	public void setOrderStation(String orderStation) {
		this.orderStation = orderStation;
	}

	/**
	 * Gets the remit location name.
	 *
	 * @return the remit location name
	 */
	@Column(name = "REMIT_LOCATION_NAME", unique = false, nullable = false, insertable = true, updatable = true, length = 40)
	public String getRemitLocationName() {
		return this.remitLocationName;
	}

	/**
	 * Sets the remit location name.
	 *
	 * @param remitLocationName the new remit location name
	 */
	public void setRemitLocationName(String remitLocationName) {
		this.remitLocationName = remitLocationName;
	}

	/**
	 * Gets the remit addr line1.
	 *
	 * @return the remit addr line1
	 */
	@Column(name = "REMIT_ADDR_LINE1", unique = false, nullable = false, insertable = true, updatable = true, length = 25)
	public String getRemitAddrLine1() {
		return this.remitAddrLine1;
	}

	/**
	 * Sets the remit addr line1.
	 *
	 * @param remitAddrLine1 the new remit addr line1
	 */
	public void setRemitAddrLine1(String remitAddrLine1) {
		this.remitAddrLine1 = remitAddrLine1;
	}

	/**
	 * Gets the remit addr line2.
	 *
	 * @return the remit addr line2
	 */
	@Column(name = "REMIT_ADDR_LINE2", unique = false, nullable = false, insertable = true, updatable = true, length = 25)
	public String getRemitAddrLine2() {
		return this.remitAddrLine2;
	}

	/**
	 * Sets the remit addr line2.
	 *
	 * @param remitAddrLine2 the new remit addr line2
	 */
	public void setRemitAddrLine2(String remitAddrLine2) {
		this.remitAddrLine2 = remitAddrLine2;
	}

	/**
	 * Gets the remit city.
	 *
	 * @return the remit city
	 */
	@Column(name = "REMIT_CITY", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getRemitCity() {
		return this.remitCity;
	}

	/**
	 * Sets the remit city.
	 *
	 * @param remitCity the new remit city
	 */
	public void setRemitCity(String remitCity) {
		this.remitCity = remitCity;
	}

	/**
	 * Gets the remit state.
	 *
	 * @return the remit state
	 */
	@Column(name = "REMIT_STATE", unique = false, nullable = true, insertable = true, updatable = true, length = 2)
	public String getRemitState() {
		return this.remitState;
	}

	/**
	 * Sets the remit state.
	 *
	 * @param remitState the new remit state
	 */
	public void setRemitState(String remitState) {
		this.remitState = remitState;
	}

	/**
	 * Gets the remit zip.
	 *
	 * @return the remit zip
	 */
	@Column(name = "REMIT_ZIP", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getRemitZip() {
		return this.remitZip;
	}

	/**
	 * Sets the remit zip.
	 *
	 * @param remitZip the new remit zip
	 */
	public void setRemitZip(String remitZip) {
		this.remitZip = remitZip;
	}

	/**
	 * Gets the remit country.
	 *
	 * @return the remit country
	 */
	@Column(name = "REMIT_COUNTRY", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getRemitCountry() {
		return this.remitCountry;
	}

	/**
	 * Sets the remit country.
	 *
	 * @param remitCountry the new remit country
	 */
	public void setRemitCountry(String remitCountry) {
		this.remitCountry = remitCountry;
	}

	/**
	 * Gets the remit phone num.
	 *
	 * @return the remit phone num
	 */
	@Column(name = "REMIT_PHONE_NUM", unique = false, nullable = true, insertable = true, updatable = true, precision = 10, scale = 0)
	public Long getRemitPhoneNum() {
		return this.remitPhoneNum;
	}

	/**
	 * Sets the remit phone num.
	 *
	 * @param remitPhoneNum the new remit phone num
	 */
	public void setRemitPhoneNum(Long remitPhoneNum) {
		this.remitPhoneNum = remitPhoneNum;
	}

	/**
	 * Gets the summary date.
	 *
	 * @return the summary date
	 */
	@Column(name = "SUMMARY_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Timestamp getSummaryDate() {
		return this.summaryDate;
	}

	/**
	 * Sets the summary date.
	 *
	 * @param summaryDate the new summary date
	 */
	public void setSummaryDate(Timestamp summaryDate) {
		this.summaryDate = summaryDate;
	}

	/**
	 * Gets the balance date.
	 *
	 * @return the balance date
	 */
	@Column(name = "BALANCE_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Timestamp getBalanceDate() {
		return this.balanceDate;
	}

	/**
	 * Sets the balance date.
	 *
	 * @param balanceDate the new balance date
	 */
	public void setBalanceDate(Timestamp balanceDate) {
		this.balanceDate = balanceDate;
	}

	/**
	 * Gets the ship charge.
	 *
	 * @return the ship charge
	 */
	@Column(name = "SHIP_CHARGE", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getShipCharge() {
		return this.shipCharge;
	}

	/**
	 * Sets the ship charge.
	 *
	 * @param shipCharge the new ship charge
	 */
	public void setShipCharge(String shipCharge) {
		this.shipCharge = shipCharge;
	}

	/**
	 * Gets the summary format.
	 *
	 * @return the summary format
	 */
	@Column(name = "SUMMARY_FORMAT", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public String getSummaryFormat() {
		return this.summaryFormat;
	}

	/**
	 * Sets the summary format.
	 *
	 * @param summaryFormat the new summary format
	 */
	public void setSummaryFormat(String summaryFormat) {
		this.summaryFormat = summaryFormat;
	}

	/**
	 * Gets the cc charge.
	 *
	 * @return the cc charge
	 */
	@Column(name = "CC_CHARGE", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getCcCharge() {
		return this.ccCharge;
	}

	/**
	 * Sets the cc charge.
	 *
	 * @param ccCharge the new cc charge
	 */
	public void setCcCharge(String ccCharge) {
		this.ccCharge = ccCharge;
	}

	/**
	 * Gets the auto charge ind.
	 *
	 * @return the auto charge ind
	 */
	@Column(name = "AUTO_CHARGE_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getAutoChargeInd() {
		return this.autoChargeInd;
	}

	/**
	 * Sets the auto charge ind.
	 *
	 * @param autoChargeInd the new auto charge ind
	 */
	public void setAutoChargeInd(String autoChargeInd) {
		this.autoChargeInd = autoChargeInd;
	}

	/**
	 * Gets the begin balance.
	 *
	 * @return the begin balance
	 */
	@Column(name = "BEGIN_BALANCE", unique = false, nullable = false, insertable = true, updatable = true, length = 10)
	public String getBeginBalance() {
		return this.beginBalance;
	}

	/**
	 * Sets the begin balance.
	 *
	 * @param beginBalance the new begin balance
	 */
	public void setBeginBalance(String beginBalance) {
		this.beginBalance = beginBalance;
	}

	/**
	 * Gets the payment received.
	 *
	 * @return the payment received
	 */
	@Column(name = "PAYMENT_RECEIVED", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getPaymentReceived() {
		return this.paymentReceived;
	}

	/**
	 * Sets the payment received.
	 *
	 * @param paymentReceived the new payment received
	 */
	public void setPaymentReceived(String paymentReceived) {
		this.paymentReceived = paymentReceived;
	}

	/**
	 * Gets the final balance.
	 *
	 * @return the final balance
	 */
	@Column(name = "FINAL_BALANCE", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getFinalBalance() {
		return this.finalBalance;
	}

	/**
	 * Sets the final balance.
	 *
	 * @param finalBalance the new final balance
	 */
	public void setFinalBalance(String finalBalance) {
		this.finalBalance = finalBalance;
	}

	/**
	 * Gets the total amount due.
	 *
	 * @return the total amount due
	 */
	@Column(name = "TOTAL_AMOUNT_DUE", unique = false, nullable = true, insertable = true, updatable = true, precision = 7)
	public BigDecimal getTotalAmountDue() {
		return this.totalAmountDue;
	}

	/**
	 * Sets the total amount due.
	 *
	 * @param totalAmountDue the new total amount due
	 */
	public void setTotalAmountDue(BigDecimal totalAmountDue) {
		this.totalAmountDue = totalAmountDue;
	}

	/**
	 * Gets the credit card type.
	 *
	 * @return the credit card type
	 */
	@Column(name = "CREDIT_CARD_TYPE", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getCreditCardType() {
		return this.creditCardType;
	}

	/**
	 * Sets the credit card type.
	 *
	 * @param creditCardType the new credit card type
	 */
	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}

	/**
	 * Gets the sub order balance.
	 *
	 * @return the sub order balance
	 */
	@Column(name = "SUB_ORDER_BALANCE", unique = false, nullable = true, insertable = true, updatable = true, precision = 7)
	public BigDecimal getSubOrderBalance() {
		return this.subOrderBalance;
	}

	/**
	 * Sets the sub order balance.
	 *
	 * @param subOrderBalance the new sub order balance
	 */
	public void setSubOrderBalance(BigDecimal subOrderBalance) {
		this.subOrderBalance = subOrderBalance;
	}

	/**
	 * Gets the sub order total.
	 *
	 * @return the sub order total
	 */
	@Column(name = "SUB_ORDER_TOTAL", unique = false, nullable = true, insertable = true, updatable = true, precision = 10, scale = 0)
	public Long getSubOrderTotal() {
		return this.subOrderTotal;
	}

	/**
	 * Sets the sub order total.
	 *
	 * @param subOrderTotal the new sub order total
	 */
	public void setSubOrderTotal(Long subOrderTotal) {
		this.subOrderTotal = subOrderTotal;
	}

	/**
	 * Gets the payment type.
	 *
	 * @return the payment type
	 */
	@Column(name = "PAYMENT_TYPE", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getPaymentType() {
		return this.paymentType;
	}

	/**
	 * Sets the payment type.
	 *
	 * @param paymentType the new payment type
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * Gets the rx check.
	 *
	 * @return the rx check
	 */
	@Column(name = "RX_CHECK", unique = false, nullable = true, insertable = true, updatable = true, precision = 2, scale = 0)
	public Byte getRxCheck() {
		return this.rxCheck;
	}

	/**
	 * Sets the rx check.
	 *
	 * @param rxCheck the new rx check
	 */
	public void setRxCheck(Byte rxCheck) {
		this.rxCheck = rxCheck;
	}

	/**
	 * Gets the credit card number.
	 *
	 * @return the credit card number
	 */
	@Column(name = "CREDIT_CARD_NUMBER", unique = false, nullable = true, insertable = true, updatable = true, precision = 16, scale = 0)
	public Long getCreditCardNumber() {
		return this.creditCardNumber;
	}

	/**
	 * Sets the credit card number.
	 *
	 * @param creditCardNumber the new credit card number
	 */
	public void setCreditCardNumber(Long creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	/**
	 * Gets the credit card expiration.
	 *
	 * @return the credit card expiration
	 */
	@Column(name = "CREDIT_CARD_EXPIRATION", unique = false, nullable = true, insertable = true, updatable = true, precision = 4, scale = 0)
	public Short getCreditCardExpiration() {
		return this.creditCardExpiration;
	}

	/**
	 * Sets the credit card expiration.
	 *
	 * @param creditCardExpiration the new credit card expiration
	 */
	public void setCreditCardExpiration(Short creditCardExpiration) {
		this.creditCardExpiration = creditCardExpiration;
	}

	/**
	 * Gets the credit card approval code.
	 *
	 * @return the credit card approval code
	 */
	@Column(name = "CREDIT_CARD_APPROVAL_CODE", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getCreditCardApprovalCode() {
		return this.creditCardApprovalCode;
	}

	/**
	 * Sets the credit card approval code.
	 *
	 * @param creditCardApprovalCode the new credit card approval code
	 */
	public void setCreditCardApprovalCode(String creditCardApprovalCode) {
		this.creditCardApprovalCode = creditCardApprovalCode;
	}

	/**
	 * Gets the manufacturer name.
	 *
	 * @return the manufacturer name
	 */
	@Column(name = "MANUFACTURER_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getManufacturerName() {
		return this.manufacturerName;
	}

	/**
	 * Sets the manufacturer name.
	 *
	 * @param manufacturerName the new manufacturer name
	 */
	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}

	/**
	 * Gets the brand name.
	 *
	 * @return the brand name
	 */
	@Column(name = "BRAND_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getBrandName() {
		return this.brandName;
	}

	/**
	 * Sets the brand name.
	 *
	 * @param brandName the new brand name
	 */
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	/**
	 * Gets the prescribed drug name.
	 *
	 * @return the prescribed drug name
	 */
	@Column(name = "PRESCRIBED_DRUG_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getPrescribedDrugName() {
		return this.prescribedDrugName;
	}

	/**
	 * Sets the prescribed drug name.
	 *
	 * @param prescribedDrugName the new prescribed drug name
	 */
	public void setPrescribedDrugName(String prescribedDrugName) {
		this.prescribedDrugName = prescribedDrugName;
	}

	/**
	 * Gets the generic name.
	 *
	 * @return the generic name
	 */
	@Column(name = "GENERIC_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getGenericName() {
		return this.genericName;
	}

	/**
	 * Sets the generic name.
	 *
	 * @param genericName the new generic name
	 */
	public void setGenericName(String genericName) {
		this.genericName = genericName;
	}

	/**
	 * Gets the generic indicator.
	 *
	 * @return the generic indicator
	 */
	@Column(name = "GENERIC_INDICATOR", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getGenericIndicator() {
		return this.genericIndicator;
	}

	/**
	 * Sets the generic indicator.
	 *
	 * @param genericIndicator the new generic indicator
	 */
	public void setGenericIndicator(String genericIndicator) {
		this.genericIndicator = genericIndicator;
	}

	/**
	 * Gets the drug substitution flag.
	 *
	 * @return the drug substitution flag
	 */
	@Column(name = "DRUG_SUBSTITUTION_FLAG", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getDrugSubstitutionFlag() {
		return this.drugSubstitutionFlag;
	}

	/**
	 * Sets the drug substitution flag.
	 *
	 * @param drugSubstitutionFlag the new drug substitution flag
	 */
	public void setDrugSubstitutionFlag(String drugSubstitutionFlag) {
		this.drugSubstitutionFlag = drugSubstitutionFlag;
	}

	/**
	 * Gets the unit of use.
	 *
	 * @return the unit of use
	 */
	@Column(name = "UNIT_OF_USE", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getUnitOfUse() {
		return this.unitOfUse;
	}

	/**
	 * Sets the unit of use.
	 *
	 * @param unitOfUse the new unit of use
	 */
	public void setUnitOfUse(String unitOfUse) {
		this.unitOfUse = unitOfUse;
	}

	/**
	 * Gets the unit of measure.
	 *
	 * @return the unit of measure
	 */
	@Column(name = "UNIT_OF_MEASURE", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getUnitOfMeasure() {
		return this.unitOfMeasure;
	}

	/**
	 * Sets the unit of measure.
	 *
	 * @param unitOfMeasure the new unit of measure
	 */
	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	/**
	 * Gets the dosage form.
	 *
	 * @return the dosage form
	 */
	@Column(name = "DOSAGE_FORM", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getDosageForm() {
		return this.dosageForm;
	}

	/**
	 * Sets the dosage form.
	 *
	 * @param dosageForm the new dosage form
	 */
	public void setDosageForm(String dosageForm) {
		this.dosageForm = dosageForm;
	}

	/**
	 * Gets the package size.
	 *
	 * @return the package size
	 */
	@Column(name = "PACKAGE_SIZE", unique = false, nullable = true, insertable = true, updatable = true, length = 5)
	public String getPackageSize() {
		return this.packageSize;
	}

	/**
	 * Sets the package size.
	 *
	 * @param packageSize the new package size
	 */
	public void setPackageSize(String packageSize) {
		this.packageSize = packageSize;
	}

	/**
	 * Gets the upc code.
	 *
	 * @return the upc code
	 */
	@Column(name = "UPC_CODE", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getUpcCode() {
		return this.upcCode;
	}

	/**
	 * Sets the upc code.
	 *
	 * @param upcCode the new upc code
	 */
	public void setUpcCode(String upcCode) {
		this.upcCode = upcCode;
	}

	/**
	 * Gets the pick station.
	 *
	 * @return the pick station
	 */
	@Column(name = "PICK_STATION", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getPickStation() {
		return this.pickStation;
	}

	/**
	 * Sets the pick station.
	 *
	 * @param pickStation the new pick station
	 */
	public void setPickStation(String pickStation) {
		this.pickStation = pickStation;
	}

	/**
	 * Gets the location.
	 *
	 * @return the location
	 */
	@Column(name = "LOCATION", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getLocation() {
		return this.location;
	}

	/**
	 * Sets the location.
	 *
	 * @param location the new location
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * Gets the awp.
	 *
	 * @return the awp
	 */
	@Column(name = "AWP", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getAwp() {
		return this.awp;
	}

	/**
	 * Sets the awp.
	 *
	 * @param awp the new awp
	 */
	public void setAwp(String awp) {
		this.awp = awp;
	}

	/**
	 * Gets the fsahra eligible.
	 *
	 * @return the fsahra eligible
	 */
	@Column(name = "FSAHRA_ELIGIBLE", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getFsahraEligible() {
		return this.fsahraEligible;
	}

	/**
	 * Sets the fsahra eligible.
	 *
	 * @param fsahraEligible the new fsahra eligible
	 */
	public void setFsahraEligible(String fsahraEligible) {
		this.fsahraEligible = fsahraEligible;
	}

	/**
	 * Gets the color.
	 *
	 * @return the color
	 */
	@Column(name = "COLOR", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getColor() {
		return this.color;
	}

	/**
	 * Sets the color.
	 *
	 * @param color the new color
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * Gets the pill image.
	 *
	 * @return the pill image
	 */
	@Column(name = "PILL_IMAGE", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getPillImage() {
		return this.pillImage;
	}

	/**
	 * Sets the pill image.
	 *
	 * @param pillImage the new pill image
	 */
	public void setPillImage(String pillImage) {
		this.pillImage = pillImage;
	}

	/**
	 * Gets the shape.
	 *
	 * @return the shape
	 */
	@Column(name = "SHAPE", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getShape() {
		return this.shape;
	}

	/**
	 * Sets the shape.
	 *
	 * @param shape the new shape
	 */
	public void setShape(String shape) {
		this.shape = shape;
	}

	/**
	 * Gets the imprint.
	 *
	 * @return the imprint
	 */
	@Column(name = "IMPRINT", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getImprint() {
		return this.imprint;
	}

	/**
	 * Sets the imprint.
	 *
	 * @param imprint the new imprint
	 */
	public void setImprint(String imprint) {
		this.imprint = imprint;
	}

	/**
	 * Gets the front imprint.
	 *
	 * @return the front imprint
	 */
	@Column(name = "FRONT_IMPRINT", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getFrontImprint() {
		return this.frontImprint;
	}

	/**
	 * Sets the front imprint.
	 *
	 * @param frontImprint the new front imprint
	 */
	public void setFrontImprint(String frontImprint) {
		this.frontImprint = frontImprint;
	}

	/**
	 * Gets the back imprint.
	 *
	 * @return the back imprint
	 */
	@Column(name = "BACK_IMPRINT", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getBackImprint() {
		return this.backImprint;
	}

	/**
	 * Sets the back imprint.
	 *
	 * @param backImprint the new back imprint
	 */
	public void setBackImprint(String backImprint) {
		this.backImprint = backImprint;
	}

	/**
	 * Gets the flavor.
	 *
	 * @return the flavor
	 */
	@Column(name = "FLAVOR", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getFlavor() {
		return this.flavor;
	}

	/**
	 * Sets the flavor.
	 *
	 * @param flavor the new flavor
	 */
	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}

	/**
	 * Gets the warning message.
	 *
	 * @return the warning message
	 */
	@Column(name = "WARNING_MESSAGE", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getWarningMessage() {
		return this.warningMessage;
	}

	/**
	 * Sets the warning message.
	 *
	 * @param warningMessage the new warning message
	 */
	public void setWarningMessage(String warningMessage) {
		this.warningMessage = warningMessage;
	}

	/**
	 * Gets the warning number1.
	 *
	 * @return the warning number1
	 */
	@Column(name = "WARNING_NUMBER1", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getWarningNumber1() {
		return this.warningNumber1;
	}

	/**
	 * Sets the warning number1.
	 *
	 * @param warningNumber1 the new warning number1
	 */
	public void setWarningNumber1(String warningNumber1) {
		this.warningNumber1 = warningNumber1;
	}

	/**
	 * Gets the warning number2.
	 *
	 * @return the warning number2
	 */
	@Column(name = "WARNING_NUMBER2", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getWarningNumber2() {
		return this.warningNumber2;
	}

	/**
	 * Sets the warning number2.
	 *
	 * @param warningNumber2 the new warning number2
	 */
	public void setWarningNumber2(String warningNumber2) {
		this.warningNumber2 = warningNumber2;
	}

	/**
	 * Gets the warning number3.
	 *
	 * @return the warning number3
	 */
	@Column(name = "WARNING_NUMBER3", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getWarningNumber3() {
		return this.warningNumber3;
	}

	/**
	 * Sets the warning number3.
	 *
	 * @param warningNumber3 the new warning number3
	 */
	public void setWarningNumber3(String warningNumber3) {
		this.warningNumber3 = warningNumber3;
	}

	/**
	 * Gets the warning number4.
	 *
	 * @return the warning number4
	 */
	@Column(name = "WARNING_NUMBER4", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getWarningNumber4() {
		return this.warningNumber4;
	}

	/**
	 * Sets the warning number4.
	 *
	 * @param warningNumber4 the new warning number4
	 */
	public void setWarningNumber4(String warningNumber4) {
		this.warningNumber4 = warningNumber4;
	}

	/**
	 * Gets the drug storage condition.
	 *
	 * @return the drug storage condition
	 */
	@Column(name = "DRUG_STORAGE_CONDITION", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getDrugStorageCondition() {
		return this.drugStorageCondition;
	}

	/**
	 * Sets the drug storage condition.
	 *
	 * @param drugStorageCondition the new drug storage condition
	 */
	public void setDrugStorageCondition(String drugStorageCondition) {
		this.drugStorageCondition = drugStorageCondition;
	}

	/**
	 * Gets the drug gpi.
	 *
	 * @return the drug gpi
	 */
	@Column(name = "DRUG_GPI", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getDrugGpi() {
		return this.drugGpi;
	}

	/**
	 * Sets the drug gpi.
	 *
	 * @param drugGpi the new drug gpi
	 */
	public void setDrugGpi(String drugGpi) {
		this.drugGpi = drugGpi;
	}

	/**
	 * Gets the drug dea code.
	 *
	 * @return the drug dea code
	 */
	@Column(name = "DRUG_DEA_CODE", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getDrugDeaCode() {
		return this.drugDeaCode;
	}

	/**
	 * Sets the drug dea code.
	 *
	 * @param drugDeaCode the new drug dea code
	 */
	public void setDrugDeaCode(String drugDeaCode) {
		this.drugDeaCode = drugDeaCode;
	}

	/**
	 * Gets the coverage type.
	 *
	 * @return the coverage type
	 */
	@Column(name = "COVERAGE_TYPE", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getCoverageType() {
		return this.coverageType;
	}

	/**
	 * Sets the coverage type.
	 *
	 * @param coverageType the new coverage type
	 */
	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	/**
	 * Gets the patient account.
	 *
	 * @return the patient account
	 */
	@Column(name = "PATIENT_ACCOUNT", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getPatientAccount() {
		return this.patientAccount;
	}

	/**
	 * Sets the patient account.
	 *
	 * @param patientAccount the new patient account
	 */
	public void setPatientAccount(String patientAccount) {
		this.patientAccount = patientAccount;
	}

	/**
	 * Gets the coverage id.
	 *
	 * @return the coverage id
	 */
	@Column(name = "COVERAGE_ID", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getCoverageId() {
		return this.coverageId;
	}

	/**
	 * Sets the coverage id.
	 *
	 * @param coverageId the new coverage id
	 */
	public void setCoverageId(String coverageId) {
		this.coverageId = coverageId;
	}

	/**
	 * Gets the coverage name.
	 *
	 * @return the coverage name
	 */
	@Column(name = "COVERAGE_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getCoverageName() {
		return this.coverageName;
	}

	/**
	 * Sets the coverage name.
	 *
	 * @param coverageName the new coverage name
	 */
	public void setCoverageName(String coverageName) {
		this.coverageName = coverageName;
	}

	/**
	 * Gets the coverage plan id.
	 *
	 * @return the coverage plan id
	 */
	@Column(name = "COVERAGE_PLAN_ID", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getCoveragePlanId() {
		return this.coveragePlanId;
	}

	/**
	 * Sets the coverage plan id.
	 *
	 * @param coveragePlanId the new coverage plan id
	 */
	public void setCoveragePlanId(String coveragePlanId) {
		this.coveragePlanId = coveragePlanId;
	}

	/**
	 * Gets the cooverage member name.
	 *
	 * @return the cooverage member name
	 */
	@Column(name = "COOVERAGE_MEMBER_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getCooverageMemberName() {
		return this.cooverageMemberName;
	}

	/**
	 * Sets the cooverage member name.
	 *
	 * @param cooverageMemberName the new cooverage member name
	 */
	public void setCooverageMemberName(String cooverageMemberName) {
		this.cooverageMemberName = cooverageMemberName;
	}

	/**
	 * Gets the coverage plan group.
	 *
	 * @return the coverage plan group
	 */
	@Column(name = "COVERAGE_PLAN_GROUP", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getCoveragePlanGroup() {
		return this.coveragePlanGroup;
	}

	/**
	 * Sets the coverage plan group.
	 *
	 * @param coveragePlanGroup the new coverage plan group
	 */
	public void setCoveragePlanGroup(String coveragePlanGroup) {
		this.coveragePlanGroup = coveragePlanGroup;
	}

	/**
	 * Gets the coverage priority.
	 *
	 * @return the coverage priority
	 */
	@Column(name = "COVERAGE_PRIORITY", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getCoveragePriority() {
		return this.coveragePriority;
	}

	/**
	 * Sets the coverage priority.
	 *
	 * @param coveragePriority the new coverage priority
	 */
	public void setCoveragePriority(String coveragePriority) {
		this.coveragePriority = coveragePriority;
	}

	/**
	 * Gets the third party amount paid.
	 *
	 * @return the third party amount paid
	 */
	@Column(name = "THIRD_PARTY_AMOUNT_PAID", unique = false, nullable = true, insertable = true, updatable = true, precision = 7)
	public BigDecimal getThirdPartyAmountPaid() {
		return this.thirdPartyAmountPaid;
	}

	/**
	 * Sets the third party amount paid.
	 *
	 * @param thirdPartyAmountPaid the new third party amount paid
	 */
	public void setThirdPartyAmountPaid(BigDecimal thirdPartyAmountPaid) {
		this.thirdPartyAmountPaid = thirdPartyAmountPaid;
	}

	/**
	 * Gets the pharmacy name.
	 *
	 * @return the pharmacy name
	 */
	@Column(name = "PHARMACY_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getPharmacyName() {
		return this.pharmacyName;
	}

	/**
	 * Sets the pharmacy name.
	 *
	 * @param pharmacyName the new pharmacy name
	 */
	public void setPharmacyName(String pharmacyName) {
		this.pharmacyName = pharmacyName;
	}

	/**
	 * Gets the pharmacy addr line1.
	 *
	 * @return the pharmacy addr line1
	 */
	@Column(name = "PHARMACY_ADDR_LINE1", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getPharmacyAddrLine1() {
		return this.pharmacyAddrLine1;
	}

	/**
	 * Sets the pharmacy addr line1.
	 *
	 * @param pharmacyAddrLine1 the new pharmacy addr line1
	 */
	public void setPharmacyAddrLine1(String pharmacyAddrLine1) {
		this.pharmacyAddrLine1 = pharmacyAddrLine1;
	}

	/**
	 * Gets the pharmacy addr line2.
	 *
	 * @return the pharmacy addr line2
	 */
	@Column(name = "PHARMACY_ADDR_LINE2", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getPharmacyAddrLine2() {
		return this.pharmacyAddrLine2;
	}

	/**
	 * Sets the pharmacy addr line2.
	 *
	 * @param pharmacyAddrLine2 the new pharmacy addr line2
	 */
	public void setPharmacyAddrLine2(String pharmacyAddrLine2) {
		this.pharmacyAddrLine2 = pharmacyAddrLine2;
	}

	/**
	 * Gets the pharmacy1.
	 *
	 * @return the pharmacy1
	 */
	@Column(name = "PHARMACY1", unique = false, nullable = false, insertable = true, updatable = true, precision = 2, scale = 0)
	public byte getPharmacy1() {
		return this.pharmacy1;
	}

	/**
	 * Sets the pharmacy1.
	 *
	 * @param pharmacy1 the new pharmacy1
	 */
	public void setPharmacy1(byte pharmacy1) {
		this.pharmacy1 = pharmacy1;
	}

	/**
	 * Gets the pharmacy2.
	 *
	 * @return the pharmacy2
	 */
	@Column(name = "PHARMACY2", unique = false, nullable = true, insertable = true, updatable = true, precision = 2, scale = 0)
	public Byte getPharmacy2() {
		return this.pharmacy2;
	}

	/**
	 * Sets the pharmacy2.
	 *
	 * @param pharmacy2 the new pharmacy2
	 */
	public void setPharmacy2(Byte pharmacy2) {
		this.pharmacy2 = pharmacy2;
	}

	/**
	 * Gets the pharmacy3.
	 *
	 * @return the pharmacy3
	 */
	@Column(name = "PHARMACY3", unique = false, nullable = true, insertable = true, updatable = true, precision = 2, scale = 0)
	public Byte getPharmacy3() {
		return this.pharmacy3;
	}

	/**
	 * Sets the pharmacy3.
	 *
	 * @param pharmacy3 the new pharmacy3
	 */
	public void setPharmacy3(Byte pharmacy3) {
		this.pharmacy3 = pharmacy3;
	}

	/**
	 * Gets the pharmacy4.
	 *
	 * @return the pharmacy4
	 */
	@Column(name = "PHARMACY4", unique = false, nullable = true, insertable = true, updatable = true, precision = 2, scale = 0)
	public Byte getPharmacy4() {
		return this.pharmacy4;
	}

	/**
	 * Sets the pharmacy4.
	 *
	 * @param pharmacy4 the new pharmacy4
	 */
	public void setPharmacy4(Byte pharmacy4) {
		this.pharmacy4 = pharmacy4;
	}

	/**
	 * Gets the pharmacy5.
	 *
	 * @return the pharmacy5
	 */
	@Column(name = "PHARMACY5", unique = false, nullable = true, insertable = true, updatable = true, precision = 2, scale = 0)
	public Byte getPharmacy5() {
		return this.pharmacy5;
	}

	/**
	 * Sets the pharmacy5.
	 *
	 * @param pharmacy5 the new pharmacy5
	 */
	public void setPharmacy5(Byte pharmacy5) {
		this.pharmacy5 = pharmacy5;
	}

	/**
	 * Gets the ppharmacy short name.
	 *
	 * @return the ppharmacy short name
	 */
	@Column(name = "PPHARMACY_SHORT_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getPpharmacyShortName() {
		return this.ppharmacyShortName;
	}

	/**
	 * Sets the ppharmacy short name.
	 *
	 * @param ppharmacyShortName the new ppharmacy short name
	 */
	public void setPpharmacyShortName(String ppharmacyShortName) {
		this.ppharmacyShortName = ppharmacyShortName;
	}

	/**
	 * Gets the pharmacy city.
	 *
	 * @return the pharmacy city
	 */
	@Column(name = "PHARMACY_CITY", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getPharmacyCity() {
		return this.pharmacyCity;
	}

	/**
	 * Sets the pharmacy city.
	 *
	 * @param pharmacyCity the new pharmacy city
	 */
	public void setPharmacyCity(String pharmacyCity) {
		this.pharmacyCity = pharmacyCity;
	}

	/**
	 * Gets the pharmacy state.
	 *
	 * @return the pharmacy state
	 */
	@Column(name = "PHARMACY_STATE", unique = false, nullable = true, insertable = true, updatable = true, length = 2)
	public String getPharmacyState() {
		return this.pharmacyState;
	}

	/**
	 * Sets the pharmacy state.
	 *
	 * @param pharmacyState the new pharmacy state
	 */
	public void setPharmacyState(String pharmacyState) {
		this.pharmacyState = pharmacyState;
	}

	/**
	 * Gets the pharmacy country.
	 *
	 * @return the pharmacy country
	 */
	@Column(name = "PHARMACY_COUNTRY", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getPharmacyCountry() {
		return this.pharmacyCountry;
	}

	/**
	 * Sets the pharmacy country.
	 *
	 * @param pharmacyCountry the new pharmacy country
	 */
	public void setPharmacyCountry(String pharmacyCountry) {
		this.pharmacyCountry = pharmacyCountry;
	}

	/**
	 * Gets the pharmacy zip.
	 *
	 * @return the pharmacy zip
	 */
	@Column(name = "PHARMACY_ZIP", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getPharmacyZip() {
		return this.pharmacyZip;
	}

	/**
	 * Sets the pharmacy zip.
	 *
	 * @param pharmacyZip the new pharmacy zip
	 */
	public void setPharmacyZip(String pharmacyZip) {
		this.pharmacyZip = pharmacyZip;
	}

	/**
	 * Gets the pharmacy phone number.
	 *
	 * @return the pharmacy phone number
	 */
	@Column(name = "PHARMACY_PHONE_NUMBER", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getPharmacyPhoneNumber() {
		return this.pharmacyPhoneNumber;
	}

	/**
	 * Sets the pharmacy phone number.
	 *
	 * @param pharmacyPhoneNumber the new pharmacy phone number
	 */
	public void setPharmacyPhoneNumber(String pharmacyPhoneNumber) {
		this.pharmacyPhoneNumber = pharmacyPhoneNumber;
	}

	/**
	 * Gets the pharmacy nabp.
	 *
	 * @return the pharmacy nabp
	 */
	@Column(name = "PHARMACY_NABP", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getPharmacyNabp() {
		return this.pharmacyNabp;
	}

	/**
	 * Sets the pharmacy nabp.
	 *
	 * @param pharmacyNabp the new pharmacy nabp
	 */
	public void setPharmacyNabp(String pharmacyNabp) {
		this.pharmacyNabp = pharmacyNabp;
	}

	/**
	 * Gets the pharmacy dea.
	 *
	 * @return the pharmacy dea
	 */
	@Column(name = "PHARMACY_DEA", unique = false, nullable = true, insertable = true, updatable = true, length = 16)
	public String getPharmacyDea() {
		return this.pharmacyDea;
	}

	/**
	 * Sets the pharmacy dea.
	 *
	 * @param pharmacyDea the new pharmacy dea
	 */
	public void setPharmacyDea(String pharmacyDea) {
		this.pharmacyDea = pharmacyDea;
	}

	/**
	 * Gets the pharmacy npi.
	 *
	 * @return the pharmacy npi
	 */
	@Column(name = "PHARMACY_NPI", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getPharmacyNpi() {
		return this.pharmacyNpi;
	}

	/**
	 * Sets the pharmacy npi.
	 *
	 * @param pharmacyNpi the new pharmacy npi
	 */
	public void setPharmacyNpi(String pharmacyNpi) {
		this.pharmacyNpi = pharmacyNpi;
	}

	/**
	 * Gets the status code.
	 *
	 * @return the status code
	 */
	@Column(name = "STATUS_CODE", unique = false, nullable = true, insertable = true, updatable = true, length = 4)
	public String getStatusCode() {
		return this.statusCode;
	}

	/**
	 * Sets the status code.
	 *
	 * @param statusCode the new status code
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Gets the status msg.
	 *
	 * @return the status msg
	 */
	@Column(name = "STATUS_MSG", unique = false, nullable = false, insertable = true, updatable = true, length = 80)
	public String getStatusMsg() {
		return this.statusMsg;
	}

	/**
	 * Sets the status msg.
	 *
	 * @param statusMsg the new status msg
	 */
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}

	/**
	 * Gets the reason code.
	 *
	 * @return the reason code
	 */
	@Column(name = "REASON_CODE", unique = false, nullable = true, insertable = true, updatable = true, length = 4)
	public String getReasonCode() {
		return this.reasonCode;
	}

	/**
	 * Sets the reason code.
	 *
	 * @param reasonCode the new reason code
	 */
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	/**
	 * Gets the reason msg.
	 *
	 * @return the reason msg
	 */
	@Column(name = "REASON_MSG", unique = false, nullable = false, insertable = true, updatable = true, length = 80)
	public String getReasonMsg() {
		return this.reasonMsg;
	}

	/**
	 * Sets the reason msg.
	 *
	 * @param reasonMsg the new reason msg
	 */
	public void setReasonMsg(String reasonMsg) {
		this.reasonMsg = reasonMsg;
	}

	/**
	 * Gets the msg type.
	 *
	 * @return the msg type
	 */
	@Column(name = "MSG_TYPE", unique = false, nullable = false, insertable = true, updatable = true, length = 80)
	public String getMsgType() {
		return this.msgType;
	}

	/**
	 * Sets the msg type.
	 *
	 * @param msgType the new msg type
	 */
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}

	/**
	 * Gets the medco trans id.
	 *
	 * @return the medco trans id
	 */
	@Column(name = "MEDCO_TRANS_ID", unique = false, nullable = false, insertable = true, updatable = true, precision = 30, scale = 0)
	public BigDecimal getMedcoTransId() {
		return this.medcoTransId;
	}

	/**
	 * Sets the medco trans id.
	 *
	 * @param medcoTransId the new medco trans id
	 */
	public void setMedcoTransId(BigDecimal medcoTransId) {
		this.medcoTransId = medcoTransId;
	}

	/**
	 * Gets the shipping address info set.
	 *
	 * @return the shipping address info set
	 */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "rxDispenseRequest")
	public Set<ShippingAddressInfoDdo> getShippingAddressInfoSet() {
		return this.shippingAddressInfoSet;
	}

	/**
	 * Sets the shipping address info set.
	 *
	 * @param shippingAddressInfoSet the new shipping address info set
	 */
	public void setShippingAddressInfoSet(
			Set<ShippingAddressInfoDdo> shippingAddressInfoSet) {
		this.shippingAddressInfoSet = shippingAddressInfoSet;
	}

	/**
	 * Gets the package info set.
	 *
	 * @return the packageInfoSet
	 */
	@OneToMany(cascade={CascadeType.ALL}, fetch=FetchType.EAGER, mappedBy="rxDispenseRequest")	
	public Set<PackageInfoDdo> getPackageInfoSet() {
		return this.packageInfoSet;
	}

	/**
	 * Sets the package info set.
	 *
	 * @param packageInfoSet the packageInfoSet to set
	 */
	public void setPackageInfoSet(Set<PackageInfoDdo> packageInfoSet) {
		this.packageInfoSet = packageInfoSet;
	}

	/**
	 * Gets the rx info set.
	 *
	 * @return the rx info set
	 */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "rxDispenseRequest")
	public Set<RxInfoDdo> getRxInfoSet() {
		return this.rxInfoSet;
	}



	/**
	 * Sets the rx info set.
	 *
	 * @param rxInfoSet the new rx info set
	 */
	public void setRxInfoSet(Set<RxInfoDdo> rxInfoSet) {
		this.rxInfoSet = rxInfoSet;
	}

	
	/**
	 * Gets the status info.
	 *
	 * @return the status info
	 */
	@OneToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "rxDispenseRequest")
	public StatusInfoDdo getStatusInfo() {
		return statusInfo;
	}

	/**
	 * Sets the status info.
	 *
	 * @param statusInfo the statusInfo to set
	 */
	public void setStatusInfo(StatusInfoDdo statusInfo) {
		this.statusInfo = statusInfo;
	}
	
	/**
	 * Gets the return address info set.
	 *
	 * @return the return address info set
	 */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "rxDispenseRequest")
	public Set<ReturnAddressInfoDdo> getReturnAddressInfoSet() {
		return this.returnAddressInfoSet;
	}

	/**
	 * Sets the return address info set.
	 *
	 * @param returnAddressInfoSet the new return address info set
	 */
	public void setReturnAddressInfoSet(
			Set<ReturnAddressInfoDdo> returnAddressInfoSet) {
		this.returnAddressInfoSet = returnAddressInfoSet;
	}

	/**
	 * Gets the letter info set.
	 *
	 * @return the letter info set
	 */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "rxDispenseRequest")
	public Set<LetterInfoDdo> getLetterInfoSet() {
		return this.letterInfoSet;
	}

	/**
	 * Sets the letter info set.
	 *
	 * @param letterInfoSet the new letter info set
	 */
	public void setLetterInfoSet(Set<LetterInfoDdo> letterInfoSet) {
		this.letterInfoSet = letterInfoSet;
	}

	/**
	 * Gets the web service info.
	 *
	 * @return the webServiceInfo
	 */
	@OneToOne(cascade = { CascadeType.ALL}, fetch = FetchType.LAZY, mappedBy = "rxDispenseRequest")
	public WebServiceInfoDdo getWebServiceInfo() {
		return webServiceInfo;
	}

	/**
	 * Sets the web service info.
	 *
	 * @param webServiceInfo the webServiceInfo to set
	 */
	public void setWebServiceInfo(WebServiceInfoDdo webServiceInfo) {
		this.webServiceInfo = webServiceInfo;
	}

	/**
 * Gets the patient infos.
 *
 * @return the patientInfos
 */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "rxDispenseRequest")
	public Set<PatientInfoDdo> getPatientInfos() {
		return patientInfos;
	}


	/**
	 * Gets the doctor infos.
	 *
	 * @return the doctorInfos
	 */
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER, mappedBy = "rxDispenseRequest")
	public Set<DoctorInfoDdo> getDoctorInfos() {
		return doctorInfos;
	}

	/**
 * Sets the patient infos.
 *
 * @param patientInfos the patientInfos to set
 */
	public void setPatientInfos(Set<PatientInfoDdo> patientInfos) {
		this.patientInfos = patientInfos;
	}

	/**
	 * Sets the doctor infos.
	 *
	 * @param doctorInfos the doctorInfos to set
	 */
	public void setDoctorInfos(Set<DoctorInfoDdo> doctorInfos) {
		this.doctorInfos = doctorInfos;
	}
	
}
