package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.RACF_REJECT;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.getPacStatusCode;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;

public class SendMsgPacBoHelper {

	private NRxInvoiceDao nrxInvoiceDao;
	
	/**
	 * @return the nrxInvoiceDao
	 */
	public NRxInvoiceDao getNrxInvoiceDao() {
		return nrxInvoiceDao;
	}


	/**
	 * @param nrxInvoiceDao the nrxInvoiceDao to set
	 */
	public void setNrxInvoiceDao(NRxInvoiceDao nrxInvoiceDao) {
		this.nrxInvoiceDao = nrxInvoiceDao;
	}


	public void updateSendStatusForSendMsgToPac(NRxInvoice nrxInvoiceDdo) {
		if(nrxInvoiceDdo != null) { 
			nrxInvoiceDdo.setSendStatus(getPacStatusCode(RACF_REJECT));
			nrxInvoiceDao.updateNDISendStatus(nrxInvoiceDdo);
		}
	}
}
