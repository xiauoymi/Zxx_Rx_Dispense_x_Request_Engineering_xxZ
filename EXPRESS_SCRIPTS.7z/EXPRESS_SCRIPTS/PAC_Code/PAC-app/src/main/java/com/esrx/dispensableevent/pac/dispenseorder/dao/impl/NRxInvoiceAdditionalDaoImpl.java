package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditional;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditionalId;
import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceAdditionalDao;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class NRxInvoiceAdditionalDaoImpl extends
		GenericDaoHibernate<NRxInvoiceAdditional> implements
		NRxInvoiceAdditionalDao {

	private static final Logger log = LoggerFactory
			.getLogger(NRxMclInfoDaoImpl.class);

	public NRxInvoiceAdditionalDaoImpl(SessionFactory sf) {
		super(NRxInvoiceAdditional.class, sf);
	}

	public NRxInvoiceAdditional getN000OrderRecordAdditional(
			NRxInvoiceAdditionalId nrxInvoiceAdditionalId) {
		NRxInvoiceAdditional nrxInvoiceAdditional = null;
		if (nrxInvoiceAdditionalId != null) {
			nrxInvoiceAdditional = findById(nrxInvoiceAdditionalId);
		}
		return nrxInvoiceAdditional;
	}

	public NRxInvoiceAdditional getOrderAdditionalForPackagePacData(
			NRxInvoiceAdditionalId nrxInvoiceAdditionalId) {
//		List<NRxInvoiceAdditional> nrxInvoiceAdditionalList = null;
		NRxInvoiceAdditional nrxInvoiceAdditional = null;
		if (nrxInvoiceAdditionalId != null) {
			DetachedCriteria nrxInvoiceAdditionalCriteria = DetachedCriteria
					.forClass(NRxInvoiceAdditional.class);

			nrxInvoiceAdditionalCriteria.add(Restrictions.eq("id.ordPartNbr",nrxInvoiceAdditionalId.getOrdPartNbr()))
									 .add(Restrictions.eq("id.ordFillNo",nrxInvoiceAdditionalId.getOrdFillNo()))
									 .add(Restrictions.eq("id.ordExtInvno",nrxInvoiceAdditionalId.getOrdExtInvno()));

			List<?> nrxInvAdditionalList = getHibernateTemplate()
					.findByCriteria(nrxInvoiceAdditionalCriteria);
			nrxInvoiceAdditional = (NRxInvoiceAdditional) nrxInvAdditionalList.get(ZERO);
//			nrxInvoiceAdditionalList = new ArrayList<NRxInvoiceAdditional>();
//			for (Object nrxInvoiceAdditionalObj : nrxInvAdditionalList) {
//				NRxInvoiceAdditional nrxInvoiceAdditional = (NRxInvoiceAdditional) nrxInvoiceAdditionalObj;
//				nrxInvoiceAdditionalList.add(nrxInvoiceAdditional);
//			}
		}
		return nrxInvoiceAdditional;
	}

	public void updateNDPTmsStatusCde(
			NRxInvoiceAdditional nrxInvoiceAdditional) {
		StringBuilder updateHql = new StringBuilder();
		updateHql.append("update NRxInvoiceAdditional set ");
		updateHql.append("ndpTms=:ndpTms,");
		updateHql.append("statusCde=:statusCde");
		updateHql.append(" where ");
		updateHql.append("id.ordPartNbr=:ordPartNbr");
		updateHql.append(" and ");
		updateHql.append("id.ordFillNo=:ordFillNo");
		updateHql.append(" and ");
		updateHql.append("id.ordExtInvno=:ordExtInvno");
		
		String updateNDPTmsStatusCdeHQL = String.valueOf(updateHql);

		if (nrxInvoiceAdditional != null) {
			Query updateNDIMEMFirstLastNameQuery = getSession().createQuery(updateNDPTmsStatusCdeHQL);
			updateNDIMEMFirstLastNameQuery.setTimestamp("ndpTms", nrxInvoiceAdditional.getNdpTms());
			updateNDIMEMFirstLastNameQuery.setString("statusCde", nrxInvoiceAdditional.getStatusCde());			
			updateNDIMEMFirstLastNameQuery.setInteger("ordPartNbr", nrxInvoiceAdditional.getId().getOrdPartNbr());
			updateNDIMEMFirstLastNameQuery.setInteger("ordFillNo", nrxInvoiceAdditional.getId().getOrdFillNo());
			updateNDIMEMFirstLastNameQuery.setInteger("ordExtInvno",
					nrxInvoiceAdditional.getId().getOrdExtInvno());
			updateNDIMEMFirstLastNameQuery.executeUpdate();
		}
	}

}
