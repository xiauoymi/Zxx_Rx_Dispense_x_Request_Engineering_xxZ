/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * RxInfoDdo.
 */
@Entity
@Table(name = "TBL_RX_INFO", uniqueConstraints = {})
public class RxInfoDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

	/** The rx num. */
	private long rxNum;
	
	/** The disp rx num. */
	private Integer dispRxNum;
	
	/** The disp ndc num. */
	private long dispNdcNum;
	
	/** The rx drug num. */
	private Integer rxDrugNum;
	
	/** The orig ndc num. */
	private Long origNdcNum;
	
	/** The dispense txt. */
	private String dispenseTxt;
	
	/** The compound ind. */
	private String compoundInd;
	
	/** The compound name. */
	private String compoundName;
	
	/** The substitute ind. */
	private int substituteInd;
	
	/** The dispense qty. */
	private Integer dispenseQty;
	
	/** The service date. */
	private Timestamp serviceDate;
	
	/** The rx price. */
	private String rxPrice;
	
	/** The co pay amt. */
	private String coPayAmt;
	
	/** The pt pay amount. */
	private String ptPayAmount;
	
	/** The exp date. */
	private Timestamp expDate;
	
	/** The refill date. */
	private Timestamp refillDate;
	
	/** The refill max. */
	private byte refillMax;
	
	/** The refill count. */
	private byte refillCount;
	
	/** The rx type. */
	private String rxType;
	
	/** The line txt1. */
	private String lineTxt1;
	
	/** The line txt2. */
	private String lineTxt2;
	
	/** The line txt3. */
	private String lineTxt3;
	
	/** The daw flag. */
	private String dawFlag;
	
	/** The issue date. */
	private Timestamp issueDate;
	
	/** The daily dose. */
	private Long dailyDose;
	
	/** The rx code. */
	private String rxCode;
	
	/** The prescription ien. */
	private String prescriptionIen;
	
	/** The total amount paid. */
	private BigDecimal totalAmountPaid;
	
	/** The U and c price. */
	private BigDecimal UAndCPrice;
	
	/** The discard date. */
	private Timestamp discardDate;
	
	/** The origianl fill date. */
	private Timestamp origianlFillDate;
	
	/** The last fill date. */
	private Timestamp lastFillDate;
	
	/** The last qty dispensed. */
	private Long lastQtyDispensed;
	
	/** The refills remaining. */
	private String refillsRemaining;
	
	/** The quantity remaining. */
	private String quantityRemaining;
	
	/** The partial fill. */
	private String partialFill;
	
	/** The days supply. */
	private String daysSupply;
	
	/** The rx origin. */
	private String rxOrigin;
	
	/** The sig code. */
	private String sigCode;
	
	/** The sig character count. */
	private Short sigCharacterCount;
	
	/** The pharmacist initials. */
	private String pharmacistInitials;
	
	/** The pharmacist id. */
	private String pharmacistId;
	
	/** The pharmacist first name. */
	private String pharmacistFirstName;
	
	/** The pharmacist last name. */
	private String pharmacistLastName;
	
	/** The tech initials. */
	private String techInitials;
	
	/** The technician id. */
	private String technicianId;
	
	/** The tech first name. */
	private String techFirstName;
	
	/** The tech last name. */
	private String techLastName;
	
	/** The tech computer login name. */
	private String techComputerLoginName;
	
	/** The technician location. */
	private String technicianLocation;
	
	/** The technician department. */
	private String technicianDepartment;
	
	/** The previous rx. */
	private String previousRx;
	
	/** The special message rx num. */
	private String specialMessageRxNum;
	
	/** The msg txt. */
	private String msgTxt;
    
    /** The rx count. */
    private Integer rxCount;
    
    /** The state license num. */
    private String stateLicenseNum;
    
    /** The triplcate serial num. */
    private String triplcateSerialNum;
    
    /** The country. */
    private String country;
    
    /** The qa pharma id. */
    private String qaPharmaId;
    
    /** The minfc lot num. */
    private String minfcLotNum;
    
    /** The minfc exp date. */
    private Timestamp minfcExpDate;
    
    /** The qty. */
    private Short qty;
    
    /** The qa date. */
    private Timestamp qaDate;
    
    /** The qa time. */
    private Timestamp qaTime;
    
    /** The rx disp txt. */
    private String rxDispTxt;
    
    /** The ingredient cost. */
    private BigDecimal ingredientCost;
    
    /** The reason code. */
    private Short reasonCode;
    
    /** The reason msg. */
    private String reasonMsg;
	
	/**
	 * default constructor.
	 */
	public RxInfoDdo() {
	}

	/** The id. */
	@EmbeddedId
	@AttributeOverrides({
		@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, precision = 30, scale = 0)),
		@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, length = 15)),
		@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, precision = 9, scale = 0)),
		@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, length = 1))})
	private RxDispenseRequestIdDdo id;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public RxDispenseRequestIdDdo getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(RxDispenseRequestIdDdo id) {
		this.id = id;
	}

	/**
	 * Gets the rx num.
	 *
	 * @return the rx num
	 */
	@Id
	@Column(name = "RX_NUM", unique = true, nullable = false, insertable = true, updatable = true, precision = 10, scale = 0)
	public long getRxNum() {
		return this.rxNum;
	}

	/**
	 * Sets the rx num.
	 *
	 * @param rxNum the new rx num
	 */
	public void setRxNum(long rxNum) {
		this.rxNum = rxNum;
	}

	/** The rx dispense request. */
	private RxDispenseRequestDdo rxDispenseRequest;

	/**
	 * Gets the rx dispense request.
	 *
	 * @return the rx dispense request
	 */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumns({
			@JoinColumn(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="TRANS_ID"),
			@JoinColumn(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="CLIENT_ID"),
			@JoinColumn(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="ORDER_NUM"),
			@JoinColumn(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="SUBORDER_IND")})
	public RxDispenseRequestDdo getRxDispenseRequest() {
		return this.rxDispenseRequest;
	}

	/**
	 * Sets the rx dispense request.
	 *
	 * @param rxDispenseRequest the new rx dispense request
	 */
	public void setRxDispenseRequest(RxDispenseRequestDdo rxDispenseRequest) {
		this.rxDispenseRequest = rxDispenseRequest;
	}

	/**
	 * Gets the disp rx num.
	 *
	 * @return the disp rx num
	 */
	@Column(name = "DISP_RX_NUM", unique = false, nullable = false, insertable = true, updatable = true, precision = 5, scale = 0)
	public Integer getDispRxNum() {
		return this.dispRxNum;
	}

	/**
	 * Sets the disp rx num.
	 *
	 * @param dispRxNum the new disp rx num
	 */
	public void setDispRxNum(Integer dispRxNum) {
		this.dispRxNum = dispRxNum;
	}

	/**
	 * Gets the disp ndc num.
	 *
	 * @return the disp ndc num
	 */
	@Column(name = "DISP_NDC_NUM", unique = false, nullable = false, insertable = true, updatable = true, precision = 11, scale = 0)
	public long getDispNdcNum() {
		return this.dispNdcNum;
	}

	/**
	 * Sets the disp ndc num.
	 *
	 * @param dispNdcNum the new disp ndc num
	 */
	public void setDispNdcNum(long dispNdcNum) {
		this.dispNdcNum = dispNdcNum;
	}

	/**
	 * Gets the rx drug num.
	 *
	 * @return the rx drug num
	 */
	@Column(name = "RX_DRUG_NUM", unique = false, nullable = true, insertable = true, updatable = true, precision = 5, scale = 0)
	public Integer getRxDrugNum() {
		return this.rxDrugNum;
	}

	/**
	 * Sets the rx drug num.
	 *
	 * @param rxDrugNum the new rx drug num
	 */
	public void setRxDrugNum(Integer rxDrugNum) {
		this.rxDrugNum = rxDrugNum;
	}

	/**
	 * Gets the orig ndc num.
	 *
	 * @return the orig ndc num
	 */
	@Column(name = "ORIG_NDC_NUM", unique = false, nullable = true, insertable = true, updatable = true, precision = 11, scale = 0)
	public Long getOrigNdcNum() {
		return this.origNdcNum;
	}

	/**
	 * Sets the orig ndc num.
	 *
	 * @param origNdcNum the new orig ndc num
	 */
	public void setOrigNdcNum(Long origNdcNum) {
		this.origNdcNum = origNdcNum;
	}

	/**
	 * Gets the dispense txt.
	 *
	 * @return the dispense txt
	 */
	@Column(name = "DISPENSE_TXT", unique = false, nullable = true, insertable = true, updatable = true, length = 180)
	public String getDispenseTxt() {
		return this.dispenseTxt;
	}

	/**
	 * Sets the dispense txt.
	 *
	 * @param dispenseTxt the new dispense txt
	 */
	public void setDispenseTxt(String dispenseTxt) {
		this.dispenseTxt = dispenseTxt;
	}

	/**
	 * Gets the compound ind.
	 *
	 * @return the compound ind
	 */
	@Column(name = "COMPOUND_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getCompoundInd() {
		return this.compoundInd;
	}

	/**
	 * Sets the compound ind.
	 *
	 * @param compoundInd the new compound ind
	 */
	public void setCompoundInd(String compoundInd) {
		this.compoundInd = compoundInd;
	}

	/**
	 * Gets the compound name.
	 *
	 * @return the compound name
	 */
	@Column(name = "COMPOUND_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 29)
	public String getCompoundName() {
		return this.compoundName;
	}

	/**
	 * Sets the compound name.
	 *
	 * @param compoundName the new compound name
	 */
	public void setCompoundName(String compoundName) {
		this.compoundName = compoundName;
	}

	/**
	 * Gets the substitute ind.
	 *
	 * @return the substitute ind
	 */
	@Column(name = "SUBSTITUTE_IND", unique = false, nullable = true, insertable = true, updatable = true, precision = 1, scale = 0)
	public int getSubstituteInd() {
		return this.substituteInd;
	}

	/**
	 * Sets the substitute ind.
	 *
	 * @param substituteInd the new substitute ind
	 */
	public void setSubstituteInd(int substituteInd) {
		this.substituteInd = substituteInd;
	}

	/**
	 * Gets the dispense qty.
	 *
	 * @return the dispense qty
	 */
	@Column(name = "DISPENSE_QTY", unique = false, nullable = false, insertable = true, updatable = true, precision = 5, scale = 0)
	public Integer getDispenseQty() {
		return this.dispenseQty;
	}

	/**
	 * Sets the dispense qty.
	 *
	 * @param dispenseQty the new dispense qty
	 */
	public void setDispenseQty(Integer dispenseQty) {
		this.dispenseQty = dispenseQty;
	}

	/**
	 * Gets the service date.
	 *
	 * @return the service date
	 */
	@Column(name = "SERVICE_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Timestamp getServiceDate() {
		return this.serviceDate;
	}

	/**
	 * Sets the service date.
	 *
	 * @param serviceDate the new service date
	 */
	public void setServiceDate(Timestamp serviceDate) {
		this.serviceDate = serviceDate;
	}

	/**
	 * Gets the rx price.
	 *
	 * @return the rx price
	 */
	@Column(name = "RX_PRICE", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getRxPrice() {
		return this.rxPrice;
	}

	/**
	 * Sets the rx price.
	 *
	 * @param rxPrice the new rx price
	 */
	public void setRxPrice(String rxPrice) {
		this.rxPrice = rxPrice;
	}

	/**
	 * Gets the co pay amt.
	 *
	 * @return the co pay amt
	 */
	@Column(name = "CO_PAY_AMT", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getCoPayAmt() {
		return this.coPayAmt;
	}

	/**
	 * Sets the co pay amt.
	 *
	 * @param coPayAmt the new co pay amt
	 */
	public void setCoPayAmt(String coPayAmt) {
		this.coPayAmt = coPayAmt;
	}

	/**
	 * Gets the pt pay amount.
	 *
	 * @return the pt pay amount
	 */
	@Column(name = "PT_PAY_AMOUNT", unique = false, nullable = false, insertable = true, updatable = true, length = 10)
	public String getPtPayAmount() {
		return this.ptPayAmount;
	}

	/**
	 * Sets the pt pay amount.
	 *
	 * @param ptPayAmount the new pt pay amount
	 */
	public void setPtPayAmount(String ptPayAmount) {
		this.ptPayAmount = ptPayAmount;
	}

	/**
	 * Gets the exp date.
	 *
	 * @return the exp date
	 */
	@Column(name = "EXP_DATE", unique = false, nullable = false, insertable = true, updatable = true, length = 7)
	public Timestamp getExpDate() {
		return this.expDate;
	}

	/**
	 * Sets the exp date.
	 *
	 * @param expDate the new exp date
	 */
	public void setExpDate(Timestamp expDate) {
		this.expDate = expDate;
	}

	/**
	 * Gets the refill date.
	 *
	 * @return the refill date
	 */
	@Column(name = "REFILL_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getRefillDate() {
		return this.refillDate;
	}

	/**
	 * Sets the refill date.
	 *
	 * @param refillDate the new refill date
	 */
	public void setRefillDate(Timestamp refillDate) {
		this.refillDate = refillDate;
	}

	/**
	 * Gets the refill max.
	 *
	 * @return the refill max
	 */
	@Column(name = "REFILL_MAX", unique = false, nullable = false, insertable = true, updatable = true, precision = 2, scale = 0)
	public byte getRefillMax() {
		return this.refillMax;
	}

	/**
	 * Sets the refill max.
	 *
	 * @param refillMax the new refill max
	 */
	public void setRefillMax(byte refillMax) {
		this.refillMax = refillMax;
	}

	/**
	 * Gets the refill count.
	 *
	 * @return the refill count
	 */
	@Column(name = "REFILL_COUNT", unique = false, nullable = false, insertable = true, updatable = true, precision = 2, scale = 0)
	public byte getRefillCount() {
		return this.refillCount;
	}

	/**
	 * Sets the refill count.
	 *
	 * @param refillCount the new refill count
	 */
	public void setRefillCount(byte refillCount) {
		this.refillCount = refillCount;
	}

	/**
	 * Gets the rx type.
	 *
	 * @return the rx type
	 */
	@Column(name = "RX_TYPE", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public String getRxType() {
		return this.rxType;
	}

	/**
	 * Sets the rx type.
	 *
	 * @param rxType the new rx type
	 */
	public void setRxType(String rxType) {
		this.rxType = rxType;
	}

	/**
	 * Gets the line txt1.
	 *
	 * @return the line txt1
	 */
	@Column(name = "LINE_TXT1", unique = false, nullable = false, insertable = true, updatable = true, length = 48)
	public String getLineTxt1() {
		return this.lineTxt1;
	}

	/**
	 * Sets the line txt1.
	 *
	 * @param lineTxt1 the new line txt1
	 */
	public void setLineTxt1(String lineTxt1) {
		this.lineTxt1 = lineTxt1;
	}

	/**
	 * Gets the line txt2.
	 *
	 * @return the line txt2
	 */
	@Column(name = "LINE_TXT2", unique = false, nullable = false, insertable = true, updatable = true, length = 48)
	public String getLineTxt2() {
		return this.lineTxt2;
	}

	/**
	 * Sets the line txt2.
	 *
	 * @param lineTxt2 the new line txt2
	 */
	public void setLineTxt2(String lineTxt2) {
		this.lineTxt2 = lineTxt2;
	}

	/**
	 * Gets the line txt3.
	 *
	 * @return the line txt3
	 */
	@Column(name = "LINE_TXT3", unique = false, nullable = false, insertable = true, updatable = true, length = 48)
	public String getLineTxt3() {
		return this.lineTxt3;
	}

	/**
	 * Sets the line txt3.
	 *
	 * @param lineTxt3 the new line txt3
	 */
	public void setLineTxt3(String lineTxt3) {
		this.lineTxt3 = lineTxt3;
	}

	/**
	 * Gets the daw flag.
	 *
	 * @return the daw flag
	 */
	@Column(name = "DAW_FLAG", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getDawFlag() {
		return this.dawFlag;
	}

	/**
	 * Sets the daw flag.
	 *
	 * @param dawFlag the new daw flag
	 */
	public void setDawFlag(String dawFlag) {
		this.dawFlag = dawFlag;
	}

	/**
	 * Gets the issue date.
	 *
	 * @return the issue date
	 */
	@Column(name = "ISSUE_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getIssueDate() {
		return this.issueDate;
	}

	/**
	 * Sets the issue date.
	 *
	 * @param issueDate the new issue date
	 */
	public void setIssueDate(Timestamp issueDate) {
		this.issueDate = issueDate;
	}

	/**
	 * Gets the daily dose.
	 *
	 * @return the daily dose
	 */
	@Column(name = "DAILY_DOSE", unique = false, nullable = true, insertable = true, updatable = true, precision = 12, scale = 0)
	public Long getDailyDose() {
		return this.dailyDose;
	}

	/**
	 * Sets the daily dose.
	 *
	 * @param dailyDose the new daily dose
	 */
	public void setDailyDose(Long dailyDose) {
		this.dailyDose = dailyDose;
	}

	/**
	 * Gets the rx code.
	 *
	 * @return the rx code
	 */
	@Column(name = "RX_CODE", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getRxCode() {
		return this.rxCode;
	}

	/**
	 * Sets the rx code.
	 *
	 * @param rxCode the new rx code
	 */
	public void setRxCode(String rxCode) {
		this.rxCode = rxCode;
	}

	/**
	 * Gets the prescription ien.
	 *
	 * @return the prescription ien
	 */
	@Column(name = "PRESCRIPTION_IEN", unique = false, nullable = true, insertable = true, updatable = true, length = 30)
	public String getPrescriptionIen() {
		return this.prescriptionIen;
	}

	/**
	 * Sets the prescription ien.
	 *
	 * @param prescriptionIen the new prescription ien
	 */
	public void setPrescriptionIen(String prescriptionIen) {
		this.prescriptionIen = prescriptionIen;
	}

	/**
	 * Gets the total amount paid.
	 *
	 * @return the total amount paid
	 */
	@Column(name = "TOTAL_AMOUNT_PAID", unique = false, nullable = true, insertable = true, updatable = true, precision = 7)
	public BigDecimal getTotalAmountPaid() {
		return this.totalAmountPaid;
	}

	/**
	 * Sets the total amount paid.
	 *
	 * @param totalAmountPaid the new total amount paid
	 */
	public void setTotalAmountPaid(BigDecimal totalAmountPaid) {
		this.totalAmountPaid = totalAmountPaid;
	}

	/**
	 * Gets the u and c price.
	 *
	 * @return the u and c price
	 */
	@Column(name = "U_AND_C_PRICE", unique = false, nullable = true, insertable = true, updatable = true, precision = 7)
	public BigDecimal getUAndCPrice() {
		return this.UAndCPrice;
	}

	/**
	 * Sets the u and c price.
	 *
	 * @param UAndCPrice the new u and c price
	 */
	public void setUAndCPrice(BigDecimal UAndCPrice) {
		this.UAndCPrice = UAndCPrice;
	}

	/**
	 * Gets the discard date.
	 *
	 * @return the discard date
	 */
	@Column(name = "DISCARD_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getDiscardDate() {
		return this.discardDate;
	}

	/**
	 * Sets the discard date.
	 *
	 * @param discardDate the new discard date
	 */
	public void setDiscardDate(Timestamp discardDate) {
		this.discardDate = discardDate;
	}

	/**
	 * Gets the origianl fill date.
	 *
	 * @return the origianl fill date
	 */
	@Column(name = "ORIGIANL_FILL_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getOrigianlFillDate() {
		return this.origianlFillDate;
	}

	/**
	 * Sets the origianl fill date.
	 *
	 * @param origianlFillDate the new origianl fill date
	 */
	public void setOrigianlFillDate(Timestamp origianlFillDate) {
		this.origianlFillDate = origianlFillDate;
	}

	/**
	 * Gets the last fill date.
	 *
	 * @return the last fill date
	 */
	@Column(name = "LAST_FILL_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getLastFillDate() {
		return this.lastFillDate;
	}

	/**
	 * Sets the last fill date.
	 *
	 * @param lastFillDate the new last fill date
	 */
	public void setLastFillDate(Timestamp lastFillDate) {
		this.lastFillDate = lastFillDate;
	}

	/**
	 * Gets the last qty dispensed.
	 *
	 * @return the last qty dispensed
	 */
	@Column(name = "LAST_QTY_DISPENSED", unique = false, nullable = true, insertable = true, updatable = true, precision = 10, scale = 0)
	public Long getLastQtyDispensed() {
		return this.lastQtyDispensed;
	}

	/**
	 * Sets the last qty dispensed.
	 *
	 * @param lastQtyDispensed the new last qty dispensed
	 */
	public void setLastQtyDispensed(Long lastQtyDispensed) {
		this.lastQtyDispensed = lastQtyDispensed;
	}

	/**
	 * Gets the refills remaining.
	 *
	 * @return the refills remaining
	 */
	@Column(name = "REFILLS_REMAINING", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getRefillsRemaining() {
		return this.refillsRemaining;
	}

	/**
	 * Sets the refills remaining.
	 *
	 * @param refillsRemaining the new refills remaining
	 */
	public void setRefillsRemaining(String refillsRemaining) {
		this.refillsRemaining = refillsRemaining;
	}

	/**
	 * Gets the quantity remaining.
	 *
	 * @return the quantity remaining
	 */
	@Column(name = "QUANTITY_REMAINING", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getQuantityRemaining() {
		return this.quantityRemaining;
	}

	/**
	 * Sets the quantity remaining.
	 *
	 * @param quantityRemaining the new quantity remaining
	 */
	public void setQuantityRemaining(String quantityRemaining) {
		this.quantityRemaining = quantityRemaining;
	}

	/**
	 * Gets the partial fill.
	 *
	 * @return the partial fill
	 */
	@Column(name = "PARTIAL_FILL", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getPartialFill() {
		return this.partialFill;
	}

	/**
	 * Sets the partial fill.
	 *
	 * @param partialFill the new partial fill
	 */
	public void setPartialFill(String partialFill) {
		this.partialFill = partialFill;
	}

	/**
	 * Gets the days supply.
	 *
	 * @return the days supply
	 */
	@Column(name = "DAYS_SUPPLY", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getDaysSupply() {
		return this.daysSupply;
	}

	/**
	 * Sets the days supply.
	 *
	 * @param daysSupply the new days supply
	 */
	public void setDaysSupply(String daysSupply) {
		this.daysSupply = daysSupply;
	}

	/**
	 * Gets the rx origin.
	 *
	 * @return the rx origin
	 */
	@Column(name = "RX_ORIGIN", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getRxOrigin() {
		return this.rxOrigin;
	}

	/**
	 * Sets the rx origin.
	 *
	 * @param rxOrigin the new rx origin
	 */
	public void setRxOrigin(String rxOrigin) {
		this.rxOrigin = rxOrigin;
	}

	/**
	 * Gets the sig code.
	 *
	 * @return the sig code
	 */
	@Column(name = "SIG_CODE", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getSigCode() {
		return this.sigCode;
	}

	/**
	 * Sets the sig code.
	 *
	 * @param sigCode the new sig code
	 */
	public void setSigCode(String sigCode) {
		this.sigCode = sigCode;
	}

	/**
	 * Gets the sig character count.
	 *
	 * @return the sig character count
	 */
	@Column(name = "SIG_CHARACTER_COUNT", unique = false, nullable = true, insertable = true, updatable = true, precision = 3, scale = 0)
	public Short getSigCharacterCount() {
		return this.sigCharacterCount;
	}

	/**
	 * Sets the sig character count.
	 *
	 * @param sigCharacterCount the new sig character count
	 */
	public void setSigCharacterCount(Short sigCharacterCount) {
		this.sigCharacterCount = sigCharacterCount;
	}

	/**
	 * Gets the pharmacist initials.
	 *
	 * @return the pharmacist initials
	 */
	@Column(name = "PHARMACIST_INITIALS", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getPharmacistInitials() {
		return this.pharmacistInitials;
	}

	/**
	 * Sets the pharmacist initials.
	 *
	 * @param pharmacistInitials the new pharmacist initials
	 */
	public void setPharmacistInitials(String pharmacistInitials) {
		this.pharmacistInitials = pharmacistInitials;
	}

	/**
	 * Gets the pharmacist id.
	 *
	 * @return the pharmacist id
	 */
	@Column(name = "PHARMACIST_ID", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getPharmacistId() {
		return this.pharmacistId;
	}

	/**
	 * Sets the pharmacist id.
	 *
	 * @param pharmacistId the new pharmacist id
	 */
	public void setPharmacistId(String pharmacistId) {
		this.pharmacistId = pharmacistId;
	}

	/**
	 * Gets the pharmacist first name.
	 *
	 * @return the pharmacist first name
	 */
	@Column(name = "PHARMACIST_FIRST_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getPharmacistFirstName() {
		return this.pharmacistFirstName;
	}

	/**
	 * Sets the pharmacist first name.
	 *
	 * @param pharmacistFirstName the new pharmacist first name
	 */
	public void setPharmacistFirstName(String pharmacistFirstName) {
		this.pharmacistFirstName = pharmacistFirstName;
	}

	/**
	 * Gets the pharmacist last name.
	 *
	 * @return the pharmacist last name
	 */
	@Column(name = "PHARMACIST_LAST_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getPharmacistLastName() {
		return this.pharmacistLastName;
	}

	/**
	 * Sets the pharmacist last name.
	 *
	 * @param pharmacistLastName the new pharmacist last name
	 */
	public void setPharmacistLastName(String pharmacistLastName) {
		this.pharmacistLastName = pharmacistLastName;
	}

	/**
	 * Gets the tech initials.
	 *
	 * @return the tech initials
	 */
	@Column(name = "TECH_INITIALS", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getTechInitials() {
		return this.techInitials;
	}

	/**
	 * Sets the tech initials.
	 *
	 * @param techInitials the new tech initials
	 */
	public void setTechInitials(String techInitials) {
		this.techInitials = techInitials;
	}

	/**
	 * Gets the technician id.
	 *
	 * @return the technician id
	 */
	@Column(name = "TECHNICIAN_ID", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getTechnicianId() {
		return this.technicianId;
	}

	/**
	 * Sets the technician id.
	 *
	 * @param technicianId the new technician id
	 */
	public void setTechnicianId(String technicianId) {
		this.technicianId = technicianId;
	}

	/**
	 * Gets the tech first name.
	 *
	 * @return the tech first name
	 */
	@Column(name = "TECH_FIRST_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getTechFirstName() {
		return this.techFirstName;
	}

	/**
	 * Sets the tech first name.
	 *
	 * @param techFirstName the new tech first name
	 */
	public void setTechFirstName(String techFirstName) {
		this.techFirstName = techFirstName;
	}

	/**
	 * Gets the tech last name.
	 *
	 * @return the tech last name
	 */
	@Column(name = "TECH_LAST_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getTechLastName() {
		return this.techLastName;
	}

	/**
	 * Sets the tech last name.
	 *
	 * @param techLastName the new tech last name
	 */
	public void setTechLastName(String techLastName) {
		this.techLastName = techLastName;
	}

	/**
	 * Gets the tech computer login name.
	 *
	 * @return the tech computer login name
	 */
	@Column(name = "TECH_COMPUTER_LOGIN_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getTechComputerLoginName() {
		return this.techComputerLoginName;
	}

	/**
	 * Sets the tech computer login name.
	 *
	 * @param techComputerLoginName the new tech computer login name
	 */
	public void setTechComputerLoginName(String techComputerLoginName) {
		this.techComputerLoginName = techComputerLoginName;
	}

	/**
	 * Gets the technician location.
	 *
	 * @return the technician location
	 */
	@Column(name = "TECHNICIAN_LOCATION", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getTechnicianLocation() {
		return this.technicianLocation;
	}

	/**
	 * Sets the technician location.
	 *
	 * @param technicianLocation the new technician location
	 */
	public void setTechnicianLocation(String technicianLocation) {
		this.technicianLocation = technicianLocation;
	}

	/**
	 * Gets the technician department.
	 *
	 * @return the technician department
	 */
	@Column(name = "TECHNICIAN_DEPARTMENT", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getTechnicianDepartment() {
		return this.technicianDepartment;
	}

	/**
	 * Sets the technician department.
	 *
	 * @param technicianDepartment the new technician department
	 */
	public void setTechnicianDepartment(String technicianDepartment) {
		this.technicianDepartment = technicianDepartment;
	}

	/**
	 * Gets the previous rx.
	 *
	 * @return the previous rx
	 */
	@Column(name = "PREVIOUS_RX", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getPreviousRx() {
		return this.previousRx;
	}

	/**
	 * Sets the previous rx.
	 *
	 * @param previousRx the new previous rx
	 */
	public void setPreviousRx(String previousRx) {
		this.previousRx = previousRx;
	}

	/**
	 * Gets the special message rx num.
	 *
	 * @return the special message rx num
	 */
	@Column(name = "SPECIAL_MESSAGE_RX_NUM", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getSpecialMessageRxNum() {
		return this.specialMessageRxNum;
	}

	/**
	 * Sets the special message rx num.
	 *
	 * @param specialMessageRxNum the new special message rx num
	 */
	public void setSpecialMessageRxNum(String specialMessageRxNum) {
		this.specialMessageRxNum = specialMessageRxNum;
	}

	/**
	 * Gets the msg txt.
	 *
	 * @return the msg txt
	 */
	@Column(name = "MSG_TXT", unique = false, nullable = true, insertable = true, updatable = true, length = 180)
	public String getMsgTxt() {
		return this.msgTxt;
	}

	/**
	 * Sets the msg txt.
	 *
	 * @param msgTxt the new msg txt
	 */
	public void setMsgTxt(String msgTxt) {
		this.msgTxt = msgTxt;
	}

	/**
	 * Gets the rx count.
	 *
	 * @return the rx count
	 */
	@Column(name = "RX_COUNT", unique = false, nullable = true, insertable = true, updatable = true, precision = 5, scale = 0)
	public Integer getRxCount() {
		return this.rxCount;
	}

	/**
	 * Sets the rx count.
	 *
	 * @param rxCount the new rx count
	 */
	public void setRxCount(Integer rxCount) {
		this.rxCount = rxCount;
	}


	/**
	 * Gets the state license num.
	 *
	 * @return the state license num
	 */
	@Column(name = "STATE_LICENSE_NUM", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getStateLicenseNum() {
		return this.stateLicenseNum;
	}

	/**
	 * Sets the state license num.
	 *
	 * @param stateLicenseNum the new state license num
	 */
	public void setStateLicenseNum(String stateLicenseNum) {
		this.stateLicenseNum = stateLicenseNum;
	}

	/**
	 * Gets the triplcate serial num.
	 *
	 * @return the triplcate serial num
	 */
	@Column(name = "TRIPLCATE_SERIAL_NUM", unique = false, nullable = true, insertable = true, updatable = true, length = 20)
	public String getTriplcateSerialNum() {
		return this.triplcateSerialNum;
	}

	/**
	 * Sets the triplcate serial num.
	 *
	 * @param triplcateSerialNum the new triplcate serial num
	 */
	public void setTriplcateSerialNum(String triplcateSerialNum) {
		this.triplcateSerialNum = triplcateSerialNum;
	}

	/**
	 * Gets the country.
	 *
	 * @return the country
	 */
	@Column(name = "COUNTRY", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getCountry() {
		return this.country;
	}

	/**
	 * Sets the country.
	 *
	 * @param country the new country
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Gets the qa pharma id.
	 *
	 * @return the qa pharma id
	 */
	@Column(name = "QA_PHARMA_ID", unique = false, nullable = true, insertable = true, updatable = true, length = 6)
	public String getQaPharmaId() {
		return this.qaPharmaId;
	}

	/**
	 * Sets the qa pharma id.
	 *
	 * @param qaPharmaId the new qa pharma id
	 */
	public void setQaPharmaId(String qaPharmaId) {
		this.qaPharmaId = qaPharmaId;
	}

	/**
	 * Gets the minfc lot num.
	 *
	 * @return the minfc lot num
	 */
	@Column(name = "MINFC_LOT_NUM", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getMinfcLotNum() {
		return this.minfcLotNum;
	}

	/**
	 * Sets the minfc lot num.
	 *
	 * @param minfcLotNum the new minfc lot num
	 */
	public void setMinfcLotNum(String minfcLotNum) {
		this.minfcLotNum = minfcLotNum;
	}

	/**
	 * Gets the minfc exp date.
	 *
	 * @return the minfc exp date
	 */
	@Column(name = "MINFC_EXP_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getMinfcExpDate() {
		return this.minfcExpDate;
	}

	/**
	 * Sets the minfc exp date.
	 *
	 * @param minfcExpDate the new minfc exp date
	 */
	public void setMinfcExpDate(Timestamp minfcExpDate) {
		this.minfcExpDate = minfcExpDate;
	}

	/**
	 * Gets the qty.
	 *
	 * @return the qty
	 */
	@Column(name = "QTY", unique = false, nullable = true, insertable = true, updatable = true, precision = 4, scale = 0)
	public Short getQty() {
		return this.qty;
	}

	/**
	 * Sets the qty.
	 *
	 * @param qty the new qty
	 */
	public void setQty(Short qty) {
		this.qty = qty;
	}

	/**
	 * Gets the qa date.
	 *
	 * @return the qa date
	 */
	@Column(name = "QA_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 7)
	public Timestamp getQaDate() {
		return this.qaDate;
	}

	/**
	 * Sets the qa date.
	 *
	 * @param qaDate the new qa date
	 */
	public void setQaDate(Timestamp qaDate) {
		this.qaDate = qaDate;
	}

	/**
	 * Gets the qa time.
	 *
	 * @return the qa time
	 */
	@Column(name = "QA_TIME", unique = false, nullable = true, insertable = true, updatable = true, length = 11)
	public Timestamp getQaTime() {
		return this.qaTime;
	}

	/**
	 * Sets the qa time.
	 *
	 * @param qaTime the new qa time
	 */
	public void setQaTime(Timestamp qaTime) {
		this.qaTime = qaTime;
	}

	/**
	 * Gets the rx disp txt.
	 *
	 * @return the rx disp txt
	 */
	@Column(name = "RX_DISP_TXT", unique = false, nullable = true, insertable = true, updatable = true, length = 80)
	public String getRxDispTxt() {
		return this.rxDispTxt;
	}

	/**
	 * Sets the rx disp txt.
	 *
	 * @param rxDispTxt the new rx disp txt
	 */
	public void setRxDispTxt(String rxDispTxt) {
		this.rxDispTxt = rxDispTxt;
	}

	/**
	 * Gets the ingredient cost.
	 *
	 * @return the ingredient cost
	 */
	@Column(name = "INGREDIENT_COST", unique = false, nullable = true, insertable = true, updatable = true, precision = 5)
	public BigDecimal getIngredientCost() {
		return this.ingredientCost;
	}

	/**
	 * Sets the ingredient cost.
	 *
	 * @param ingredientCost the new ingredient cost
	 */
	public void setIngredientCost(BigDecimal ingredientCost) {
		this.ingredientCost = ingredientCost;
	}

	/**
	 * Gets the reason code.
	 *
	 * @return the reason code
	 */
	@Column(name = "REASON_CODE", unique = false, nullable = true, insertable = true, updatable = true, precision = 4, scale = 0)
	public Short getReasonCode() {
		return this.reasonCode;
	}

	/**
	 * Sets the reason code.
	 *
	 * @param reasonCode the new reason code
	 */
	public void setReasonCode(Short reasonCode) {
		this.reasonCode = reasonCode;
	}

	/**
	 * Gets the reason msg.
	 *
	 * @return the reason msg
	 */
	@Column(name = "REASON_MSG", unique = false, nullable = true, insertable = true, updatable = true, length = 50)
	public String getReasonMsg() {
		return this.reasonMsg;
	}

	/**
	 * Sets the reason msg.
	 *
	 * @param reasonMsg the new reason msg
	 */
	public void setReasonMsg(String reasonMsg) {
		this.reasonMsg = reasonMsg;
	}

}
