package com.esrx.dispensableevent.pac.dispenseorder.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.pac.dispenseorder.bo.impl.PackageInvoiceDataBoHelper;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;



public class PacDispenseOrderPartNbrUtil {

	private static final Logger log = LoggerFactory
	.getLogger(PacDispenseOrderPartNbrUtil.class);

	public static String getOrdPartNbr(Integer ordPartNbr) {
		
		String ordPartNbrVal = null;
		if(ordPartNbr != null) {
			try {
				ordPartNbrVal = String.valueOf(ordPartNbr);
				ordPartNbrVal = ordPartNbrVal.substring(8, 10);
			} catch(StringIndexOutOfBoundsException exception) { 
				ordPartNbrVal = String.valueOf(ZERO);
				log.error("StringIndexOutOfBoundsException thrown for ordPartNbr : ", ordPartNbr);
				log.info("StringIndexOutOfBoundsException Ignored");
			}
		}
		return ordPartNbrVal;
	}

}
