/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.pac.dispenseorder.util;

import generated.Request;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant;

public class PacDispenseOrderMarshaller {

	private static final Logger log = LoggerFactory
	.getLogger(PacDispenseOrderMarshaller.class);

	private static final JAXBContext pacJAXBContext = initResponseJAXBContext();


	private static JAXBContext initResponseJAXBContext() {
		try {
			return JAXBContext.newInstance(Request.class);
		} catch (JAXBException e) {
			throw new RuntimeException(e);
		}
	}


	public static  String requestMarshallToString(Request pacDispenseOrderRequest)
			throws JAXBException {

		Marshaller marshaller = null;
		String pacXML = null;
		
		log.info("Method requestToMarshall Entered : ");
		if (pacDispenseOrderRequest != null) {
			marshaller = pacJAXBContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, PacDispenseOrderRequestConstant.BOOLEAN_TRUE_FLAG);
			StringWriter strWriter = new StringWriter();
			marshaller.marshal(pacDispenseOrderRequest, strWriter);
			
			pacXML = String.valueOf(strWriter);	
		}
		log.info("Method requestToMarshall Exited");
		return pacXML;
	}

}
