/**
 * Author : Guru Krishnan
 */
package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="NRXCDE00")
public class NRxInvoiceControl implements Serializable{
	
	private static final long serialVersionUID = -9144744137307045270L;
	private NRxInvoiceControlId id;
	private String decode;
	private Date transTmstp;
	private String operId;
	private String table1Txt;
	private String table2Txt;

	// Default Constructor
	public NRxInvoiceControl() {
		
	}
	
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "nrxcdeTableNo", column = @Column(name = "NRXCDE_TABLE_NO")),
			@AttributeOverride(name = "nrxcdeCodeVlu", column = @Column(name = "NRXCDE_CODE_VLU"))
	})
	public NRxInvoiceControlId getId() {
		return id;
	}

	public void setId(NRxInvoiceControlId id) {
		this.id = id;
	}

	@Column(name="NRXCDE_DECODE")
	public String getDecode() {
		return decode;
	}

	public void setDecode(String decode) {
		this.decode = decode;
	}

	@Column(name="NRXCDE_TRANS_TMSTP")
	public Date getTransTmstp() {
		return transTmstp;
	}

	public void setTransTmstp(Date transTmstp) {
		this.transTmstp = transTmstp;
	}

	@Column(name="NRXCDE_OPER_ID")
	public String getOperId() {
		return operId;
	}

	public void setOperId(String operId) {
		this.operId = operId;
	}

	@Column(name="NRXCDE_TABLE1_TXT")
	public String getTable1Txt() {
		return table1Txt;
	}

	public void setTable1Txt(String table1Txt) {
		this.table1Txt = table1Txt;
	}

	@Column(name="NRXCDE_TABLE2_TXT")
	public String getTable2Txt() {
		return table2Txt;
	}

	public void setTable2Txt(String table2Txt) {
		this.table2Txt = table2Txt;
	}
}