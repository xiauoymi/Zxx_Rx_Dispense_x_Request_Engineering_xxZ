package com.esrx.dispensableevent.pac.dispenseorder.dao;

import com.esrx.dispensableevent.nrxupdate.domain.NRxExpeditedShipmentInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxExpeditedShipmentInfoId;

public interface NRxExpeditedShipmentInfoDao {

	NRxExpeditedShipmentInfo getNRxExpeditedShipmentInfo(NRxExpeditedShipmentInfoId nrxExpeditedShipmentInfoId);
}
