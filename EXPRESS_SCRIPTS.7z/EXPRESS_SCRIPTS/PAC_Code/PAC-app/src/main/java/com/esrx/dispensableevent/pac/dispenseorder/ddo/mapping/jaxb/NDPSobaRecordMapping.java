package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.NDPSobaRecord;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;

public class NDPSobaRecordMapping {

	public void mapDatabaseToBusinessDomain(NDPSobaRecord ndpSobaRecordBdo, NRxSobaInfo nrxSobaInfoDdo) {
		ndpSobaRecordBdo.setMessCodeNo(nrxSobaInfoDdo.getMessCodeNo());
		ndpSobaRecordBdo.setMessText(nrxSobaInfoDdo.getMessParm1());
//		ndpSobaRecordBdo.setMessText(nrxSobaInfoDdo.getMessCodeNo());
		ndpSobaRecordBdo.setRxNum(String.valueOf(nrxSobaInfoDdo.getId().getNdsRxno()));
	}
}
