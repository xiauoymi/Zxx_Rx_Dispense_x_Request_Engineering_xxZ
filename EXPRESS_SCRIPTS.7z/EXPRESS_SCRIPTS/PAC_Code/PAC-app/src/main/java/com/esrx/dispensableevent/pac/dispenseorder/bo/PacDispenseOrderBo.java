package com.esrx.dispensableevent.pac.dispenseorder.bo;

import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderSubStatusCode;
import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderStatusCode;

public interface PacDispenseOrderBo {
	void processNRxDispenseOrderList(RxDispenseOrderStatusCode statusCode, RxDispenseOrderSubStatusCode subStatusCode);
}
