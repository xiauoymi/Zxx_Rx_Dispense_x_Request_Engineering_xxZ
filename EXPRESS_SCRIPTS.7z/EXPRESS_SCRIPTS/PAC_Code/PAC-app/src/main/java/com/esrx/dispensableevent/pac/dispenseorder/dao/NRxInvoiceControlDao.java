package com.esrx.dispensableevent.pac.dispenseorder.dao;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceControl;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceControlId;

public interface NRxInvoiceControlDao {

	List<NRxInvoiceControl> getNRxInvoiceControlList(NRxInvoiceControlId nrxInvoiceControlId);
	
	List<NRxInvoiceControl> getNRxInvoiceControlListByNMC(String nrxcdeTableNo);
	
	NRxInvoiceControl getNRxInvoiceControlForClientTable(String nrxcdeTableNo);
}
