package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.Request;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.CHANNEL;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.FORMAT;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ORG_ID;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ROLE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NO_INDICATOR;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;

public class RequestMapping {
	
	public void mapDatabaseToBusinessDomain(Request pacRequestBdo) {
		
		if(pacRequestBdo != null) {
			pacRequestBdo.setChannel(CHANNEL);
			pacRequestBdo.setFormat(FORMAT);
//			pacRequestBdo.setOrderRecord(OrderRecord);
			pacRequestBdo.setOrgId(ORG_ID);
			pacRequestBdo.setRole(ROLE);
			pacRequestBdo.setTestMode(NO_INDICATOR);
			pacRequestBdo.setUserId(EMPTY_STRING);
		}
	}

}
