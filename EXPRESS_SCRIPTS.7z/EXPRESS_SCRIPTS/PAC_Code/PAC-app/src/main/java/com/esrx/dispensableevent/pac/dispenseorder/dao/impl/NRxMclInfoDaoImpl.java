package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxMclInfoDao;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class NRxMclInfoDaoImpl extends GenericDaoHibernate<NRxMclInfo>
		implements NRxMclInfoDao {

	private static final Logger log = LoggerFactory
			.getLogger(NRxMclInfoDaoImpl.class);

	public NRxMclInfoDaoImpl(SessionFactory sf) {
		super(NRxMclInfo.class, sf);
	}

	public NRxMclInfo getManagedCareLetterRecord(NRxMclInfoId nrxMclInfoId) {
		NRxMclInfo nrxMclInfo = null;

		if (nrxMclInfoId != null) {
			nrxMclInfo = findById(nrxMclInfoId);
		}
		return nrxMclInfo;
	}

	public List<NRxMclInfo> getN006ManagedCareLetterRecordList(
			NRxMclInfoId nrxMclInfoId) {
		List<NRxMclInfo> managedCareLetterList = null;

		if (nrxMclInfoId != null) {
			DetachedCriteria managedCareLetterCriteria = DetachedCriteria
					.forClass(NRxMclInfo.class);

			managedCareLetterCriteria.add(Restrictions.eq("id", nrxMclInfoId));

			List<?> managedCareLetterRecordList = getHibernateTemplate()
					.findByCriteria(managedCareLetterCriteria);

			managedCareLetterList = new ArrayList<NRxMclInfo>();
			for (Object nrxMclInfoObj : managedCareLetterRecordList) {
				NRxMclInfo nrxMclInfo = (NRxMclInfo) nrxMclInfoObj;
				managedCareLetterList.add(nrxMclInfo);
			}
		}
		return managedCareLetterList;
	}

	public void updateNDMSendTimeStamp(NRxMclInfo nrxMclInfo) {
		StringBuilder updateHql = new StringBuilder();
		updateHql.append("update NRxMclInfo set ");
		updateHql.append("sendTms=:sendTms");
		updateHql.append(" where ");
		updateHql.append("id=:nrxMclInfoId");

		String updateNDMSendTimeStampHQL = String.valueOf(updateHql);

		if (nrxMclInfo != null) {
			Query updateNDXSendTimeStampQuery = getSession()
					.createQuery(updateNDMSendTimeStampHQL);
			updateNDXSendTimeStampQuery.setTimestamp("sendTms",
					nrxMclInfo.getSendTms());
			updateNDXSendTimeStampQuery.setParameter("nrxMclInfoId",
					nrxMclInfo.getId());
			updateNDXSendTimeStampQuery.executeUpdate();
		}
	}

	public List<NRxMclInfo> getManagedCareLetterOrderByLetterNum(
			NRxMclInfoId nrxMclInfoId) {
		List<NRxMclInfo> managedCareLetterList = null;

		if (nrxMclInfoId != null) {
			DetachedCriteria managedCareLetterCriteria = DetachedCriteria
					.forClass(NRxMclInfo.class);

			managedCareLetterCriteria.add(Restrictions.eq("id.ndmFillNo",nrxMclInfoId.getNdmFillNo()))
									 .add(Restrictions.eq("id.ndmInvno",nrxMclInfoId.getNdmInvno()))
									 .add(Restrictions.eq("id.ndmInvnoSub",nrxMclInfoId.getNdmInvnoSub()))
									 .add(Restrictions.eq("id.ndmLocaNo",nrxMclInfoId.getNdmLocaNo()))
									 .add(Restrictions.eq("id.ndmRxno",nrxMclInfoId.getNdmRxno()))
									 .addOrder(Order.asc("id.ndmLetterNo"));

			List<?> managedCareLetterRecordList = getHibernateTemplate()
					.findByCriteria(managedCareLetterCriteria);

			managedCareLetterList = new ArrayList<NRxMclInfo>();
			for (Object nrxMclInfoObj : managedCareLetterRecordList) {
				NRxMclInfo nrxMclInfo = (NRxMclInfo) nrxMclInfoObj;
				managedCareLetterList.add(nrxMclInfo);
			}
		}
		return managedCareLetterList;
	}
}
