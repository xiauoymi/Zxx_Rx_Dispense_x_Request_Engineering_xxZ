package com.esrx.dispensableevent.pac.dispenseorder.dao;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfoId;

public interface NRxSobaInfoDao {

	NRxSobaInfo getN002SOBARecord(NRxSobaInfoId nrxSobaInfoId); 
	
	List<NRxSobaInfo> getN002SOBARecordListById(NRxSobaInfoId nrxSobaInfoId); 
	
	List<NRxSobaInfo> getSOBARecordList(NRxSobaInfoId nrxSobaInfoId);
	
	void updateNDSTimeStamp(NRxSobaInfo nrxSobaInfo);
}
