package com.esrx.dispensableevent.pac.dispenseorder.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_FALSE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_TRUE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.DATE_FORMAT;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.TIME_STAMP_FORMAT;

public class DateUtil {
    
    public static boolean isAfterDate(Timestamp timestamp1, Timestamp timestamp2) {
    	Calendar  calendar1 = null;
    	Calendar  calendar2 = null;
    	boolean isAfterDateFlag = BOOLEAN_FALSE_FLAG;
    	if (timestamp1 != null || timestamp2 != null) {
    		
    		calendar1 =  Calendar.getInstance();
    		calendar2 =  Calendar.getInstance();
    		
    		calendar1.setTimeInMillis(timestamp1.getTime());
    		calendar2.setTimeInMillis(timestamp2.getTime());

            if (calendar1.after(calendar2))  {
            	isAfterDateFlag = BOOLEAN_TRUE_FLAG;
            }
    	}
        return isAfterDateFlag;
    }

	/**
	 * Gets the timestamp for string.
	 *
	 * @param date the date
	 * @return the timestamp for string
	 * @throws ParseException Dates should be xsi:string type in yyyy-MM-dd format.
	 * Timestamps should be xsi:string type in yyyy-MM-dd
	 * HH:mm:ss.mmm format.
	 */
	public static Timestamp getTimestampForString(String date)
			throws ParseException {
	
		Date parsedDate = null;
		Timestamp timestamp = null;
	
		if (date != null) {
			DateFormat currentDateFormat = new SimpleDateFormat(
					DATE_FORMAT);
			parsedDate = currentDateFormat.parse(date);
	
			
			Calendar dbFormatDate = Calendar.getInstance();
			dbFormatDate.setTime(parsedDate);
			
			Calendar currentTime = Calendar.getInstance();
			dbFormatDate.set(Calendar.HOUR, currentTime.get(Calendar.HOUR));
			dbFormatDate.set(Calendar.HOUR_OF_DAY, currentTime.get(Calendar.HOUR_OF_DAY));
			dbFormatDate.set(Calendar.MINUTE, currentTime.get(Calendar.MINUTE));
			dbFormatDate.set(Calendar.SECOND, currentTime.get(Calendar.SECOND));
			dbFormatDate.set(Calendar.MILLISECOND, currentTime.get(Calendar.MILLISECOND));
	
			timestamp = new Timestamp(dbFormatDate.getTime().getTime());
		}
		return timestamp;
	}

	/**
		 * @param date
		 * @return
		 * @throws ParseException
		 *             Dates should be xsi:string type in yyyy-MM-dd format.
		 *             Timestamps should be xsi:string type in yyyy-MM-dd
		 *             HH:mm:ss.mmm format.
		 */
		public static Timestamp getDB2TimestampForString(String date)
				throws ParseException {
	
			Date parsedDate = null;
			Timestamp timestamp = null;
			
			if (date != null) {
				parsedDate = new SimpleDateFormat(DATE_FORMAT).parse(date);
	
				Calendar dbFormatDate = Calendar.getInstance();
				dbFormatDate.setTime(parsedDate);
				
				Calendar currentTime = Calendar.getInstance();
				dbFormatDate.set(Calendar.HOUR, currentTime.get(Calendar.HOUR));
				dbFormatDate.set(Calendar.HOUR_OF_DAY, currentTime.get(Calendar.HOUR_OF_DAY));
				dbFormatDate.set(Calendar.MINUTE, currentTime.get(Calendar.MINUTE));
				dbFormatDate.set(Calendar.SECOND, currentTime.get(Calendar.SECOND));
				dbFormatDate.clear(Calendar.MILLISECOND);
	//			dbFormatDate.set(Calendar.MILLISECOND, currentTime.get(Calendar.MILLISECOND));			
	
				DateFormat db2DateFormat = new SimpleDateFormat(TIME_STAMP_FORMAT);
	
				timestamp = new Timestamp(dbFormatDate.getTime().getTime());
				parsedDate = db2DateFormat.parse(db2DateFormat.format(dbFormatDate.getTime()));  
			}
			return timestamp;
		}
		
		public static Timestamp getCurrentTimestamp() {
			Date currentDate = new Date();
			Timestamp currentTimestamp = new Timestamp(currentDate.getTime());
			return currentTimestamp;
		}
}