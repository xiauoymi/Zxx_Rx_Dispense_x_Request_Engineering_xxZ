/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * PatientInfoDdo.
 */
@Entity
@Table(name="TBL_PATIENT_INFO"
, uniqueConstraints = {  }
)

public class PatientInfoDdo  implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

     /** The patient id. */
     private String patientId;
     
     /** The patient first name. */
     private String patientFirstName;
     
     /** The patient last name. */
     private String patientLastName;
     
     /** The patient date of birth. */
     private Date patientDateOfBirth;
     
     /** The patient gender. */
     private String patientGender;
     
     /** The patient middle initial. */
     private String patientMiddleInitial;
     
     /** The patient address name. */
     private String patientAddressName;
     
     /** The patient address line1. */
     private String patientAddressLine1;
     
     /** The patient address line2. */
     private String patientAddressLine2;
     
     /** The patient city. */
     private String patientCity;
     
     /** The patient state. */
     private String patientState;
     
     /** The patient zip. */
     private String patientZip;
     
     /** The patient country. */
     private String patientCountry;
     
     /** The patient phone. */
     private Long patientPhone;
     
     /** The patient email. */
     private String patientEmail;
     
     /** The patient business phone. */
     private String patientBusinessPhone;
     
     /** The patient item count. */
     private Byte patientItemCount;
     
     /** The patient identifier. */
     private String patientIdentifier;
     
     /** The patient language. */
     private String patientLanguage;
     
     /** The patient rx count. */
     private Integer patientRxCount;


    /**
     * default constructor.
     */
    public PatientInfoDdo() {
    }

	/** The id. */
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, precision = 30, scale = 0)),
			@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, length = 15)),
			@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, precision = 9, scale = 0)),
			@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, length = 1))})
	private RxDispenseRequestIdDdo id;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public RxDispenseRequestIdDdo getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(RxDispenseRequestIdDdo id) {
		this.id = id;
	}

    /**
     * Gets the patient id.
     *
     * @return the patient id
     */
    @Id
    @Column(name="PATIENT_ID", unique=true, nullable=false, insertable=true, updatable=true, length=10)

    public String getPatientId() {
        return this.patientId;
    }
    
    /**
     * Sets the patient id.
     *
     * @param patientId the new patient id
     */
    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }
	
    /** The rx dispense request. */
    private RxDispenseRequestDdo rxDispenseRequest;

	/**
	 * Gets the rx dispense request.
	 *
	 * @return the rx dispense request
	 */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumns({
			@JoinColumn(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "TRANS_ID"),
			@JoinColumn(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "CLIENT_ID"),
			@JoinColumn(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "ORDER_NUM"),
			@JoinColumn(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName = "SUBORDER_IND")})
	public RxDispenseRequestDdo getRxDispenseRequest() {
		return this.rxDispenseRequest;
	}

	/**
	 * Sets the rx dispense request.
	 *
	 * @param rxDispenseRequest the new rx dispense request
	 */
	public void setRxDispenseRequest(RxDispenseRequestDdo rxDispenseRequest) {
		this.rxDispenseRequest = rxDispenseRequest;
	}
	
    /**
     * Gets the patient first name.
     *
     * @return the patient first name
     */
    @Column(name="PATIENT_FIRST_NAME", unique=false, nullable=true, insertable=true, updatable=true, length=20)

    public String getPatientFirstName() {
        return this.patientFirstName;
    }
    
    /**
     * Sets the patient first name.
     *
     * @param patientFirstName the new patient first name
     */
    public void setPatientFirstName(String patientFirstName) {
        this.patientFirstName = patientFirstName;
    }
    
    /**
     * Gets the patient last name.
     *
     * @return the patient last name
     */
    @Column(name="PATIENT_LAST_NAME", unique=false, nullable=true, insertable=true, updatable=true, length=20)

    public String getPatientLastName() {
        return this.patientLastName;
    }
    
    /**
     * Sets the patient last name.
     *
     * @param patientLastName the new patient last name
     */
    public void setPatientLastName(String patientLastName) {
        this.patientLastName = patientLastName;
    }
    
    /**
     * Gets the patient date of birth.
     *
     * @return the patient date of birth
     */
    @Column(name="PATIENT_DATE_OF_BIRTH", unique=false, nullable=true, insertable=true, updatable=true, length=7)

    public Date getPatientDateOfBirth() {
        return this.patientDateOfBirth;
    }
    
    /**
     * Sets the patient date of birth.
     *
     * @param patientDateOfBirth the new patient date of birth
     */
    public void setPatientDateOfBirth(Date patientDateOfBirth) {
        this.patientDateOfBirth = patientDateOfBirth;
    }
    
    /**
     * Gets the patient gender.
     *
     * @return the patient gender
     */
    @Column(name="PATIENT_GENDER", unique=false, nullable=true, insertable=true, updatable=true, length=1)

    public String getPatientGender() {
        return this.patientGender;
    }
    
    /**
     * Sets the patient gender.
     *
     * @param patientGender the new patient gender
     */
    public void setPatientGender(String patientGender) {
        this.patientGender = patientGender;
    }
    
    /**
     * Gets the patient middle initial.
     *
     * @return the patient middle initial
     */
    @Column(name="PATIENT_MIDDLE_INITIAL", unique=false, nullable=true, insertable=true, updatable=true, length=5)

    public String getPatientMiddleInitial() {
        return this.patientMiddleInitial;
    }
    
    /**
     * Sets the patient middle initial.
     *
     * @param patientMiddleInitial the new patient middle initial
     */
    public void setPatientMiddleInitial(String patientMiddleInitial) {
        this.patientMiddleInitial = patientMiddleInitial;
    }
    
    /**
     * Gets the patient address name.
     *
     * @return the patient address name
     */
    @Column(name="PATIENT_ADDRESS_NAME", unique=false, nullable=true, insertable=true, updatable=true, length=40)

    public String getPatientAddressName() {
        return this.patientAddressName;
    }
    
    /**
     * Sets the patient address name.
     *
     * @param patientAddressName the new patient address name
     */
    public void setPatientAddressName(String patientAddressName) {
        this.patientAddressName = patientAddressName;
    }
    
    /**
     * Gets the patient address line1.
     *
     * @return the patient address line1
     */
    @Column(name="PATIENT_ADDRESS_LINE1", unique=false, nullable=true, insertable=true, updatable=true, length=25)

    public String getPatientAddressLine1() {
        return this.patientAddressLine1;
    }
    
    /**
     * Sets the patient address line1.
     *
     * @param patientAddressLine1 the new patient address line1
     */
    public void setPatientAddressLine1(String patientAddressLine1) {
        this.patientAddressLine1 = patientAddressLine1;
    }
    
    /**
     * Gets the patient address line2.
     *
     * @return the patient address line2
     */
    @Column(name="PATIENT_ADDRESS_LINE2", unique=false, nullable=true, insertable=true, updatable=true, length=25)

    public String getPatientAddressLine2() {
        return this.patientAddressLine2;
    }
    
    /**
     * Sets the patient address line2.
     *
     * @param patientAddressLine2 the new patient address line2
     */
    public void setPatientAddressLine2(String patientAddressLine2) {
        this.patientAddressLine2 = patientAddressLine2;
    }
    
    /**
     * Gets the patient city.
     *
     * @return the patient city
     */
    @Column(name="PATIENT_CITY", unique=false, nullable=true, insertable=true, updatable=true, length=25)

    public String getPatientCity() {
        return this.patientCity;
    }
    
    /**
     * Sets the patient city.
     *
     * @param patientCity the new patient city
     */
    public void setPatientCity(String patientCity) {
        this.patientCity = patientCity;
    }
    
    /**
     * Gets the patient state.
     *
     * @return the patient state
     */
    @Column(name="PATIENT_STATE", unique=false, nullable=true, insertable=true, updatable=true, length=2)

    public String getPatientState() {
        return this.patientState;
    }
    
    /**
     * Sets the patient state.
     *
     * @param patientState the new patient state
     */
    public void setPatientState(String patientState) {
        this.patientState = patientState;
    }
    
    /**
     * Gets the patient zip.
     *
     * @return the patient zip
     */
    @Column(name="PATIENT_ZIP", unique=false, nullable=true, insertable=true, updatable=true, length=10)

    public String getPatientZip() {
        return this.patientZip;
    }
    
    /**
     * Sets the patient zip.
     *
     * @param patientZip the new patient zip
     */
    public void setPatientZip(String patientZip) {
        this.patientZip = patientZip;
    }
    
    /**
     * Gets the patient country.
     *
     * @return the patient country
     */
    @Column(name="PATIENT_COUNTRY", unique=false, nullable=true, insertable=true, updatable=true, length=40)

    public String getPatientCountry() {
        return this.patientCountry;
    }
    
    /**
     * Sets the patient country.
     *
     * @param patientCountry the new patient country
     */
    public void setPatientCountry(String patientCountry) {
        this.patientCountry = patientCountry;
    }
    
    /**
     * Gets the patient phone.
     *
     * @return the patient phone
     */
    @Column(name="PATIENT_PHONE", unique=false, nullable=true, insertable=true, updatable=true, precision=10, scale=0)

    public Long getPatientPhone() {
        return this.patientPhone;
    }
    
    /**
     * Sets the patient phone.
     *
     * @param patientPhone the new patient phone
     */
    public void setPatientPhone(Long patientPhone) {
        this.patientPhone = patientPhone;
    }
    
    /**
     * Gets the patient email.
     *
     * @return the patient email
     */
    @Column(name="PATIENT_EMAIL", unique=false, nullable=true, insertable=true, updatable=true, length=40)

    public String getPatientEmail() {
        return this.patientEmail;
    }
    
    /**
     * Sets the patient email.
     *
     * @param patientEmail the new patient email
     */
    public void setPatientEmail(String patientEmail) {
        this.patientEmail = patientEmail;
    }
    
    /**
     * Gets the patient business phone.
     *
     * @return the patient business phone
     */
    @Column(name="PATIENT_BUSINESS_PHONE", unique=false, nullable=true, insertable=true, updatable=true, length=10)

    public String getPatientBusinessPhone() {
        return this.patientBusinessPhone;
    }
    
    /**
     * Sets the patient business phone.
     *
     * @param patientBusinessPhone the new patient business phone
     */
    public void setPatientBusinessPhone(String patientBusinessPhone) {
        this.patientBusinessPhone = patientBusinessPhone;
    }
    
    /**
     * Gets the patient item count.
     *
     * @return the patient item count
     */
    @Column(name="PATIENT_ITEM_COUNT", unique=false, nullable=true, insertable=true, updatable=true, precision=2, scale=0)

    public Byte getPatientItemCount() {
        return this.patientItemCount;
    }
    
    /**
     * Sets the patient item count.
     *
     * @param patientItemCount the new patient item count
     */
    public void setPatientItemCount(Byte patientItemCount) {
        this.patientItemCount = patientItemCount;
    }
    
    /**
     * Gets the patient identifier.
     *
     * @return the patient identifier
     */
    @Column(name="PATIENT_IDENTIFIER", unique=false, nullable=true, insertable=true, updatable=true, length=10)

    public String getPatientIdentifier() {
        return this.patientIdentifier;
    }
    
    /**
     * Sets the patient identifier.
     *
     * @param patientIdentifier the new patient identifier
     */
    public void setPatientIdentifier(String patientIdentifier) {
        this.patientIdentifier = patientIdentifier;
    }
    
    /**
     * Gets the patient language.
     *
     * @return the patient language
     */
    @Column(name="PATIENT_LANGUAGE", unique=false, nullable=true, insertable=true, updatable=true, length=10)

    public String getPatientLanguage() {
        return this.patientLanguage;
    }
    
    /**
     * Sets the patient language.
     *
     * @param patientLanguage the new patient language
     */
    public void setPatientLanguage(String patientLanguage) {
        this.patientLanguage = patientLanguage;
    }
    
    /**
     * Gets the patient rx count.
     *
     * @return the patient rx count
     */
    @Column(name="PATIENT_RX_COUNT", unique=false, nullable=true, insertable=true, updatable=true, precision=5, scale=0)

    public Integer getPatientRxCount() {
        return this.patientRxCount;
    }
    
    /**
     * Sets the patient rx count.
     *
     * @param patientRxCount the new patient rx count
     */
    public void setPatientRxCount(Integer patientRxCount) {
        this.patientRxCount = patientRxCount;
    }
   








}
