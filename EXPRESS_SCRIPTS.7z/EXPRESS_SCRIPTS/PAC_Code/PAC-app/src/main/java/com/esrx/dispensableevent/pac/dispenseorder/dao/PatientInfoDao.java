package com.esrx.dispensableevent.pac.dispenseorder.dao;

import java.util.List;
import java.util.Set;

import com.esrx.dispensableevent.rxdispense.domain.PatientInfoDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestIdDdo;

public interface PatientInfoDao {
	RxDispenseRequestDdo getPatientInfoDdoList(RxDispenseRequestIdDdo rxDispenseRequestIdDdo);
	 
}
