package com.esrx.dispensableevent.pac.dispenseorder.dao;

import com.esrx.dispensableevent.nrxupdate.domain.NRxRxFinancial;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxFinancialId;

public interface NRxRxFinancialDao {

	NRxRxFinancial getNRxRxFinancialInfoWithUR(NRxRxFinancialId nrxRxFinancialId);
}
