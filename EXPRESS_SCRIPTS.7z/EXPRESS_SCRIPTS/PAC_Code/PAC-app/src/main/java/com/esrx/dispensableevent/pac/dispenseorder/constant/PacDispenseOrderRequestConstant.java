package com.esrx.dispensableevent.pac.dispenseorder.constant;

public class PacDispenseOrderRequestConstant {
	
	public final static boolean BOOLEAN_FALSE_FLAG = false;
	public final static boolean BOOLEAN_TRUE_FLAG = true;
	
	public final static int NDI_VER_NO = 99;
	public final static int NDI_RECEIVE_ERROR_CODE = 80;
	
	public final static String R_INDICATOR = "R";
	/**
	 * Dates should be xsi:string type in yyyy-MM-dd format. Timestamps should
	 * be xsi:string type in yyyy-MM-dd HH:mm:ss.mmm format.
	 */
	public final static String DATE_FORMAT = "MM/dd/yyyy";
	public final static String DB2_TIME_STAMP_FORMAT = "MM/dd/yyyy hh:mm:ss aa";
	public final static String TIME_STAMP_FORMAT = "yyyy-MM-dd HH:mm:ss";
	
	public final static String CATAMARAN_CONTROL_TABLE  = "COT";
	public final static String NRX_INVOICE_CONTROL_NMC  = "NMC";


//	public final static String TEST_MODE = "N";
	public final static String ORG_ID = "MEDCO";
	public final static String CHANNEL = "PAC";
	public final static String ROLE = "DEV";
//	public final static String USER_ID = "";
	public final static String FORMAT = "X";
	
	public final static String ADMIN_CODE = "MHS";
//	public final static int DIVERT_NO = 0;
	public final static int ZERO = 0;	
	public final static int ONE = 1;
	public final static int THREE = 3;
	public final static int FOUR = 4;
	
	public final static int PAC_ALLOWED_RX_MAX_LIMIT = 24;
	
	public final static String SUB_GROUP = "GM22400";
	public final static String TAX = "+00000.00";
	public final static String PACK_REL_NUMBER = "003779141";
	public final static String VERB_CODE = "000";
	public final static String CC_LAST4DIGIT = "0000";
	public final static String RETAIL_PHARM_NUM = "0000000";
	public final static String ADDRESS_TYPE = "H";
	public final static String REFRIG_FLAG = "Y";
	public final static String ALT_SHIPPING_PHONENUM = "0000000000";
	public final static String DECLARED_VALUE = "+0000000.00";
	public final static String SVC_BRANCH_ID = "000";
	public final static String WRK_ORDR_ID = "NN";
//	public final static String QSI_DELIV_DATE = "20060314";
	public final static String CLEAN_INTERV = "I";
//	public final static String EAST_WEST_FLAG = "W";
	public final static String EAST_WEST_FLAG = "M";
	public final static String BRAND_ID = "01";
	
	public final static String YES_INDICATOR="Y";
	public final static String NO_INDICATOR="N";
	public final static String Q_INDICATOR="Q";
	
	public final static String NS_ORD_COMM_RES_IND = "R";
	public final static String NS_ORD_DOM_INTER_IND = "D";
	
	public final static String LANG_FLAG_SPANISH = "S";
	public final static String LANG_FLAG_ENGLISH = "1";

//	public final static String SAFETY_CAP = "N";

	public final static String NDP_MANAGED_CARE_PARAMETER_BEGINDELIM = "&lt;#";      
	public final static String NDP_MANAGED_CARE_PARAMETER_MIDDELIM = "=";
	public final static String NDP_MANAGED_CARE_PARAMETER_ENDDELIM = "&gt;";
	
	public final static String EMPTY_STRING = "";
	
	public final static String MCL_RX_NO = "9990000000";
	public final static String NRX_CDE_CODE_VLU = "9999999999";
	
	public final static String QSI_DELIV_DATE = "0001-01-01";
	
}
