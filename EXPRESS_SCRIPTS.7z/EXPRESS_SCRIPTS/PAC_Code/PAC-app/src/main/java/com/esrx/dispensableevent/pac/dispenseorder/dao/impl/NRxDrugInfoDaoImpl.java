package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.HibernateCallback;

import com.esrx.dispensableevent.nrxupdate.domain.NRxDrugInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxDrugInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxDrugInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.util.NRxDaoImplUtil;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import static com.esrx.dispensableevent.pac.dispenseorder.util.NRxDaoImplUtil.getDBdefaultSchema;

public class NRxDrugInfoDaoImpl extends GenericDaoHibernate<NRxDrugInfo>
		implements NRxDrugInfoDao {

	private static final Logger log = LoggerFactory
			.getLogger(NRxDrugInfoDaoImpl.class);

	
	public NRxDrugInfoDaoImpl(SessionFactory sf) {
		super(NRxDrugInfo.class, sf);
	}

	public NRxDrugInfo getNRxDrugInfo(NRxDrugInfoId nrxDrugInfoId) {
		NRxDrugInfo nrxDrugInfo = null;

		if (nrxDrugInfoId != null) {
			nrxDrugInfo = findById(nrxDrugInfoId);
		}
		return nrxDrugInfo;
	}


	public NRxDrugInfo getNRxDrugInfoWithUR(NRxDrugInfoId nrxDrugInfoId) {

		StringBuilder  constructSQLWithUR = null;
		if (nrxDrugInfoId != null) {
			String dbDefaultSchema  = getDBdefaultSchema(getSessionFactory());
			constructSQLWithUR = new StringBuilder();
			constructSQLWithUR.append("SELECT * FROM ");
			constructSQLWithUR.append(dbDefaultSchema);
			constructSQLWithUR.append(".NRXDRG00");
			constructSQLWithUR.append(" WHERE ");
			constructSQLWithUR.append("NRXDRG_DRNO=");
			constructSQLWithUR.append(nrxDrugInfoId.getDrno());
			constructSQLWithUR.append(" AND ");
			constructSQLWithUR.append("NRXDRG_FILL_NO=");
			constructSQLWithUR.append(nrxDrugInfoId.getFillNo());
			constructSQLWithUR.append(" WITH UR");      			/*Isolation.READ_UNCOMMITTED   FOR DB2*/ 
		}
		
		final String nativeSQL = String.valueOf(constructSQLWithUR);

		return getHibernateTemplate().execute(
				new HibernateCallback<NRxDrugInfo>() {
					public NRxDrugInfo doInHibernate(Session session) {
						Query query = session.createSQLQuery(nativeSQL).addEntity(NRxDrugInfo.class);
						return (NRxDrugInfo) query.list().get(ZERO);
					}
				});
	}

	/*The following will not be removed*/
/*  
    @Transactional(propagation = Propagation.REQUIRED, isolation =
	 Isolation.READ_UNCOMMITTED, readOnly = true)
	 Caused by: java.sql.SQLException: READ_COMMITTED and SERIALIZABLE are the
	 only valid transaction levels
	public NrxDrugInfo getNrxDrugInfoWithUR(NrxDrugInfoId nrxDrugInfoId) {

		final String selectHql = "FROM NrxDrugInfo WHERE id=:id";
		final String selectHql = "FROM NrxDrugInfo WHERE id.fillNo=:fillNo and id.drno=:drno";
		final String selectHql = "FROM NrxDrugInfo WHERE id.fillNo=? and id.drno=?";
		final String nativeSQL = "FROM NrxDrugInfo WHERE id=:id";
		final NrxDrugInfoId id = nrxDrugInfoId;

		return getHibernateTemplate().execute(
				new HibernateCallback<NrxDrugInfo>() {
					public NrxDrugInfo doInHibernate(Session session) {
						Query query = session.createQuery(nativeSQL);
						query.setParameter("fillNo", id.getFillNo());
						query.setParameter("drno", id.getDrno());
						
						query.setParameter("id", id);
						
						Query query = session.createSQLQuery(selectHql).addEntity(NrxDrugInfo.class);
						query.setParameter(1, id.getFillNo());
						query.setParameter(2, id.getDrno());
						System.out.println("  A:   "+query.getQueryString());
						
						return (NrxDrugInfo) query.list().get(0);
					}
				});
	}
*/	
}
