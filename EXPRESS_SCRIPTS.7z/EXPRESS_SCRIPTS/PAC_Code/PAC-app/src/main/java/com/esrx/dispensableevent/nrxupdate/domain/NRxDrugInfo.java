package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "NRXDRG00", uniqueConstraints = {})
public class NRxDrugInfo implements Serializable {

	private static final long serialVersionUID = -8715724344297920900L;
	private NRxDrugInfoId id;
	private String ndcLab;
	private String ndcProd;
	private String ndcSize;
	private String name;
	private String potency;
	private String manu;
	private String abuseCd;
	private String nrxdrgClass;
	private String locPfx01;
	private String locPfx02;
	private String locPfx03;
	private String locPfx04;
	private String locPfx05;
	private String locPfx06;
	private String locPfx07;
	private String locPfx08;
	private String locPfx09;
	private String locPfx10;
	private int locNo01;
	private int locNo02;
	private int locNo03;
	private int locNo04;
	private int locNo05;
	private int locNo06;
	private int locNo07;
	private int locNo08;
	private int locNo09;
	private int locNo10;
	private int locSize01;
	private int locSize02;
	private int locSize03;
	private int locSize04;
	private int locSize05;
	private int locSize06;
	private int locSize07;
	private int locSize08;
	private int locSize09;
	private int locSize10;
	private int genno;
	private int locaNo;
	private int boh;
	private int qtyDisp;
	private int qtyOrd;
	private double awp;
	private int cat;
	private int insertno;
	private double metricSz;
	private int allergy01;
	private int allergy02;
	private int allergy03;
	private int auxno01;
	private int auxno02;
	private int auxno03;
	private int auxno04;
	private int auxno05;
	private int auxno06;
	private int auxno07;
	private int auxno08;
	private int auxno09;
	private int auxno10;
	private double dosesDay;
	private Date expDate01;
	private Date expDate02;
	private Date expDate03;
	private Date expDate04;
	private Date expDate05;
	private Date expDate06;
	private Date expDate07;
	private Date expDate08;
	private Date expDate09;
	private Date expDate10;
	private double dosageUnit;
	private double wasteFactr;
	private double stdMeasure;
	private String tabletId;
	private String ctlClass;
	private int rank;
	private String botNdcLab;
	private String botNdcPrd;
	private String botNdcSze;
	private int pd1Cat;
	private int uscCode;
	private double prevAwp;
	private Date awpEffDt;
	private String unitType;
	private double unitsPkg;
	private String voidCd;
	private Date transTmstp;
	private String operId;
	private String qtyRndInd;
	private double pkgsBox;
	private Date transDate;
	private String comment;
	private String altLocPfx;
	private int altLocNo;
	private String protReason;
	private String protType;
	private String mfAuxFlg;
	private Date mfExpDt;
	private String mandPpi;
	private Date mandPpiDt;
	private String mktgPpi;
	private String enhPpi;
	private String newPpi1;
	private String newPpi2;
	private String drgSpPpi;
	private String scrDspInd;
	private String chemNm;
	private String stopCode;
	private Date stopEffDt;
	private String ltrDrgNm;
	private String ltrDrgSt;
	private String ltrManuNm;
	private String ltrManuSt;
	private String botDrgNm;
	private String botDrgSt;
	private String tabId;
	private String pdMultisrc;
	private int disExtNbr;
	private String ltrGnrcNm;
	private Date ppiRevDt;
	private String botManuNm;
	private int spPpiPgs;
	private String specDrgIn;
	private int drgInsPgs;
	private int mndPpiPgs;
	private int mkgPpiPgs;
	private int enhPpiPgs;
	private int nwPpi1Pgs;
	private int nwPpi2Pgs;
	private int ndpDrugNo;
	private String salesCde;
	private int regCat1Cd;
	private int regCat2Cd;
	private String dispCatCd;
	private String stopCdDsc;
	private String tmpSensCd;
	private String mltBrdNm;
	private String mltGenNm;
	private double mltRevNm;
	private Date stopEndDt;
	private double divisorQty;
	private String prefInd;
	private int regCat3Cd;
	private int regCat4Cd;
	private int regCat5Cd;
	private String ndcQual;
	private String botndcQual;
	private String dawCd;
	private String ndcObsdt;
	private String ndcObsfl;
	private String btndcObsdt;
	private String btndcObsfl;
	private int specialty;
	private int ancillary;
	private String mfrQty;
	private String specltyInd;
	private String ancllryInd;
	private String dspMailCd;
	private String mfrRegCd;
	private String refrgtCd;
	private String patCallCd;
	private String spTherCat;
	private double awpAmt;
	private String spHandlCd;
	private Date gmqEffDt;
	private String indntDrCd;
	private String ndcPs;
	private String rtlPickup;
	private double uslDspQty;
	private String medbOutsrc;
	private String baseInd;
	private int esiwRefDrno;
	private int dodDrno;
	private String dodUnitsPkgInd;
	private String dodPkgSizeSwCd;
	private int dispTypeCd;
	private String dodReplenishInd;
	private String dodCentralFillInd;
	private double dodMetricSz;
	private String dodRepackInd;
	private String dodSpecialtyInd;
	private String mtfInd;
	private String dodNdcCd;
	private double dodUnitsPkg;
	private String stop2Code;
	private Date stop2EffDt;
	private String stop2CdDsc;

	// Default Constructor
	public NRxDrugInfo() {
		
	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "fillNo", column = @Column(name = "NRXDRG_FILL_NO")),
			@AttributeOverride(name = "drno", column = @Column(name = "NRXDRG_DRNO"))
	})
	public NRxDrugInfoId getId() {
		return id;
	}

	public void setId(NRxDrugInfoId id) {
		this.id = id;
	}

	@Column(name = "NRXDRG_NDC_LAB")
	public String getNdcLab() {
		return ndcLab;
	}

	public void setNdcLab(String ndcLab) {
		this.ndcLab = ndcLab;
	}

	@Column(name = "NRXDRG_NDC_PROD")
	public String getNdcProd() {
		return ndcProd;
	}

	public void setNdcProd(String ndcProd) {
		this.ndcProd = ndcProd;
	}

	@Column(name = "NRXDRG_NDC_SIZE")
	public String getNdcSize() {
		return ndcSize;
	}

	public void setNdcSize(String ndcSize) {
		this.ndcSize = ndcSize;
	}

	@Column(name = "NRXDRG_NAME")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "NRXDRG_POTENCY")
	public String getPotency() {
		return potency;
	}

	public void setPotency(String potency) {
		this.potency = potency;
	}

	@Column(name = "NRXDRG_MANU")
	public String getManu() {
		return manu;
	}

	public void setManu(String manu) {
		this.manu = manu;
	}

	@Column(name = "NRXDRG_ABUSE_CD")
	public String getAbuseCd() {
		return abuseCd;
	}

	public void setAbuseCd(String abuseCd) {
		this.abuseCd = abuseCd;
	}

	@Column(name = "NRXDRG_CLASS")
	public String getNrxdrgClass() {
		return nrxdrgClass;
	}

	public void setNrxdrgClass(String nrxdrgClass) {
		this.nrxdrgClass = nrxdrgClass;
	}

	@Column(name = "NRXDRG_LOC_PFX_01")
	public String getLocPfx01() {
		return locPfx01;
	}

	public void setLocPfx01(String locPfx01) {
		this.locPfx01 = locPfx01;
	}

	@Column(name = "NRXDRG_LOC_PFX_02")
	public String getLocPfx02() {
		return locPfx02;
	}

	public void setLocPfx02(String locPfx02) {
		this.locPfx02 = locPfx02;
	}

	@Column(name = "NRXDRG_LOC_PFX_03")
	public String getLocPfx03() {
		return locPfx03;
	}

	public void setLocPfx03(String locPfx03) {
		this.locPfx03 = locPfx03;
	}

	@Column(name = "NRXDRG_LOC_PFX_04")
	public String getLocPfx04() {
		return locPfx04;
	}

	public void setLocPfx04(String locPfx04) {
		this.locPfx04 = locPfx04;
	}

	@Column(name = "NRXDRG_LOC_PFX_05")
	public String getLocPfx05() {
		return locPfx05;
	}

	public void setLocPfx05(String locPfx05) {
		this.locPfx05 = locPfx05;
	}

	@Column(name = "NRXDRG_LOC_PFX_06")
	public String getLocPfx06() {
		return locPfx06;
	}

	public void setLocPfx06(String locPfx06) {
		this.locPfx06 = locPfx06;
	}

	@Column(name = "NRXDRG_LOC_PFX_07")
	public String getLocPfx07() {
		return locPfx07;
	}

	public void setLocPfx07(String locPfx07) {
		this.locPfx07 = locPfx07;
	}

	@Column(name = "NRXDRG_LOC_PFX_08")
	public String getLocPfx08() {
		return locPfx08;
	}

	public void setLocPfx08(String locPfx08) {
		this.locPfx08 = locPfx08;
	}

	@Column(name = "NRXDRG_LOC_PFX_09")
	public String getLocPfx09() {
		return locPfx09;
	}

	public void setLocPfx09(String locPfx09) {
		this.locPfx09 = locPfx09;
	}

	@Column(name = "NRXDRG_LOC_PFX_10")
	public String getLocPfx10() {
		return locPfx10;
	}

	public void setLocPfx10(String locPfx10) {
		this.locPfx10 = locPfx10;
	}

	@Column(name = "NRXDRG_LOC_NO_01")
	public int getLocNo01() {
		return locNo01;
	}

	public void setLocNo01(int locNo01) {
		this.locNo01 = locNo01;
	}

	@Column(name = "NRXDRG_LOC_NO_02")
	public int getLocNo02() {
		return locNo02;
	}

	public void setLocNo02(int locNo02) {
		this.locNo02 = locNo02;
	}

	@Column(name = "NRXDRG_LOC_NO_03")
	public int getLocNo03() {
		return locNo03;
	}

	public void setLocNo03(int locNo03) {
		this.locNo03 = locNo03;
	}

	@Column(name = "NRXDRG_LOC_NO_04")
	public int getLocNo04() {
		return locNo04;
	}

	public void setLocNo04(int locNo04) {
		this.locNo04 = locNo04;
	}

	@Column(name = "NRXDRG_LOC_NO_05")
	public int getLocNo05() {
		return locNo05;
	}

	public void setLocNo05(int locNo05) {
		this.locNo05 = locNo05;
	}

	@Column(name = "NRXDRG_LOC_NO_06")
	public int getLocNo06() {
		return locNo06;
	}

	public void setLocNo06(int locNo06) {
		this.locNo06 = locNo06;
	}

	@Column(name = "NRXDRG_LOC_NO_07")
	public int getLocNo07() {
		return locNo07;
	}

	public void setLocNo07(int locNo07) {
		this.locNo07 = locNo07;
	}

	@Column(name = "NRXDRG_LOC_NO_08")
	public int getLocNo08() {
		return locNo08;
	}

	public void setLocNo08(int locNo08) {
		this.locNo08 = locNo08;
	}

	@Column(name = "NRXDRG_LOC_NO_09")
	public int getLocNo09() {
		return locNo09;
	}

	public void setLocNo09(int locNo09) {
		this.locNo09 = locNo09;
	}

	@Column(name = "NRXDRG_LOC_NO_10")
	public int getLocNo10() {
		return locNo10;
	}

	public void setLocNo10(int locNo10) {
		this.locNo10 = locNo10;
	}

	@Column(name = "NRXDRG_LOC_SIZE_01")
	public int getLocSize01() {
		return locSize01;
	}

	public void setLocSize01(int locSize01) {
		this.locSize01 = locSize01;
	}

	@Column(name = "NRXDRG_LOC_SIZE_02")
	public int getLocSize02() {
		return locSize02;
	}

	public void setLocSize02(int locSize02) {
		this.locSize02 = locSize02;
	}

	@Column(name = "NRXDRG_LOC_SIZE_03")
	public int getLocSize03() {
		return locSize03;
	}

	public void setLocSize03(int locSize03) {
		this.locSize03 = locSize03;
	}

	@Column(name = "NRXDRG_LOC_SIZE_04")
	public int getLocSize04() {
		return locSize04;
	}

	public void setLocSize04(int locSize04) {
		this.locSize04 = locSize04;
	}

	@Column(name = "NRXDRG_LOC_SIZE_05")
	public int getLocSize05() {
		return locSize05;
	}

	public void setLocSize05(int locSize05) {
		this.locSize05 = locSize05;
	}

	@Column(name = "NRXDRG_LOC_SIZE_06")
	public int getLocSize06() {
		return locSize06;
	}

	public void setLocSize06(int locSize06) {
		this.locSize06 = locSize06;
	}

	@Column(name = "NRXDRG_LOC_SIZE_07")
	public int getLocSize07() {
		return locSize07;
	}

	public void setLocSize07(int locSize07) {
		this.locSize07 = locSize07;
	}

	@Column(name = "NRXDRG_LOC_SIZE_08")
	public int getLocSize08() {
		return locSize08;
	}

	public void setLocSize08(int locSize08) {
		this.locSize08 = locSize08;
	}

	@Column(name = "NRXDRG_LOC_SIZE_09")
	public int getLocSize09() {
		return locSize09;
	}

	public void setLocSize09(int locSize09) {
		this.locSize09 = locSize09;
	}

	@Column(name = "NRXDRG_LOC_SIZE_10")
	public int getLocSize10() {
		return locSize10;
	}

	public void setLocSize10(int locSize10) {
		this.locSize10 = locSize10;
	}

	@Column(name = "NRXDRG_GENNO")
	public int getGenno() {
		return genno;
	}

	public void setGenno(int genno) {
		this.genno = genno;
	}

	@Column(name = "NRXDRG_LOCA_NO")
	public int getLocaNo() {
		return locaNo;
	}

	public void setLocaNo(int locaNo) {
		this.locaNo = locaNo;
	}

	@Column(name = "NRXDRG_BOH")
	public int getBoh() {
		return boh;
	}

	public void setBoh(int boh) {
		this.boh = boh;
	}

	@Column(name = "NRXDRG_QTY_DISP")
	public int getQtyDisp() {
		return qtyDisp;
	}

	public void setQtyDisp(int qtyDisp) {
		this.qtyDisp = qtyDisp;
	}

	@Column(name = "NRXDRG_QTY_ORD")
	public int getQtyOrd() {
		return qtyOrd;
	}

	public void setQtyOrd(int qtyOrd) {
		this.qtyOrd = qtyOrd;
	}

	@Column(name = "NRXDRG_AWP")
	public double getAwp() {
		return awp;
	}

	public void setAwp(double awp) {
		this.awp = awp;
	}

	@Column(name = "NRXDRG_CAT")
	public int getCat() {
		return cat;
	}

	public void setCat(int cat) {
		this.cat = cat;
	}

	@Column(name = "NRXDRG_INSERTNO")
	public int getInsertno() {
		return insertno;
	}

	public void setInsertno(int insertno) {
		this.insertno = insertno;
	}

	@Column(name = "NRXDRG_METRIC_SZ")
	public double getMetricSz() {
		return metricSz;
	}

	public void setMetricSz(double metricSz) {
		this.metricSz = metricSz;
	}

	@Column(name = "NRXDRG_ALLERGY_01")
	public int getAllergy01() {
		return allergy01;
	}

	public void setAllergy01(int allergy01) {
		this.allergy01 = allergy01;
	}

	@Column(name = "NRXDRG_ALLERGY_02")
	public int getAllergy02() {
		return allergy02;
	}

	public void setAllergy02(int allergy02) {
		this.allergy02 = allergy02;
	}

	@Column(name = "NRXDRG_ALLERGY_03")
	public int getAllergy03() {
		return allergy03;
	}

	public void setAllergy03(int allergy03) {
		this.allergy03 = allergy03;
	}

	@Column(name = "NRXDRG_AUXNO_01")
	public int getAuxno01() {
		return auxno01;
	}

	public void setAuxno01(int auxno01) {
		this.auxno01 = auxno01;
	}

	@Column(name = "NRXDRG_AUXNO_02")
	public int getAuxno02() {
		return auxno02;
	}

	public void setAuxno02(int auxno02) {
		this.auxno02 = auxno02;
	}

	@Column(name = "NRXDRG_AUXNO_03")
	public int getAuxno03() {
		return auxno03;
	}

	public void setAuxno03(int auxno03) {
		this.auxno03 = auxno03;
	}

	@Column(name = "NRXDRG_AUXNO_04")
	public int getAuxno04() {
		return auxno04;
	}

	public void setAuxno04(int auxno04) {
		this.auxno04 = auxno04;
	}

	@Column(name = "NRXDRG_AUXNO_05")
	public int getAuxno05() {
		return auxno05;
	}

	public void setAuxno05(int auxno05) {
		this.auxno05 = auxno05;
	}

	@Column(name = "NRXDRG_AUXNO_06")
	public int getAuxno06() {
		return auxno06;
	}

	public void setAuxno06(int auxno06) {
		this.auxno06 = auxno06;
	}

	@Column(name = "NRXDRG_AUXNO_07")
	public int getAuxno07() {
		return auxno07;
	}

	public void setAuxno07(int auxno07) {
		this.auxno07 = auxno07;
	}

	@Column(name = "NRXDRG_AUXNO_08")
	public int getAuxno08() {
		return auxno08;
	}

	public void setAuxno08(int auxno08) {
		this.auxno08 = auxno08;
	}

	@Column(name = "NRXDRG_AUXNO_09")
	public int getAuxno09() {
		return auxno09;
	}

	public void setAuxno09(int auxno09) {
		this.auxno09 = auxno09;
	}

	@Column(name = "NRXDRG_AUXNO_10")
	public int getAuxno10() {
		return auxno10;
	}

	public void setAuxno10(int auxno10) {
		this.auxno10 = auxno10;
	}

	@Column(name = "NRXDRG_DOSES_DAY")
	public double getDosesDay() {
		return dosesDay;
	}

	public void setDosesDay(double dosesDay) {
		this.dosesDay = dosesDay;
	}

	@Column(name = "NRXDRG_EXP_DATE_01")
	public Date getExpDate01() {
		return expDate01;
	}

	public void setExpDate01(Date expDate01) {
		this.expDate01 = expDate01;
	}

	@Column(name = "NRXDRG_EXP_DATE_02")
	public Date getExpDate02() {
		return expDate02;
	}

	public void setExpDate02(Date expDate02) {
		this.expDate02 = expDate02;
	}

	@Column(name = "NRXDRG_EXP_DATE_03")
	public Date getExpDate03() {
		return expDate03;
	}

	public void setExpDate03(Date expDate03) {
		this.expDate03 = expDate03;
	}

	@Column(name = "NRXDRG_EXP_DATE_04")
	public Date getExpDate04() {
		return expDate04;
	}

	public void setExpDate04(Date expDate04) {
		this.expDate04 = expDate04;
	}

	@Column(name = "NRXDRG_EXP_DATE_05")
	public Date getExpDate05() {
		return expDate05;
	}

	public void setExpDate05(Date expDate05) {
		this.expDate05 = expDate05;
	}

	@Column(name = "NRXDRG_EXP_DATE_06")
	public Date getExpDate06() {
		return expDate06;
	}

	public void setExpDate06(Date expDate06) {
		this.expDate06 = expDate06;
	}

	@Column(name = "NRXDRG_EXP_DATE_07")
	public Date getExpDate07() {
		return expDate07;
	}

	public void setExpDate07(Date expDate07) {
		this.expDate07 = expDate07;
	}

	@Column(name = "NRXDRG_EXP_DATE_08")
	public Date getExpDate08() {
		return expDate08;
	}

	public void setExpDate08(Date expDate08) {
		this.expDate08 = expDate08;
	}

	@Column(name = "NRXDRG_EXP_DATE_09")
	public Date getExpDate09() {
		return expDate09;
	}

	public void setExpDate09(Date expDate09) {
		this.expDate09 = expDate09;
	}

	@Column(name = "NRXDRG_EXP_DATE_10")
	public Date getExpDate10() {
		return expDate10;
	}

	public void setExpDate10(Date expDate10) {
		this.expDate10 = expDate10;
	}

	@Column(name = "NRXDRG_DOSAGE_UNIT")
	public double getDosageUnit() {
		return dosageUnit;
	}

	public void setDosageUnit(double dosageUnit) {
		this.dosageUnit = dosageUnit;
	}

	@Column(name = "NRXDRG_WASTE_FACTR")
	public double getWasteFactr() {
		return wasteFactr;
	}

	public void setWasteFactr(double wasteFactr) {
		this.wasteFactr = wasteFactr;
	}

	@Column(name = "NRXDRG_STD_MEASURE")
	public double getStdMeasure() {
		return stdMeasure;
	}

	public void setStdMeasure(double stdMeasure) {
		this.stdMeasure = stdMeasure;
	}

	@Column(name = "NRXDRG_TABLET_ID")
	public String getTabletId() {
		return tabletId;
	}

	public void setTabletId(String tabletId) {
		this.tabletId = tabletId;
	}

	@Column(name = "NRXDRG_CTL_CLASS")
	public String getCtlClass() {
		return ctlClass;
	}

	public void setCtlClass(String ctlClass) {
		this.ctlClass = ctlClass;
	}

	@Column(name = "NRXDRG_RANK")
	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	@Column(name = "NRXDRG_BOT_NDC_LAB")
	public String getBotNdcLab() {
		return botNdcLab;
	}

	public void setBotNdcLab(String botNdcLab) {
		this.botNdcLab = botNdcLab;
	}

	@Column(name = "NRXDRG_BOT_NDC_PRD")
	public String getBotNdcPrd() {
		return botNdcPrd;
	}

	public void setBotNdcPrd(String botNdcPrd) {
		this.botNdcPrd = botNdcPrd;
	}

	@Column(name = "NRXDRG_BOT_NDC_SZE")
	public String getBotNdcSze() {
		return botNdcSze;
	}

	public void setBotNdcSze(String botNdcSze) {
		this.botNdcSze = botNdcSze;
	}

	@Column(name = "NRXDRG_PD1_CAT")
	public int getPd1Cat() {
		return pd1Cat;
	}

	public void setPd1Cat(int pd1Cat) {
		this.pd1Cat = pd1Cat;
	}

	@Column(name = "NRXDRG_USC_CODE")
	public int getUscCode() {
		return uscCode;
	}

	public void setUscCode(int uscCode) {
		this.uscCode = uscCode;
	}

	@Column(name = "NRXDRG_PREV_AWP")
	public double getPrevAwp() {
		return prevAwp;
	}

	public void setPrevAwp(double prevAwp) {
		this.prevAwp = prevAwp;
	}

	@Column(name = "NRXDRG_AWP_EFF_DT")
	public Date getAwpEffDt() {
		return awpEffDt;
	}

	public void setAwpEffDt(Date awpEffDt) {
		this.awpEffDt = awpEffDt;
	}

	@Column(name = "NRXDRG_UNIT_TYPE")
	public String getUnitType() {
		return unitType;
	}

	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}

	@Column(name = "NRXDRG_UNITS_PKG")
	public double getUnitsPkg() {
		return unitsPkg;
	}

	public void setUnitsPkg(double unitsPkg) {
		this.unitsPkg = unitsPkg;
	}

	@Column(name = "NRXDRG_VOID_CD")
	public String getVoidCd() {
		return voidCd;
	}

	public void setVoidCd(String voidCd) {
		this.voidCd = voidCd;
	}

	@Column(name = "NRXDRG_TRANS_TMSTP")
	public Date getTransTmstp() {
		return transTmstp;
	}

	public void setTransTmstp(Date transTmstp) {
		this.transTmstp = transTmstp;
	}

	@Column(name = "NRXDRG_OPER_ID")
	public String getOperId() {
		return operId;
	}

	public void setOperId(String operId) {
		this.operId = operId;
	}

	@Column(name = "NRXDRG_QTY_RND_IND")
	public String getQtyRndInd() {
		return qtyRndInd;
	}

	public void setQtyRndInd(String qtyRndInd) {
		this.qtyRndInd = qtyRndInd;
	}

	@Column(name = "NRXDRG_PKGS_BOX")
	public double getPkgsBox() {
		return pkgsBox;
	}

	public void setPkgsBox(double pkgsBox) {
		this.pkgsBox = pkgsBox;
	}

	@Column(name = "NRXDRG_TRANS_DATE")
	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	@Column(name = "NRXDRG_COMMENT")
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	@Column(name = "NRXDRG_ALT_LOC_PFX")
	public String getAltLocPfx() {
		return altLocPfx;
	}

	public void setAltLocPfx(String altLocPfx) {
		this.altLocPfx = altLocPfx;
	}

	@Column(name = "NRXDRG_ALT_LOC_NO")
	public int getAltLocNo() {
		return altLocNo;
	}

	public void setAltLocNo(int altLocNo) {
		this.altLocNo = altLocNo;
	}

	@Column(name = "NRXDRG_PROT_REASON")
	public String getProtReason() {
		return protReason;
	}

	public void setProtReason(String protReason) {
		this.protReason = protReason;
	}

	@Column(name = "NRXDRG_PROT_TYPE")
	public String getProtType() {
		return protType;
	}

	public void setProtType(String protType) {
		this.protType = protType;
	}

	@Column(name = "NRXDRG_MF_AUX_FLG")
	public String getMfAuxFlg() {
		return mfAuxFlg;
	}

	public void setMfAuxFlg(String mfAuxFlg) {
		this.mfAuxFlg = mfAuxFlg;
	}

	@Column(name = "NRXDRG_MF_EXP_DT")
	public Date getMfExpDt() {
		return mfExpDt;
	}

	public void setMfExpDt(Date mfExpDt) {
		this.mfExpDt = mfExpDt;
	}

	@Column(name = "NRXDRG_MAND_PPI")
	public String getMandPpi() {
		return mandPpi;
	}

	public void setMandPpi(String mandPpi) {
		this.mandPpi = mandPpi;
	}

	@Column(name = "NRXDRG_MAND_PPI_DT")
	public Date getMandPpiDt() {
		return mandPpiDt;
	}

	public void setMandPpiDt(Date mandPpiDt) {
		this.mandPpiDt = mandPpiDt;
	}

	@Column(name = "NRXDRG_MKTG_PPI")
	public String getMktgPpi() {
		return mktgPpi;
	}

	public void setMktgPpi(String mktgPpi) {
		this.mktgPpi = mktgPpi;
	}

	@Column(name = "NRXDRG_ENH_PPI")
	public String getEnhPpi() {
		return enhPpi;
	}

	public void setEnhPpi(String enhPpi) {
		this.enhPpi = enhPpi;
	}

	@Column(name = "NRXDRG_NEW_PPI1")
	public String getNewPpi1() {
		return newPpi1;
	}

	public void setNewPpi1(String newPpi1) {
		this.newPpi1 = newPpi1;
	}

	@Column(name = "NRXDRG_NEW_PPI2")
	public String getNewPpi2() {
		return newPpi2;
	}

	public void setNewPpi2(String newPpi2) {
		this.newPpi2 = newPpi2;
	}

	@Column(name = "NRXDRG_DRG_SP_PPI")
	public String getDrgSpPpi() {
		return drgSpPpi;
	}

	public void setDrgSpPpi(String drgSpPpi) {
		this.drgSpPpi = drgSpPpi;
	}

	@Column(name = "NRXDRG_SCR_DSP_IND")
	public String getScrDspInd() {
		return scrDspInd;
	}

	public void setScrDspInd(String scrDspInd) {
		this.scrDspInd = scrDspInd;
	}

	@Column(name = "NRXDRG_CHEM_NM")
	public String getChemNm() {
		return chemNm;
	}

	public void setChemNm(String chemNm) {
		this.chemNm = chemNm;
	}

	@Column(name = "NRXDRG_STOP_CODE")
	public String getStopCode() {
		return stopCode;
	}

	public void setStopCode(String stopCode) {
		this.stopCode = stopCode;
	}

	@Column(name = "NRXDRG_STOP_EFF_DT")
	public Date getStopEffDt() {
		return stopEffDt;
	}

	public void setStopEffDt(Date stopEffDt) {
		this.stopEffDt = stopEffDt;
	}

	@Column(name = "NRXDRG_LTR_DRG_NM")
	public String getLtrDrgNm() {
		return ltrDrgNm;
	}

	public void setLtrDrgNm(String ltrDrgNm) {
		this.ltrDrgNm = ltrDrgNm;
	}

	@Column(name = "NRXDRG_LTR_DRG_ST")
	public String getLtrDrgSt() {
		return ltrDrgSt;
	}

	public void setLtrDrgSt(String ltrDrgSt) {
		this.ltrDrgSt = ltrDrgSt;
	}

	@Column(name = "NRXDRG_LTR_MANU_NM")
	public String getLtrManuNm() {
		return ltrManuNm;
	}

	public void setLtrManuNm(String ltrManuNm) {
		this.ltrManuNm = ltrManuNm;
	}

	@Column(name = "NRXDRG_LTR_MANU_ST")
	public String getLtrManuSt() {
		return ltrManuSt;
	}

	public void setLtrManuSt(String ltrManuSt) {
		this.ltrManuSt = ltrManuSt;
	}

	@Column(name = "NRXDRG_BOT_DRG_NM")
	public String getBotDrgNm() {
		return botDrgNm;
	}

	public void setBotDrgNm(String botDrgNm) {
		this.botDrgNm = botDrgNm;
	}

	@Column(name = "NRXDRG_BOT_DRG_ST")
	public String getBotDrgSt() {
		return botDrgSt;
	}

	public void setBotDrgSt(String botDrgSt) {
		this.botDrgSt = botDrgSt;
	}

	@Column(name = "NRXDRG_TAB_ID")
	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

	@Column(name = "NRXDRG_PD_MULTISRC")
	public String getPdMultisrc() {
		return pdMultisrc;
	}

	public void setPdMultisrc(String pdMultisrc) {
		this.pdMultisrc = pdMultisrc;
	}

	@Column(name = "NRXDRG_DIS_EXT_NBR")
	public int getDisExtNbr() {
		return disExtNbr;
	}

	public void setDisExtNbr(int disExtNbr) {
		this.disExtNbr = disExtNbr;
	}

	@Column(name = "NRXDRG_LTR_GNRC_NM")
	public String getLtrGnrcNm() {
		return ltrGnrcNm;
	}

	public void setLtrGnrcNm(String ltrGnrcNm) {
		this.ltrGnrcNm = ltrGnrcNm;
	}

	@Column(name = "NRXDRG_PPI_REV_DT")
	public Date getPpiRevDt() {
		return ppiRevDt;
	}

	public void setPpiRevDt(Date ppiRevDt) {
		this.ppiRevDt = ppiRevDt;
	}

	@Column(name = "NRXDRG_BOT_MANU_NM")
	public String getBotManuNm() {
		return botManuNm;
	}

	public void setBotManuNm(String botManuNm) {
		this.botManuNm = botManuNm;
	}

	@Column(name = "NRXDRG_SP_PPI_PGS")
	public int getSpPpiPgs() {
		return spPpiPgs;
	}

	public void setSpPpiPgs(int spPpiPgs) {
		this.spPpiPgs = spPpiPgs;
	}

	@Column(name = "NRXDRG_SPEC_DRG_IN")
	public String getSpecDrgIn() {
		return specDrgIn;
	}

	public void setSpecDrgIn(String specDrgIn) {
		this.specDrgIn = specDrgIn;
	}

	@Column(name = "NRXDRG_DRG_INS_PGS")
	public int getDrgInsPgs() {
		return drgInsPgs;
	}

	public void setDrgInsPgs(int drgInsPgs) {
		this.drgInsPgs = drgInsPgs;
	}

	@Column(name = "NRXDRG_MND_PPI_PGS")
	public int getMndPpiPgs() {
		return mndPpiPgs;
	}

	public void setMndPpiPgs(int mndPpiPgs) {
		this.mndPpiPgs = mndPpiPgs;
	}

	@Column(name = "NRXDRG_MKG_PPI_PGS")
	public int getMkgPpiPgs() {
		return mkgPpiPgs;
	}

	public void setMkgPpiPgs(int mkgPpiPgs) {
		this.mkgPpiPgs = mkgPpiPgs;
	}

	@Column(name = "NRXDRG_ENH_PPI_PGS")
	public int getEnhPpiPgs() {
		return enhPpiPgs;
	}

	public void setEnhPpiPgs(int enhPpiPgs) {
		this.enhPpiPgs = enhPpiPgs;
	}

	@Column(name = "NRXDRG_NW_PPI1_PGS")
	public int getNwPpi1Pgs() {
		return nwPpi1Pgs;
	}

	public void setNwPpi1Pgs(int nwPpi1Pgs) {
		this.nwPpi1Pgs = nwPpi1Pgs;
	}

	@Column(name = "NRXDRG_NW_PPI2_PGS")
	public int getNwPpi2Pgs() {
		return nwPpi2Pgs;
	}

	public void setNwPpi2Pgs(int nwPpi2Pgs) {
		this.nwPpi2Pgs = nwPpi2Pgs;
	}

	@Column(name = "NRXDRG_NDP_DRUG_NO")
	public int getNdpDrugNo() {
		return ndpDrugNo;
	}

	public void setNdpDrugNo(int ndpDrugNo) {
		this.ndpDrugNo = ndpDrugNo;
	}

	@Column(name = "NRXDRG_SALES_CDE")
	public String getSalesCde() {
		return salesCde;
	}

	public void setSalesCde(String salesCde) {
		this.salesCde = salesCde;
	}

	@Column(name = "NRXDRG_REG_CAT1_CD")
	public int getRegCat1Cd() {
		return regCat1Cd;
	}

	public void setRegCat1Cd(int regCat1Cd) {
		this.regCat1Cd = regCat1Cd;
	}

	@Column(name = "NRXDRG_REG_CAT2_CD")
	public int getRegCat2Cd() {
		return regCat2Cd;
	}

	public void setRegCat2Cd(int regCat2Cd) {
		this.regCat2Cd = regCat2Cd;
	}

	@Column(name = "NRXDRG_DISP_CAT_CD")
	public String getDispCatCd() {
		return dispCatCd;
	}

	public void setDispCatCd(String dispCatCd) {
		this.dispCatCd = dispCatCd;
	}

	@Column(name = "NRXDRG_STOP_CD_DSC")
	public String getStopCdDsc() {
		return stopCdDsc;
	}

	public void setStopCdDsc(String stopCdDsc) {
		this.stopCdDsc = stopCdDsc;
	}

	@Column(name = "NRXDRG_TMP_SENS_CD")
	public String getTmpSensCd() {
		return tmpSensCd;
	}

	public void setTmpSensCd(String tmpSensCd) {
		this.tmpSensCd = tmpSensCd;
	}

	@Column(name = "NRXDRG_MLT_BRD_NM")
	public String getMltBrdNm() {
		return mltBrdNm;
	}

	public void setMltBrdNm(String mltBrdNm) {
		this.mltBrdNm = mltBrdNm;
	}

	@Column(name = "NRXDRG_MLT_GEN_NM")
	public String getMltGenNm() {
		return mltGenNm;
	}

	public void setMltGenNm(String mltGenNm) {
		this.mltGenNm = mltGenNm;
	}

	@Column(name = "NRXDRG_MLT_REV_NM")
	public double getMltRevNm() {
		return mltRevNm;
	}

	public void setMltRevNm(double mltRevNm) {
		this.mltRevNm = mltRevNm;
	}

	@Column(name = "NRXDRG_STOP_END_DT")
	public Date getStopEndDt() {
		return stopEndDt;
	}

	public void setStopEndDt(Date stopEndDt) {
		this.stopEndDt = stopEndDt;
	}

	@Column(name = "NRXDRG_DIVISOR_QTY")
	public double getDivisorQty() {
		return divisorQty;
	}

	public void setDivisorQty(double divisorQty) {
		this.divisorQty = divisorQty;
	}

	@Column(name = "NRXDRG_PREF_IND")
	public String getPrefInd() {
		return prefInd;
	}

	public void setPrefInd(String prefInd) {
		this.prefInd = prefInd;
	}

	@Column(name = "NRXDRG_REG_CAT3_CD")
	public int getRegCat3Cd() {
		return regCat3Cd;
	}

	public void setRegCat3Cd(int regCat3Cd) {
		this.regCat3Cd = regCat3Cd;
	}

	@Column(name = "NRXDRG_REG_CAT4_CD")
	public int getRegCat4Cd() {
		return regCat4Cd;
	}

	public void setRegCat4Cd(int regCat4Cd) {
		this.regCat4Cd = regCat4Cd;
	}

	@Column(name = "NRXDRG_REG_CAT5_CD")
	public int getRegCat5Cd() {
		return regCat5Cd;
	}

	public void setRegCat5Cd(int regCat5Cd) {
		this.regCat5Cd = regCat5Cd;
	}

	@Column(name = "NRXDRG_NDC_QUAL")
	public String getNdcQual() {
		return ndcQual;
	}

	public void setNdcQual(String ndcQual) {
		this.ndcQual = ndcQual;
	}

	@Column(name = "NRXDRG_BOTNDC_QUAL")
	public String getBotndcQual() {
		return botndcQual;
	}

	public void setBotndcQual(String botndcQual) {
		this.botndcQual = botndcQual;
	}

	@Column(name = "NRXDRG_DAW_CD")
	public String getDawCd() {
		return dawCd;
	}

	public void setDawCd(String dawCd) {
		this.dawCd = dawCd;
	}

	@Column(name = "NRXDRG_NDC_OBSDT")
	public String getNdcObsdt() {
		return ndcObsdt;
	}

	public void setNdcObsdt(String ndcObsdt) {
		this.ndcObsdt = ndcObsdt;
	}

	@Column(name = "NRXDRG_NDC_OBSFL")
	public String getNdcObsfl() {
		return ndcObsfl;
	}

	public void setNdcObsfl(String ndcObsfl) {
		this.ndcObsfl = ndcObsfl;
	}

	@Column(name = "NRXDRG_BTNDC_OBSDT")
	public String getBtndcObsdt() {
		return btndcObsdt;
	}

	public void setBtndcObsdt(String btndcObsdt) {
		this.btndcObsdt = btndcObsdt;
	}

	@Column(name = "NRXDRG_BTNDC_OBSFL")
	public String getBtndcObsfl() {
		return btndcObsfl;
	}

	public void setBtndcObsfl(String btndcObsfl) {
		this.btndcObsfl = btndcObsfl;
	}

	@Column(name = "NRXDRG_SPECIALTY")
	public int getSpecialty() {
		return specialty;
	}

	public void setSpecialty(int specialty) {
		this.specialty = specialty;
	}

	@Column(name = "NRXDRG_ANCILLARY")
	public int getAncillary() {
		return ancillary;
	}

	public void setAncillary(int ancillary) {
		this.ancillary = ancillary;
	}

	@Column(name = "NRXDRG_MFR_QTY")
	public String getMfrQty() {
		return mfrQty;
	}

	public void setMfrQty(String mfrQty) {
		this.mfrQty = mfrQty;
	}

	@Column(name = "NRXDRG_SPECLTY_IND")
	public String getSpecltyInd() {
		return specltyInd;
	}

	public void setSpecltyInd(String specltyInd) {
		this.specltyInd = specltyInd;
	}

	@Column(name = "NRXDRG_ANCLLRY_IND")
	public String getAncllryInd() {
		return ancllryInd;
	}

	public void setAncllryInd(String ancllryInd) {
		this.ancllryInd = ancllryInd;
	}

	@Column(name = "NRXDRG_DSP_MAIL_CD")
	public String getDspMailCd() {
		return dspMailCd;
	}

	public void setDspMailCd(String dspMailCd) {
		this.dspMailCd = dspMailCd;
	}

	@Column(name = "NRXDRG_MFR_REG_CD")
	public String getMfrRegCd() {
		return mfrRegCd;
	}

	public void setMfrRegCd(String mfrRegCd) {
		this.mfrRegCd = mfrRegCd;
	}

	@Column(name = "NRXDRG_REFRGT_CD")
	public String getRefrgtCd() {
		return refrgtCd;
	}

	public void setRefrgtCd(String refrgtCd) {
		this.refrgtCd = refrgtCd;
	}

	@Column(name = "NRXDRG_PAT_CALL_CD")
	public String getPatCallCd() {
		return patCallCd;
	}

	public void setPatCallCd(String patCallCd) {
		this.patCallCd = patCallCd;
	}

	@Column(name = "NRXDRG_SP_THER_CAT")
	public String getSpTherCat() {
		return spTherCat;
	}

	public void setSpTherCat(String spTherCat) {
		this.spTherCat = spTherCat;
	}

	@Column(name = "NRXDRG_AWP_AMT")
	public double getAwpAmt() {
		return awpAmt;
	}

	public void setAwpAmt(double awpAmt) {
		this.awpAmt = awpAmt;
	}

	@Column(name = "NRXDRG_SP_HANDL_CD")
	public String getSpHandlCd() {
		return spHandlCd;
	}

	public void setSpHandlCd(String spHandlCd) {
		this.spHandlCd = spHandlCd;
	}

	@Column(name = "NRXDRG_GMQ_EFF_DT")
	public Date getGmqEffDt() {
		return gmqEffDt;
	}

	public void setGmqEffDt(Date gmqEffDt) {
		this.gmqEffDt = gmqEffDt;
	}

	@Column(name = "NRXDRG_INDNT_DR_CD")
	public String getIndntDrCd() {
		return indntDrCd;
	}

	public void setIndntDrCd(String indntDrCd) {
		this.indntDrCd = indntDrCd;
	}

	@Column(name = "NRXDRG_NDC_PS")
	public String getNdcPs() {
		return ndcPs;
	}

	public void setNdcPs(String ndcPs) {
		this.ndcPs = ndcPs;
	}

	@Column(name = "NRXDRG_RTL_PICKUP")
	public String getRtlPickup() {
		return rtlPickup;
	}

	public void setRtlPickup(String rtlPickup) {
		this.rtlPickup = rtlPickup;
	}

	@Column(name = "NRXDRG_USL_DSP_QTY")
	public double getUslDspQty() {
		return uslDspQty;
	}

	public void setUslDspQty(double uslDspQty) {
		this.uslDspQty = uslDspQty;
	}

	@Column(name = "NRXDRG_MEDB_OUTSRC")
	public String getMedbOutsrc() {
		return medbOutsrc;
	}

	public void setMedbOutsrc(String medbOutsrc) {
		this.medbOutsrc = medbOutsrc;
	}

	@Column(name = "NRXDRG_BASE_IND")
	public String getBaseInd() {
		return baseInd;
	}

	public void setBaseInd(String baseInd) {
		this.baseInd = baseInd;
	}

	@Column(name = "NRXDRG_ESIW_REF_DRNO")
	public int getEsiwRefDrno() {
		return esiwRefDrno;
	}

	public void setEsiwRefDrno(int esiwRefDrno) {
		this.esiwRefDrno = esiwRefDrno;
	}

	@Column(name = "NRXDRG_DOD_DRNO")
	public int getDodDrno() {
		return dodDrno;
	}

	public void setDodDrno(int dodDrno) {
		this.dodDrno = dodDrno;
	}

	@Column(name = "NRXDRG_DOD_UNITS_PKG_IND")
	public String getDodUnitsPkgInd() {
		return dodUnitsPkgInd;
	}

	public void setDodUnitsPkgInd(String dodUnitsPkgInd) {
		this.dodUnitsPkgInd = dodUnitsPkgInd;
	}

	@Column(name = "NRXDRG_DOD_PKG_SIZE_SW_CD")
	public String getDodPkgSizeSwCd() {
		return dodPkgSizeSwCd;
	}

	public void setDodPkgSizeSwCd(String dodPkgSizeSwCd) {
		this.dodPkgSizeSwCd = dodPkgSizeSwCd;
	}

	@Column(name = "NRXDRG_DISP_TYPE_CD")
	public int getDispTypeCd() {
		return dispTypeCd;
	}

	public void setDispTypeCd(int dispTypeCd) {
		this.dispTypeCd = dispTypeCd;
	}

	@Column(name = "NRXDRG_DOD_REPLENISH_IND")
	public String getDodReplenishInd() {
		return dodReplenishInd;
	}

	public void setDodReplenishInd(String dodReplenishInd) {
		this.dodReplenishInd = dodReplenishInd;
	}

	@Column(name = "NRXDRG_DOD_CENTRAL_FILL_IND")
	public String getDodCentralFillInd() {
		return dodCentralFillInd;
	}

	public void setDodCentralFillInd(String dodCentralFillInd) {
		this.dodCentralFillInd = dodCentralFillInd;
	}

	@Column(name = "NRXDRG_DOD_METRIC_SZ")
	public double getDodMetricSz() {
		return dodMetricSz;
	}

	public void setDodMetricSz(double dodMetricSz) {
		this.dodMetricSz = dodMetricSz;
	}

	@Column(name = "NRXDRG_DOD_REPACK_IND")
	public String getDodRepackInd() {
		return dodRepackInd;
	}

	public void setDodRepackInd(String dodRepackInd) {
		this.dodRepackInd = dodRepackInd;
	}

	@Column(name = "NRXDRG_DOD_SPECIALTY_IND")
	public String getDodSpecialtyInd() {
		return dodSpecialtyInd;
	}

	public void setDodSpecialtyInd(String dodSpecialtyInd) {
		this.dodSpecialtyInd = dodSpecialtyInd;
	}

	@Column(name = "NRXDRG_MTF_IND")
	public String getMtfInd() {
		return mtfInd;
	}

	public void setMtfInd(String mtfInd) {
		this.mtfInd = mtfInd;
	}

	@Column(name = "NRXDRG_DOD_NDC_CD")
	public String getDodNdcCd() {
		return dodNdcCd;
	}

	public void setDodNdcCd(String dodNdcCd) {
		this.dodNdcCd = dodNdcCd;
	}

	@Column(name = "NRXDRG_DOD_UNITS_PKG")
	public double getDodUnitsPkg() {
		return dodUnitsPkg;
	}

	public void setDodUnitsPkg(double dodUnitsPkg) {
		this.dodUnitsPkg = dodUnitsPkg;
	}

	@Column(name = "NRXDRG_STOP2_CODE")
	public String getStop2Code() {
		return stop2Code;
	}

	public void setStop2Code(String stop2Code) {
		this.stop2Code = stop2Code;
	}

	@Column(name = "NRXDRG_STOP2_EFF_DT")
	public Date getStop2EffDt() {
		return stop2EffDt;
	}

	public void setStop2EffDt(Date stop2EffDt) {
		this.stop2EffDt = stop2EffDt;
	}

	@Column(name = "NRXDRG_STOP2_CD_DSC")
	public String getStop2CdDsc() {
		return stop2CdDsc;
	}

	public void setStop2CdDsc(String stop2CdDsc) {
		this.stop2CdDsc = stop2CdDsc;
	}
}