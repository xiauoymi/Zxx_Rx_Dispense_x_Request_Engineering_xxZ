package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NRxDrugInfoId implements Serializable{

	private static final long serialVersionUID = 3893216794298987853L;
	private int fillNo;
	private int drno;
	
	// Default Constructor
	public NRxDrugInfoId() {
		
	}

	@Column(name = "NRXDRG_FILL_NO")
	public int getFillNo() {
		return fillNo;
	}

	public void setFillNo(int fillNo) {
		this.fillNo = fillNo;
	}

	@Column(name = "NRXDRG_DRNO")
	public int getDrno() {
		return drno;
	}

	public void setDrno(int drno) {
		this.drno = drno;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + drno;
		result = prime * result + fillNo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NRxDrugInfoId other = (NRxDrugInfoId) obj;
		if (drno != other.drno)
			return false;
		if (fillNo != other.fillNo)
			return false;
		return true;
	}	
}