/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * StatusCodeInfoDdo.
 */
@Entity
@Table(name="TBL_STATUS_CODE_INFO"
, uniqueConstraints = {  }
)

public class StatusCodeInfoDdo  implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

     /** The status code. */
     private boolean statusCode;
     
     /** The status desc. */
     private String statusDesc;


    /**
     * default constructor.
     */
    public StatusCodeInfoDdo() {
    }

    
    /**
     * full constructor.
     *
     * @param statusCode the status code
     * @param statusDesc the status desc
     */
    public StatusCodeInfoDdo(boolean statusCode, String statusDesc) {
        this.statusCode = statusCode;
        this.statusDesc = statusDesc;
    }
   
    /**
     * Checks if is status code.
     *
     * @return true, if is status code
     */
    @Id
    @Column(name="STATUS_CODE", unique=true, nullable=false, insertable=true, updatable=true, precision=1, scale=0)

    public boolean isStatusCode() {
        return this.statusCode;
    }
    
    /**
     * Sets the status code.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(boolean statusCode) {
        this.statusCode = statusCode;
    }
    
    /**
     * Gets the status desc.
     *
     * @return the status desc
     */
    @Column(name="STATUS_DESC", unique=false, nullable=false, insertable=true, updatable=true, length=40)

    public String getStatusDesc() {
        return this.statusDesc;
    }
    
    /**
     * Sets the status desc.
     *
     * @param statusDesc the new status desc
     */
    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }
   








}
