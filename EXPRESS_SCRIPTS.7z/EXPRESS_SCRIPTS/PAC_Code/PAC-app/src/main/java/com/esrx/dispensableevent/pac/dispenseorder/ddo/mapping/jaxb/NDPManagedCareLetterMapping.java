package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.NDPManagedCareLetter;

import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;

public class NDPManagedCareLetterMapping {

	public void mapDatabaseToBusinessDomain(NDPManagedCareLetter ndpManagedCareLetterBdo, NRxMclInfo nrxMclInfoDdo) {
		ndpManagedCareLetterBdo.setLetterNumber(nrxMclInfoDdo.getId().getNdmLetterNo());
//		ndpManagedCareLetterBdo.setNDPManagedCareParameterList(NDPManagedCareParameterList);
//		ndpManagedCareLetterBdo.setNoOfParams(nrxMclInfoDdo);
		ndpManagedCareLetterBdo.setRxNum(String.valueOf(nrxMclInfoDdo.getId().getNdmRxno()));
	}
}
