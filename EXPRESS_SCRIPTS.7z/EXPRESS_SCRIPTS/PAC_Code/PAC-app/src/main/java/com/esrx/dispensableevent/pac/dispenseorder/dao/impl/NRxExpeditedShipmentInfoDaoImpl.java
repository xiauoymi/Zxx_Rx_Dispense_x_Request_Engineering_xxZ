package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxExpeditedShipmentInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxExpeditedShipmentInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxExpeditedShipmentInfoDao;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class NRxExpeditedShipmentInfoDaoImpl extends
		GenericDaoHibernate<NRxExpeditedShipmentInfo> implements
		NRxExpeditedShipmentInfoDao {

	private static final Logger log = LoggerFactory
			.getLogger(NRxExpeditedShipmentInfoDaoImpl.class);

	public NRxExpeditedShipmentInfoDaoImpl(SessionFactory sf) {
		super(NRxExpeditedShipmentInfo.class, sf);
	}

	public NRxExpeditedShipmentInfo getNRxExpeditedShipmentInfo(
			NRxExpeditedShipmentInfoId nrxExpeditedShipmentInfoId) {
		NRxExpeditedShipmentInfo nrxExpeditedShipmentInfo = null;

		if (nrxExpeditedShipmentInfoId != null) {
			nrxExpeditedShipmentInfo = findById(nrxExpeditedShipmentInfoId);
		}
		return nrxExpeditedShipmentInfo;
	}

}
