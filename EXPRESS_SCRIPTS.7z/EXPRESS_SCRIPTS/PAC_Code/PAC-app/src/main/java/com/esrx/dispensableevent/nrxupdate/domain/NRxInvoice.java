/**
 * Author : Guru Krishnan
 */
package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "NCUNDI00", uniqueConstraints = {})
public class NRxInvoice implements Serializable {

	private static final long serialVersionUID = -5899378207384641442L;
	private NRxInvoiceId id;
	private int noRxRecs;
	private String enclNo;
	private int divertNo;
	private String memNameFst;
	private String memNameLst;
	private String memAddLn1;
	private String memAddLn2;
	private String memAddCity;
	private String memAddState;
	private int memAddZip5;
	private int memAddZip4;
	private double memDayPhone;
	private double memEvePhone;
	private Date recDate;
	private String memberNo;
	private String group;
	private String subgroup;
	private Date tmstmp;
	private int noSobaMsgs;
	private double newCharges;
	private double tax;
	private double priorBal;
	private double payReceived;
	private double newBalance;
	private String delvService;
	private String classService;
	private String langFlag;
	private String emerOrdFlag;
	private String guarDelvFlag;
	private Date guarDelvDate;
	private int orgFillNo;
	private int orgInvno;
	private String orgInvnoSub;
	private String modifiedFlag;
	private String invPharmName;
	private String invPharmAdd1;
	private String invPharmAdd2;
	private String rmitPhrmNme;
	private String rmitPhrmAdd1;
	private String rmitPhrmAdd2;
	private String ordPhrmNme;
	private String ordPhrmAdd1;
	private String ordPhrmAdd2;
	private int pharmLocano;
	private double pharmPhone;
	private double csPhone;
	private int busRplyPerm;
	private String domInterInd;
	private String qaFlag;
	private String rateShopInd;
	private int packRelCode;
	private int sendStatus;
	private String ordStatus;
	private int recvNoRxs;
	private Date recvMailDte;
	private Date recvMailTime;
	private double recvWeight;
	private double recvCharge;
	private String recvZone;
	private String recvDelvSvc;
	private String recvClsSvc;
	private String recvRefno;
	private Date respTmstmp;
	private int qaAssureCode;
	private int recvErrorCde;
	private int pacRxRecQty;
	private Date pacAckTms;
	private Date sendTms;
	private String replInd;
	private String pacOrderNo;
	private Date orgCoTms;
	private Date lpsCoTms;
	private Date pacRecvTms;
	private int logoTifId;
	private String unionBInd;
	private double clientAmount;
	private String clientAmtDsc;
	private String logoTifFile;
	private String internetInd;
	private String netCommInd;
	private String clntNetAddr;
	private String ordVerbCde;
	private String opt800Nbr;
	private Date acctSummDte;
	private Date acctBalDte;
	private double othPkgQty;
	private double shipChgAmt;
	private String acctSummCde;
	private double ccAmt;
	private String autoChgInd;
	private String ccTypeCde;
	private String ccLast4Nbr;
	private int paymentsQty;
	private double ordrPriorBal;
	private double ordrPayRecvd;
	private double ordrNewBlnce;
	private double ordrNewChrgs;
	private String clientName;
	private String shipNameFst;
	private String shipNameLst;
	private String clntDeptNo;
	private String barCode;
	private double mailSackNbr;
	private int dispPhyNo;
	private int pdLocaNo;
	private int verNo;
	private String refId;
	private String pbmId;
	private String mbrGrpId;
	private Date ordrTargTms;
	private double taBalanceAmt;
	private String ndpProcFlg;
	private String balTypCde;
	private String newRecvRefno;
	private int clntDaysSply;
	private String mrcInd;
	private String litpakLogoCd;
	private String phmBrandId;
	private String medDInd;
	private String eligUmbrGrp;
	private String ppccInd;
	private String wffAutoEnrollInd;

	// Default Constructor
	public NRxInvoice() {

	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "ndiFillNO", column = @Column(name = "NDI_FILL_NO")),
			@AttributeOverride(name = "ndiInvno", column = @Column(name = "NDI_INVNO")),
			@AttributeOverride(name = "ndiInvnoSub", column = @Column(name = "NDI_INVNO_SUB")) })
	public NRxInvoiceId getId() {
		return id;
	}

	public void setId(NRxInvoiceId id) {
		this.id = id;
	}

	@Column(name = "NDI_NO_RX_RECS")
	public int getNoRxRecs() {
		return noRxRecs;
	}

	public void setNoRxRecs(int noRxRecs) {
		this.noRxRecs = noRxRecs;
	}

	@Column(name = "NDI_ENCL_NO")
	public String getEnclNo() {
		return enclNo;
	}

	public void setEnclNo(String enclNo) {
		this.enclNo = enclNo;
	}

	@Column(name = "NDI_DIVERT_NO")
	public int getDivertNo() {
		return divertNo;
	}

	public void setDivertNo(int divertNo) {
		this.divertNo = divertNo;
	}

	@Column(name = "NDI_MEM_NAME_FST")
	public String getMemNameFst() {
		return memNameFst;
	}

	public void setMemNameFst(String memNameFst) {
		this.memNameFst = memNameFst;
	}

	@Column(name = "NDI_MEM_NAME_LST")
	public String getMemNameLst() {
		return memNameLst;
	}

	public void setMemNameLst(String memNameLst) {
		this.memNameLst = memNameLst;
	}

	@Column(name = "NDI_MEM_ADD_LN1")
	public String getMemAddLn1() {
		return memAddLn1;
	}

	public void setMemAddLn1(String memAddLn1) {
		this.memAddLn1 = memAddLn1;
	}

	@Column(name = "NDI_MEM_ADD_LN2")
	public String getMemAddLn2() {
		return memAddLn2;
	}

	public void setMemAddLn2(String memAddLn2) {
		this.memAddLn2 = memAddLn2;
	}

	@Column(name = "NDI_MEM_ADD_CITY")
	public String getMemAddCity() {
		return memAddCity;
	}

	public void setMemAddCity(String memAddCity) {
		this.memAddCity = memAddCity;
	}

	@Column(name = "NDI_MEM_ADD_STATE")
	public String getMemAddState() {
		return memAddState;
	}

	public void setMemAddState(String memAddState) {
		this.memAddState = memAddState;
	}

	@Column(name = "NDI_MEM_ADD_ZIP5")
	public int getMemAddZip5() {
		return memAddZip5;
	}

	public void setMemAddZip5(int memAddZip5) {
		this.memAddZip5 = memAddZip5;
	}

	@Column(name = "NDI_MEM_ADD_ZIP4")
	public int getMemAddZip4() {
		return memAddZip4;
	}

	public void setMemAddZip4(int memAddZip4) {
		this.memAddZip4 = memAddZip4;
	}

	@Column(name = "NDI_MEM_DAY_PHONE")
	public double getMemDayPhone() {
		return memDayPhone;
	}

	public void setMemDayPhone(double memDayPhone) {
		this.memDayPhone = memDayPhone;
	}

	@Column(name = "NDI_MEM_EVE_PHONE")
	public double getMemEvePhone() {
		return memEvePhone;
	}

	public void setMemEvePhone(double memEvePhone) {
		this.memEvePhone = memEvePhone;
	}

	@Column(name = "NDI_REC_DATE")
	@Temporal(TemporalType.DATE)
	public Date getRecDate() {
		return recDate;
	}

	public void setRecDate(Date recDate) {
		this.recDate = recDate;
	}

	@Column(name = "NDI_MEMBER_NO")
	public String getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}

	@Column(name = "NDI_GROUP")
	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	@Column(name = "NDI_SUBGROUP")
	public String getSubgroup() {
		return subgroup;
	}

	public void setSubgroup(String subgroup) {
		this.subgroup = subgroup;
	}

	@Column(name = "NDI_TMSTMP")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getTmstmp() {
		return tmstmp;
	}

	public void setTmstmp(Date tmstmp) {
		this.tmstmp = tmstmp;
	}

	@Column(name = "NDI_NO_SOBA_MSGS")
	public int getNoSobaMsgs() {
		return noSobaMsgs;
	}

	public void setNoSobaMsgs(int noSobaMsgs) {
		this.noSobaMsgs = noSobaMsgs;
	}

	@Column(name = "NDI_NEW_CHARGES")
	public double getNewCharges() {
		return newCharges;
	}

	public void setNewCharges(double newCharges) {
		this.newCharges = newCharges;
	}

	@Column(name = "NDI_TAX")
	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	@Column(name = "NDI_PRIOR_BAL")
	public double getPriorBal() {
		return priorBal;
	}

	public void setPriorBal(double priorBal) {
		this.priorBal = priorBal;
	}

	@Column(name = "NDI_PAY_RECEIVED")
	public double getPayReceived() {
		return payReceived;
	}

	public void setPayReceived(double payReceived) {
		this.payReceived = payReceived;
	}

	@Column(name = "NDI_NEW_BALANCE")
	public double getNewBalance() {
		return newBalance;
	}

	public void setNewBalance(double newBalance) {
		this.newBalance = newBalance;
	}

	@Column(name = "NDI_DELV_SERVICE")
	public String getDelvService() {
		return delvService;
	}

	public void setDelvService(String delvService) {
		this.delvService = delvService;
	}

	@Column(name = "NDI_CLASS_SERVICE")
	public String getClassService() {
		return classService;
	}

	public void setClassService(String classService) {
		this.classService = classService;
	}

	@Column(name = "NDI_LANG_FLAG")
	public String getLangFlag() {
		return langFlag;
	}

	public void setLangFlag(String langFlag) {
		this.langFlag = langFlag;
	}

	@Column(name = "NDI_EMER_ORD_FLAG")
	public String getEmerOrdFlag() {
		return emerOrdFlag;
	}

	public void setEmerOrdFlag(String emerOrdFlag) {
		this.emerOrdFlag = emerOrdFlag;
	}

	@Column(name = "NDI_GUAR_DELV_FLAG")
	public String getGuarDelvFlag() {
		return guarDelvFlag;
	}

	public void setGuarDelvFlag(String guarDelvFlag) {
		this.guarDelvFlag = guarDelvFlag;
	}

	@Column(name = "NDI_GUAR_DELV_DATE")
	@Temporal(TemporalType.DATE)
	public Date getGuarDelvDate() {
		return guarDelvDate;
	}

	public void setGuarDelvDate(Date guarDelvDate) {
		this.guarDelvDate = guarDelvDate;
	}

	@Column(name = "NDI_ORG_FILL_NO")
	public int getOrgFillNo() {
		return orgFillNo;
	}

	public void setOrgFillNo(int orgFillNo) {
		this.orgFillNo = orgFillNo;
	}

	@Column(name = "NDI_ORG_INVNO")
	public int getOrgInvno() {
		return orgInvno;
	}

	public void setOrgInvno(int orgInvno) {
		this.orgInvno = orgInvno;
	}

	@Column(name = "NDI_ORG_INVNO_SUB")
	public String getOrgInvnoSub() {
		return orgInvnoSub;
	}

	public void setOrgInvnoSub(String orgInvnoSub) {
		this.orgInvnoSub = orgInvnoSub;
	}

	@Column(name = "NDI_MODIFIED_FLAG")
	public String getModifiedFlag() {
		return modifiedFlag;
	}

	public void setModifiedFlag(String modifiedFlag) {
		this.modifiedFlag = modifiedFlag;
	}

	@Column(name = "NDI_INV_PHARM_NAME")
	public String getInvPharmName() {
		return invPharmName;
	}

	public void setInvPharmName(String invPharmName) {
		this.invPharmName = invPharmName;
	}

	@Column(name = "NDI_INV_PHARM_ADD1")
	public String getInvPharmAdd1() {
		return invPharmAdd1;
	}

	public void setInvPharmAdd1(String invPharmAdd1) {
		this.invPharmAdd1 = invPharmAdd1;
	}

	@Column(name = "NDI_INV_PHARM_ADD2")
	public String getInvPharmAdd2() {
		return invPharmAdd2;
	}

	public void setInvPharmAdd2(String invPharmAdd2) {
		this.invPharmAdd2 = invPharmAdd2;
	}

	@Column(name = "NDI_RMIT_PHRM_NME")
	public String getRmitPhrmNme() {
		return rmitPhrmNme;
	}

	public void setRmitPhrmNme(String rmitPhrmNme) {
		this.rmitPhrmNme = rmitPhrmNme;
	}

	@Column(name = "NDI_RMIT_PHRM_ADD1")
	public String getRmitPhrmAdd1() {
		return rmitPhrmAdd1;
	}

	public void setRmitPhrmAdd1(String rmitPhrmAdd1) {
		this.rmitPhrmAdd1 = rmitPhrmAdd1;
	}

	@Column(name = "NDI_RMIT_PHRM_ADD2")
	public String getRmitPhrmAdd2() {
		return rmitPhrmAdd2;
	}

	public void setRmitPhrmAdd2(String rmitPhrmAdd2) {
		this.rmitPhrmAdd2 = rmitPhrmAdd2;
	}

	@Column(name = "NDI_ORD_PHRM_NME")
	public String getOrdPhrmNme() {
		return ordPhrmNme;
	}

	public void setOrdPhrmNme(String ordPhrmNme) {
		this.ordPhrmNme = ordPhrmNme;
	}

	@Column(name = "NDI_ORD_PHRM_ADD1")
	public String getOrdPhrmAdd1() {
		return ordPhrmAdd1;
	}

	public void setOrdPhrmAdd1(String ordPhrmAdd1) {
		this.ordPhrmAdd1 = ordPhrmAdd1;
	}

	@Column(name = "NDI_ORD_PHRM_ADD2")
	public String getOrdPhrmAdd2() {
		return ordPhrmAdd2;
	}

	public void setOrdPhrmAdd2(String ordPhrmAdd2) {
		this.ordPhrmAdd2 = ordPhrmAdd2;
	}

	@Column(name = "NDI_PHARM_LOCANO")
	public int getPharmLocano() {
		return pharmLocano;
	}

	public void setPharmLocano(int pharmLocano) {
		this.pharmLocano = pharmLocano;
	}

	@Column(name = "NDI_PHARM_PHONE")
	public double getPharmPhone() {
		return pharmPhone;
	}

	public void setPharmPhone(double pharmPhone) {
		this.pharmPhone = pharmPhone;
	}

	@Column(name = "NDI_CS_PHONE")
	public double getCsPhone() {
		return csPhone;
	}

	public void setCsPhone(double csPhone) {
		this.csPhone = csPhone;
	}

	@Column(name = "NDI_BUS_RPLY_PERM")
	public int getBusRplyPerm() {
		return busRplyPerm;
	}

	public void setBusRplyPerm(int busRplyPerm) {
		this.busRplyPerm = busRplyPerm;
	}

	@Column(name = "NDI_DOM_INTER_IND")
	public String getDomInterInd() {
		return domInterInd;
	}

	public void setDomInterInd(String domInterInd) {
		this.domInterInd = domInterInd;
	}

	@Column(name = "NDI_QA_FLAG")
	public String getQaFlag() {
		return qaFlag;
	}

	public void setQaFlag(String qaFlag) {
		this.qaFlag = qaFlag;
	}

	@Column(name = "NDI_RATE_SHOP_IND")
	public String getRateShopInd() {
		return rateShopInd;
	}

	public void setRateShopInd(String rateShopInd) {
		this.rateShopInd = rateShopInd;
	}

	@Column(name = "NDI_PACK_REL_CODE")
	public int getPackRelCode() {
		return packRelCode;
	}

	public void setPackRelCode(int packRelCode) {
		this.packRelCode = packRelCode;
	}

	@Column(name = "NDI_SEND_STATUS")
	public int getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(int sendStatus) {
		this.sendStatus = sendStatus;
	}

	@Column(name = "NDI_ORD_STATUS")
	public String getOrdStatus() {
		return ordStatus;
	}

	public void setOrdStatus(String ordStatus) {
		this.ordStatus = ordStatus;
	}

	@Column(name = "NDI_RECV_NO_RXS")
	public int getRecvNoRxs() {
		return recvNoRxs;
	}

	public void setRecvNoRxs(int recvNoRxs) {
		this.recvNoRxs = recvNoRxs;
	}

	@Column(name = "NDI_RECV_MAIL_DTE")
	@Temporal(TemporalType.DATE)
	public Date getRecvMailDte() {
		return recvMailDte;
	}

	public void setRecvMailDte(Date recvMailDte) {
		this.recvMailDte = recvMailDte;
	}

	@Column(name = "NDI_RECV_MAIL_TIME")
	@Temporal(TemporalType.TIME)
	public Date getRecvMailTime() {
		return recvMailTime;
	}

	public void setRecvMailTime(Date recvMailTime) {
		this.recvMailTime = recvMailTime;
	}

	@Column(name = "NDI_RECV_WEIGHT")
	public double getRecvWeight() {
		return recvWeight;
	}

	public void setRecvWeight(double recvWeight) {
		this.recvWeight = recvWeight;
	}

	@Column(name = "NDI_RECV_CHARGE")
	public double getRecvCharge() {
		return recvCharge;
	}

	public void setRecvCharge(double recvCharge) {
		this.recvCharge = recvCharge;
	}

	@Column(name = "NDI_RECV_ZONE")
	public String getRecvZone() {
		return recvZone;
	}

	public void setRecvZone(String recvZone) {
		this.recvZone = recvZone;
	}

	@Column(name = "NDI_RECV_DELV_SVC")
	public String getRecvDelvSvc() {
		return recvDelvSvc;
	}

	public void setRecvDelvSvc(String recvDelvSvc) {
		this.recvDelvSvc = recvDelvSvc;
	}

	@Column(name = "NDI_RECV_CLS_SVC")
	public String getRecvClsSvc() {
		return recvClsSvc;
	}

	public void setRecvClsSvc(String recvClsSvc) {
		this.recvClsSvc = recvClsSvc;
	}

	@Column(name = "NDI_RECV_REFNO")
	public String getRecvRefno() {
		return recvRefno;
	}

	public void setRecvRefno(String recvRefno) {
		this.recvRefno = recvRefno;
	}

	@Column(name = "NDI_RESP_TMSTMP")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getRespTmstmp() {
		return respTmstmp;
	}

	public void setRespTmstmp(Date respTmstmp) {
		this.respTmstmp = respTmstmp;
	}

	@Column(name = "NDI_QA_ASSURE_CODE")
	public int getQaAssureCode() {
		return qaAssureCode;
	}

	public void setQaAssureCode(int qaAssureCode) {
		this.qaAssureCode = qaAssureCode;
	}

	@Column(name = "NDI_RECV_ERROR_CDE")
	public int getRecvErrorCde() {
		return recvErrorCde;
	}

	public void setRecvErrorCde(int recvErrorCde) {
		this.recvErrorCde = recvErrorCde;
	}

	@Column(name = "NDI_PAC_RX_REC_QTY")
	public int getPacRxRecQty() {
		return pacRxRecQty;
	}

	public void setPacRxRecQty(int pacRxRecQty) {
		this.pacRxRecQty = pacRxRecQty;
	}

	@Column(name = "NDI_PAC_ACK_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getPacAckTms() {
		return pacAckTms;
	}

	public void setPacAckTms(Date pacAckTms) {
		this.pacAckTms = pacAckTms;
	}

	@Column(name = "NDI_SEND_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getSendTms() {
		return sendTms;
	}

	public void setSendTms(Date sendTms) {
		this.sendTms = sendTms;
	}

	@Column(name = "NDI_REPL_IND")
	public String getReplInd() {
		return replInd;
	}

	public void setReplInd(String replInd) {
		this.replInd = replInd;
	}

	@Column(name = "NDI_PAC_ORDER_NO")
	public String getPacOrderNo() {
		return pacOrderNo;
	}

	public void setPacOrderNo(String pacOrderNo) {
		this.pacOrderNo = pacOrderNo;
	}

	@Column(name = "NDI_ORG_CO_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getOrgCoTms() {
		return orgCoTms;
	}

	public void setOrgCoTms(Date orgCoTms) {
		this.orgCoTms = orgCoTms;
	}

	@Column(name = "NDI_LPS_CO_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getLpsCoTms() {
		return lpsCoTms;
	}

	public void setLpsCoTms(Date lpsCoTms) {
		this.lpsCoTms = lpsCoTms;
	}

	@Column(name = "NDI_PAC_RECV_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getPacRecvTms() {
		return pacRecvTms;
	}

	public void setPacRecvTms(Date pacRecvTms) {
		this.pacRecvTms = pacRecvTms;
	}

	@Column(name = "NDI_LOGO_TIF_ID")
	public int getLogoTifId() {
		return logoTifId;
	}

	public void setLogoTifId(int logoTifId) {
		this.logoTifId = logoTifId;
	}

	@Column(name = "NDI_UNION_B_IND")
	public String getUnionBInd() {
		return unionBInd;
	}

	public void setUnionBInd(String unionBInd) {
		this.unionBInd = unionBInd;
	}

	@Column(name = "NDI_CLIENT_AMOUNT")
	public double getClientAmount() {
		return clientAmount;
	}

	public void setClientAmount(double clientAmount) {
		this.clientAmount = clientAmount;
	}

	@Column(name = "NDI_CLIENT_AMT_DSC")
	public String getClientAmtDsc() {
		return clientAmtDsc;
	}

	public void setClientAmtDsc(String clientAmtDsc) {
		this.clientAmtDsc = clientAmtDsc;
	}

	@Column(name = "NDI_LOGO_TIF_FILE")
	public String getLogoTifFile() {
		return logoTifFile;
	}

	public void setLogoTifFile(String logoTifFile) {
		this.logoTifFile = logoTifFile;
	}

	@Column(name = "NDI_INTERNET_IND")
	public String getInternetInd() {
		return internetInd;
	}

	public void setInternetInd(String internetInd) {
		this.internetInd = internetInd;
	}

	@Column(name = "NDI_NET_COMM_IND")
	public String getNetCommInd() {
		return netCommInd;
	}

	public void setNetCommInd(String netCommInd) {
		this.netCommInd = netCommInd;
	}

	@Column(name = "NDI_CLNT_NET_ADDR")
	public String getClntNetAddr() {
		return clntNetAddr;
	}

	public void setClntNetAddr(String clntNetAddr) {
		this.clntNetAddr = clntNetAddr;
	}

	@Column(name = "NDI_ORD_VERB_CDE")
	public String getOrdVerbCde() {
		return ordVerbCde;
	}

	public void setOrdVerbCde(String ordVerbCde) {
		this.ordVerbCde = ordVerbCde;
	}

	@Column(name = "NDI_OPT_800_NBR")
	public String getOpt800Nbr() {
		return opt800Nbr;
	}

	public void setOpt800Nbr(String opt800Nbr) {
		this.opt800Nbr = opt800Nbr;
	}

	@Column(name = "NDI_ACCT_SUMM_DTE")
	@Temporal(TemporalType.DATE)
	public Date getAcctSummDte() {
		return acctSummDte;
	}

	public void setAcctSummDte(Date acctSummDte) {
		this.acctSummDte = acctSummDte;
	}

	@Column(name = "NDI_ACCT_BAL_DTE")
	@Temporal(TemporalType.DATE)
	public Date getAcctBalDte() {
		return acctBalDte;
	}

	public void setAcctBalDte(Date acctBalDte) {
		this.acctBalDte = acctBalDte;
	}

	@Column(name = "NDI_OTH_PKG_QTY")
	public double getOthPkgQty() {
		return othPkgQty;
	}

	public void setOthPkgQty(double othPkgQty) {
		this.othPkgQty = othPkgQty;
	}

	@Column(name = "NDI_SHIP_CHG_AMT")
	public double getShipChgAmt() {
		return shipChgAmt;
	}

	public void setShipChgAmt(double shipChgAmt) {
		this.shipChgAmt = shipChgAmt;
	}

	@Column(name = "NDI_ACCT_SUMM_CDE")
	public String getAcctSummCde() {
		return acctSummCde;
	}

	public void setAcctSummCde(String acctSummCde) {
		this.acctSummCde = acctSummCde;
	}

	@Column(name = "NDI_CC_AMT")
	public double getCcAmt() {
		return ccAmt;
	}

	public void setCcAmt(double ccAmt) {
		this.ccAmt = ccAmt;
	}

	@Column(name = "NDI_AUTO_CHG_IND")
	public String getAutoChgInd() {
		return autoChgInd;
	}

	public void setAutoChgInd(String autoChgInd) {
		this.autoChgInd = autoChgInd;
	}

	@Column(name = "NDI_CC_TYPE_CDE")
	public String getCcTypeCde() {
		return ccTypeCde;
	}

	public void setCcTypeCde(String ccTypeCde) {
		this.ccTypeCde = ccTypeCde;
	}

	@Column(name = "NDI_CC_LAST_4_NBR")
	public String getCcLast4Nbr() {
		return ccLast4Nbr;
	}

	public void setCcLast4Nbr(String ccLast4Nbr) {
		this.ccLast4Nbr = ccLast4Nbr;
	}

	@Column(name = "NDI_PAYMENTS_QTY")
	public int getPaymentsQty() {
		return paymentsQty;
	}

	public void setPaymentsQty(int paymentsQty) {
		this.paymentsQty = paymentsQty;
	}

	@Column(name = "NDI_ORDR_PRIOR_BAL")
	public double getOrdrPriorBal() {
		return ordrPriorBal;
	}

	public void setOrdrPriorBal(double ordrPriorBal) {
		this.ordrPriorBal = ordrPriorBal;
	}

	@Column(name = "NDI_ORDR_PAY_RECVD")
	public double getOrdrPayRecvd() {
		return ordrPayRecvd;
	}

	public void setOrdrPayRecvd(double ordrPayRecvd) {
		this.ordrPayRecvd = ordrPayRecvd;
	}

	@Column(name = "NDI_ORDR_NEW_BLNCE")
	public double getOrdrNewBlnce() {
		return ordrNewBlnce;
	}

	public void setOrdrNewBlnce(double ordrNewBlnce) {
		this.ordrNewBlnce = ordrNewBlnce;
	}

	@Column(name = "NDI_ORDR_NEW_CHRGS")
	public double getOrdrNewChrgs() {
		return ordrNewChrgs;
	}

	public void setOrdrNewChrgs(double ordrNewChrgs) {
		this.ordrNewChrgs = ordrNewChrgs;
	}

	@Column(name = "NDI_CLIENT_NAME")
	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	@Column(name = "NDI_SHIP_NAME_FST")
	public String getShipNameFst() {
		return shipNameFst;
	}

	public void setShipNameFst(String shipNameFst) {
		this.shipNameFst = shipNameFst;
	}

	@Column(name = "NDI_SHIP_NAME_LST")
	public String getShipNameLst() {
		return shipNameLst;
	}

	public void setShipNameLst(String shipNameLst) {
		this.shipNameLst = shipNameLst;
	}

	@Column(name = "NDI_CLNT_DEPT_NO")
	public String getClntDeptNo() {
		return clntDeptNo;
	}

	public void setClntDeptNo(String clntDeptNo) {
		this.clntDeptNo = clntDeptNo;
	}

	@Column(name = "NDI_BAR_CODE")
	public String getBarCode() {
		return barCode;
	}

	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}

	@Column(name = "NDI_MAIL_SACK_NBR")
	public double getMailSackNbr() {
		return mailSackNbr;
	}

	public void setMailSackNbr(double mailSackNbr) {
		this.mailSackNbr = mailSackNbr;
	}

	@Column(name = "NDI_DISP_PHY_NO")
	public int getDispPhyNo() {
		return dispPhyNo;
	}

	public void setDispPhyNo(int dispPhyNo) {
		this.dispPhyNo = dispPhyNo;
	}

	@Column(name = "NDI_PD_LOCA_NO")
	public int getPdLocaNo() {
		return pdLocaNo;
	}

	public void setPdLocaNo(int pdLocaNo) {
		this.pdLocaNo = pdLocaNo;
	}

	@Column(name = "NDI_VER_NO")
	public int getVerNo() {
		return verNo;
	}

	public void setVerNo(int verNo) {
		this.verNo = verNo;
	}

	@Column(name = "NDI_REF_ID")
	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	@Column(name = "NDI_PBM_ID")
	public String getPbmId() {
		return pbmId;
	}

	public void setPbmId(String pbmId) {
		this.pbmId = pbmId;
	}

	@Column(name = "NDI_MBR_GRP_ID")
	public String getMbrGrpId() {
		return mbrGrpId;
	}

	public void setMbrGrpId(String mbrGrpId) {
		this.mbrGrpId = mbrGrpId;
	}

	@Column(name = "NDI_ORDR_TARG_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getOrdrTargTms() {
		return ordrTargTms;
	}

	public void setOrdrTargTms(Date ordrTargTms) {
		this.ordrTargTms = ordrTargTms;
	}

	@Column(name = "NDI_TA_BALANCE_AMT")
	public double getTaBalanceAmt() {
		return taBalanceAmt;
	}

	public void setTaBalanceAmt(double taBalanceAmt) {
		this.taBalanceAmt = taBalanceAmt;
	}

	@Column(name = "NDI_NDP_PROC_FLG")
	public String getNdpProcFlg() {
		return ndpProcFlg;
	}

	public void setNdpProcFlg(String ndpProcFlg) {
		this.ndpProcFlg = ndpProcFlg;
	}

	@Column(name = "NDI_BAL_TYP_CDE")
	public String getBalTypCde() {
		return balTypCde;
	}

	public void setBalTypCde(String balTypCde) {
		this.balTypCde = balTypCde;
	}

	@Column(name = "NDI_NEW_RECV_REFNO")
	public String getNewRecvRefno() {
		return newRecvRefno;
	}

	public void setNewRecvRefno(String newRecvRefno) {
		this.newRecvRefno = newRecvRefno;
	}

	@Column(name = "NDI_CLNT_DAYS_SPLY")
	public int getClntDaysSply() {
		return clntDaysSply;
	}

	public void setClntDaysSply(int clntDaysSply) {
		this.clntDaysSply = clntDaysSply;
	}

	@Column(name = "NDI_MRC_IND")
	public String getMrcInd() {
		return mrcInd;
	}

	public void setMrcInd(String mrcInd) {
		this.mrcInd = mrcInd;
	}

	@Column(name = "NDI_LITPAK_LOGO_CD")
	public String getLitpakLogoCd() {
		return litpakLogoCd;
	}

	public void setLitpakLogoCd(String litpakLogoCd) {
		this.litpakLogoCd = litpakLogoCd;
	}

	@Column(name = "NDI_PHM_BRAND_ID")
	public String getPhmBrandId() {
		return phmBrandId;
	}

	public void setPhmBrandId(String phmBrandId) {
		this.phmBrandId = phmBrandId;
	}

	@Column(name = "NDI_MED_D_IND")
	public String getMedDInd() {
		return medDInd;
	}

	public void setMedDInd(String medDInd) {
		this.medDInd = medDInd;
	}

	@Column(name = "NDI_ELIG_UMBR_GRP")
	public String getEligUmbrGrp() {
		return eligUmbrGrp;
	}

	public void setEligUmbrGrp(String eligUmbrGrp) {
		this.eligUmbrGrp = eligUmbrGrp;
	}

	@Column(name = "NDI_PPCC_IND")
	public String getPpccInd() {
		return ppccInd;
	}

	public void setPpccInd(String ppccInd) {
		this.ppccInd = ppccInd;
	}

	@Column(name = "NDI_WFF_AUTO_ENROLL_IND")
	public String getWffAutoEnrollInd() {
		return wffAutoEnrollInd;
	}

	public void setWffAutoEnrollInd(String wffAutoEnrollInd) {
		this.wffAutoEnrollInd = wffAutoEnrollInd;
	}
}