package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderStatusCode;
import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderSubStatusCode;
import com.esrx.dispensableevent.pac.dispenseorder.dao.StatusInfoPacDao;
import com.esrx.dispensableevent.rxdispense.domain.StatusInfoDdo;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class StatusInfoPacDaoImpl extends GenericDaoHibernate<StatusInfoDdo>
		implements StatusInfoPacDao {

	private static final Logger log = LoggerFactory
			.getLogger(StatusInfoPacDaoImpl.class);

	public StatusInfoPacDaoImpl(SessionFactory sf) {
		super(StatusInfoDdo.class, sf);
	}

	public List<StatusInfoDdo> getStatusInfoDdoList(
			RxDispenseOrderStatusCode statusCode,
			RxDispenseOrderSubStatusCode subStatusCode) {

		List<StatusInfoDdo> statusInfoDdoList = null;

//		StringBuilder selectHql = new StringBuilder();
//		selectHql.append("from StatusInfoDdo");
//		selectHql.append(" where ");
//		selectHql.append("statusCode=:statusCode");
//		selectHql.append(" and ");
//		selectHql.append("subStatusCode=:subStatusCode");
//
//		String selectStatusInfoDdoHql = String.valueOf(selectHql);
//
//		if (statusCode != null && subStatusCode != null) {
//			Query updateMcLettersNoQuery = getSession()
//					.createQuery(selectStatusInfoDdoHql);
//			updateMcLettersNoQuery.setInteger("statusCode", statusCode.getOrderStatusVal());
//			updateMcLettersNoQuery.setInteger("subStatusCode", subStatusCode.getOrderSubStatusVal());
//			List<?> statusInfoList = updateMcLettersNoQuery.list();
//
//			statusInfoDdoList = new ArrayList<StatusInfoDdo>();
//
//			for (Object statusInfoDdoObj : statusInfoList) {
//				StatusInfoDdo statusInfoDdo = (StatusInfoDdo) statusInfoDdoObj;
//				statusInfoDdoList.add(statusInfoDdo);
//			}
//
//		}

		if (statusCode != null && subStatusCode != null) {

			DetachedCriteria statusInfoDdoCheckCriteria = DetachedCriteria
					.forClass(StatusInfoDdo.class);

			statusInfoDdoCheckCriteria.add(
					Restrictions.eq("statusCode",
							statusCode.getOrderStatusVal())).add(
					Restrictions.eq("subStatusCode",
							subStatusCode.getOrderSubStatusVal()));

			List<?> statusInfoList = getHibernateTemplate().findByCriteria(
					statusInfoDdoCheckCriteria);

			statusInfoDdoList = new ArrayList<StatusInfoDdo>();

			for (Object statusInfoDdoObj : statusInfoList) {
				StatusInfoDdo statusInfoDdo = (StatusInfoDdo) statusInfoDdoObj;
				statusInfoDdoList.add(statusInfoDdo);
			}
		}
		return statusInfoDdoList;
	}

}
