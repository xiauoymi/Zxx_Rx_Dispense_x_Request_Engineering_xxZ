package com.esrx.dispensableevent.pac.dispenseorder.util;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestIdDdo;

public class RecordN150KeySplitter {

	private static final Logger log = LoggerFactory
	.getLogger(RecordN150KeySplitter.class);

	public static RxDispenseRequestIdDdo getRxDispenseRequestId(String recordN150Key) {
		RxDispenseRequestIdDdo rxDispenseRequestIdDdo = null;
		if(recordN150Key != null) {
			rxDispenseRequestIdDdo = new RxDispenseRequestIdDdo();
			//temp assignment ...only.........................................................................
			recordN150Key ="160,MEDCO,103,1";
		    String[] tokensForN150 = recordN150Key.split(",");
		    
			try {   
				rxDispenseRequestIdDdo.setTransId(new BigDecimal(tokensForN150[0]));
				rxDispenseRequestIdDdo.setClientId(tokensForN150[1]);
				rxDispenseRequestIdDdo.setOrderNum(Integer.valueOf(tokensForN150[2]));
				rxDispenseRequestIdDdo.setSuborderInd(tokensForN150[3]);

			} catch(StringIndexOutOfBoundsException exception) { 
				log.error("StringIndexOutOfBoundsException thrown for recordN150Key : ", recordN150Key);
				log.info("StringIndexOutOfBoundsException Ignored");
			}
		}
		return rxDispenseRequestIdDdo;
	}
}
