package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import java.util.List;
import java.util.Set;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.pac.dispenseorder.dao.PatientInfoDao;
import com.esrx.dispensableevent.rxdispense.domain.PatientInfoDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestIdDdo;
import com.esrx.dispensableevent.rxdispense.domain.StatusInfoDdo;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class PatientInfoDaoImpl extends GenericDaoHibernate<RxDispenseRequestDdo>
		implements PatientInfoDao {

	private static final Logger log = LoggerFactory
			.getLogger(PatientInfoDaoImpl.class);

	public PatientInfoDaoImpl(SessionFactory sf) {
		super(RxDispenseRequestDdo.class, sf);
	}

	public RxDispenseRequestDdo getPatientInfoDdoList(
			RxDispenseRequestIdDdo rxDispenseRequestIdDdo) {
		RxDispenseRequestDdo rxDispenseRequestDdo = null; 
		if (rxDispenseRequestIdDdo != null) {
			rxDispenseRequestDdo = findById(rxDispenseRequestIdDdo);
		}
		return rxDispenseRequestDdo;
	}

}
