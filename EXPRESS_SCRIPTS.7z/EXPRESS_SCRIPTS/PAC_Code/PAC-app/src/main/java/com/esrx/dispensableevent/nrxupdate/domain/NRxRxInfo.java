/**
 * Author : Guru Krishnan
 */
package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "NCUNDX00", uniqueConstraints = {})
public class NRxRxInfo implements Serializable {

	private static final long serialVersionUID = 2972071096533106943L;
	private NRxRxInfoId id;
	private int refillno;
	private String patNmeFst;
	private String patNmeLst;
	private String mdNameLst;
	private int drugNo;
	private int brndSubNo;
	private String cmpndFlg;
	private int quantity;
	private Date dteOfServ;
	private double price;
	private double copay;
	private double patPayAmt;
	private String noSftyCap;
	private Date rflBefDte;
	private Date rflAftDte;
	private int orgRefills;
	private int numRefills;
	private String renewalFlg;
	private String replFlag;
	private int replQty;
	private Date replDate;
	private int drgInsrtno;
	private int noMcLetters;
	private String directions;
	private int rcvFillPhmno;
	private String rcvDispRph;
	private Date rcvDispDate;
	private Date rcvDispTime;
	private String rcvLotNo;
	private Date rcvExpDte;
	private int rcvQty;
	private String rcvWkstn;
	private String rcvRxStatus;
	private Date tmstmp;
	private Date respTmstmp;
	private int xtraLabels;
	private int qtyDivisor;
	private String mandPpi;
	private String mktgPpi;
	private Date sendTms;
	private int drgInsPgs;
	private int mandPpiPgs;
	private int mktgPpiPgs;
	private String enhPpi;
	private int enhPpiPgs;
	private String newPpi1;
	private int newPpi1Pgs;
	private String newPpi2;
	private int newPpi2Pgs;
	private String drgSpPpi;
	private int drgSpPpiPgs;
	private int ndpDrugNo;
	private String clientAmtDsc;
	private String rflBarcdeFmt;
	private String rflBarcdeCd;
	private Date manfstDate;
	private Date manfstTime;
	private String renewalCde;
	private String canclReasCde;
	private double dedAplAmt;
	private int priceTypeCde;
	private String bottleMsgCde;
	private double prcDiffAmt;
	private String rcvFillerId;
	private Date rcvFillDte;
	private Date rcvFillTim;
	private String cmpndDrgNme;
	private String renewalInd;
	private String clPenTblInd;
	private double cmpndQty;

	// Default Constructor
	public NRxRxInfo() {

	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "ndxFillNO", column = @Column(name = "NDX_FILL_NO")),
			@AttributeOverride(name = "ndxInvno", column = @Column(name = "NDX_INVNO")),
			@AttributeOverride(name = "ndxInvnoSub", column = @Column(name = "NDX_INVNO_SUB")),
			@AttributeOverride(name = "ndxLocaNo", column = @Column(name = "NDX_LOCA_NO")),
			@AttributeOverride(name = "ndxRxno", column = @Column(name = "NDX_RXNO")) })
	public NRxRxInfoId getId() {
		return id;
	}

	public void setId(NRxRxInfoId id) {
		this.id = id;
	}

	@Column(name = "NDX_REFILLNO")
	public int getRefillno() {
		return refillno;
	}

	public void setRefillno(int refillno) {
		this.refillno = refillno;
	}

	@Column(name = "NDX_PAT_NME_FST")
	public String getPatNmeFst() {
		return patNmeFst;
	}

	public void setPatNmeFst(String patNmeFst) {
		this.patNmeFst = patNmeFst;
	}

	@Column(name = "NDX_PAT_NME_LST")
	public String getPatNmeLst() {
		return patNmeLst;
	}

	public void setPatNmeLst(String patNmeLst) {
		this.patNmeLst = patNmeLst;
	}

	@Column(name = "NDX_MD_NAME_LST")
	public String getMdNameLst() {
		return mdNameLst;
	}

	public void setMdNameLst(String mdNameLst) {
		this.mdNameLst = mdNameLst;
	}

	@Column(name = "NDX_DRUG_NO")
	public int getDrugNo() {
		return drugNo;
	}

	public void setDrugNo(int drugNo) {
		this.drugNo = drugNo;
	}

	@Column(name = "NDX_BRND_SUB_NO")
	public int getBrndSubNo() {
		return brndSubNo;
	}

	public void setBrndSubNo(int brndSubNo) {
		this.brndSubNo = brndSubNo;
	}

	@Column(name = "NDX_CMPND_FLG")
	public String getCmpndFlg() {
		return cmpndFlg;
	}

	public void setCmpndFlg(String cmpndFlg) {
		this.cmpndFlg = cmpndFlg;
	}

	@Column(name = "NDX_QUANTITY")
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Column(name = "NDX_DTE_OF_SERV")
	@Temporal(TemporalType.DATE)
	public Date getDteOfServ() {
		return dteOfServ;
	}

	public void setDteOfServ(Date dteOfServ) {
		this.dteOfServ = dteOfServ;
	}

	@Column(name = "NDX_PRICE")
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Column(name = "NDX_COPAY")
	public double getCopay() {
		return copay;
	}

	public void setCopay(double copay) {
		this.copay = copay;
	}

	@Column(name = "NDX_PAT_PAY_AMT")
	public double getPatPayAmt() {
		return patPayAmt;
	}

	public void setPatPayAmt(double patPayAmt) {
		this.patPayAmt = patPayAmt;
	}

	@Column(name = "NDX_NO_SFTY_CAP")
	public String getNoSftyCap() {
		return noSftyCap;
	}

	public void setNoSftyCap(String noSftyCap) {
		this.noSftyCap = noSftyCap;
	}

	@Column(name = "NDX_RFL_BEF_DTE")
	@Temporal(TemporalType.DATE)
	public Date getRflBefDte() {
		return rflBefDte;
	}

	public void setRflBefDte(Date rflBefDte) {
		this.rflBefDte = rflBefDte;
	}

	@Column(name = "NDX_RFL_AFT_DTE")
	@Temporal(TemporalType.DATE)
	public Date getRflAftDte() {
		return rflAftDte;
	}

	public void setRflAftDte(Date rflAftDte) {
		this.rflAftDte = rflAftDte;
	}

	@Column(name = "NDX_ORG_REFILLS")
	public int getOrgRefills() {
		return orgRefills;
	}

	public void setOrgRefills(int orgRefills) {
		this.orgRefills = orgRefills;
	}

	@Column(name = "NDX_NUM_REFILLS")
	public int getNumRefills() {
		return numRefills;
	}

	public void setNumRefills(int numRefills) {
		this.numRefills = numRefills;
	}

	@Column(name = "NDX_RENEWAL_FLG")
	public String getRenewalFlg() {
		return renewalFlg;
	}

	public void setRenewalFlg(String renewalFlg) {
		this.renewalFlg = renewalFlg;
	}

	@Column(name = "NDX_REPL_FLAG")
	public String getReplFlag() {
		return replFlag;
	}

	public void setReplFlag(String replFlag) {
		this.replFlag = replFlag;
	}

	@Column(name = "NDX_REPL_QTY")
	public int getReplQty() {
		return replQty;
	}

	public void setReplQty(int replQty) {
		this.replQty = replQty;
	}

	@Column(name = "NDX_REPL_DATE")
	@Temporal(TemporalType.DATE)
	public Date getReplDate() {
		return replDate;
	}

	public void setReplDate(Date replDate) {
		this.replDate = replDate;
	}

	@Column(name = "NDX_DRG_INSRTNO")
	public int getDrgInsrtno() {
		return drgInsrtno;
	}

	public void setDrgInsrtno(int drgInsrtno) {
		this.drgInsrtno = drgInsrtno;
	}

	@Column(name = "NDX_NO_MC_LETTERS")
	public int getNoMcLetters() {
		return noMcLetters;
	}

	public void setNoMcLetters(int noMcLetters) {
		this.noMcLetters = noMcLetters;
	}

	@Column(name = "NDX_DIRECTIONS")
	public String getDirections() {
		return directions;
	}

	public void setDirections(String directions) {
		this.directions = directions;
	}

	@Column(name = "NDX_RCV_FILL_PHMNO")
	public int getRcvFillPhmno() {
		return rcvFillPhmno;
	}

	public void setRcvFillPhmno(int rcvFillPhmno) {
		this.rcvFillPhmno = rcvFillPhmno;
	}

	@Column(name = "NDX_RCV_DISP_RPH")
	public String getRcvDispRph() {
		return rcvDispRph;
	}

	public void setRcvDispRph(String rcvDispRph) {
		this.rcvDispRph = rcvDispRph;
	}

	@Column(name = "NDX_RCV_DISP_DATE")
	@Temporal(TemporalType.DATE)
	public Date getRcvDispDate() {
		return rcvDispDate;
	}

	public void setRcvDispDate(Date rcvDispDate) {
		this.rcvDispDate = rcvDispDate;
	}

	@Column(name = "NDX_RCV_DISP_TIME")
	@Temporal(TemporalType.TIME)
	public Date getRcvDispTime() {
		return rcvDispTime;
	}

	public void setRcvDispTime(Date rcvDispTime) {
		this.rcvDispTime = rcvDispTime;
	}

	@Column(name = "NDX_RCV_LOT_NO")
	public String getRcvLotNo() {
		return rcvLotNo;
	}

	public void setRcvLotNo(String rcvLotNo) {
		this.rcvLotNo = rcvLotNo;
	}

	@Column(name = "NDX_RCV_EXP_DTE")
	@Temporal(TemporalType.DATE)
	public Date getRcvExpDte() {
		return rcvExpDte;
	}

	public void setRcvExpDte(Date rcvExpDte) {
		this.rcvExpDte = rcvExpDte;
	}

	@Column(name = "NDX_RCV_QTY")
	public int getRcvQty() {
		return rcvQty;
	}

	public void setRcvQty(int rcvQty) {
		this.rcvQty = rcvQty;
	}

	@Column(name = "NDX_RCV_WKSTN")
	public String getRcvWkstn() {
		return rcvWkstn;
	}

	public void setRcvWkstn(String rcvWkstn) {
		this.rcvWkstn = rcvWkstn;
	}

	@Column(name = "NDX_RCV_RX_STATUS")
	public String getRcvRxStatus() {
		return rcvRxStatus;
	}

	public void setRcvRxStatus(String rcvRxStatus) {
		this.rcvRxStatus = rcvRxStatus;
	}

	@Column(name = "NDX_TMSTMP")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getTmstmp() {
		return tmstmp;
	}

	public void setTmstmp(Date tmstmp) {
		this.tmstmp = tmstmp;
	}

	@Column(name = "NDX_RESP_TMSTMP")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getRespTmstmp() {
		return respTmstmp;
	}

	public void setRespTmstmp(Date respTmstmp) {
		this.respTmstmp = respTmstmp;
	}

	@Column(name = "NDX_XTRA_LABELS")
	public int getXtraLabels() {
		return xtraLabels;
	}

	public void setXtraLabels(int xtraLabels) {
		this.xtraLabels = xtraLabels;
	}

	@Column(name = "NDX_QTY_DIVISOR")
	public int getQtyDivisor() {
		return qtyDivisor;
	}

	public void setQtyDivisor(int qtyDivisor) {
		this.qtyDivisor = qtyDivisor;
	}

	@Column(name = "NDX_MAND_PPI")
	public String getMandPpi() {
		return mandPpi;
	}

	public void setMandPpi(String mandPpi) {
		this.mandPpi = mandPpi;
	}

	@Column(name = "NDX_MKTG_PPI")
	public String getMktgPpi() {
		return mktgPpi;
	}

	public void setMktgPpi(String mktgPpi) {
		this.mktgPpi = mktgPpi;
	}

	@Column(name = "NDX_SEND_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getSendTms() {
		return sendTms;
	}

	public void setSendTms(Date sendTms) {
		this.sendTms = sendTms;
	}

	@Column(name = "NDX_DRG_INS_PGS")
	public int getDrgInsPgs() {
		return drgInsPgs;
	}

	public void setDrgInsPgs(int drgInsPgs) {
		this.drgInsPgs = drgInsPgs;
	}

	@Column(name = "NDX_MAND_PPI_PGS")
	public int getMandPpiPgs() {
		return mandPpiPgs;
	}

	public void setMandPpiPgs(int mandPpiPgs) {
		this.mandPpiPgs = mandPpiPgs;
	}

	@Column(name = "NDX_MKTG_PPI_PGS")
	public int getMktgPpiPgs() {
		return mktgPpiPgs;
	}

	public void setMktgPpiPgs(int mktgPpiPgs) {
		this.mktgPpiPgs = mktgPpiPgs;
	}

	@Column(name = "NDX_ENH_PPI")
	public String getEnhPpi() {
		return enhPpi;
	}

	public void setEnhPpi(String enhPpi) {
		this.enhPpi = enhPpi;
	}

	@Column(name = "NDX_ENH_PPI_PGS")
	public int getEnhPpiPgs() {
		return enhPpiPgs;
	}

	public void setEnhPpiPgs(int enhPpiPgs) {
		this.enhPpiPgs = enhPpiPgs;
	}

	@Column(name = "NDX_NEW_PPI1")
	public String getNewPpi1() {
		return newPpi1;
	}

	public void setNewPpi1(String newPpi1) {
		this.newPpi1 = newPpi1;
	}

	@Column(name = "NDX_NEW_PPI1_PGS")
	public int getNewPpi1Pgs() {
		return newPpi1Pgs;
	}

	public void setNewPpi1Pgs(int newPpi1Pgs) {
		this.newPpi1Pgs = newPpi1Pgs;
	}

	@Column(name = "NDX_NEW_PPI2")
	public String getNewPpi2() {
		return newPpi2;
	}

	public void setNewPpi2(String newPpi2) {
		this.newPpi2 = newPpi2;
	}

	@Column(name = "NDX_NEW_PPI2_PGS")
	public int getNewPpi2Pgs() {
		return newPpi2Pgs;
	}

	public void setNewPpi2Pgs(int newPpi2Pgs) {
		this.newPpi2Pgs = newPpi2Pgs;
	}

	@Column(name = "NDX_DRG_SP_PPI")
	public String getDrgSpPpi() {
		return drgSpPpi;
	}

	public void setDrgSpPpi(String drgSpPpi) {
		this.drgSpPpi = drgSpPpi;
	}

	@Column(name = "NDX_DRG_SP_PPI_PGS")
	public int getDrgSpPpiPgs() {
		return drgSpPpiPgs;
	}

	public void setDrgSpPpiPgs(int drgSpPpiPgs) {
		this.drgSpPpiPgs = drgSpPpiPgs;
	}

	@Column(name = "NDX_NDP_DRUG_NO")
	public int getNdpDrugNo() {
		return ndpDrugNo;
	}

	public void setNdpDrugNo(int ndpDrugNo) {
		this.ndpDrugNo = ndpDrugNo;
	}

	@Column(name = "NDX_CLIENT_AMT_DSC")
	public String getClientAmtDsc() {
		return clientAmtDsc;
	}

	public void setClientAmtDsc(String clientAmtDsc) {
		this.clientAmtDsc = clientAmtDsc;
	}

	@Column(name = "NDX_RFL_BARCDE_FMT")
	public String getRflBarcdeFmt() {
		return rflBarcdeFmt;
	}

	public void setRflBarcdeFmt(String rflBarcdeFmt) {
		this.rflBarcdeFmt = rflBarcdeFmt;
	}

	@Column(name = "NDX_RFL_BARCDE_CD")
	public String getRflBarcdeCd() {
		return rflBarcdeCd;
	}

	public void setRflBarcdeCd(String rflBarcdeCd) {
		this.rflBarcdeCd = rflBarcdeCd;
	}

	@Column(name = "NDX_MANFST_DATE")
	@Temporal(TemporalType.DATE)
	public Date getManfstDate() {
		return manfstDate;
	}

	public void setManfstDate(Date manfstDate) {
		this.manfstDate = manfstDate;
	}

	@Column(name = "NDX_MANFST_TIME")
	@Temporal(TemporalType.TIME)
	public Date getManfstTime() {
		return manfstTime;
	}

	public void setManfstTime(Date manfstTime) {
		this.manfstTime = manfstTime;
	}

	@Column(name = "NDX_RENEWAL_CDE")
	public String getRenewalCde() {
		return renewalCde;
	}

	public void setRenewalCde(String renewalCde) {
		this.renewalCde = renewalCde;
	}

	@Column(name = "NDX_CANCL_REAS_CDE")
	public String getCanclReasCde() {
		return canclReasCde;
	}

	public void setCanclReasCde(String canclReasCde) {
		this.canclReasCde = canclReasCde;
	}

	@Column(name = "NDX_DED_APL_AMT")
	public double getDedAplAmt() {
		return dedAplAmt;
	}

	public void setDedAplAmt(double dedAplAmt) {
		this.dedAplAmt = dedAplAmt;
	}

	@Column(name = "NDX_PRICE_TYPE_CDE")
	public int getPriceTypeCde() {
		return priceTypeCde;
	}

	public void setPriceTypeCde(int priceTypeCde) {
		this.priceTypeCde = priceTypeCde;
	}

	@Column(name = "NDX_BOTTLE_MSG_CDE")
	public String getBottleMsgCde() {
		return bottleMsgCde;
	}

	public void setBottleMsgCde(String bottleMsgCde) {
		this.bottleMsgCde = bottleMsgCde;
	}

	@Column(name = "NDX_PRC_DIFF_AMT")
	public double getPrcDiffAmt() {
		return prcDiffAmt;
	}

	public void setPrcDiffAmt(double prcDiffAmt) {
		this.prcDiffAmt = prcDiffAmt;
	}

	@Column(name = "NDX_RCV_FILLER_ID")
	public String getRcvFillerId() {
		return rcvFillerId;
	}

	public void setRcvFillerId(String rcvFillerId) {
		this.rcvFillerId = rcvFillerId;
	}

	@Column(name = "NDX_RCV_FILL_DTE")
	@Temporal(TemporalType.DATE)
	public Date getRcvFillDte() {
		return rcvFillDte;
	}

	public void setRcvFillDte(Date rcvFillDte) {
		this.rcvFillDte = rcvFillDte;
	}

	@Column(name = "NDX_RCV_FILL_TIM")
	@Temporal(TemporalType.TIME)
	public Date getRcvFillTim() {
		return rcvFillTim;
	}

	public void setRcvFillTim(Date rcvFillTim) {
		this.rcvFillTim = rcvFillTim;
	}

	@Column(name = "NDX_CMPND_DRG_NME")
	public String getCmpndDrgNme() {
		return cmpndDrgNme;
	}

	public void setCmpndDrgNme(String cmpndDrgNme) {
		this.cmpndDrgNme = cmpndDrgNme;
	}

	@Column(name = "NCUNDX_RENEWAL_IND")
	public String getRenewalInd() {
		return renewalInd;
	}

	public void setRenewalInd(String renewalInd) {
		this.renewalInd = renewalInd;
	}

	@Column(name = "NDX_CL_PEN_TBL_IND")
	public String getClPenTblInd() {
		return clPenTblInd;
	}

	public void setClPenTblInd(String clPenTblInd) {
		this.clPenTblInd = clPenTblInd;
	}

	@Column(name = "NDX_CMPND_QTY")
	public double getCmpndQty() {
		return cmpndQty;
	}

	public void setCmpndQty(double cmpndQty) {
		this.cmpndQty = cmpndQty;
	}
}