package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceControl;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceControlId;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;

import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceControlDao;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class NRxInvoiceControlDaoImpl extends
		GenericDaoHibernate<NRxInvoiceControl> implements NRxInvoiceControlDao {

	private static final Logger log = LoggerFactory
			.getLogger(NRxInvoiceControlDaoImpl.class);

	public NRxInvoiceControlDaoImpl(SessionFactory sf) {
		super(NRxInvoiceControl.class, sf);
	}

	public List<NRxInvoiceControl> getNRxInvoiceControlListByNMC(String nrxcdeTableNo) {
		List<NRxInvoiceControl> nrxInvoiceControlList = null;		
		if (nrxcdeTableNo != null) {
			DetachedCriteria nrxInvoiceControlCriteria = DetachedCriteria
					.forClass(NRxInvoiceControl.class);

			nrxInvoiceControlCriteria.add(Restrictions.eq("id.nrxcdeTableNo",
					nrxcdeTableNo));

			List<?> nrxInvControlList = getHibernateTemplate().findByCriteria(
					nrxInvoiceControlCriteria);

			nrxInvoiceControlList = new ArrayList<NRxInvoiceControl>();
			for (Object nrxInvoiceControlObj : nrxInvControlList) {
				NRxInvoiceControl nrxInvoiceControl = (NRxInvoiceControl) nrxInvoiceControlObj;
				nrxInvoiceControlList.add(nrxInvoiceControl);
			}
		}
		return nrxInvoiceControlList;
	}

	public List<NRxInvoiceControl> getNRxInvoiceControlList(
			NRxInvoiceControlId nrxInvoiceControlId) {
		List<NRxInvoiceControl> nrxInvoiceControlList = null;

		if (nrxInvoiceControlId != null) {
			DetachedCriteria nrxInvoiceControlCriteria = DetachedCriteria
					.forClass(NRxInvoiceControl.class);

			nrxInvoiceControlCriteria.add(Restrictions.eq("id",
					nrxInvoiceControlId));

			List<?> nrxInvControlList = getHibernateTemplate().findByCriteria(
					nrxInvoiceControlCriteria);

			nrxInvoiceControlList = new ArrayList<NRxInvoiceControl>();
			for (Object nrxInvoiceControlObj : nrxInvControlList) {
				NRxInvoiceControl nrxInvoiceControl = (NRxInvoiceControl) nrxInvoiceControlObj;
				nrxInvoiceControlList.add(nrxInvoiceControl);
			}
		}
		return nrxInvoiceControlList;
	}

	public NRxInvoiceControl getNRxInvoiceControlForClientTable(
			String nrxcdeTableNo) {
		NRxInvoiceControl nrxInvoiceControl = null;		
		if (nrxcdeTableNo != null) {
			DetachedCriteria nrxInvoiceControlCriteria = DetachedCriteria
					.forClass(NRxInvoiceControl.class);

			nrxInvoiceControlCriteria.add(Restrictions.eq("id.nrxcdeTableNo",
					nrxcdeTableNo));

			nrxInvoiceControl = (NRxInvoiceControl)getHibernateTemplate().findByCriteria(
					nrxInvoiceControlCriteria).get(ZERO);

		}
		return nrxInvoiceControl;
	}
}
