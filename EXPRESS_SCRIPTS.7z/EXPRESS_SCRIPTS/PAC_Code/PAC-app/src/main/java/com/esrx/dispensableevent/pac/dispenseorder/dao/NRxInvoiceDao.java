package com.esrx.dispensableevent.pac.dispenseorder.dao;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceId;

public interface NRxInvoiceDao {
	
	NRxInvoice getN000OrderRecord(NRxInvoiceId nrxInvoiceId);
	
	void updateNDIVersionNo(Integer versionNum, NRxInvoice nrxInvoice);
	
	void updateNDIMEMFirstLastName(NRxInvoice nrxInvoice);
	
	void updateNDITimeStatusErrorCode(NRxInvoice nrxInvoice);
	
	void updateNDISendStatus(NRxInvoice nrxInvoice);
	
	
}
