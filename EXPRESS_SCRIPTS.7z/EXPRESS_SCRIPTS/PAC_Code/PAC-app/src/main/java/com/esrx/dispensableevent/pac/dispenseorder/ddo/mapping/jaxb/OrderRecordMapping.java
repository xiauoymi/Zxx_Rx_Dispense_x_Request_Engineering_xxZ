package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.DispPharmList;
import generated.OrderRecord;
import generated.QaCodeList;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.pac.dispenseorder.util.CatamaranControlInfoHelper;
import com.esrx.dispensableevent.rxdispense.domain.PatientInfoDdo;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ADDRESS_TYPE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ADMIN_CODE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ALT_SHIPPING_PHONENUM;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NO_INDICATOR;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.TAX;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.REFRIG_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.RETAIL_PHARM_NUM;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.SUB_GROUP;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.SVC_BRANCH_ID;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.WRK_ORDR_ID;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.CLEAN_INTERV;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NS_ORD_COMM_RES_IND;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NS_ORD_DOM_INTER_IND;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.DECLARED_VALUE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.PACK_REL_NUMBER;

public class OrderRecordMapping {

	public void mapDatabaseToBusinessDomain(OrderRecord orderRecordBdo, NRxInvoice nrxInvoiceDdo, OrderRecordMappingHelper orderRecordMappingHelper, PatientInfoDdo patientInfoDdo) {
		
		if(orderRecordBdo != null && nrxInvoiceDdo != null && orderRecordMappingHelper != null && patientInfoDdo != null) {
			orderRecordBdo.setAcctBalDate(String.valueOf(nrxInvoiceDdo.getAcctBalDte()));
			orderRecordBdo.setAcctSummDate(String.valueOf(nrxInvoiceDdo.getAcctSummDte()));
			orderRecordBdo.setAcctSummFormat(nrxInvoiceDdo.getAcctSummCde());
			orderRecordBdo.setAddressType(ADDRESS_TYPE);         // Missing in NRX   
			orderRecordBdo.setAdminCode(ADMIN_CODE); // Missing in NRX
			orderRecordBdo.setAltShippingAddLn1(EMPTY_STRING);  // Missing in NRX
			orderRecordBdo.setAltShippingAddLn2(EMPTY_STRING); // Missing in NRX
			orderRecordBdo.setAltShippingCity(EMPTY_STRING); // Missing in NRX
			orderRecordBdo.setAltShippingName(EMPTY_STRING); // Missing in NRX
			orderRecordBdo.setAltShippingPhoneNum(ALT_SHIPPING_PHONENUM); // Missing in NRX
			orderRecordBdo.setAltShippingState(EMPTY_STRING); // Missing in NRX
			orderRecordBdo.setAltShippingZip4(EMPTY_STRING);  // Missing in NRX
			orderRecordBdo.setAltShippingZip5(EMPTY_STRING);  // Missing in NRX
			orderRecordBdo.setApdata(EMPTY_STRING);    //  Missing in NRX
//			orderRecordBdo.setAutoChgInd(EMPTY_STRING);
			orderRecordBdo.setAutoChgInd(nrxInvoiceDdo.getAutoChgInd());

//			orderRecordBdo.setBrandid(BRAND_ID);    /// Missing in NRX
			orderRecordBdo.setBrandid(orderRecordMappingHelper.getBrandId());    /// Missing in NRX

			orderRecordBdo.setBusReplyPermit(nrxInvoiceDdo.getBusRplyPerm());
			orderRecordBdo.setCcChgAmount(String.valueOf(nrxInvoiceDdo.getCcAmt()));
//			orderRecordBdo.setCcLast4Digit(CC_LAST4DIGIT);
			orderRecordBdo.setCcLast4Digit(nrxInvoiceDdo.getCcLast4Nbr());

//			orderRecordBdo.setCcTypeCode(EMPTY_STRING);
			orderRecordBdo.setCcTypeCode(nrxInvoiceDdo.getCcTypeCde());

			orderRecordBdo.setClassServ(nrxInvoiceDdo.getClassService());
			orderRecordBdo.setCleanInterv(CLEAN_INTERV);   // Missing in NRX
			orderRecordBdo.setClientAmount(String.valueOf(nrxInvoiceDdo.getClientAmount()));
			orderRecordBdo.setClientAmtDsc(String.valueOf(nrxInvoiceDdo.getClientAmount()));
//			orderRecordBdo.setClientLogo(String.valueOf(ZERO));
			orderRecordBdo.setClientLogo(nrxInvoiceDdo.getLogoTifFile());

			orderRecordBdo.setClientNetAddr(nrxInvoiceDdo.getClntNetAddr());
			orderRecordBdo.setCommResInd(NS_ORD_COMM_RES_IND);
			orderRecordBdo.setCstScrubFlag(orderRecordMappingHelper.getCstScrubFlag());    // Missing in NRX   
			orderRecordBdo.setCustServPhone(String.valueOf(nrxInvoiceDdo.getCsPhone()));
			orderRecordBdo.setDeclaredValue(DECLARED_VALUE);  //  Missing in NRX   
			orderRecordBdo.setDelService(nrxInvoiceDdo.getDelvService());
			orderRecordBdo.setDispNo(String.valueOf(nrxInvoiceDdo.getDispPhyNo())); //  Missing in NRX 
//			DispPharmList dispPharmList = orderRecordBdo.getDispPharmList();
//			if(dispPharmList !=null) {
//				dispPharmList.getDispPharmNos().add(String.valueOf(nrxInvoiceDdo.getDispPhyNo()));
//			}
			orderRecordBdo.setDispPharmList(orderRecordMappingHelper.getDispPharmList());
//			orderRecordBdo.setDivertNo(ZERO);
			orderRecordBdo.setDivertNo(nrxInvoiceDdo.getDivertNo());

			orderRecordBdo.setDomInterInd(NS_ORD_DOM_INTER_IND);
//			orderRecordBdo.setEastWestFlag(nrxInvoiceDdo.gete);   // 
			orderRecordBdo.setEnclosureNo(nrxInvoiceDdo.getEnclNo());
//			orderRecordBdo.setFlatDispPharm(nrxInvoiceDdo.getD);  // Missing in NRX  
			orderRecordBdo.setGroup(nrxInvoiceDdo.getGroup());
			orderRecordBdo.setGroupShippingId(EMPTY_STRING);     //  Missing in NRX            
			orderRecordBdo.setGuarDelDate(String.valueOf(nrxInvoiceDdo.getGuarDelvDate()));
//			orderRecordBdo.setGuarDelFlag(nrxInvoiceDdo.getGuarDelvFlag());
			orderRecordBdo.setGuarDelFlag(orderRecordMappingHelper.getGuarDelvFlag());

//			orderRecordBdo.setInternetInd(YES_INDICATOR);
			orderRecordBdo.setInternetInd(nrxInvoiceDdo.getInternetInd());

			orderRecordBdo.setInvoiceNumber(String.valueOf(nrxInvoiceDdo.getId().getNdiInvno()));
			orderRecordBdo.setInvoiceSub(nrxInvoiceDdo.getId().getNdiInvnoSub());
			orderRecordBdo.setInvPharmAdd1(nrxInvoiceDdo.getInvPharmAdd1());
			orderRecordBdo.setInvPharmAdd2(nrxInvoiceDdo.getInvPharmAdd2());
			orderRecordBdo.setInvPharmName(nrxInvoiceDdo.getInvPharmName());
			orderRecordBdo.setLabelNameFst(nrxInvoiceDdo.getMemNameFst());
			orderRecordBdo.setLabelNameLst(nrxInvoiceDdo.getMemNameLst());
			orderRecordBdo.setLanguageFlag(nrxInvoiceDdo.getLangFlag());
//			orderRecordBdo.setLanguageFlag(orderRecordMappingHelper.getLangFlag());

//			orderRecordBdo.setMedicareFlag(nrxInvoiceDdo.getMedDInd());
			orderRecordBdo.setMedicareFlag(NO_INDICATOR);

			orderRecordBdo.setMemAddLn1(nrxInvoiceDdo.getMemAddLn1());
			orderRecordBdo.setMemAddLn2(nrxInvoiceDdo.getMemAddLn2());
			orderRecordBdo.setMemberId(nrxInvoiceDdo.getMemberNo());
			orderRecordBdo.setMemCity(nrxInvoiceDdo.getMemAddCity());
			orderRecordBdo.setMemDayPhone(String.valueOf(nrxInvoiceDdo.getMemDayPhone()));
			orderRecordBdo.setMemEvePhone(String.valueOf(nrxInvoiceDdo.getMemEvePhone()));
			orderRecordBdo.setMemNameFst(patientInfoDdo.getPatientFirstName());
			orderRecordBdo.setMemNameLst(patientInfoDdo.getPatientLastName());
			orderRecordBdo.setMemState(nrxInvoiceDdo.getMemAddState());
			orderRecordBdo.setMemZip4(String.valueOf(nrxInvoiceDdo.getMemAddZip4()));
			orderRecordBdo.setMemZip5(String.valueOf(nrxInvoiceDdo.getMemAddZip5()));
//			orderRecordBdo.setModifyFlag(nrxInvoiceDdo.getModifiedFlag());
			orderRecordBdo.setModifyFlag(orderRecordMappingHelper.getModifiedFlag());
//			orderRecordBdo.setNDPManagedCareLetterList(NDPManagedCareLetterList);
//			orderRecordBdo.setNetCommInd(YES_INDICATOR);
			orderRecordBdo.setNetCommInd(nrxInvoiceDdo.getNetCommInd());

			orderRecordBdo.setNewCharges(String.valueOf(nrxInvoiceDdo.getNewCharges()));
			orderRecordBdo.setNoRxRecs(nrxInvoiceDdo.getNoRxRecs());
			orderRecordBdo.setNoSobaMsgs(nrxInvoiceDdo.getNoSobaMsgs());
			orderRecordBdo.setOpt800Nbr(nrxInvoiceDdo.getOpt800Nbr());
			orderRecordBdo.setOrderDate(String.valueOf(nrxInvoiceDdo.getRecDate()));
			orderRecordBdo.setOrderPharmAdd1(nrxInvoiceDdo.getOrdPhrmAdd1());
			orderRecordBdo.setOrderPharmAdd2(nrxInvoiceDdo.getOrdPhrmAdd2());
			orderRecordBdo.setOrderPharmName(nrxInvoiceDdo.getOrdPhrmNme());
			orderRecordBdo.setOrdrNewBal(String.valueOf(nrxInvoiceDdo.getOrdrNewBlnce()));
			orderRecordBdo.setOrdrNewChrgs(String.valueOf(nrxInvoiceDdo.getOrdrNewChrgs()));
			orderRecordBdo.setOrdrPayRecv(String.valueOf(nrxInvoiceDdo.getOrdrPayRecvd()));
			orderRecordBdo.setOrdrPriorBal(String.valueOf(nrxInvoiceDdo.getOrdrPriorBal()));
			orderRecordBdo.setOrgRxSrce(EMPTY_STRING); // Missing in NRX
			orderRecordBdo.setOrigInvno(String.valueOf(nrxInvoiceDdo.getOrgInvno()));
			orderRecordBdo.setOrigInvnoSub(String.valueOf(nrxInvoiceDdo.getOrgInvnoSub()));
			orderRecordBdo.setOthPkgAmount(String.valueOf(nrxInvoiceDdo.getOthPkgQty()));
			orderRecordBdo.setPackRelNumber(Integer.valueOf(PACK_REL_NUMBER));
//			orderRecordBdo.setPackRelNumber(nrxInvoiceDdo.getPackRelCode());

//			orderRecordBdo.setPageCount(nrxInvoiceDdo);  // Missing in NRX
			orderRecordBdo.setPaymentRecCount(nrxInvoiceDdo.getPaymentsQty());
			orderRecordBdo.setPharmacyPhone(String.valueOf(nrxInvoiceDdo.getPharmPhone()));
			orderRecordBdo.setPharmLocaNo(String.valueOf(nrxInvoiceDdo.getId().getNdiFillNo()));
			QaCodeList qaCodeList = orderRecordBdo.getQaCodeList();
			if(qaCodeList !=null) {
				qaCodeList.getQaCodes().add(String.valueOf(nrxInvoiceDdo.getQaAssureCode()));
				orderRecordBdo.setQaCodeList(qaCodeList);				
			}
			orderRecordBdo.setQAComment(EMPTY_STRING);                 // Missing in NRX
			orderRecordBdo.setQaFlag(nrxInvoiceDdo.getQaFlag());
			orderRecordBdo.setQaOrderMode(String.valueOf(ZERO));       // Missing in NRX 
			orderRecordBdo.setQsiDelivDate(orderRecordMappingHelper.getQsiDelivDate());    // Missing in NRX   // available in NRXQSI00
			orderRecordBdo.setQsiDelivInstr(orderRecordMappingHelper.getQsiDelivInstr());    //Missing in NRX    // available in NRXQSI00 nrxqsiDelivryTxt
			orderRecordBdo.setQsiOptions(orderRecordMappingHelper.getQsiOptions());   /// need to be checked in DB for G 
//			orderRecordBdo.setRateShopInd(String.valueOf(ZERO));
			orderRecordBdo.setRateShopInd(nrxInvoiceDdo.getRateShopInd());

			orderRecordBdo.setRefrigFlag(REFRIG_FLAG); 		// Missing in NRX 
			orderRecordBdo.setRemitPharmAdd1(nrxInvoiceDdo.getRmitPhrmAdd1());
			orderRecordBdo.setRemitPharmAdd2(nrxInvoiceDdo.getRmitPhrmAdd2());
			orderRecordBdo.setRemitPharmName(nrxInvoiceDdo.getRmitPhrmNme());
//			orderRecordBdo.setReplFlag(nrxInvoiceDdo.getReplInd()); 
			orderRecordBdo.setReplFlag(nrxInvoiceDdo.getReplInd()); 
			orderRecordBdo.setRetailPharmNum(RETAIL_PHARM_NUM);  // Missing in NRX 
			orderRecordBdo.setRushOrderFlag(nrxInvoiceDdo.getEmerOrdFlag());
			orderRecordBdo.setSafetyCap(NO_INDICATOR); 
			orderRecordBdo.setShipChgAmount(String.valueOf(nrxInvoiceDdo.getShipChgAmt()));
			orderRecordBdo.setSubgroup(SUB_GROUP);
			orderRecordBdo.setSvcBranchId(SVC_BRANCH_ID);  // Missing in NRX 
			orderRecordBdo.setTargetDate(String.valueOf(nrxInvoiceDdo.getOrdrTargTms()));  
			orderRecordBdo.setTax(String.valueOf(TAX));
			orderRecordBdo.setUnionBugInd(nrxInvoiceDdo.getUnionBInd());
//			orderRecordBdo.setVerbCode(VERB_CODE);
			orderRecordBdo.setVerbCode(nrxInvoiceDdo.getOrdVerbCde());

			orderRecordBdo.setWrkOrdrId(WRK_ORDR_ID);  //Missing in NRX
		}
	}
}
