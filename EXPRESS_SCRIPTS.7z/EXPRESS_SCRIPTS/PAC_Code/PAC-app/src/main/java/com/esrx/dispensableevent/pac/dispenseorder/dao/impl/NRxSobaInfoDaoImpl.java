package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxSobaInfoDao;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class NRxSobaInfoDaoImpl extends GenericDaoHibernate<NRxSobaInfo>
		implements NRxSobaInfoDao {

	private static final Logger log = LoggerFactory
			.getLogger(NRxMclInfoDaoImpl.class);

	public NRxSobaInfoDaoImpl(SessionFactory sf) {
		super(NRxSobaInfo.class, sf);
	}

	public NRxSobaInfo getN002SOBARecord(NRxSobaInfoId nrxSobaInfoId) {
		NRxSobaInfo nrxSobaInfo = null;

		if (nrxSobaInfoId != null) {
			nrxSobaInfo = findById(nrxSobaInfoId);
		}
		return nrxSobaInfo;
	}

	public List<NRxSobaInfo> getN002SOBARecordListById(NRxSobaInfoId nrxSobaInfoId) {
		List<NRxSobaInfo> sobaRecordList = null;

		if (nrxSobaInfoId != null) {
			DetachedCriteria sobaRecordCriteria = DetachedCriteria
					.forClass(NRxSobaInfo.class);

			sobaRecordCriteria.add(Restrictions.eq("id", nrxSobaInfoId));

			List<?> sobaList = getHibernateTemplate().findByCriteria(
					sobaRecordCriteria);

			sobaRecordList = new ArrayList<NRxSobaInfo>();
			for (Object nrxSobaInfoObj : sobaList) {
				NRxSobaInfo nrxRxInfo = (NRxSobaInfo) nrxSobaInfoObj;
				sobaRecordList.add(nrxRxInfo);
			}
		}
		return sobaRecordList;
	}

	public List<NRxSobaInfo> getSOBARecordList(NRxSobaInfoId nrxSobaInfoId) {
		List<NRxSobaInfo> sobaRecordList = null;

		if (nrxSobaInfoId != null) {
			DetachedCriteria sobaRecordCriteria = DetachedCriteria
					.forClass(NRxSobaInfo.class);

			sobaRecordCriteria.add(Restrictions.eq("id.ndsFillNo", nrxSobaInfoId.getNdsFillNo()))
					.add(Restrictions.eq("id.ndsInvno", nrxSobaInfoId.getNdsInvno()))
					.add(Restrictions.eq("id.ndsInvnoSub", nrxSobaInfoId.getNdsInvnoSub()))
					.addOrder(Order.asc("id.ndsRxno"));

			List<?> sobaList = getHibernateTemplate().findByCriteria(
					sobaRecordCriteria);

			sobaRecordList = new ArrayList<NRxSobaInfo>();
			for (Object nrxSobaInfoObj : sobaList) {
				NRxSobaInfo nrxRxInfo = (NRxSobaInfo) nrxSobaInfoObj;
				sobaRecordList.add(nrxRxInfo);
			}
		}
		return sobaRecordList;
	}

	public void updateNDSTimeStamp(NRxSobaInfo nrxSobaInfo) {
		StringBuilder updateHql = new StringBuilder();
		updateHql.append("update NRxSobaInfo set ");
		updateHql.append("sendTms=:sendTms");
		updateHql.append(" where ");
		updateHql.append("id=:nrxSobaInfoId");
		updateHql.append(" and ");
		updateHql.append("messCodeNo=:messCodeNo");
		
		String updateNDSTimeStampHQL = String.valueOf(updateHql);

		if (nrxSobaInfo != null) {
			Query updateNDIMEMFirstLastNameQuery = getSession().createQuery(updateNDSTimeStampHQL);
			updateNDIMEMFirstLastNameQuery.setTimestamp("sendTms", nrxSobaInfo.getSendTms());
			updateNDIMEMFirstLastNameQuery.setParameter("nrxSobaInfoId", nrxSobaInfo.getId());
			updateNDIMEMFirstLastNameQuery.setString("messCodeNo", nrxSobaInfo.getMessCodeNo());			
			updateNDIMEMFirstLastNameQuery.executeUpdate();
		}
	}
}
