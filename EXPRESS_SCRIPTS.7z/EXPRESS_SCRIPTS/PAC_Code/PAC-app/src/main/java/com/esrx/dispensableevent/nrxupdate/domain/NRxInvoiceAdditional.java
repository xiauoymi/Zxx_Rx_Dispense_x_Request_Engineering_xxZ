/**
 * Author : Guru Krishnan
 */
package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="AUXORD00", uniqueConstraints = {})
public class NRxInvoiceAdditional implements Serializable{
	
	private static final long serialVersionUID = 2056630771795075208L;
	private NRxInvoiceAdditionalId id;
	private String cardholderId;
	private String clientId;
	private String xrfRequstTxt;
	private String xrfResponTxt;
	private String statusCde;
	private Date insertTms;
	private Date billingTms;
	private Date ndpTms;
	private Date ndpMailedTms;
	private Date ndpManfstTms;
	private int dispPhyNo;

	// Default Constructor
	public NRxInvoiceAdditional() {

	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "ordPartNbr", column = @Column(name = "ORD_PART_NBR")),
			@AttributeOverride(name = "ordFillNo", column = @Column(name = "ORD_FILL_NO")),
			@AttributeOverride(name = "ordExtInvno", column = @Column(name = "ORD_EXT_INVNO")),
			@AttributeOverride(name = "ordInvnoSub", column = @Column(name = "ORD_INVNO_SUB"))
	})
	public NRxInvoiceAdditionalId getId() {
		return id;
	}

	public void setId(NRxInvoiceAdditionalId id) {
		this.id = id;
	}

	@Column(name="ORD_CARDHOLDER_ID")
	public String getCardholderId() {
		return cardholderId;
	}


	public void setCardholderId(String cardholderId) {
		this.cardholderId = cardholderId;
	}

	@Column(name="ORD_CLIENT_ID")
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	@Column(name="ORD_XRF_REQUST_TXT")
	public String getXrfRequstTxt() {
		return xrfRequstTxt;
	}

	public void setXrfRequstTxt(String xrfRequstTxt) {
		this.xrfRequstTxt = xrfRequstTxt;
	}
	
	@Column(name="ORD_XRF_RESPON_TXT")
	public String getXrfResponTxt() {
		return xrfResponTxt;
	}

	public void setXrfResponTxt(String xrfResponTxt) {
		this.xrfResponTxt = xrfResponTxt;
	}

	@Column(name="ORD_STATUS_CDE")
	public String getStatusCde() {
		return statusCde;
	}

	public void setStatusCde(String statusCde) {
		this.statusCde = statusCde;
	}

	@Column(name="ORD_INSERT_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getInsertTms() {
		return insertTms;
	}

	public void setInsertTms(Date insertTms) {
		this.insertTms = insertTms;
	}

	@Column(name="ORD_BILLING_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getBillingTms() {
		return billingTms;
	}

	public void setBillingTms(Date billingTms) {
		this.billingTms = billingTms;
	}

	@Column(name="ORD_NDP_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getNdpTms() {
		return ndpTms;
	}

	public void setNdpTms(Date ndpTms) {
		this.ndpTms = ndpTms;
	}

	@Column(name="ORD_NDP_MAILED_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getNdpMailedTms() {
		return ndpMailedTms;
	}

	public void setNdpMailedTms(Date ndpMailedTms) {
		this.ndpMailedTms = ndpMailedTms;
	}

	@Column(name="ORD_NDP_MANFST_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getNdpManfstTms() {
		return ndpManfstTms;
	}

	public void setNdpManfstTms(Date ndpManfstTms) {
		this.ndpManfstTms = ndpManfstTms;
	}

	@Column(name="ORD_DISP_PHY_NO")
	public int getDispPhyNo() {
		return dispPhyNo;
	}

	public void setDispPhyNo(int dispPhyNo) {
		this.dispPhyNo = dispPhyNo;
	}
}