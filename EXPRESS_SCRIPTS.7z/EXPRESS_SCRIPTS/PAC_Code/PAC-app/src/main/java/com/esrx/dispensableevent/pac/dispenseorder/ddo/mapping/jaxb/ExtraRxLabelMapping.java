package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.ExtraRxLabel;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;

public class ExtraRxLabelMapping {

	public void mapDatabaseToBusinessDomain(ExtraRxLabel extraRxLabelBdo) {
//		extraRxLabelBdo.setLblNum(int);
		extraRxLabelBdo.setLblText(EMPTY_STRING);
		extraRxLabelBdo.setRxNum(EMPTY_STRING);
	}
}
