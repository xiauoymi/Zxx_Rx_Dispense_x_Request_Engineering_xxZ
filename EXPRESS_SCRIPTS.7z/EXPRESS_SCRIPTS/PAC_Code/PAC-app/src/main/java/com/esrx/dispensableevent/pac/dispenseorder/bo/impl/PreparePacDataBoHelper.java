package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import generated.ExtraRxLabel;
import generated.NDPPaymentRecord;
import generated.NDPRxRecord;
import generated.NDPSobaRecord;
import generated.OrderRecord;
import generated.ProcareOTCOrder;
import generated.Request;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.ExtraRxLabelMapping;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPManagedCareLetterMappingHelper;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPPaymentRecordMapping;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPRxRecordMappingHelper;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.NDPSobaRecordMappingHelper;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.ProcareOTCOrderMapping;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.RequestMapping;
import com.esrx.dispensableevent.pac.dispenseorder.util.CatamaranControlInfoHelper;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestDdo;

public class PreparePacDataBoHelper {

	private PackageInvoiceDataBoHelper packagePacDataBoHelper;
	private SobaRecordBoHelper sobaRecordBoHelper;
	private RxRecordBoHelper rxRecordBoHelper;
	
	private NDPPaymentRecordMapping ndpPaymentRecordMapping;
	private ProcareOTCOrderMapping procareOTCOrderMapping;
	private ExtraRxLabelMapping extraRxLabelMapping;
	private RequestMapping requestMapping;
	
	private CheckViolationsBoHelper checkViolationsBoHelper;
	private UpdateTimeStampBoHelper updateTimeStampBoHelper;
	private SendMsgPacBoHelper sendMsgPacBoHelper;

	
	/**
	 * @return the ndpPaymentRecordMapping
	 */
	public NDPPaymentRecordMapping getNdpPaymentRecordMapping() {
		return ndpPaymentRecordMapping;
	}


	/**
	 * @param ndpPaymentRecordMapping the ndpPaymentRecordMapping to set
	 */
	public void setNdpPaymentRecordMapping(
			NDPPaymentRecordMapping ndpPaymentRecordMapping) {
		this.ndpPaymentRecordMapping = ndpPaymentRecordMapping;
	}


	/**
	 * @return the rxRecordBoHelper
	 */
	public RxRecordBoHelper getRxRecordBoHelper() {
		return rxRecordBoHelper;
	}


	/**
	 * @param rxRecordBoHelper the rxRecordBoHelper to set
	 */
	public void setRxRecordBoHelper(RxRecordBoHelper rxRecordBoHelper) {
		this.rxRecordBoHelper = rxRecordBoHelper;
	}


	/**
	 * @return the packagePacDataBoHelper
	 */
	public PackageInvoiceDataBoHelper getPackagePacDataBoHelper() {
		return packagePacDataBoHelper;
	}


	/**
	 * @param packagePacDataBoHelper the packagePacDataBoHelper to set
	 */
	public void setPackagePacDataBoHelper(
			PackageInvoiceDataBoHelper packagePacDataBoHelper) {
		this.packagePacDataBoHelper = packagePacDataBoHelper;
	}


	/**
	 * @return the sobaRecordBoHelper
	 */
	public SobaRecordBoHelper getSobaRecordBoHelper() {
		return sobaRecordBoHelper;
	}


	/**
	 * @param sobaRecordBoHelper the sobaRecordBoHelper to set
	 */
	public void setSobaRecordBoHelper(SobaRecordBoHelper sobaRecordBoHelper) {
		this.sobaRecordBoHelper = sobaRecordBoHelper;
	}


	/**
	 * @return the procareOTCOrderMapping
	 */
	public ProcareOTCOrderMapping getProcareOTCOrderMapping() {
		return procareOTCOrderMapping;
	}


	/**
	 * @param procareOTCOrderMapping the procareOTCOrderMapping to set
	 */
	public void setProcareOTCOrderMapping(
			ProcareOTCOrderMapping procareOTCOrderMapping) {
		this.procareOTCOrderMapping = procareOTCOrderMapping;
	}


	/**
	 * @return the extraRxLabelMapping
	 */
	public ExtraRxLabelMapping getExtraRxLabelMapping() {
		return extraRxLabelMapping;
	}


	/**
	 * @param extraRxLabelMapping the extraRxLabelMapping to set
	 */
	public void setExtraRxLabelMapping(ExtraRxLabelMapping extraRxLabelMapping) {
		this.extraRxLabelMapping = extraRxLabelMapping;
	}


	/**
	 * @return the requestMapping
	 */
	public RequestMapping getRequestMapping() {
		return requestMapping;
	}


	/**
	 * @param requestMapping the requestMapping to set
	 */
	public void setRequestMapping(RequestMapping requestMapping) {
		this.requestMapping = requestMapping;
	}

	/**
	 * @return the checkViolationsBoHelper
	 */
	public CheckViolationsBoHelper getCheckViolationsBoHelper() {
		return checkViolationsBoHelper;
	}

	/**
	 * @param checkViolationsBoHelper the checkViolationsBoHelper to set
	 */
	public void setCheckViolationsBoHelper(
			CheckViolationsBoHelper checkViolationsBoHelper) {
		this.checkViolationsBoHelper = checkViolationsBoHelper;
	}

	/**
	 * @return the updateTimeStampBoHelper
	 */
	public UpdateTimeStampBoHelper getUpdateTimeStampBoHelper() {
		return updateTimeStampBoHelper;
	}

	/**
	 * @param updateTimeStampBoHelper the updateTimeStampBoHelper to set
	 */
	public void setUpdateTimeStampBoHelper(
			UpdateTimeStampBoHelper updateTimeStampBoHelper) {
		this.updateTimeStampBoHelper = updateTimeStampBoHelper;
	}

	/**
	 * @return the sendMsgPacBoHelper
	 */
	public SendMsgPacBoHelper getSendMsgPacBoHelper() {
		return sendMsgPacBoHelper;
	}

	/**
	 * @param sendMsgPacBoHelper the sendMsgPacBoHelper to set
	 */
	public void setSendMsgPacBoHelper(SendMsgPacBoHelper sendMsgPacBoHelper) {
		this.sendMsgPacBoHelper = sendMsgPacBoHelper;
	}

	public Request preparePacData(NRxInvoice nrxInvoiceDdo, RxDispenseRequestDdo rxDispenseRequestDdo, CatamaranControlInfoHelper catamaranControlInfoHelper) {
		Request pacRequestBdo  = null;
		OrderRecord orderRecordBdo = null;
		List<NDPSobaRecord> ndpSobaRecordList = null;
		List<NDPRxRecord> ndpRxRecordBdoList = null;
		NDPRxRecordMappingHelper ndpRxRecordMappingHelper  = null;
		NDPSobaRecordMappingHelper ndpSobaRecordMappingHelper = null;
		NDPManagedCareLetterMappingHelper ndpManagedCareLetterMappingHelper = null;
		
		List<NRxRxInfo> nrxRxInfoList = null; 
		List<NRxSobaInfo> nrxSobaRecordList = null; 
		List<NRxMclInfo> nrxMclInfoDdoList = null;
		
		if(nrxInvoiceDdo != null) {
			orderRecordBdo = packagePacDataBoHelper.packageInvoiceData(nrxInvoiceDdo, catamaranControlInfoHelper);
//			ndpSobaRecordList = sobaRecordBoHelper.packagePacSobaRecordData(nrxInvoiceDdo);
			ndpSobaRecordMappingHelper = new NDPSobaRecordMappingHelper();
			ndpSobaRecordMappingHelper = sobaRecordBoHelper.packagePacSobaRecordData(nrxInvoiceDdo, ndpSobaRecordMappingHelper);
			ndpSobaRecordList = ndpSobaRecordMappingHelper.getNdpSobaRecordList();
			nrxSobaRecordList = ndpSobaRecordMappingHelper.getNrxSobaRecordList();
			
			ndpManagedCareLetterMappingHelper = new NDPManagedCareLetterMappingHelper();
			ndpRxRecordMappingHelper = rxRecordBoHelper.packagePacRxRecordData(rxDispenseRequestDdo, nrxInvoiceDdo, orderRecordBdo, ndpManagedCareLetterMappingHelper);
			ndpRxRecordBdoList = ndpRxRecordMappingHelper.getNdpRxRecordBdoList();
			nrxRxInfoList = ndpRxRecordMappingHelper.getPrescriptionRecordList();
			
			nrxMclInfoDdoList = ndpManagedCareLetterMappingHelper.getManagedCareLetterList();
			
			NDPPaymentRecord ndpPaymentRecordBdo = new NDPPaymentRecord();
			ndpPaymentRecordMapping.mapDatabaseToBusinessDomain(ndpPaymentRecordBdo);
			
			ProcareOTCOrder procareOTCOrderBdo = new ProcareOTCOrder();
			procareOTCOrderMapping.mapDatabaseToBusinessDomain(procareOTCOrderBdo);

			ExtraRxLabel extraRxLabelBdo = new ExtraRxLabel();
			extraRxLabelMapping.mapDatabaseToBusinessDomain(extraRxLabelBdo);
 
			for(NDPSobaRecord ndpSobaRecordBdo : ndpSobaRecordList) {
				orderRecordBdo.getNDPSobaRecords().add(ndpSobaRecordBdo);
			}

			for(NDPRxRecord ndpRxRecordBdo : ndpRxRecordBdoList) {
				orderRecordBdo.getNDPRxRecords().add(ndpRxRecordBdo);
			}

			orderRecordBdo.getNDPPaymentRecords().add(ndpPaymentRecordBdo);
			orderRecordBdo.getProcareOTCOrders().add(procareOTCOrderBdo);
			orderRecordBdo.getExtraRxLabels().add(extraRxLabelBdo);
			
			pacRequestBdo = new Request(); 
			requestMapping.mapDatabaseToBusinessDomain(pacRequestBdo);
			pacRequestBdo.setOrderRecord(orderRecordBdo);
			
			checkViolationsOnPacMessage(orderRecordBdo, nrxInvoiceDdo, nrxRxInfoList);
			updateTimeStampOnSendingMsgToPac(nrxInvoiceDdo, nrxSobaRecordList, nrxRxInfoList, nrxMclInfoDdoList);
			updateSendStatusForSendMsgToPac(nrxInvoiceDdo);
		}
		return pacRequestBdo; 
	}
	
	public void checkViolationsOnPacMessage(OrderRecord orderRecordBdo , NRxInvoice nrxInvoiceDdo, List<NRxRxInfo> prescriptionRecordList) {
		checkViolationsBoHelper.CheckViolationsForPacData(orderRecordBdo, nrxInvoiceDdo, prescriptionRecordList);
	}
	
	public void updateTimeStampOnSendingMsgToPac(NRxInvoice nrxInvoiceDdo, List<NRxSobaInfo> nrxSobaInfoDdoList, List<NRxRxInfo> nrxRxInfoDdoList, List<NRxMclInfo> nrxMclInfoDdoList) {
		updateTimeStampBoHelper.updateTimeStampOnPackagePacData(nrxInvoiceDdo, nrxSobaInfoDdoList, nrxRxInfoDdoList, nrxMclInfoDdoList);
	}

	public void updateSendStatusForSendMsgToPac(NRxInvoice nrxInvoiceDdo) {
		sendMsgPacBoHelper.updateSendStatusForSendMsgToPac(nrxInvoiceDdo);
	}
	

}
