package com.esrx.dispensableevent.pac.dispenseorder.constant;

import java.util.HashMap;
import java.util.Map;

public enum PacDispenseOrderStatusCode {

	INITIAL_SETUP(1), 
	REPLACEMENT_SETUP(2), 
	CORRECTION_SETUP(3), 
	QUEUE_DATA_READY(4),			
	RECEIVE_INPROCESS(5), 
	RECEIVE_ENDED(6), 
	PAC_REJECT(7), 
	REPLACEMENT_PROTOCOL(8), 
	RESEND_REQUIRED(9), 
	ORDER_CANCELED(10), 
	ORDER_CHECKED(11), 
	PAC_RECEIVED(12), 
	RACF_REJECT(13), 
	PAC_ACCEPTED(14), 
	REPLACEMENT_COMPLETED(98),
	ORDER_COMPLETED(99); 

	int pacStatusCode;

	private static final Map<Integer,PacDispenseOrderStatusCode>  statusCodeMap = new HashMap<Integer,PacDispenseOrderStatusCode>();
	
	static {
		for(PacDispenseOrderStatusCode statusMap : PacDispenseOrderStatusCode.values()) {
			
			statusCodeMap.put(statusMap.pacStatusCode, statusMap);
		}
	}
	
	private PacDispenseOrderStatusCode(int pacStatusCode) {
		this.pacStatusCode = pacStatusCode;
	}

	public int getPacStatusVal() {
		return pacStatusCode;
	}

	public static int getPacStatusCode(PacDispenseOrderStatusCode pacStatusCode) {
		return PacDispenseOrderStatusCode.valueOf(String.valueOf(pacStatusCode))
				.getPacStatusVal();
	}
	
	public static PacDispenseOrderStatusCode getPacStatusCode(int pacStatusCode) {
		
		return statusCodeMap.get(pacStatusCode);
	}

}
