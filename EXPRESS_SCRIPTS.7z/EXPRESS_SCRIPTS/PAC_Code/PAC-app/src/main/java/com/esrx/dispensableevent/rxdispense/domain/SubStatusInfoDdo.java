/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * SubStatusInfoDdo.
 */
@Entity
@Table(name = "TBL_SUB_STATUS_INFO", uniqueConstraints = {})
public class SubStatusInfoDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

	/** The sub status code. */
	private int subStatusCode;
	
	/** The status desc. */
	private String statusDesc;

	/**
	 * default constructor.
	 */
	public SubStatusInfoDdo() {
	}

	/**
	 * Checks if is sub status code.
	 *
	 * @return the int
	 */
	@Id
	@Column(name = "SUB_STATUS_CODE", unique = true, nullable = false, insertable = true, updatable = true, precision = 1, scale = 0)
	public int isSubStatusCode() {
		return this.subStatusCode;
	}

	/**
	 * Sets the sub status code.
	 *
	 * @param subStatusCode the new sub status code
	 */
	public void setSubStatusCode(int subStatusCode) {
		this.subStatusCode = subStatusCode;
	}

	/**
	 * Gets the status desc.
	 *
	 * @return the status desc
	 */
	@Column(name = "STATUS_DESC", unique = false, nullable = false, insertable = true, updatable = true, length = 40)
	public String getStatusDesc() {
		return this.statusDesc;
	}

	/**
	 * Sets the status desc.
	 *
	 * @param statusDesc the new status desc
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

}
