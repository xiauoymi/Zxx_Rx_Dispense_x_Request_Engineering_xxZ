package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;

public class NRxInvoiceDaoImpl extends GenericDaoHibernate<NRxInvoice>
		implements NRxInvoiceDao {

	private static final Logger log = LoggerFactory
			.getLogger(NRxMclInfoDaoImpl.class);

	public NRxInvoiceDaoImpl(SessionFactory sf) {
		super(NRxInvoice.class, sf);
	}

	public NRxInvoice getN000OrderRecord(NRxInvoiceId nrxInvoiceId) {
		NRxInvoice nrxInvoice = null;
		if (nrxInvoiceId  != null ) {
			nrxInvoice = findById(nrxInvoiceId);
		}
		return nrxInvoice;
	}

	public void updateNDIVersionNo(Integer versionNum, NRxInvoice nrxInvoice) {

		StringBuilder updateHql = new StringBuilder();
		updateHql.append("update NRxInvoice set ");
		updateHql.append("verNo=:verNo");
		updateHql.append(" where ");
		updateHql.append("id=:nrxInvoiceId");

		String updateNDIVersionNoHQL = String.valueOf(updateHql);

		if (nrxInvoice != null && versionNum != null ) {
			Query updateVersionNoQuery = getSession().createQuery(updateNDIVersionNoHQL);
			updateVersionNoQuery.setInteger("verNo",
					versionNum);
			updateVersionNoQuery.setParameter("nrxInvoiceId",
					nrxInvoice.getId());
			updateVersionNoQuery.executeUpdate();
		}
	}

	public void updateNDIMEMFirstLastName(NRxInvoice nrxInvoice) {
		
		StringBuilder updateHql = new StringBuilder();
		updateHql.append("update NRxInvoice set ");
		updateHql.append("memNameFst=:memNameFst,");
		updateHql.append("memNameLst=:memNameLst");
		updateHql.append(" where ");
		updateHql.append("id=:nrxInvoiceId");

		String updateNDIMEMFirstLastNameHQL = String.valueOf(updateHql);

		if (nrxInvoice != null) {
			Query updateNDIMEMFirstLastNameQuery = getSession().createQuery(updateNDIMEMFirstLastNameHQL);
			updateNDIMEMFirstLastNameQuery.setString("memNameFst", nrxInvoice.getMemNameFst());
			updateNDIMEMFirstLastNameQuery.setString("memNameLst", nrxInvoice.getMemNameLst());
			updateNDIMEMFirstLastNameQuery.setParameter("nrxInvoiceId",
					nrxInvoice.getId());
			updateNDIMEMFirstLastNameQuery.executeUpdate();
		}
	}

	public void updateNDITimeStatusErrorCode(NRxInvoice nrxInvoice) {

		StringBuilder updateHql = new StringBuilder();
		updateHql.append("update NRxInvoice set ");
		updateHql.append("sendTms=:sendTms,");
		updateHql.append("sendStatus=:sendStatus,");
		updateHql.append("recvErrorCde=:recvErrorCde");
		updateHql.append(" where ");
		updateHql.append("id=:nrxInvoiceId");

		String updateNDITimeStatusErrorCodeHQL = String.valueOf(updateHql);
		
		if (nrxInvoice != null) {
			Query updateNDITimeStatusErrorCode = getSession().createQuery(updateNDITimeStatusErrorCodeHQL);
			updateNDITimeStatusErrorCode.setTimestamp("sendTms", nrxInvoice.getSendTms());
			updateNDITimeStatusErrorCode.setInteger("sendStatus", nrxInvoice.getSendStatus());
			updateNDITimeStatusErrorCode.setInteger("recvErrorCde", nrxInvoice.getRecvErrorCde());
			updateNDITimeStatusErrorCode.setParameter("nrxInvoiceId",
					nrxInvoice.getId());
			updateNDITimeStatusErrorCode.executeUpdate();
		}
	}

	public void updateNDISendStatus(NRxInvoice nrxInvoice) {
		StringBuilder updateHql = new StringBuilder();
		updateHql.append("update NRxInvoice set ");
		updateHql.append("sendStatus=:sendStatus");
		updateHql.append(" where ");
		updateHql.append("id=:nrxInvoiceId");
		
		String updateNDISendStatusHQL = String.valueOf(updateHql);

		if (nrxInvoice != null) {
			Query updateNDXSendTimeStampQuery = getSession().createQuery(updateNDISendStatusHQL);
			updateNDXSendTimeStampQuery.setInteger("sendStatus", nrxInvoice.getSendStatus());
			updateNDXSendTimeStampQuery.setParameter("nrxInvoiceId", nrxInvoice.getId());
			updateNDXSendTimeStampQuery.executeUpdate();
		}
	}
}
