package com.esrx.dispensableevent.pac.dispenseorder.dao;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfoId;

public interface NRxMclInfoDao {

	NRxMclInfo getManagedCareLetterRecord(NRxMclInfoId nrxMclInfoId);
	
	List<NRxMclInfo> getN006ManagedCareLetterRecordList(NRxMclInfoId nrxMclInfoId);
	
	void updateNDMSendTimeStamp(NRxMclInfo nrxMclInfo);
	
	List<NRxMclInfo> getManagedCareLetterOrderByLetterNum(NRxMclInfoId nrxMclInfoId);
}
