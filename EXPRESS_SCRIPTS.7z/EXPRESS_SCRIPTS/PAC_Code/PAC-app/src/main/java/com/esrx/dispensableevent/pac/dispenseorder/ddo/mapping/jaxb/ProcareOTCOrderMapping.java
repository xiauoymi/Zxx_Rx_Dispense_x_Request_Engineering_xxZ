package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.ProcareOTCOrder;

import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;


public class ProcareOTCOrderMapping {

	public void mapDatabaseToBusinessDomain(ProcareOTCOrder procareOTCOrderBdo) {
		procareOTCOrderBdo.setInvId(EMPTY_STRING);
//		procareOTCOrderBdo.setPackSze();
//		procareOTCOrderBdo.setQty(PacRequestConstant.ZERO);
		procareOTCOrderBdo.setRxNum(EMPTY_STRING);
	}
}
