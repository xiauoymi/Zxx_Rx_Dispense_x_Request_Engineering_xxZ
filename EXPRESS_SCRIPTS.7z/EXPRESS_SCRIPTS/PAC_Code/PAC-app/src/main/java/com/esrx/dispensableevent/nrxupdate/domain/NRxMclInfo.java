/**
 * Author : Guru Krishnan
 */
package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="NCUNDM00")
public class NRxMclInfo implements Serializable {
	
	private static final long serialVersionUID = -1160954568011388405L;
	private NRxMclInfoId id;
	private int noVar;
	private String varText;
	private Date tmpstp;
	private Date sendTms;
	private String varTag;
	private int varLen;
	private String varText1;

	// Default Constructor
	public NRxMclInfo() {
		
	}

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "ndmFillNO", column = @Column(name = "NDM_FILL_NO")),
			@AttributeOverride(name = "ndmInvno", column = @Column(name = "NDM_INVNO")),
			@AttributeOverride(name = "ndmInvnoSub", column = @Column(name = "NDM_INVNO_SUB")),
			@AttributeOverride(name = "ndmLocaNo", column = @Column(name = "NDM_LOCA_NO")),
			@AttributeOverride(name = "ndmRxno", column = @Column(name = "NDM_RXNO")),
			@AttributeOverride(name = "ndmLetterNo", column = @Column(name = "NDM_LETTER_NO")),
			@AttributeOverride(name = "ndmSeqNo", column = @Column(name = "NDM_SEQ_NO"))
	})
	public NRxMclInfoId getId() {
		return id;
	}

	public void setId(NRxMclInfoId id) {
		this.id = id;
	}

	@Column(name="NDM_NO_VAR")
	public int getNoVar() {
		return noVar;
	}

	public void setNoVar(int noVar) {
		this.noVar = noVar;
	}

	@Column(name="NDM_VAR_TEXT")
	public String getVarText() {
		return varText;
	}

	public void setVarText(String varText) {
		this.varText = varText;
	}

	@Column(name="NDM_TMPSTP")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getTmpstp() {
		return tmpstp;
	}

	public void setTmpstp(Date tmpstp) {
		this.tmpstp = tmpstp;
	}

	@Column(name="NDM_SEND_TMS")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getSendTms() {
		return sendTms;
	}

	public void setSendTms(Date sendTms) {
		this.sendTms = sendTms;
	}

	@Column(name="NDM_VAR_TAG")	
	public String getVarTag() {
		return varTag;
	}

	public void setVarTag(String varTag) {
		this.varTag = varTag;
	}

	@Column(name="NDM_VAR_LEN")
	public int getVarLen() {
		return varLen;
	}

	public void setVarLen(int varLen) {
		this.varLen = varLen;
	}
	
	@Column(name="NDM_VAR_TEXT1")
	public String getVarText1() {
		return varText1;
	}

	public void setVarText1(String varText1) {
		this.varText1 = varText1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + noVar;
		result = prime * result + ((sendTms == null) ? 0 : sendTms.hashCode());
		result = prime * result + ((tmpstp == null) ? 0 : tmpstp.hashCode());
		result = prime * result + varLen;
		result = prime * result + ((varTag == null) ? 0 : varTag.hashCode());
		result = prime * result + ((varText == null) ? 0 : varText.hashCode());
		result = prime * result
				+ ((varText1 == null) ? 0 : varText1.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NRxMclInfo other = (NRxMclInfo) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (noVar != other.noVar)
			return false;
		if (sendTms == null) {
			if (other.sendTms != null)
				return false;
		} else if (!sendTms.equals(other.sendTms))
			return false;
		if (tmpstp == null) {
			if (other.tmpstp != null)
				return false;
		} else if (!tmpstp.equals(other.tmpstp))
			return false;
		if (varLen != other.varLen)
			return false;
		if (varTag == null) {
			if (other.varTag != null)
				return false;
		} else if (!varTag.equals(other.varTag))
			return false;
		if (varText == null) {
			if (other.varText != null)
				return false;
		} else if (!varText.equals(other.varText))
			return false;
		if (varText1 == null) {
			if (other.varText1 != null)
				return false;
		} else if (!varText1.equals(other.varText1))
			return false;
		return true;
	}	
}