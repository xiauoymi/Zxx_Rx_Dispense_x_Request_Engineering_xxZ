package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.NDPPaymentRecord;

import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;

public class NDPPaymentRecordMapping {

	public void mapDatabaseToBusinessDomain(NDPPaymentRecord ndpPaymentRecordBdo) {
		ndpPaymentRecordBdo.setAmount(EMPTY_STRING);
		ndpPaymentRecordBdo.setDatePosted(EMPTY_STRING);
		ndpPaymentRecordBdo.setRefInfo(EMPTY_STRING);
		ndpPaymentRecordBdo.setTypeDesc(EMPTY_STRING);
	}
}
