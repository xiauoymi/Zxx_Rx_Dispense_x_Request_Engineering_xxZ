/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * v
 * ReturnAddressInfoDdo.
 */
@Entity
@Table(name = "TBL_RETURN_ADDRESS_INFO", uniqueConstraints = {})
public class ReturnAddressInfoDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

	/** The return address1. */
	private String returnAddress1;
	
	/** The return address2. */
	private String returnAddress2;
	
	/** The return address city. */
	private String returnAddressCity;
	
	/** The return address country. */
	private String returnAddressCountry;
	
	/** The return address name. */
	private String returnAddressName;
	
	/** The return address phone. */
	private Long returnAddressPhone;
	
	/** The return address state. */
	private String returnAddressState;
	
	/** The return address zip. */
	private String returnAddressZip;
	
	/**
	 * default constructor.
	 */
	public ReturnAddressInfoDdo() {
	}

	/** The rx dispense request. */
	private RxDispenseRequestDdo rxDispenseRequest;

	/** The id. */
	@EmbeddedId
	@AttributeOverrides({
		@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = true, updatable = false, precision = 30, scale = 0)),
		@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = true, updatable = false, length = 15)),
		@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = true, updatable = false, precision = 9, scale = 0)),
		@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = true, updatable = false, length = 1))})
	private RxDispenseRequestIdDdo id;
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public RxDispenseRequestIdDdo getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(RxDispenseRequestIdDdo id) {
		this.id = id;
	}

	/**
	 * Gets the rx dispense request.
	 *
	 * @return the rx dispense request
	 */
	@ManyToOne(cascade = {}, fetch = FetchType.EAGER)
	@JoinColumns({
			@JoinColumn(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="TRANS_ID"),
			@JoinColumn(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="CLIENT_ID"),
			@JoinColumn(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="ORDER_NUM"),
			@JoinColumn(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="SUBORDER_IND")})
	public RxDispenseRequestDdo getRxDispenseRequest() {
		return this.rxDispenseRequest;
	}

	/**
	 * Sets the rx dispense request.
	 *
	 * @param rxDispenseRequest the new rx dispense request
	 */
	public void setRxDispenseRequest(RxDispenseRequestDdo rxDispenseRequest) {
		this.rxDispenseRequest = rxDispenseRequest;
	}

    /**
     * Gets the return address name.
     *
     * @return the return address name
     */
    @Id
	@Column(name = "RETURN_ADDRESS_NAME", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getReturnAddressName() {
		return this.returnAddressName;
	}

	/**
	 * Sets the return address name.
	 *
	 * @param returnAddressName the new return address name
	 */
	public void setReturnAddressName(String returnAddressName) {
		this.returnAddressName = returnAddressName;
	}

	/**
	 * Gets the return address1.
	 *
	 * @return the return address1
	 */
	@Column(name = "RETURN_ADDRESS1", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getReturnAddress1() {
		return this.returnAddress1;
	}

	/**
	 * Sets the return address1.
	 *
	 * @param returnAddress1 the new return address1
	 */
	public void setReturnAddress1(String returnAddress1) {
		this.returnAddress1 = returnAddress1;
	}

	/**
	 * Gets the return address2.
	 *
	 * @return the return address2
	 */
	@Column(name = "RETURN_ADDRESS2", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getReturnAddress2() {
		return this.returnAddress2;
	}

	/**
	 * Sets the return address2.
	 *
	 * @param returnAddress2 the new return address2
	 */
	public void setReturnAddress2(String returnAddress2) {
		this.returnAddress2 = returnAddress2;
	}

	/**
	 * Gets the return address city.
	 *
	 * @return the return address city
	 */
	@Column(name = "RETURN_ADDRESS_CITY", unique = false, nullable = true, insertable = true, updatable = true, length = 25)
	public String getReturnAddressCity() {
		return this.returnAddressCity;
	}

	/**
	 * Sets the return address city.
	 *
	 * @param returnAddressCity the new return address city
	 */
	public void setReturnAddressCity(String returnAddressCity) {
		this.returnAddressCity = returnAddressCity;
	}

	/**
	 * Gets the return address state.
	 *
	 * @return the return address state
	 */
	@Column(name = "RETURN_ADDRESS_STATE", unique = false, nullable = true, insertable = true, updatable = true, length = 2)
	public String getReturnAddressState() {
		return this.returnAddressState;
	}

	/**
	 * Sets the return address state.
	 *
	 * @param returnAddressState the new return address state
	 */
	public void setReturnAddressState(String returnAddressState) {
		this.returnAddressState = returnAddressState;
	}

	/**
	 * Gets the return address country.
	 *
	 * @return the return address country
	 */
	@Column(name = "RETURN_ADDRESS_COUNTRY", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getReturnAddressCountry() {
		return this.returnAddressCountry;
	}

	/**
	 * Sets the return address country.
	 *
	 * @param returnAddressCountry the new return address country
	 */
	public void setReturnAddressCountry(String returnAddressCountry) {
		this.returnAddressCountry = returnAddressCountry;
	}

	/**
	 * Gets the return address zip.
	 *
	 * @return the return address zip
	 */
	@Column(name = "RETURN_ADDRESS_ZIP", unique = false, nullable = true, insertable = true, updatable = true, length = 10)
	public String getReturnAddressZip() {
		return this.returnAddressZip;
	}

	/**
	 * Sets the return address zip.
	 *
	 * @param returnAddressZip the new return address zip
	 */
	public void setReturnAddressZip(String returnAddressZip) {
		this.returnAddressZip = returnAddressZip;
	}

	/**
	 * Gets the return address phone.
	 *
	 * @return the return address phone
	 */
	@Column(name = "RETURN_ADDRESS_PHONE", unique = false, nullable = true, insertable = true, updatable = true, precision = 10, scale = 0)
	public Long getReturnAddressPhone() {
		return this.returnAddressPhone;
	}

	/**
	 * Sets the return address phone.
	 *
	 * @param returnAddressPhone the new return address phone
	 */
	public void setReturnAddressPhone(Long returnAddressPhone) {
		this.returnAddressPhone = returnAddressPhone;
	}

}
