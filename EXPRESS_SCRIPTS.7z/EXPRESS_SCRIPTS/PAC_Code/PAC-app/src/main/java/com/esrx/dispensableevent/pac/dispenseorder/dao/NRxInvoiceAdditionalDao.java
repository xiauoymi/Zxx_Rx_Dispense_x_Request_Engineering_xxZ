package com.esrx.dispensableevent.pac.dispenseorder.dao;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditional;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditionalId;

public interface NRxInvoiceAdditionalDao {

	NRxInvoiceAdditional getN000OrderRecordAdditional(NRxInvoiceAdditionalId nrxInvoiceAdditionalId);

	NRxInvoiceAdditional getOrderAdditionalForPackagePacData(NRxInvoiceAdditionalId nrxInvoiceAdditionalId);

	void updateNDPTmsStatusCde(NRxInvoiceAdditional nrxInvoiceAdditional);
	
}
