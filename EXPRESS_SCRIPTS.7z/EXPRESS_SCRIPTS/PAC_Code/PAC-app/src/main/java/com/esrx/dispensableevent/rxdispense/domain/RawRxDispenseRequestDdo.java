/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * RawRxDispenseRequestDdo.
 */
@Entity
@Table(name = "TBL_RAW_RX_DISPENSE_REQUEST", uniqueConstraints = {})
public class RawRxDispenseRequestDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

	/** The raw xml id. */
	private BigDecimal rawXmlId;
	
	/** The trans id. */
	private BigDecimal transId;
	
	/** The client id. */
	private String clientId;
	
	/** The order num. */
	private Integer orderNum;
	
	/** The suborder ind. */
	private String suborderInd;
	
	/** The xml date. */
	private Timestamp xmlDate;
	
	/** The xml txt. */
	private Blob xmlTxt;
	
	/** The status code. */
	private int statusCode;
	
	/** The error msg. */
	private String errorMsg;
	
	/** The processed. */
	private String processed;

	/** The rx dispense xml. */
	private String rxDispenseXML;

	/**
	 * Gets the rx dispense xml.
	 *
	 * @return the rxDispenseXML
	 */
	@Transient
	public String getRxDispenseXML() {
		return rxDispenseXML;
	}

	/**
	 * Sets the rx dispense xml.
	 *
	 * @param rxDispenseXML the rxDispenseXML to set
	 */
	public void setRxDispenseXML(String rxDispenseXML) {
		this.rxDispenseXML = rxDispenseXML;
	}

	/**
	 * default constructor.
	 */
	public RawRxDispenseRequestDdo() {
	}

	/**
	 * Gets the raw xml id.
	 *
	 * @return the raw xml id
	 */
	@Id
	@Column(name = "RAW_XML_ID", unique = true, nullable = false, insertable = true, updatable = true, precision = 30, scale = 0)
	public BigDecimal getRawXmlId() {
		return this.rawXmlId;
	}

	/**
	 * Sets the raw xml id.
	 *
	 * @param rawXmlId the new raw xml id
	 */
	public void setRawXmlId(BigDecimal rawXmlId) {
		this.rawXmlId = rawXmlId;
	}

	/**
	 * Gets the trans id.
	 *
	 * @return the trans id
	 */
	@Column(name = "TRANS_ID", unique = false, nullable = true, insertable = true, updatable = true, precision = 30, scale = 0)
	public BigDecimal getTransId() {
		return this.transId;
	}

	/**
	 * Sets the trans id.
	 *
	 * @param transId the new trans id
	 */
	public void setTransId(BigDecimal transId) {
		this.transId = transId;
	}

	/**
	 * Gets the client id.
	 *
	 * @return the client id
	 */
	@Column(name = "CLIENT_ID", unique = false, nullable = true, insertable = true, updatable = true, length = 15)
	public String getClientId() {
		return this.clientId;
	}

	/**
	 * Sets the client id.
	 *
	 * @param clientId the new client id
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * Gets the order num.
	 *
	 * @return the order num
	 */
	@Column(name = "ORDER_NUM", unique = false, nullable = true, insertable = true, updatable = true, precision = 9, scale = 0)
	public Integer getOrderNum() {
		return this.orderNum;
	}

	/**
	 * Sets the order num.
	 *
	 * @param orderNum the new order num
	 */
	public void setOrderNum(Integer orderNum) {
		this.orderNum = orderNum;
	}

	/**
	 * Gets the suborder ind.
	 *
	 * @return the suborder ind
	 */
	@Column(name = "SUBORDER_IND", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getSuborderInd() {
		return this.suborderInd;
	}

	/**
	 * Sets the suborder ind.
	 *
	 * @param suborderInd the new suborder ind
	 */
	public void setSuborderInd(String suborderInd) {
		this.suborderInd = suborderInd;
	}

	/**
	 * Gets the xml date.
	 *
	 * @return the xml date
	 */
	@Column(name = "XML_DATE", unique = false, nullable = true, insertable = true, updatable = true, length = 11)
	public Timestamp getXmlDate() {
		return this.xmlDate;
	}

	/**
	 * Sets the xml date.
	 *
	 * @param xmlDate the new xml date
	 */
	public void setXmlDate(Timestamp xmlDate) {
		this.xmlDate = xmlDate;
	}

	/**
	 * Gets the xml txt.
	 *
	 * @return the xmlTxt
	 */
	@Column(name = "XML_TXT", unique = false, nullable = true, insertable = true, updatable = true)
	@Basic(fetch = FetchType.EAGER)
	public Blob getXmlTxt() {
		return xmlTxt;
	}

	/**
	 * Sets the xml txt.
	 *
	 * @param xmlTxt the xmlTxt to set
	 */
	public void setXmlTxt(Blob xmlTxt) {
		this.xmlTxt = xmlTxt;
	}

	/**
	 * Gets the status code.
	 *
	 * @return the statusCode
	 */
	@Column(name = "STATUS_CODE", unique = false, nullable = true, insertable = true, updatable = true, precision = 1, scale = 0)
	public int getStatusCode() {
		return statusCode;
	}

	/**
	 * Sets the status code.
	 *
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Gets the error msg.
	 *
	 * @return the error msg
	 */
	@Column(name = "ERROR_MSG", unique = false, nullable = true, insertable = true, updatable = true, length = 40)
	public String getErrorMsg() {
		return this.errorMsg;
	}

	/**
	 * Sets the error msg.
	 *
	 * @param errorMsg the new error msg
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * Gets the processed.
	 *
	 * @return the processed
	 */
	@Column(name = "PROCESSED", unique = false, nullable = true, insertable = true, updatable = true, length = 1)
	public String getProcessed() {
		return this.processed;
	}

	/**
	 * Sets the processed.
	 *
	 * @param processed the new processed
	 */
	public void setProcessed(String processed) {
		this.processed = processed;
	}
}
