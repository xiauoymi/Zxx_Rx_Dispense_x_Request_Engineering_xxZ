package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_FALSE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_TRUE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BRAND_ID;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.LANG_FLAG_ENGLISH;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.LANG_FLAG_SPANISH;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NO_INDICATOR;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ONE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.Q_INDICATOR;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.R_INDICATOR;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.YES_INDICATOR;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.QSI_DELIV_DATE;
import static com.esrx.dispensableevent.pac.dispenseorder.util.PacDispenseOrderPartNbrUtil.getOrdPartNbr;
import static com.esrx.dispensableevent.pac.dispenseorder.util.RecordN150KeySplitter.getRxDispenseRequestId;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PackagePacDataValidator.isNegative;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PackagePacDataValidator.validateNDIVersionNo;
import generated.DispPharmList;
import generated.OrderRecord;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxExpeditedShipmentInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxExpeditedShipmentInfoId;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditional;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditionalId;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxExpeditedShipmentInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceAdditionalDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxRxInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.PatientInfoDao;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.OrderRecordMapping;
import com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb.OrderRecordMappingHelper;
import com.esrx.dispensableevent.pac.dispenseorder.util.CatamaranControlInfoHelper;
import com.esrx.dispensableevent.rxdispense.domain.PatientInfoDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestIdDdo;
import com.esrx.dispensableevent.rxdispense.domain.ShippingAddressInfoDdo;

public class PackageInvoiceDataBoHelper {
	
	private static final Logger log = LoggerFactory
	.getLogger(PackageInvoiceDataBoHelper.class);

	private NRxInvoiceDao nrxInvoiceDao;
	private NRxRxInfoDao nrxRxInfoDao;
	private NRxInvoiceAdditionalDao nrxInvoiceAdditionalDao;
	private PatientInfoDao patientInfoDao;
	private NRxExpeditedShipmentInfoDao nrxExpeditedShipmentInfoDao;
	
	private OrderRecord orderRecordBdo;
	private OrderRecordMapping orderRecordMapping;
	private OrderRecordMappingHelper orderRecordMappingHelper;

	private RxDispenseRequestDdo rxDispenseRequestDdo; 
	private PatientInfoDdo patientInfoDdo;
	private Set<PatientInfoDdo> patientInfos;

	private RxDispenseRequestIdDdo rxDispenseRequestIdDdo;
	
	private SendN153BoHelper sendN153BoHelper;
	
	/**
	 * @return the nrxInvoiceDao
	 */
	public NRxInvoiceDao getNrxInvoiceDao() {
		return nrxInvoiceDao;
	}
	/**
	 * @param nrxInvoiceDao the nrxInvoiceDao to set
	 */
	public void setNrxInvoiceDao(NRxInvoiceDao nrxInvoiceDao) {
		this.nrxInvoiceDao = nrxInvoiceDao;
	}

	/**
	 * @return the nrxRxInfoDao
	 */
	public NRxRxInfoDao getNrxRxInfoDao() {
		return nrxRxInfoDao;
	}


	/**
	 * @param nrxRxInfoDao the nrxRxInfoDao to set
	 */
	public void setNrxRxInfoDao(NRxRxInfoDao nrxRxInfoDao) {
		this.nrxRxInfoDao = nrxRxInfoDao;
	}


	/**
	 * @return the orderRecordMapping
	 */
	public OrderRecordMapping getOrderRecordMapping() {
		return orderRecordMapping;
	}


	/**
	 * @param orderRecordMapping the orderRecordMapping to set
	 */
	public void setOrderRecordMapping(OrderRecordMapping orderRecordMapping) {
		this.orderRecordMapping = orderRecordMapping;
	}

	/**
	 * @return the nrxInvoiceAdditionalDao
	 */
	public NRxInvoiceAdditionalDao getNrxInvoiceAdditionalDao() {
		return nrxInvoiceAdditionalDao;
	}
	/**
	 * @param nrxInvoiceAdditionalDao the nrxInvoiceAdditionalDao to set
	 */
	public void setNrxInvoiceAdditionalDao(
			NRxInvoiceAdditionalDao nrxInvoiceAdditionalDao) {
		this.nrxInvoiceAdditionalDao = nrxInvoiceAdditionalDao;
	}
	/**
	 * @return the patientInfoDao
	 */
	public PatientInfoDao getPatientInfoDao() {
		return patientInfoDao;
	}
	/**
	 * @param patientInfoDao the patientInfoDao to set
	 */
	public void setPatientInfoDao(PatientInfoDao patientInfoDao) {
		this.patientInfoDao = patientInfoDao;
	}
	/**
	 * @return the nrxExpeditedShipmentInfoDao
	 */
	public NRxExpeditedShipmentInfoDao getNrxExpeditedShipmentInfoDao() {
		return nrxExpeditedShipmentInfoDao;
	}
	/**
	 * @param nrxExpeditedShipmentInfoDao the nrxExpeditedShipmentInfoDao to set
	 */
	public void setNrxExpeditedShipmentInfoDao(
			NRxExpeditedShipmentInfoDao nrxExpeditedShipmentInfoDao) {
		this.nrxExpeditedShipmentInfoDao = nrxExpeditedShipmentInfoDao;
	}

	
	/**
	 * @return the sendN153BoHelper
	 */
	public SendN153BoHelper getSendN153BoHelper() {
		return sendN153BoHelper;
	}
	/**
	 * @param sendN153BoHelper the sendN153BoHelper to set
	 */
	public void setSendN153BoHelper(SendN153BoHelper sendN153BoHelper) {
		this.sendN153BoHelper = sendN153BoHelper;
	}
	public OrderRecord packageInvoiceData(NRxInvoice nrxInvoiceDdo, CatamaranControlInfoHelper catamaranControlInfoHelper) {
//		OrderRecordMappingHelper orderRecordMappingHelper = null;
//		NRxRxInfo nrxRxInfo = null;
		
		if(nrxInvoiceDdo != null) {
			boolean ndiVersionNoFlag = isNegative(nrxInvoiceDdo.getVerNo());
			if(ndiVersionNoFlag) {
				nrxInvoiceDao.updateNDIVersionNo(nrxInvoiceDdo.getVerNo(), nrxInvoiceDdo);
			} else {
//				nrxInvoiceDdo  = validateNDIVersionNo(ndiVersionNoFlag, nrxInvoiceDdo);
				validateNDIVersionNo(ndiVersionNoFlag, nrxInvoiceDdo);
				nrxInvoiceDao.updateNDIVersionNo(nrxInvoiceDdo.getVerNo(), nrxInvoiceDdo);
			}
			orderRecordMappingHelper = new OrderRecordMappingHelper();
			if(nrxInvoiceDdo.getModifiedFlag().equals(R_INDICATOR)) {
//				nrxInvoiceDdo.setReplInd(YES_INDICATOR);
//				nrxInvoiceDdo.setModifiedFlag(NO_INDICATOR);
//				orderRecordMappingHelper.setReplInd(YES_INDICATOR);
				orderRecordMappingHelper.setModifiedFlag(NO_INDICATOR);
			} else {
//				nrxInvoiceDdo.setReplInd(NO_INDICATOR);
//				nrxInvoiceDdo.setModifiedFlag(nrxInvoiceDdo.getModifiedFlag());
//				orderRecordMappingHelper.setReplInd(NO_INDICATOR);
				orderRecordMappingHelper.setModifiedFlag(nrxInvoiceDdo.getModifiedFlag());
			}
//			orderRecordMappingHelper.setBrandId(BRAND_ID);             //old
			orderRecordMappingHelper.setBrandId(String.valueOf(catamaranControlInfoHelper.getBrandId()));            

			
			if(nrxInvoiceDdo.getModifiedFlag().equals(R_INDICATOR)) {
				NRxRxInfoId nrxRxInfoId = new NRxRxInfoId();
				nrxRxInfoId.setNdxFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
				nrxRxInfoId.setNdxInvno(nrxInvoiceDdo.getId().getNdiInvno());
				
				boolean nrxRxInfoCountExists = nrxRxInfoDao.getCountForPackagePACData(nrxRxInfoId);
				boolean updateModifiedFlag;
				if(nrxRxInfoCountExists) {
					updateModifiedFlag = BOOLEAN_TRUE_FLAG;
				} else {
					updateModifiedFlag = BOOLEAN_FALSE_FLAG;
				}
				if(updateModifiedFlag) {
					orderRecordMappingHelper.setModifiedFlag(YES_INDICATOR);
				} else {
					//call populate data for order  
					packageInvoiceAdditionalData(nrxInvoiceDdo, orderRecordMappingHelper);
				}
			} else {
				packageInvoiceAdditionalData(nrxInvoiceDdo, orderRecordMappingHelper);
			}
		}
		orderRecordBdo = new OrderRecord();
		orderRecordMapping.mapDatabaseToBusinessDomain(orderRecordBdo, nrxInvoiceDdo, orderRecordMappingHelper, patientInfoDdo);
		return orderRecordBdo;
	}
	
	public void packageInvoiceAdditionalData(NRxInvoice nrxInvoiceDdo, OrderRecordMappingHelper orderRecordMappingHelper) {
//		if(nrxInvoiceDdo.getLangFlag().equals(LANG_FLAG_SPANISH)) {
//			orderRecordMappingHelper.setLangFlag(String.valueOf(ONE));
//		} else if(nrxInvoiceDdo.getLangFlag().equals(LANG_FLAG_ENGLISH)) {
//			orderRecordMappingHelper.setLangFlag(String.valueOf(ZERO));
//		}
		
		if(nrxInvoiceDdo.getGuarDelvFlag().equals(Q_INDICATOR)||
				nrxInvoiceDdo.getGuarDelvFlag().equals(YES_INDICATOR)) {
			orderRecordMappingHelper.setGuarDelvFlag(nrxInvoiceDdo.getGuarDelvFlag());
		} else {
			orderRecordMappingHelper.setGuarDelvFlag(NO_INDICATOR);
		}
		
		String ordPartNbr = getOrdPartNbr(nrxInvoiceDdo.getId().getNdiInvno()); 
		NRxInvoiceAdditionalId nrxInvoiceAdditionalId = new NRxInvoiceAdditionalId();
//		temp comment
//		nrxInvoiceAdditionalId.setOrdPartNbr(Integer.valueOf(ordPartNbr));
		nrxInvoiceAdditionalId.setOrdPartNbr(11);
		
		nrxInvoiceAdditionalId.setOrdFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
		nrxInvoiceAdditionalId.setOrdExtInvno(nrxInvoiceDdo.getId().getNdiInvno());
		
		NRxInvoiceAdditional nrxInvoiceAdditional = nrxInvoiceAdditionalDao.getOrderAdditionalForPackagePacData(nrxInvoiceAdditionalId);
		if(nrxInvoiceAdditional != null) {
			if(nrxInvoiceAdditional.getXrfRequstTxt() != null) {
				rxDispenseRequestIdDdo = getRxDispenseRequestId(nrxInvoiceAdditional.getXrfRequstTxt());
				rxDispenseRequestDdo = patientInfoDao.getPatientInfoDdoList(rxDispenseRequestIdDdo);
				if(rxDispenseRequestDdo != null) {
					patientInfos = rxDispenseRequestDdo.getPatientInfos();
					for (PatientInfoDdo patientInfoDdo : patientInfos) {
						this.patientInfoDdo = patientInfoDdo;
						break;
					}
				} else {
					// send N153 with relevant details
					sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
				}
			} else {
				// send N153 with relevant details
				sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
			}
		} else {
			// send N153 with relevant details
			sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
		}
		NRxExpeditedShipmentInfoId nrxExpeditedShipmentInfoId = new NRxExpeditedShipmentInfoId();
		nrxExpeditedShipmentInfoId.setNrxqsiCustno(nrxInvoiceDdo.getMemberNo());
		nrxExpeditedShipmentInfoId.setNrxqsiFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
		nrxExpeditedShipmentInfoId.setNrxqsiInvno(nrxInvoiceDdo.getId().getNdiInvno());
		
		NRxExpeditedShipmentInfo nrxExpeditedShipmentInfo = nrxExpeditedShipmentInfoDao.getNRxExpeditedShipmentInfo(nrxExpeditedShipmentInfoId);
		if(nrxExpeditedShipmentInfo != null) {
			orderRecordMappingHelper.setQsiOptions(nrxExpeditedShipmentInfo.getNrxqsiOptionCde());
			orderRecordMappingHelper.setQsiDelivDate(String.valueOf(nrxExpeditedShipmentInfo.getNrxqsiDelivryDte()));
			orderRecordMappingHelper.setQsiDelivInstr(nrxExpeditedShipmentInfo.getNrxqsiDelivryTxt());
			orderRecordMappingHelper.setCstScrubFlag(YES_INDICATOR);
			DispPharmList dispPharmList = new DispPharmList();
			if(dispPharmList !=null) {
				List<String> dispPharmNoList = dispPharmList.getDispPharmNos();
				dispPharmNoList.add(String.valueOf(rxDispenseRequestDdo.getPharmacy1()));
				dispPharmNoList.add(String.valueOf(rxDispenseRequestDdo.getPharmacy2()));
				dispPharmNoList.add(String.valueOf(rxDispenseRequestDdo.getPharmacy3()));
				dispPharmNoList.add(String.valueOf(rxDispenseRequestDdo.getPharmacy4()));
				dispPharmNoList.add(String.valueOf(rxDispenseRequestDdo.getPharmacy5()));
			}
			orderRecordMappingHelper.setDispPharmList(dispPharmList);
		}else {
			Set<ShippingAddressInfoDdo> shippingAddressInfoDdoSet = rxDispenseRequestDdo.getShippingAddressInfoSet();
			for(ShippingAddressInfoDdo ShippingAddressInfoDdo : shippingAddressInfoDdoSet) {
				orderRecordMappingHelper.setQsiOptions(ShippingAddressInfoDdo.getShipMethod());
//				orderRecordMappingHelper.setQsiDelivInstr(ShippingAddressInfoDdo);   ///  **************************** need to be taken from new oracle
				orderRecordMappingHelper.setQsiDelivDate(QSI_DELIV_DATE);
			}
		}
	}
	
}
