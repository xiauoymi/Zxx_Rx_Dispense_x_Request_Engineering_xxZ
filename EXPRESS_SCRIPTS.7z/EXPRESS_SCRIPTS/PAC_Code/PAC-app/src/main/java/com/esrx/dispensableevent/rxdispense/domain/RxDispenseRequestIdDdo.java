/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * RxDispenseRequestIdDdo.
 */
@Embeddable
public class RxDispenseRequestIdDdo implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

	/** The trans id. */
	private BigDecimal transId;
	
	/** The client id. */
	private String clientId;
	
	/** The order num. */
	private Integer orderNum;
	
	/** The suborder ind. */
	private String suborderInd;

	/**
	 * default constructor.
	 */
	public RxDispenseRequestIdDdo() {
	}

	/**
	 * Gets the trans id.
	 *
	 * @return the trans id
	 */
	@Column(name = "TRANS_ID", unique = false, nullable = false, insertable = true, updatable = true, precision = 30, scale = 0)
	public BigDecimal getTransId() {
		return this.transId;
	}

	/**
	 * Sets the trans id.
	 *
	 * @param transId the new trans id
	 */
	public void setTransId(BigDecimal transId) {
		this.transId = transId;
	}

	/**
	 * Gets the client id.
	 *
	 * @return the client id
	 */
	@Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = true, updatable = true, length = 15)
	public String getClientId() {
		return this.clientId;
	}

	/**
	 * Sets the client id.
	 *
	 * @param clientId the new client id
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * Gets the order num.
	 *
	 * @return the order num
	 */
	@Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = true, updatable = true, precision = 9, scale = 0)
	public Integer getOrderNum() {
		return this.orderNum;
	}

	/**
	 * Sets the order num.
	 *
	 * @param orderNum the new order num
	 */
	public void setOrderNum(Integer orderNum) {
		this.orderNum = orderNum;
	}

	/**
	 * Gets the suborder ind.
	 *
	 * @return the suborder ind
	 */
	@Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = true, updatable = true, length = 1)
	public String getSuborderInd() {
		return this.suborderInd;
	}

	/**
	 * Sets the suborder ind.
	 *
	 * @param suborderInd the new suborder ind
	 */
	public void setSuborderInd(String suborderInd) {
		this.suborderInd = suborderInd;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((clientId == null) ? 0 : clientId.hashCode());
		result = prime * result
				+ ((orderNum == null) ? 0 : orderNum.hashCode());
		result = prime * result
				+ ((suborderInd == null) ? 0 : suborderInd.hashCode());
		result = prime * result + ((transId == null) ? 0 : transId.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RxDispenseRequestIdDdo other = (RxDispenseRequestIdDdo) obj;
		if (clientId == null) {
			if (other.clientId != null)
				return false;
		} else if (!clientId.equals(other.clientId))
			return false;
		if (orderNum == null) {
			if (other.orderNum != null)
				return false;
		} else if (!orderNum.equals(other.orderNum))
			return false;
		if (suborderInd == null) {
			if (other.suborderInd != null)
				return false;
		} else if (!suborderInd.equals(other.suborderInd))
			return false;
		if (transId == null) {
			if (other.transId != null)
				return false;
		} else if (!transId.equals(other.transId))
			return false;
		return true;
	}

}
