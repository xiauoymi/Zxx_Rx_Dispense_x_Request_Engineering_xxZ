/*
 * 
 * @author Madhan Mohan
 * 
 */
package com.esrx.dispensableevent.rxdispense.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;


/**
 * WebServiceInfoDdo.
 */
@Entity
@Table(name="TBL_WEB_SERVICE_INFO"
)

public class WebServiceInfoDdo  implements java.io.Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -391492652672418293L;

    /** The web service info. */
    private String webServiceInfo;
    
    /** The status code. */
    private String statusCode;
    
    /** The status msg. */
    private String statusMsg;
    
    /** The reason code. */
    private String reasonCode;
    
    /** The reason msg. */
    private String reasonMsg;
    
    /** The msg type. */
    private String msgType;

    /**
     * default constructor.
     */
    public WebServiceInfoDdo() {
    }
    
	/** The id. */
    private RxDispenseRequestIdDdo id;

	/** The rx dispense request. */
	private RxDispenseRequestDdo rxDispenseRequest;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	@EmbeddedId
	@AttributeOverrides({
		@AttributeOverride(name = "transId", column = @Column(name = "TRANS_ID", unique = false, nullable = false, insertable = true, updatable = false, precision = 30, scale = 0)),
		@AttributeOverride(name = "clientId", column = @Column(name = "CLIENT_ID", unique = false, nullable = false, insertable = true, updatable = false, length = 15)),
		@AttributeOverride(name = "orderNum", column = @Column(name = "ORDER_NUM", unique = false, nullable = false, insertable = true, updatable = false, precision = 9, scale = 0)),
		@AttributeOverride(name = "suborderInd", column = @Column(name = "SUBORDER_IND", unique = false, nullable = false, insertable = true, updatable = false, length = 1))})
	public RxDispenseRequestIdDdo getId() {
		return this.id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(RxDispenseRequestIdDdo id) {
		this.id = id;
	}
	
	/**
	 * Gets the rx dispense request.
	 *
	 * @return the rx dispense request
	 */
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "TRANS_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="TRANS_ID"),
			@JoinColumn(name = "CLIENT_ID", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="CLIENT_ID"),
			@JoinColumn(name = "ORDER_NUM", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="ORDER_NUM"),
			@JoinColumn(name = "SUBORDER_IND", unique = false, nullable = false, insertable = false, updatable = false, referencedColumnName="SUBORDER_IND")})
	public RxDispenseRequestDdo getRxDispenseRequest() {
		return this.rxDispenseRequest;
	}

	/**
	 * Sets the rx dispense request.
	 *
	 * @param rxDispenseRequest the new rx dispense request
	 */
	public void setRxDispenseRequest(RxDispenseRequestDdo rxDispenseRequest) {
		this.rxDispenseRequest = rxDispenseRequest;
	}

    /**
     * Gets the web service info.
     *
     * @return the web service info
     */
    @Column(name="WEB_SERVICE_INFO", unique=false, nullable=true, insertable=true, updatable=true, length=40)

    public String getWebServiceInfo() {
        return this.webServiceInfo;
    }
    
    /**
     * Sets the web service info.
     *
     * @param webServiceInfo the new web service info
     */
    public void setWebServiceInfo(String webServiceInfo) {
        this.webServiceInfo = webServiceInfo;
    }
    
    /**
     * Gets the status code.
     *
     * @return the status code
     */
    @Column(name="STATUS_CODE", unique=false, nullable=true, insertable=true, updatable=true, length=4)

    public String getStatusCode() {
        return this.statusCode;
    }
    
    /**
     * Sets the status code.
     *
     * @param statusCode the new status code
     */
    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
    
    /**
     * Gets the status msg.
     *
     * @return the status msg
     */
    @Column(name="STATUS_MSG", unique=false, nullable=true, insertable=true, updatable=true, length=80)

    public String getStatusMsg() {
        return this.statusMsg;
    }
    
    /**
     * Sets the status msg.
     *
     * @param statusMsg the new status msg
     */
    public void setStatusMsg(String statusMsg) {
        this.statusMsg = statusMsg;
    }
    
    /**
     * Gets the reason code.
     *
     * @return the reason code
     */
    @Column(name="REASON_CODE", unique=false, nullable=true, insertable=true, updatable=true, length=4)

    public String getReasonCode() {
        return this.reasonCode;
    }
    
    /**
     * Sets the reason code.
     *
     * @param reasonCode the new reason code
     */
    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode;
    }
    
    /**
     * Gets the reason msg.
     *
     * @return the reason msg
     */
    @Column(name="REASON_MSG", unique=false, nullable=true, insertable=true, updatable=true, length=80)

    public String getReasonMsg() {
        return this.reasonMsg;
    }
    
    /**
     * Sets the reason msg.
     *
     * @param reasonMsg the new reason msg
     */
    public void setReasonMsg(String reasonMsg) {
        this.reasonMsg = reasonMsg;
    }
    
    /**
     * Gets the msg type.
     *
     * @return the msg type
     */
    @Column(name="MSG_TYPE", unique=false, nullable=true, insertable=true, updatable=true, length=80)

    public String getMsgType() {
        return this.msgType;
    }
    
    /**
     * Sets the msg type.
     *
     * @param msgType the new msg type
     */
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

}
