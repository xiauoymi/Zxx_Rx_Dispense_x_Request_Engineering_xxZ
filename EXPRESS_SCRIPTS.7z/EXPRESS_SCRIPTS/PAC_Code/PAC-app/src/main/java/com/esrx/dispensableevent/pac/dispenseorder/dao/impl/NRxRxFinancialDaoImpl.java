package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.HibernateCallback;

import com.esrx.dispensableevent.nrxupdate.domain.NRxRxFinancial;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxFinancialId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxRxFinancialDao;
import com.esrx.dispensableevent.pac.dispenseorder.util.NRxDaoImplUtil;
import com.express_scripts.inf.dao.hibernate.GenericDaoHibernate;
import static com.esrx.dispensableevent.pac.dispenseorder.util.NRxDaoImplUtil.getDBdefaultSchema;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;


public class NRxRxFinancialDaoImpl extends GenericDaoHibernate<NRxRxFinancial>
		implements NRxRxFinancialDao {

	private static final Logger log = LoggerFactory
			.getLogger(NRxMclInfoDaoImpl.class);

	public NRxRxFinancialDaoImpl(SessionFactory sf) {
		super(NRxRxFinancial.class, sf);
	}

	public NRxRxFinancial getNRxRxFinancialInfoWithUR(
			NRxRxFinancialId nrxRxFinancialId) {
		StringBuilder  constructSQLWithUR = null;
		if (nrxRxFinancialId != null) {
			String dbDefaultSchema  = getDBdefaultSchema(getSessionFactory());
			constructSQLWithUR = new StringBuilder();
			constructSQLWithUR.append("SELECT * FROM ");
			constructSQLWithUR.append(dbDefaultSchema);
			constructSQLWithUR.append(".AUXRXS00");
			constructSQLWithUR.append(" WHERE ");
			constructSQLWithUR.append("ERX_PART_NBR=");
			constructSQLWithUR.append(nrxRxFinancialId.getErxPartNbr());
			constructSQLWithUR.append(" AND ");
			constructSQLWithUR.append("ERX_FILL_NO=");
			constructSQLWithUR.append(nrxRxFinancialId.getErxFillNo());
			constructSQLWithUR.append(" AND ");
			constructSQLWithUR.append("ERX_EXT_INVNO=");
			constructSQLWithUR.append(nrxRxFinancialId.getErxExtInvno());
			constructSQLWithUR.append(" AND ");
			constructSQLWithUR.append("ERX_LOCA_NO=");
			constructSQLWithUR.append(nrxRxFinancialId.getErxLocaNo());
			constructSQLWithUR.append(" AND ");
			constructSQLWithUR.append("ERX_EXT_RXNO=");
			constructSQLWithUR.append(nrxRxFinancialId.getErxExtRxno());
			constructSQLWithUR.append(" AND ");
			constructSQLWithUR.append("ERX_REFILL_NO=");
			constructSQLWithUR.append(nrxRxFinancialId.getErxRefillNo());
			constructSQLWithUR.append(" WITH UR");      			/*Isolation.READ_UNCOMMITTED   FOR DB2*/ 
		}
		
		final String nativeSQL = String.valueOf(constructSQLWithUR);

		return getHibernateTemplate().execute(
				new HibernateCallback<NRxRxFinancial>() {
					public NRxRxFinancial doInHibernate(Session session) {
						Query query = session.createSQLQuery(nativeSQL).addEntity(NRxRxFinancial.class);
						return (NRxRxFinancial) query.list().get(ZERO);
					}
				});	}
}
