package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.CATAMARAN_CONTROL_TABLE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.EMPTY_STRING;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.parseTable1Txt;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.validateNDISendStatus;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.validateNDISendStatusForPacRACFReject;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.validateNDISendStatusForPacReject;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.validateNDISendStatusForQueueDataReady;
import static com.esrx.dispensableevent.pac.dispenseorder.util.PacDispenseOrderMarshaller.requestMarshallToString;
import generated.Request;

import java.text.ParseException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceControl;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceId;
import com.esrx.dispensableevent.pac.dispenseorder.bo.PacDispenseOrderBo;
import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderStatusCode;
import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderSubStatusCode;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceControlDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.StatusInfoPacDao;
import com.esrx.dispensableevent.pac.dispenseorder.util.CatamaranControlInfoHelper;
import com.esrx.dispensableevent.rxdispense.domain.StatusInfoDdo;


public class PacDispenseOrderBoImpl implements PacDispenseOrderBo {

	private static final Logger log = LoggerFactory
			.getLogger(PacDispenseOrderBoImpl.class);

	private Long defaultTimeout = 30000L;
	private Long bufferTime = 100L;

	private NRxInvoiceDao nrxInvoiceDao;
	private NRxInvoiceControlDao nrxInvoiceControlDao;
	private PreparePacDataBoHelper preparePacDataBoHelper;
	
	private SendN153BoHelper sendN153BoHelper;
	private WorkTableOrderBoHelper workTableOrderBoHelper;
	
	private NRxInvoice nrxInvoiceDdo;
	
	
	/**
	 * @return the workTableOrderBoHelper
	 */
	public WorkTableOrderBoHelper getWorkTableOrderBoHelper() {
		return workTableOrderBoHelper;
	}

	/**
	 * @param workTableOrderBoHelper the workTableOrderBoHelper to set
	 */
	public void setWorkTableOrderBoHelper(
			WorkTableOrderBoHelper workTableOrderBoHelper) {
		this.workTableOrderBoHelper = workTableOrderBoHelper;
	}

	/**
	 * @return the preparePacDataBoHelper
	 */
	public PreparePacDataBoHelper getPreparePacDataBoHelper() {
		return preparePacDataBoHelper;
	}

	/**
	 * @param preparePacDataBoHelper the preparePacDataBoHelper to set
	 */
	public void setPreparePacDataBoHelper(
			PreparePacDataBoHelper preparePacDataBoHelper) {
		this.preparePacDataBoHelper = preparePacDataBoHelper;
	}



	/**
	 * @return the nrxInvoiceDao
	 */
	public NRxInvoiceDao getNrxInvoiceDao() {
		return nrxInvoiceDao;
	}

	/**
	 * @param nrxInvoiceDao
	 *            the nrxInvoiceDao to set
	 */
	public void setNrxInvoiceDao(NRxInvoiceDao nrxInvoiceDao) {
		this.nrxInvoiceDao = nrxInvoiceDao;
	}

	/**
	 * @return the nrxInvoiceControlDao
	 */
	public NRxInvoiceControlDao getNrxInvoiceControlDao() {
		return nrxInvoiceControlDao;
	}

	/**
	 * @param nrxInvoiceControlDao
	 *            the nrxInvoiceControlDao to set
	 */
	public void setNrxInvoiceControlDao(
			NRxInvoiceControlDao nrxInvoiceControlDao) {
		this.nrxInvoiceControlDao = nrxInvoiceControlDao;
	}


	/**
	 * @return the sendN153BoHelper
	 */
	public SendN153BoHelper getSendN153BoHelper() {
		return sendN153BoHelper;
	}

	/**
	 * @param sendN153BoHelper the sendN153BoHelper to set
	 */
	public void setSendN153BoHelper(SendN153BoHelper sendN153BoHelper) {
		this.sendN153BoHelper = sendN153BoHelper;
	}

	public void processNRxDispenseOrderList(
			RxDispenseOrderStatusCode statusCode,
			RxDispenseOrderSubStatusCode subStatusCode) {
		
		NRxInvoiceControl  nrxInvoiceControlDdo = null;
		CatamaranControlInfoHelper catamaranControlInfoHelper = null;
		
		if(statusCode != null && subStatusCode != null) {
				
				nrxInvoiceControlDdo = nrxInvoiceControlDao.getNRxInvoiceControlForClientTable(CATAMARAN_CONTROL_TABLE);
				
				catamaranControlInfoHelper = parseTable1Txt(nrxInvoiceControlDdo.getTable1Txt());
				
				List<StatusInfoDdo> statusInfoDdoList = workTableOrderBoHelper.getWorkTableORADBOrder(statusCode, subStatusCode);
				
					if(statusInfoDdoList != null) {
						for(StatusInfoDdo statusInfoDdo: statusInfoDdoList) {
							try { 
								NRxInvoiceId nrxInvoiceId = new NRxInvoiceId();

								//just commented for testing purpose
								
//								nrxInvoiceId.setNdiFillNo(Integer.valueOf(catamaranControlInfoHelper.getFillNo()));
//								nrxInvoiceId.setNdiInvno(statusInfoDdo.getRxDispenseRequestIdDdo().getOrderNum());
//								nrxInvoiceId.setNdiInvnoSub(statusInfoDdo.getRxDispenseRequestIdDdo().getSuborderInd()); ...
								
								nrxInvoiceId.setNdiFillNo(49);
								nrxInvoiceId.setNdiInvno(100511);
								nrxInvoiceId.setNdiInvnoSub(EMPTY_STRING);

								
								nrxInvoiceDdo = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
								
								if(nrxInvoiceDdo != null) {
									nrxInvoiceDdo.setId(nrxInvoiceId);
									boolean sendStatusFlag = validateNDISendStatus(nrxInvoiceDdo);
									if(sendStatusFlag) {
										boolean sendStatusPacRejectFlag = validateNDISendStatusForPacReject(nrxInvoiceDdo);
										if(sendStatusPacRejectFlag) {
											// send N153
											System.out.println(" send N153 ");
											sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
										} else {
											boolean sendStatusQueueDataReadyFlag = validateNDISendStatusForQueueDataReady(nrxInvoiceDdo);
											if(sendStatusQueueDataReadyFlag) {
												// send pac message
												Request pacRequestBdo = preparePacDataBoHelper.preparePacData(nrxInvoiceDdo,statusInfoDdo.getRxDispenseRequest(), catamaranControlInfoHelper);
												String pacXML = requestMarshallToString(pacRequestBdo);
												System.out.println("pacXML is : "+pacXML);
											} else {
												boolean sendStatusRACFRejectFlag = validateNDISendStatusForPacRACFReject(nrxInvoiceDdo);
												if(sendStatusRACFRejectFlag) {
													//send PAC message
													Request pacRequestBdo  = preparePacDataBoHelper.preparePacData(nrxInvoiceDdo,statusInfoDdo.getRxDispenseRequest(), catamaranControlInfoHelper);
													String pacXML = requestMarshallToString(pacRequestBdo);
													System.out.println("pacXML is : "+pacXML);
												} else {
													// send N153 on false
													sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
												}
											}
										}
									} else {
										// send N153 on false
										sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
									}
								} else {
									//send N153 on data not found
									sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
								}
							} catch (DataAccessException exception) {
								log.error("While processing processNRxDispenseOrderList DataAccessException thrown : ");
								log.info("DataAccessException Root Cause :", exception.getRootCause());
								//send N153 on data access error
								sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
							} catch (ParseException exception) {
								log.error("While processing processNRxDispenseOrderList ParseException thrown : ");
								log.info("ParseException Root Cause :", exception.getMessage());
								sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
							} catch(StringIndexOutOfBoundsException exception) { 
								log.error("StringIndexOutOfBoundsException thrown for  : ");
//								log.info("StringIndexOutOfBoundsException Ignored");
								sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
							} catch(JAXBException exception) { 
								log.error("JAXBException thrown for  : ");
								sendN153BoHelper.updateNRxInvoiceAdditionalNDPTmsStatusCde(nrxInvoiceDdo);
							}

						}
					}					
		}
	}
}
