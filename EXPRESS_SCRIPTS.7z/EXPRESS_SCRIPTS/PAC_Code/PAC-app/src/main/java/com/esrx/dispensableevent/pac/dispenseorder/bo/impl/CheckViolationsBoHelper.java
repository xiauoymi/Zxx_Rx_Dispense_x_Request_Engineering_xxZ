package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import generated.OrderRecord;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxRxInfoDao;

public class CheckViolationsBoHelper {

	private NRxRxInfoDao nrxRxInfoDao;
	
	
	/**
	 * @return the nrxRxInfoDao
	 */
	public NRxRxInfoDao getNrxRxInfoDao() {
		return nrxRxInfoDao;
	}


	/**
	 * @param nrxRxInfoDao the nrxRxInfoDao to set
	 */
	public void setNrxRxInfoDao(NRxRxInfoDao nrxRxInfoDao) {
		this.nrxRxInfoDao = nrxRxInfoDao;
	}


	public void CheckViolationsForPacData(OrderRecord orderRecordBdo, NRxInvoice nrxInvoiceDdo, List<NRxRxInfo> nrxRxInfoList) {
		if(orderRecordBdo != null) {
			if(orderRecordBdo.getNDPSobaRecords().size() > ZERO &&
			   orderRecordBdo.getNDPRxRecords().size() > ZERO &&
			   orderRecordBdo.getNDPManagedCareLetterList() != null && 
			   orderRecordBdo.getNDPManagedCareLetterList().getNDPManagedCareLetters().size() > ZERO) {
				if(nrxInvoiceDdo.getNoRxRecs() != orderRecordBdo.getNDPRxRecords().size()) {
					// send N153
				} else {
					if(nrxInvoiceDdo.getNoSobaMsgs() != orderRecordBdo.getNDPSobaRecords().size()) {
						// send N153
					} 
				}
			}else {
				//send N153
			}
			if(nrxInvoiceDdo != null && nrxRxInfoList != null) {
				for(NRxRxInfo nrxRxInfoDdo  : nrxRxInfoList) {
					nrxRxInfoDdo.getId().setNdxFillNo(nrxInvoiceDdo.getId().getNdiFillNo());
					nrxRxInfoDdo.getId().setNdxInvno(nrxInvoiceDdo.getId().getNdiInvno());	
					nrxRxInfoDdo.getId().setNdxInvnoSub(nrxInvoiceDdo.getId().getNdiInvnoSub());
					
					boolean nrxRxInfoCountExists = nrxRxInfoDao.getCountForNRxRxInfoViolation(nrxRxInfoDdo);
					if(nrxRxInfoCountExists) {
						//send N153
					} 
				}
			}
		} 
	}
}
