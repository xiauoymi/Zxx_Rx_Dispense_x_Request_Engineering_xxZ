package com.esrx.dispensableevent.pac.dispenseorder.validator;

import java.sql.Timestamp;
import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.pac.dispenseorder.util.CatamaranControlInfoHelper;
import com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_FALSE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.BOOLEAN_TRUE_FLAG;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.NDI_RECEIVE_ERROR_CODE;
import static com.esrx.dispensableevent.pac.dispenseorder.util.DateUtil.isAfterDate;
import static com.esrx.dispensableevent.pac.dispenseorder.util.DateUtil.getTimestampForString;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.getPacStatusCode;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.QUEUE_DATA_READY;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.RACF_REJECT;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.PAC_REJECT;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.RECEIVE_INPROCESS;

public class PacPreEditValidator {

	private static final Logger log = LoggerFactory
	.getLogger(PacPreEditValidator.class);

	public static CatamaranControlInfoHelper parseTable1Txt(String table1TxtOfNRxInvoiceControl) {
		CatamaranControlInfoHelper catamaranControlInfoHelper = null;
		
		if(table1TxtOfNRxInvoiceControl != null) {
			catamaranControlInfoHelper = new CatamaranControlInfoHelper();
			if(table1TxtOfNRxInvoiceControl.length() != ZERO) {
				try {
					catamaranControlInfoHelper.setFillNo(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(0, 2)));
					// will retained to maintain for future data 
//					catamaranControlInfoHelper.setLocaNo(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(2, 4)));
//					catamaranControlInfoHelper.setGroup(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(4, 7)));
//					catamaranControlInfoHelper.setSubGroup(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(7, 22)));
//					catamaranControlInfoHelper.setCarrier(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(22, 26)));
//					catamaranControlInfoHelper.setMemberNumber(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(26, 46)));
//					catamaranControlInfoHelper.setEligBnftGroup(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(46, 61)));
//					catamaranControlInfoHelper.setClntContNo(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(61, 69)));
//					catamaranControlInfoHelper.setDispPharm1(Integer.valueOf(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(69, 71))));
//					catamaranControlInfoHelper.setDispPharm2(Integer.valueOf(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(71, 73))));
//					catamaranControlInfoHelper.setDispPharm3(Integer.valueOf(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(73, 75))));
//					catamaranControlInfoHelper.setDispPharm4(Integer.valueOf(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(75, 77))));
//					catamaranControlInfoHelper.setDispPharm5(Integer.valueOf(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(77, 79))));
//					catamaranControlInfoHelper.setNonDispState01(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(79, 81)));
//					catamaranControlInfoHelper.setNonDispState02(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(81, 83)));
//					catamaranControlInfoHelper.setNonDispState03(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(83, 85)));
//					catamaranControlInfoHelper.setNonDispState04(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(85, 87)));
//					catamaranControlInfoHelper.setNonDispState05(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(87, 89)));
//					catamaranControlInfoHelper.setNonDispState06(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(89, 91)));
//					catamaranControlInfoHelper.setNonDispState07(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(91, 93)));
//					catamaranControlInfoHelper.setNonDispState08(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(93, 95)));
//					catamaranControlInfoHelper.setNonDispState09(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(95, 97)));
//					catamaranControlInfoHelper.setNonDispState10(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(97, 99)));
					catamaranControlInfoHelper.setBrandId(Integer.valueOf(String.valueOf(table1TxtOfNRxInvoiceControl.subSequence(99, 101))));					
				} catch(StringIndexOutOfBoundsException exception) {
					log.error("StringIndexOutOfBoundsException thrown for Table1Txt : ", table1TxtOfNRxInvoiceControl);
					log.info("StringIndexOutOfBoundsException Ignored");
				}
			}
		}
		return catamaranControlInfoHelper;
	}  

	public static boolean validateNDISendStatus(NRxInvoice nrxInvoiceDdo) {
		boolean sendStatusFlag = BOOLEAN_FALSE_FLAG;
		PacDispenseOrderStatusCode statusCode = null;

		if (nrxInvoiceDdo != null) {
			statusCode = getPacStatusCode(nrxInvoiceDdo
					.getSendStatus());

			if (statusCode != null) {
				switch (statusCode) {
				case QUEUE_DATA_READY:
					sendStatusFlag = BOOLEAN_FALSE_FLAG;
					break;
				case RECEIVE_INPROCESS:
					sendStatusFlag = BOOLEAN_FALSE_FLAG;
					break;
				case PAC_ACCEPTED:
					sendStatusFlag = BOOLEAN_FALSE_FLAG;
					break;
				case PAC_RECEIVED:
					sendStatusFlag = BOOLEAN_FALSE_FLAG;
					break;
				case PAC_REJECT:
					sendStatusFlag = BOOLEAN_FALSE_FLAG;
					break;
				case RACF_REJECT:
					sendStatusFlag = BOOLEAN_FALSE_FLAG;
					break;
				default:
					sendStatusFlag = BOOLEAN_TRUE_FLAG;
					break;
				}
			} else {
				sendStatusFlag = BOOLEAN_TRUE_FLAG;
			}
		}
		return sendStatusFlag;
	}
	
	public static boolean validateNDISendStatusForPacReject(
			NRxInvoice nrxInvoice) {
		boolean sendStatusFlag = BOOLEAN_FALSE_FLAG;

		if (nrxInvoice != null) {
			if ((nrxInvoice.getSendStatus() == getPacStatusCode(PAC_REJECT))
					&& (nrxInvoice.getRecvErrorCde() == NDI_RECEIVE_ERROR_CODE)) {
				sendStatusFlag = BOOLEAN_TRUE_FLAG;
			}
		}
		return sendStatusFlag;
	}


	public static boolean validateNDISendStatusForQueueDataReady(
			NRxInvoice nrxInvoice) throws ParseException {
		boolean sendStatusFlag = BOOLEAN_FALSE_FLAG;

		if (nrxInvoice != null) {
//			Timestamp respTimestamp = getTimestampForString(String.valueOf(nrxInvoice.getRespTmstmp()));
//			Timestamp sendTimestamp = getTimestampForString(String.valueOf(nrxInvoice.getSendTms()));

			Timestamp respTimestamp = new Timestamp(nrxInvoice.getRespTmstmp().getTime());
			Timestamp sendTimestamp = new Timestamp(nrxInvoice.getSendTms().getTime());

			boolean isAfterDateFlag = isAfterDate(respTimestamp,
					sendTimestamp);

			if ((nrxInvoice.getSendStatus() == getPacStatusCode(QUEUE_DATA_READY))
					&& isAfterDateFlag) {
				sendStatusFlag = BOOLEAN_TRUE_FLAG;
			}
		}
		return sendStatusFlag;
	}
	
	public static boolean validateNDISendStatusForPacRACFReject(
			NRxInvoice nrxInvoice) {
		boolean sendStatusFlag = BOOLEAN_FALSE_FLAG;

		PacDispenseOrderStatusCode statusCode = null;

		if (nrxInvoice != null) {
			statusCode = getPacStatusCode(nrxInvoice
					.getSendStatus());
			if (statusCode != null) {
				switch (statusCode) {
				case PAC_REJECT:
					sendStatusFlag = BOOLEAN_FALSE_FLAG;
					break;
				case RACF_REJECT:
					sendStatusFlag = BOOLEAN_FALSE_FLAG;
					break;
				default:
					sendStatusFlag = BOOLEAN_TRUE_FLAG;
					break;
				}
			} else {
				sendStatusFlag = BOOLEAN_TRUE_FLAG;
			}
		}
		return sendStatusFlag;
	}
}


