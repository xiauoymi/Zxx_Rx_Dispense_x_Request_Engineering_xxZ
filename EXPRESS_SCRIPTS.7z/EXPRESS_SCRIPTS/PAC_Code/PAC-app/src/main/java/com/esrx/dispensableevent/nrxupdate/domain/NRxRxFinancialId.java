package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NRxRxFinancialId implements Serializable{

	private static final long serialVersionUID = -6983284758484483548L;
	private Integer erxPartNbr;
	private Integer erxFillNo;
	private Integer erxExtInvno;
	private String erxInvnoSub;
	private Integer erxLocaNo;
	private Double erxExtRxno;
	private Integer erxRefillNo;
	
	// Default Constructor
	public NRxRxFinancialId() {
		
	}

	@Column(name = "ERX_PART_NBR")
	public Integer getErxPartNbr() {
		return erxPartNbr;
	}

	public void setErxPartNbr(Integer erxPartNbr) {
		this.erxPartNbr = erxPartNbr;
	}

	@Column(name = "ERX_FILL_NO")
	public Integer getErxFillNo() {
		return erxFillNo;
	}

	public void setErxFillNo(Integer erxFillNo) {
		this.erxFillNo = erxFillNo;
	}
	
	@Column(name = "ERX_EXT_INVNO")
	public Integer getErxExtInvno() {
		return erxExtInvno;
	}


	public void setErxExtInvno(Integer erxExtInvno) {
		this.erxExtInvno = erxExtInvno;
	}

	@Column(name = "ERX_INVNO_SUB")
	public String getErxInvnoSub() {
		return erxInvnoSub;
	}

	public void setErxInvnoSub(String erxInvnoSub) {
		this.erxInvnoSub = erxInvnoSub;
	}

	@Column(name = "ERX_LOCA_NO")
	public Integer getErxLocaNo() {
		return erxLocaNo;
	}

	public void setErxLocaNo(Integer erxLocaNo) {
		this.erxLocaNo = erxLocaNo;
	}

	@Column(name = "ERX_EXT_RXNO")
	public Double getErxExtRxno() {
		return erxExtRxno;
	}

	public void setErxExtRxno(Double erxExtRxno) {
		this.erxExtRxno = erxExtRxno;
	}

	@Column(name = "ERX_REFILL_NO")
	public Integer getErxRefillNo() {
		return erxRefillNo;
	}

	public void setErxRefillNo(Integer erxRefillNo) {
		this.erxRefillNo = erxRefillNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((erxExtInvno == null) ? 0 : erxExtInvno.hashCode());
		result = prime * result
				+ ((erxExtRxno == null) ? 0 : erxExtRxno.hashCode());
		result = prime * result
				+ ((erxFillNo == null) ? 0 : erxFillNo.hashCode());
		result = prime * result
				+ ((erxInvnoSub == null) ? 0 : erxInvnoSub.hashCode());
		result = prime * result
				+ ((erxLocaNo == null) ? 0 : erxLocaNo.hashCode());
		result = prime * result
				+ ((erxPartNbr == null) ? 0 : erxPartNbr.hashCode());
		result = prime * result
				+ ((erxRefillNo == null) ? 0 : erxRefillNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NRxRxFinancialId other = (NRxRxFinancialId) obj;
		if (erxExtInvno == null) {
			if (other.erxExtInvno != null)
				return false;
		} else if (!erxExtInvno.equals(other.erxExtInvno))
			return false;
		if (erxExtRxno == null) {
			if (other.erxExtRxno != null)
				return false;
		} else if (!erxExtRxno.equals(other.erxExtRxno))
			return false;
		if (erxFillNo == null) {
			if (other.erxFillNo != null)
				return false;
		} else if (!erxFillNo.equals(other.erxFillNo))
			return false;
		if (erxInvnoSub == null) {
			if (other.erxInvnoSub != null)
				return false;
		} else if (!erxInvnoSub.equals(other.erxInvnoSub))
			return false;
		if (erxLocaNo == null) {
			if (other.erxLocaNo != null)
				return false;
		} else if (!erxLocaNo.equals(other.erxLocaNo))
			return false;
		if (erxPartNbr == null) {
			if (other.erxPartNbr != null)
				return false;
		} else if (!erxPartNbr.equals(other.erxPartNbr))
			return false;
		if (erxRefillNo == null) {
			if (other.erxRefillNo != null)
				return false;
		} else if (!erxRefillNo.equals(other.erxRefillNo))
			return false;
		return true;
	}
}