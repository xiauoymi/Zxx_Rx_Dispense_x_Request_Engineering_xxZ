package com.esrx.dispensableevent.nrxupdate.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class NRxMclInfoId implements Serializable{
	
	private static final long serialVersionUID = 7305833779556438919L;
	private Integer ndmFillNo; 
	private Integer ndmInvno;
	private String ndmInvnoSub;
	private Integer ndmLocaNo;
	private Double ndmRxno;
	private Integer ndmLetterNo;
	private Integer ndmSeqNo;
	
	// Default Constructor
	public NRxMclInfoId() {
		
	}

	@Column(name = "NDM_FILL_NO")
	public int getNdmFillNo() {
		return ndmFillNo;
	}

	public void setNdmFillNo(int ndmFillNo) {
		this.ndmFillNo = ndmFillNo;
	}

	@Column(name = "NDM_INVNO")
	public int getNdmInvno() {
		return ndmInvno;
	}

	public void setNdmInvno(int ndmInvno) {
		this.ndmInvno = ndmInvno;
	}

	@Column(name = "NDM_INVNO_SUB")
	public String getNdmInvnoSub() {
		return ndmInvnoSub;
	}

	public void setNdmInvnoSub(String ndmInvnoSub) {
		this.ndmInvnoSub = ndmInvnoSub;
	}

	@Column(name = "NDM_LOCA_NO")
	public int getNdmLocaNo() {
		return ndmLocaNo;
	}

	public void setNdmLocaNo(int ndmLocaNo) {
		this.ndmLocaNo = ndmLocaNo;
	}

	@Column(name = "NDM_RXNO")
	public double getNdmRxno() {
		return ndmRxno;
	}

	public void setNdmRxno(double ndmRxno) {
		this.ndmRxno = ndmRxno;
	}

	@Column(name = "NDM_LETTER_NO")
	public Integer getNdmLetterNo() {
		return ndmLetterNo;
	}

	public void setNdmLetterNo(Integer ndmLetterNo) {
		this.ndmLetterNo = ndmLetterNo;
	}

	@Column(name = "NDM_SEQ_NO")
	public int getNdmSeqNo() {
		return ndmSeqNo;
	}

	public void setNdmSeqNo(int ndmSeqNo) {
		this.ndmSeqNo = ndmSeqNo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((ndmFillNo == null) ? 0 : ndmFillNo.hashCode());
		result = prime * result
				+ ((ndmInvno == null) ? 0 : ndmInvno.hashCode());
		result = prime * result
				+ ((ndmInvnoSub == null) ? 0 : ndmInvnoSub.hashCode());
		result = prime * result
				+ ((ndmLetterNo == null) ? 0 : ndmLetterNo.hashCode());
		result = prime * result
				+ ((ndmLocaNo == null) ? 0 : ndmLocaNo.hashCode());
		result = prime * result + ((ndmRxno == null) ? 0 : ndmRxno.hashCode());
		result = prime * result
				+ ((ndmSeqNo == null) ? 0 : ndmSeqNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NRxMclInfoId other = (NRxMclInfoId) obj;
		if (ndmFillNo == null) {
			if (other.ndmFillNo != null)
				return false;
		} else if (!ndmFillNo.equals(other.ndmFillNo))
			return false;
		if (ndmInvno == null) {
			if (other.ndmInvno != null)
				return false;
		} else if (!ndmInvno.equals(other.ndmInvno))
			return false;
		if (ndmInvnoSub == null) {
			if (other.ndmInvnoSub != null)
				return false;
		} else if (!ndmInvnoSub.equals(other.ndmInvnoSub))
			return false;
		if (ndmLetterNo == null) {
			if (other.ndmLetterNo != null)
				return false;
		} else if (!ndmLetterNo.equals(other.ndmLetterNo))
			return false;
		if (ndmLocaNo == null) {
			if (other.ndmLocaNo != null)
				return false;
		} else if (!ndmLocaNo.equals(other.ndmLocaNo))
			return false;
		if (ndmRxno == null) {
			if (other.ndmRxno != null)
				return false;
		} else if (!ndmRxno.equals(other.ndmRxno))
			return false;
		if (ndmSeqNo == null) {
			if (other.ndmSeqNo != null)
				return false;
		} else if (!ndmSeqNo.equals(other.ndmSeqNo))
			return false;
		return true;
	}
}