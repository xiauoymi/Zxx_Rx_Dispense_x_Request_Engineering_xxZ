package com.esrx.dispensableevent.pac.dispenseorder.ddo.mapping.jaxb;

import generated.NDPSobaRecord;

import java.util.List;

import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;

public class NDPSobaRecordMappingHelper {

	private List<NDPSobaRecord> ndpSobaRecordList;
	private List<NRxSobaInfo> nrxSobaRecordList;
	/**
	 * @return the ndpSobaRecordList
	 */
	public List<NDPSobaRecord> getNdpSobaRecordList() {
		return ndpSobaRecordList;
	}
	/**
	 * @param ndpSobaRecordList the ndpSobaRecordList to set
	 */
	public void setNdpSobaRecordList(List<NDPSobaRecord> ndpSobaRecordList) {
		this.ndpSobaRecordList = ndpSobaRecordList;
	}
	/**
	 * @return the nrxSobaRecordList
	 */
	public List<NRxSobaInfo> getNrxSobaRecordList() {
		return nrxSobaRecordList;
	}
	/**
	 * @param nrxSobaRecordList the nrxSobaRecordList to set
	 */
	public void setNrxSobaRecordList(List<NRxSobaInfo> nrxSobaRecordList) {
		this.nrxSobaRecordList = nrxSobaRecordList;
	}
	
	
}
