package com.esrx.dispensableevent.pac.dispenseorder.dao;

import com.esrx.dispensableevent.nrxupdate.domain.NRxDrugInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxDrugInfoId;

public interface NRxDrugInfoDao {

	NRxDrugInfo getNRxDrugInfo(NRxDrugInfoId nrxDrugInfoId);
	
	NRxDrugInfo getNRxDrugInfoWithUR(NRxDrugInfoId nrxDrugInfoId);
}
