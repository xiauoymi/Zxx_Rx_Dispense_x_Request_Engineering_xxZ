package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxMclInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxMclInfoDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class NRxMclInfoDaoImplTest {

	@Autowired
	NRxMclInfoDao nrxMclInfoDao;

	List<NRxMclInfo> managedCareLetterList = null;
	
	@Test
	public void testGetN006ManagedCareLetterRecordList() {
		
		final NRxMclInfoId nrxMclInfoId = new NRxMclInfoId();
		nrxMclInfoId.setNdmFillNo(49);
		nrxMclInfoId.setNdmInvno(533);
		nrxMclInfoId.setNdmInvnoSub("");
		nrxMclInfoId.setNdmLetterNo(new Integer(6902));
		nrxMclInfoId.setNdmLocaNo(49);
		nrxMclInfoId.setNdmRxno(826700006);
		nrxMclInfoId.setNdmSeqNo(1);
		
		managedCareLetterList = nrxMclInfoDao.getN006ManagedCareLetterRecordList(nrxMclInfoId);
		
		assertNotNull(managedCareLetterList);
		assertTrue(managedCareLetterList.size() > 0);
	}
	
	@Test
	public void testUpdateNDMSendTimeStamp() {
		final NRxMclInfoId nrxMclInfoId = new NRxMclInfoId();
		nrxMclInfoId.setNdmFillNo(49);
		nrxMclInfoId.setNdmInvno(533);
		nrxMclInfoId.setNdmInvnoSub("");
		nrxMclInfoId.setNdmLetterNo(new Integer(6902));
		nrxMclInfoId.setNdmLocaNo(49);
		nrxMclInfoId.setNdmRxno(826700006);
		nrxMclInfoId.setNdmSeqNo(1);

		final NRxMclInfo nrxMclInfo = new NRxMclInfo();
		nrxMclInfo.setId(nrxMclInfoId);
		nrxMclInfo.setSendTms(new Timestamp(new Date().getTime()));
		
		NRxMclInfo nrxMclInfoRetrieve = nrxMclInfoDao.getManagedCareLetterRecord(nrxMclInfoId);
		
		nrxMclInfoDao.updateNDMSendTimeStamp(nrxMclInfo);
		
		NRxMclInfo nrxMclInfoUpdate = nrxMclInfoDao.getManagedCareLetterRecord(nrxMclInfoId);
		
		System.out.println("nrxMclInfoRetrieve.getSendTms() is "+nrxMclInfoRetrieve.getSendTms());
		System.out.println("nrxMclInfoUpdate.getSendTms() is "+nrxMclInfoUpdate.getSendTms());
		
		assertNotSame(nrxMclInfoRetrieve.getSendTms(), nrxMclInfoUpdate.getSendTms());
	}
	
	@Test
	public void testGetManagedCareLetterOrderByLetterNum() {
		final NRxMclInfoId nrxMclInfoId = new NRxMclInfoId();
		nrxMclInfoId.setNdmFillNo(49);
		nrxMclInfoId.setNdmInvno(533);
		nrxMclInfoId.setNdmInvnoSub("");
		nrxMclInfoId.setNdmLetterNo(new Integer(6902));
		nrxMclInfoId.setNdmLocaNo(49);
		nrxMclInfoId.setNdmRxno(826700006);
		nrxMclInfoId.setNdmSeqNo(1);

		managedCareLetterList = nrxMclInfoDao.getManagedCareLetterOrderByLetterNum(nrxMclInfoId);
		
		assertNotNull(managedCareLetterList);
		assertTrue(managedCareLetterList.size() > 0);
	}

}
