package com.esrx.dispensableevent.pac.dispenseorder.util;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Test;

import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestIdDdo;
import static com.esrx.dispensableevent.pac.dispenseorder.util.RecordN150KeySplitter.getRxDispenseRequestId;

public class RecordN150KeySplitterTest {

	@Test
	public void testGetRxDispenseRequestId() {
		RxDispenseRequestIdDdo rxDispenseRequestIdDdo = getRxDispenseRequestId("160,MEDCO,103,1");
		assertNotNull(rxDispenseRequestIdDdo);
		System.out.println(rxDispenseRequestIdDdo.getTransId());
		System.out.println(rxDispenseRequestIdDdo.getClientId());
		System.out.println(rxDispenseRequestIdDdo.getOrderNum());
		System.out.println(rxDispenseRequestIdDdo.getSuborderInd());
		
//		rxDispenseRequestIdDdo.setTransId(new BigDecimal(tokensForN150[0]));
//		rxDispenseRequestIdDdo.setClientId(tokensForN150[1]);
//		rxDispenseRequestIdDdo.setOrderNum(Integer.valueOf(tokensForN150[2]));
//		rxDispenseRequestIdDdo.setSuborderInd(tokensForN150[3]);
//
//		rxDispenseRequestId.setTransId(new BigDecimal(160));
//		rxDispenseRequestId.setClientId("GLOBAL");
//		rxDispenseRequestId.setOrderNum(new Integer(103));
//		rxDispenseRequestId.setSuborderInd("1");

	}
}
