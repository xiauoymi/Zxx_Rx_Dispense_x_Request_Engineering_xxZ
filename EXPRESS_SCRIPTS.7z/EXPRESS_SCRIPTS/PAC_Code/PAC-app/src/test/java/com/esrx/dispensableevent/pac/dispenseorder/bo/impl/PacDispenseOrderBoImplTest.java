package com.esrx.dispensableevent.pac.dispenseorder.bo.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderStatusCode.ORDER_PROCESSED;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderSubStatusCode.SUB_STATUS_FOR_WORK_TABLE_TO_NRX;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class PacDispenseOrderBoImplTest {

	@Autowired
	PacDispenseOrderBoImpl pacDispenseOrderBoImpl;
	
	@Test
	public void testProcessNRxDispenseOrderList() {
		pacDispenseOrderBoImpl.processNRxDispenseOrderList(ORDER_PROCESSED, SUB_STATUS_FOR_WORK_TABLE_TO_NRX);
	}

}
