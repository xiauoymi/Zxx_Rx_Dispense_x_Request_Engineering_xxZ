package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxRxInfoDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class NRxRxInfoDaoImplTest {

	@Autowired
	NRxRxInfoDao nrxRxInfoDao;

	List<NRxRxInfo> prescriptionRecordList = null;

	@Test
	public void testGetN004PrescriptionRecordList() {
		final NRxRxInfoId nrxRxInfoId = new NRxRxInfoId();
		nrxRxInfoId.setNdxFillNo(99);
		nrxRxInfoId.setNdxInvno(1);
		nrxRxInfoId.setNdxInvnoSub("");
		nrxRxInfoId.setNdxLocaNo(99);
		nrxRxInfoId.setNdxRxno(4);

		prescriptionRecordList = nrxRxInfoDao.getN004PrescriptionRecordList(nrxRxInfoId);
		
		assertNotNull(prescriptionRecordList);
		assertTrue(prescriptionRecordList.size() > 0);
	}
	
	@Test
	public void testGetCountForNRxRxInfo() {
		final NRxRxInfoId nrxRxInfoId = new NRxRxInfoId();
		nrxRxInfoId.setNdxFillNo(1);
		nrxRxInfoId.setNdxInvno(40919065);
//		NRxRxInfo nrxRxInfoDdo = new NRxRxInfo();
//		nrxRxInfoDdo.setId(nrxRxInfoId);

		boolean nrxRxInfoCountExists = nrxRxInfoDao.getCountForPackagePACData(nrxRxInfoId);
		assertTrue(nrxRxInfoCountExists);
	}
	
	@Test
	public void testGetN004RxRecordList() {
		final NRxRxInfoId nrxRxInfoId = new NRxRxInfoId();
		nrxRxInfoId.setNdxFillNo(1);
		nrxRxInfoId.setNdxInvno(38836334);
		nrxRxInfoId.setNdxInvnoSub("A");

		prescriptionRecordList = nrxRxInfoDao.getN004RxRecordList(nrxRxInfoId) ;
		
		assertNotNull(prescriptionRecordList);
		assertTrue(prescriptionRecordList.size() > 0);
	}

	@Test
	public void testUpdateNDXNoMcLetters() {
		final NRxRxInfoId nrxRxInfoId = new NRxRxInfoId();
		nrxRxInfoId.setNdxFillNo(99);
		nrxRxInfoId.setNdxInvno(1);
		nrxRxInfoId.setNdxInvnoSub("");
		nrxRxInfoId.setNdxLocaNo(99);
		nrxRxInfoId.setNdxRxno(4);
		nrxRxInfoDao.updateNDXNoMcLetters(999, nrxRxInfoId);

		NRxRxInfo nrxRxInfo = nrxRxInfoDao.getNRxRxInfoRecord(nrxRxInfoId);
		
		assertNotNull(nrxRxInfo);
		assertEquals(999, nrxRxInfo.getNoMcLetters());
		assertNotSame(123, nrxRxInfo.getNoMcLetters());
	}
	
	@Test
	public void testGetCountForNRxRxInfoViolation() {
		final NRxRxInfoId nrxRxInfoId = new NRxRxInfoId();
		nrxRxInfoId.setNdxFillNo(99);
		nrxRxInfoId.setNdxInvno(1);
		nrxRxInfoId.setNdxInvnoSub("A");
		nrxRxInfoId.setNdxLocaNo(99);
		nrxRxInfoId.setNdxRxno(4);

		NRxRxInfo nrxRxInfoDdo = new NRxRxInfo();
		nrxRxInfoDdo.setRefillno(0);
		nrxRxInfoDdo.setId(nrxRxInfoId);
		
		boolean nrxRxInfoCountExists = nrxRxInfoDao.getCountForNRxRxInfoViolation(nrxRxInfoDdo);
		assertTrue(nrxRxInfoCountExists);
	}
	
	@Test
	public void testUpdateNDXSendTimeStamp() {
		final NRxRxInfoId nrxRxInfoId = new NRxRxInfoId();
		nrxRxInfoId.setNdxFillNo(99);
		nrxRxInfoId.setNdxInvno(1);
		nrxRxInfoId.setNdxInvnoSub("");
		nrxRxInfoId.setNdxLocaNo(99);
		nrxRxInfoId.setNdxRxno(4);

		final NRxRxInfo nrxRxInfoDdo = new NRxRxInfo();
		nrxRxInfoDdo.setSendTms(new Timestamp(new Date().getTime()));
		nrxRxInfoDdo.setId(nrxRxInfoId);

		NRxRxInfo nrxRxInfoRetrieve = nrxRxInfoDao.getNRxRxInfoRecord(nrxRxInfoId);
		
		nrxRxInfoDao.updateNDXSendTimeStamp(nrxRxInfoDdo);
		
		NRxRxInfo nrxRxInfoUpdate = nrxRxInfoDao.getNRxRxInfoRecord(nrxRxInfoId);

		System.out.println("nrxRxInfoRetrieve.getSendTms() is "+nrxRxInfoRetrieve.getSendTms());
		System.out.println("nrxRxInfoUpdate.getSendTms() is "+nrxRxInfoUpdate.getSendTms());
		
		assertNotSame(nrxRxInfoRetrieve.getSendTms(), nrxRxInfoUpdate.getSendTms());
	}

}
