package com.esrx.dispensableevent.pac.dispenseorder.util;

import java.text.ParseException;

import org.junit.Test;
import static com.esrx.dispensableevent.pac.dispenseorder.util.DateUtil.getDB2TimestampForString;

public class DB2DateStringToTimestampConverterTest {

	@Test
	public void testGetTimestampForString() throws ParseException {
		System.out.println(getDB2TimestampForString("10/7/2013"));
	}

}
