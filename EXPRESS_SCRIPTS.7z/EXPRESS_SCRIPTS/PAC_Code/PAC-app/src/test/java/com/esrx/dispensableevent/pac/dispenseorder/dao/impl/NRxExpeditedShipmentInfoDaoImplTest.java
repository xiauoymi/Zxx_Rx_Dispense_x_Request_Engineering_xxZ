package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxExpeditedShipmentInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxExpeditedShipmentInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxExpeditedShipmentInfoDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class NRxExpeditedShipmentInfoDaoImplTest {

	@Autowired
	NRxExpeditedShipmentInfoDao nrxExpeditedShipmentInfoDao; 

	@Test
	public void testGetNRxExpeditedShipmentInfo() {
		final NRxExpeditedShipmentInfoId nrxExpeditedShipmentInfoId = new NRxExpeditedShipmentInfoId(); 
		nrxExpeditedShipmentInfoId.setNrxqsiCustno("H1290");
		nrxExpeditedShipmentInfoId.setNrxqsiFillNo(90);
		nrxExpeditedShipmentInfoId.setNrxqsiInvno(2124513);
		
		NRxExpeditedShipmentInfo nrxExpeditedShipmentInfo = nrxExpeditedShipmentInfoDao.getNRxExpeditedShipmentInfo(nrxExpeditedShipmentInfoId);
		assertNotNull(nrxExpeditedShipmentInfo);
//		assertSame("TYPAPON", nrxExpeditedShipmentInfo.getNrxqsiUserId());
		assertEquals("TYPAPON", nrxExpeditedShipmentInfo.getNrxqsiUserId().trim());
	}

}
