package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderSubStatusCode;
import com.esrx.dispensableevent.pac.dispenseorder.dao.StatusInfoPacDao;
import com.esrx.dispensableevent.rxdispense.domain.StatusInfoDdo;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderStatusCode.ORDER_SYSTEM_ACKNOWLEDGED;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderSubStatusCode.SUB_STATUS_FOR_WORK_TABLE;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderSubStatusCode.SUB_STATUS_FOR_WORK_TABLE_TO_NRX;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.RxDispenseOrderStatusCode.ORDER_PROCESSED;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class StatusInfoDaoImplTest {

	@Autowired
	StatusInfoPacDao statusInfoPacDao;

	@Test
	public void testGetStatusInfoDdoList() {
		List<StatusInfoDdo> statusInfoDdoList = statusInfoPacDao.getStatusInfoDdoList(ORDER_PROCESSED, SUB_STATUS_FOR_WORK_TABLE_TO_NRX);
		assertTrue(statusInfoDdoList.size() > ZERO);
		for(StatusInfoDdo statusInfoDdo : statusInfoDdoList) {
			System.out.println(statusInfoDdo.getRxDispenseRequestIdDdo().getTransId());
		}
	}
} 
