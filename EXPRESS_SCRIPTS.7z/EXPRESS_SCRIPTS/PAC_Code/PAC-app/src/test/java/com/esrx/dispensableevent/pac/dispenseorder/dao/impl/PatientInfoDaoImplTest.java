package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.esrx.dispensableevent.pac.dispenseorder.dao.PatientInfoDao;
import com.esrx.dispensableevent.rxdispense.domain.PatientInfoDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestDdo;
import com.esrx.dispensableevent.rxdispense.domain.RxDispenseRequestIdDdo;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.ZERO;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class PatientInfoDaoImplTest {

	@Autowired
	PatientInfoDao patientInfoDao;

	@Test
	public void testGetPatientInfoDdoList() {
		final RxDispenseRequestIdDdo rxDispenseRequestId = new RxDispenseRequestIdDdo();
		rxDispenseRequestId.setTransId(new BigDecimal(160));
		rxDispenseRequestId.setClientId("MEDCO");
		rxDispenseRequestId.setOrderNum(new Integer(103));
		rxDispenseRequestId.setSuborderInd("1");

		RxDispenseRequestDdo rxDispenseRequestDdo = patientInfoDao.getPatientInfoDdoList(rxDispenseRequestId);

		assertNotNull(rxDispenseRequestDdo);
		assertTrue(rxDispenseRequestDdo.getPatientInfos().size() >  ZERO);
	}

}
