package com.esrx.dispensableevent.pac.dispenseorder.validator;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.text.ParseException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;

import static com.esrx.dispensableevent.pac.dispenseorder.validator.PackagePacDataValidator.validateNDIVersionNo;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PackagePacDataValidator.isNegative;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class PackagePacDataTest {

	@Autowired
	NRxInvoiceDao nrxInvoiceDao;

	
	@Test
	public void testIsNegative() {
		boolean ndiVersionNoFlag = isNegative(-1);
		assertTrue(ndiVersionNoFlag);
		ndiVersionNoFlag = isNegative(0);
		assertFalse(ndiVersionNoFlag);
		ndiVersionNoFlag = isNegative(1);
		assertFalse(ndiVersionNoFlag);
	}

	@Test
	public void testValidateNDIVersionNo() {
		NRxInvoice nrxInvoice = new NRxInvoice();
		nrxInvoice.setVerNo(99);

//		nrxInvoice = validateNDIVersionNo(false, nrxInvoice);
		validateNDIVersionNo(false, nrxInvoice);
		assertTrue(nrxInvoice.getVerNo() == 1);

		nrxInvoice.setVerNo(0);

//		nrxInvoice = validateNDIVersionNo(false, nrxInvoice);
		validateNDIVersionNo(false, nrxInvoice);
		assertTrue(nrxInvoice.getVerNo() == 1);

	}

	

}
