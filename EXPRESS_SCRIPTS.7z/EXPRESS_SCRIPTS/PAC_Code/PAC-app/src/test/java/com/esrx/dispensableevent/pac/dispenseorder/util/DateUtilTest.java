package com.esrx.dispensableevent.pac.dispenseorder.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.text.ParseException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;
import static com.esrx.dispensableevent.pac.dispenseorder.util.DateUtil.isAfterDate;
import static com.esrx.dispensableevent.pac.dispenseorder.util.DateUtil.getTimestampForString;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class DateUtilTest {
	
	@Autowired
	NRxInvoiceDao nrxInvoiceDao;

	@Test
	public void testIsAfterDate() {
		Timestamp timestamp1 = Timestamp.valueOf("2013-09-25 10:10:10");
		Timestamp timestamp2 = Timestamp.valueOf("2013-09-24 10:10:10");
		boolean isAfterDateFlag = isAfterDate(timestamp1, timestamp2);
		assertTrue(isAfterDateFlag);
	}
	
	@Test
	public void testGetN000OrderRecord() throws ParseException {
		final NRxInvoiceId nrxInvoiceId = new NRxInvoiceId();
		nrxInvoiceId.setNdiFillNo(new Integer(1));
		nrxInvoiceId.setNdiInvno(new Integer(36959297));
		nrxInvoiceId.setNdiInvnoSub("A");
		
		NRxInvoice nrxInvoice = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		
		Timestamp respTimestamp = getTimestampForString(String.valueOf(nrxInvoice.getRespTmstmp()));
		Timestamp sendTimestamp = getTimestampForString(String.valueOf(nrxInvoice.getSendTms()));

		boolean isAfterDateFlag = isAfterDate(respTimestamp, sendTimestamp);
		System.out.println("nrxInvoice.getRespTmstmp() is "+nrxInvoice.getRespTmstmp()); //23
		System.out.println("nrxInvoice.getSendTms() is  "+nrxInvoice.getSendTms());    //21

		assertFalse(isAfterDateFlag);
	}

	@Test
	public void testIsAfterDateForFail() {
		Timestamp timestamp1 = Timestamp.valueOf("2013-09-25 10:10:10");
		Timestamp timestamp2 = Timestamp.valueOf("2013-09-26 10:10:10");
		boolean isAfterDateFlag = isAfterDate(timestamp1, timestamp2);
		assertFalse(isAfterDateFlag);
	}

}
