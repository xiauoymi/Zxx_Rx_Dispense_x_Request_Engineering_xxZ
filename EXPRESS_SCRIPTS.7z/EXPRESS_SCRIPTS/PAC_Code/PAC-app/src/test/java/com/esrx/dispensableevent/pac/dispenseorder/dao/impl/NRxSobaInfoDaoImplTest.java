package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxSobaInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxSobaInfoDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class NRxSobaInfoDaoImplTest {

	@Autowired
	NRxSobaInfoDao nrxSobaInfoDao;

	List<NRxSobaInfo> sobaRecordList = null;

	@Test
	public void testGetN002SOBARecordList() {
		final NRxSobaInfoId nrxSobaInfoId = new NRxSobaInfoId();
		nrxSobaInfoId.setNdsFillNo(1);
		nrxSobaInfoId.setNdsInvno(37083370);
		nrxSobaInfoId.setNdsInvnoSub("A");
		nrxSobaInfoId.setNdsLocaNo(0);
		nrxSobaInfoId.setNdsRxno(0);
		nrxSobaInfoId.setNdsSeqNo(1);
		
		sobaRecordList = nrxSobaInfoDao.getN002SOBARecordListById(nrxSobaInfoId);
		
		assertNotNull(sobaRecordList);
		assertTrue(sobaRecordList.size() > 0);
	}
	
	@Test
	public void testGetSOBARecordList() {
		final NRxSobaInfoId nrxSobaInfoId = new NRxSobaInfoId();
		nrxSobaInfoId.setNdsFillNo(1);
		nrxSobaInfoId.setNdsInvno(39421335);
		nrxSobaInfoId.setNdsInvnoSub("");
		
		sobaRecordList = nrxSobaInfoDao.getSOBARecordList(nrxSobaInfoId);
		
		assertNotNull(sobaRecordList);
		System.out.println("SIZE IS :  "+sobaRecordList.size());
		assertTrue(sobaRecordList.size() > 0);

	}
	
	@Test
	public void testUpdateNDSTimeStamp() {
		final NRxSobaInfoId nrxSobaInfoId = new NRxSobaInfoId();
		nrxSobaInfoId.setNdsFillNo(1);
		nrxSobaInfoId.setNdsInvno(37083370);
		nrxSobaInfoId.setNdsInvnoSub("A");
		nrxSobaInfoId.setNdsLocaNo(0);
		nrxSobaInfoId.setNdsRxno(0);
		nrxSobaInfoId.setNdsSeqNo(1);
		
		final NRxSobaInfo nrxSobaInfo = new NRxSobaInfo();
		nrxSobaInfo.setId(nrxSobaInfoId);
		nrxSobaInfo.setMessCodeNo("H003");
		nrxSobaInfo.setSendTms(new Timestamp(new Date().getTime()));
		NRxSobaInfo nrxSobaInfoRetrieve  = nrxSobaInfoDao.getN002SOBARecord(nrxSobaInfoId);
		
		nrxSobaInfoDao.updateNDSTimeStamp(nrxSobaInfo);
		
		NRxSobaInfo nrxSobaInfoUpdate  = nrxSobaInfoDao.getN002SOBARecord(nrxSobaInfoId);
		
		assertNotSame(nrxSobaInfoRetrieve.getSendTms(), nrxSobaInfoUpdate.getSendTms());
	}
	
}
