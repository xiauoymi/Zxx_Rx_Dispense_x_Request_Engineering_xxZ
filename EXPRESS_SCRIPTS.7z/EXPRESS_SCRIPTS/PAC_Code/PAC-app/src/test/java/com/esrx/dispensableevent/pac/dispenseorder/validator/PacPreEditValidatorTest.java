package com.esrx.dispensableevent.pac.dispenseorder.validator;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.text.ParseException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceControl;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceControlDao;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;
import com.esrx.dispensableevent.pac.dispenseorder.util.CatamaranControlInfoHelper;
import static com.esrx.dispensableevent.pac.dispenseorder.util.DateUtil.getTimestampForString;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.validateNDISendStatusForPacRACFReject;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.parseTable1Txt;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.validateNDISendStatus;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.validateNDISendStatusForQueueDataReady;
import static com.esrx.dispensableevent.pac.dispenseorder.validator.PacPreEditValidator.validateNDISendStatusForPacReject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class PacPreEditValidatorTest {

	@Autowired
	NRxInvoiceDao nrxInvoiceDao;

	@Autowired
	NRxInvoiceControlDao nrxInvoiceControlDao;

	@Test
	public void testParseTable1Txt() {
		NRxInvoiceControl nrxInvoiceControl = nrxInvoiceControlDao.getNRxInvoiceControlForClientTable("COT");
		assertNotNull(nrxInvoiceControl);

		//		9090PD1LIBERTYRX      394009012006PL          LIBERTYRX      PONTIAC1                                                                                                                                   
		//		9090PD1LIBERTYRX      394009012006PL          LIBERTYRX      PONTIAC115                                                                                                                                 
		//		9090PD1LIBERTYRX      394009012006PL          LIBERTYRX      PONTIAC115                                                                                                                                 
		//		9090PD1LIBERTYRX      394009012006PL          LIBERTYRX      PONTIAC115        OR                                                                                                                       
		//		4949PD1LIBERTYCOGS    4366LIBERTYCOST         LIBERTYCOST    LBRYCOST15                                                                                                                                 
		//		9090PD1LIBERTYRX      394009012006PL          LIBERTYRX      PONTIAC115                                                                                                                                 
		//		4949PD1LIBERTYCOGS    4366LIBERTYCOST         LIBERTYCOST    LBRYCOST15 		

		System.out.println("Table1Txt : "+String.valueOf(nrxInvoiceControl.getTable1Txt()));	
		CatamaranControlInfoHelper catamaranControlInfoHelper = parseTable1Txt(String.valueOf(nrxInvoiceControl.getTable1Txt()));
		assertNotNull(catamaranControlInfoHelper);
		System.out.println("BRAND ID : "+catamaranControlInfoHelper.getBrandId());
		System.out.println(catamaranControlInfoHelper.getCarrier());
		System.out.println(catamaranControlInfoHelper.getClntContNo());
		System.out.println(catamaranControlInfoHelper.getDispPharm1());
		System.out.println(catamaranControlInfoHelper.getDispPharm2());
		System.out.println(catamaranControlInfoHelper.getDispPharm3());
		System.out.println(catamaranControlInfoHelper.getDispPharm4());
		System.out.println(catamaranControlInfoHelper.getDispPharm5());
		System.out.println(catamaranControlInfoHelper.getEligBnftGroup());
		System.out.println("FillNo : "+catamaranControlInfoHelper.getFillNo());
		System.out.println(catamaranControlInfoHelper.getGroup());
		System.out.println(catamaranControlInfoHelper.getLocaNo());
		System.out.println(catamaranControlInfoHelper.getMemberNumber());
		System.out.println(catamaranControlInfoHelper.getNonDispState01());
		System.out.println(catamaranControlInfoHelper.getNonDispState02());
		System.out.println(catamaranControlInfoHelper.getNonDispState03());
		System.out.println(catamaranControlInfoHelper.getNonDispState04());
		System.out.println(catamaranControlInfoHelper.getNonDispState05());
		System.out.println(catamaranControlInfoHelper.getNonDispState06());
		System.out.println(catamaranControlInfoHelper.getNonDispState07());
		System.out.println(catamaranControlInfoHelper.getNonDispState08());
		System.out.println(catamaranControlInfoHelper.getNonDispState09());
		System.out.println(catamaranControlInfoHelper.getNonDispState10());
		System.out.println(catamaranControlInfoHelper.getSubGroup());
/*		
		FILLNO         002 A
		LOCANO      002 A
		GROUP         003 A
		SUBGROUP 015 A
		CARRIER 004 A
		MEMBER-NUMBER 020 A
		ELIG-BNFT-GROUP 015 A
		CLNT-CONT-NO 008 A
		DISP-PHARM1 002 N
		DISP-PHARM2 002 N
		DISP-PHARM3 002 N 
		DISP-PHARM4 002 N 
		DISP-PHARM5 002 N 
		NON-DISP-STATE-01 002 A 
		NON-DISP-STATE-02 002 A 
		NON-DISP-STATE-03 002 A 
		NON-DISP-STATE-04 002 A 
		NON-DISP-STATE-05 002 A 
		NON-DISP-STATE-06 002 A 
		NON-DISP-STATE-07 002 A 
		NON-DISP-STATE-08 002 A
		NON-DISP-STATE-09 002 A
		NON-DISP-STATE-10 002 A
		BRAND-ID                002 N
*/
	}

	@Test
	public void testValidateNDISendStatus() {
		NRxInvoice nrxInvoice = new NRxInvoice();
		nrxInvoice.setSendStatus(4);
		assertFalse(validateNDISendStatus(nrxInvoice));
		nrxInvoice.setSendStatus(5);
		assertFalse(validateNDISendStatus(nrxInvoice));
		nrxInvoice.setSendStatus(14);
		assertFalse(validateNDISendStatus(nrxInvoice));
		nrxInvoice.setSendStatus(12);
		assertFalse(validateNDISendStatus(nrxInvoice));
		nrxInvoice.setSendStatus(7);
		assertFalse(validateNDISendStatus(nrxInvoice));
		nrxInvoice.setSendStatus(13);
		assertFalse(validateNDISendStatus(nrxInvoice));
//		QUEUE_DATA_READY(4),			
//		RECEIVE_INPROCESS(5),
//		PAC_ACCEPTED(14),
//		PAC_RECEIVED(12), 
//		PAC_REJECT(7),
//		RACF_REJECT(13), 

		nrxInvoice.setSendStatus(1);
		assertTrue(validateNDISendStatus(nrxInvoice));
		
		nrxInvoice.setSendStatus(111);
		assertTrue(validateNDISendStatus(nrxInvoice));
	}

	@Test
	public void testValidateNDISendStatusForPacReject() {
		NRxInvoice nrxInvoice = new NRxInvoice();
		nrxInvoice.setSendStatus(7);
		nrxInvoice.setRecvErrorCde(80);
		boolean sendStatusForPacRejectFlag =  validateNDISendStatusForPacReject(nrxInvoice);
		assertTrue(sendStatusForPacRejectFlag);
		
		nrxInvoice.setSendStatus(77);
		nrxInvoice.setRecvErrorCde(800);
		sendStatusForPacRejectFlag =  validateNDISendStatusForPacReject(nrxInvoice);
		assertFalse(sendStatusForPacRejectFlag);
	}

	@Test
	public void testValidateNDISendStatusForQueueDataReady() throws ParseException {
		final NRxInvoiceId nrxInvoiceId = new NRxInvoiceId();
		nrxInvoiceId.setNdiFillNo(new Integer(1));
		nrxInvoiceId.setNdiInvno(new Integer(36959297));
		nrxInvoiceId.setNdiInvnoSub("A");
		
		NRxInvoice nrxInvoice = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		
		Timestamp respTimestamp = getTimestampForString(String.valueOf(nrxInvoice.getRespTmstmp()));
		Timestamp sendTimestamp = getTimestampForString(String.valueOf(nrxInvoice.getSendTms()));
		System.out.println("respTimestamp "+respTimestamp);
		System.out.println("sendTimestamp "+sendTimestamp);

		
//		boolean isAfterDateFlag = isAfterDate(respTimestamp, sendTimestamp);
//		assertTrue(isAfterDateFlag);
//		System.out.println("nrxInvoice.getRespTmstmp() is "+nrxInvoice.getRespTmstmp()); //23
//		System.out.println("nrxInvoice.getSendTms() is  "+nrxInvoice.getSendTms());    //21

		boolean sendStatusForQueueDataReady =  validateNDISendStatusForQueueDataReady(nrxInvoice);
		System.out.println("sendStatusForQueueDataReady is "+sendStatusForQueueDataReady);
		System.out.println("nrxInvoice.getSendStatus() is : "+nrxInvoice.getSendStatus());
		assertFalse(sendStatusForQueueDataReady);
	}
	
	@Test
	public void testValidateNDISendStatusForPacRACFReject() {
		NRxInvoice nrxInvoice = new NRxInvoice();
		nrxInvoice.setSendStatus(7);
		assertFalse(validateNDISendStatusForPacRACFReject(nrxInvoice));
		nrxInvoice.setSendStatus(13);
		assertFalse(validateNDISendStatusForPacRACFReject(nrxInvoice));
//		PAC_REJECT(7),
//		RACF_REJECT(13), 

		nrxInvoice.setSendStatus(1);
		assertTrue(validateNDISendStatusForPacRACFReject(nrxInvoice));
		
		nrxInvoice.setSendStatus(111);
		assertTrue(validateNDISendStatusForPacRACFReject(nrxInvoice));
	}	

}
