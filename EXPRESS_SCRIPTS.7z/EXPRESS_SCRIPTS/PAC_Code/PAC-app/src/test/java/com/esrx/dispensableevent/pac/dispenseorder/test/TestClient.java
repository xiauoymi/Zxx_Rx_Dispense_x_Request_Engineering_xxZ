package com.esrx.dispensableevent.pac.dispenseorder.test;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding;

import org.apache.commons.codec.binary.Base64;

public class TestClient {
	private Service service;
    private static final String url = "http://fl1dr014892:8080/extord/";    		
    private static final QName qname = new QName("", "");
    
    @SuppressWarnings("unused")
    private static final String endPoint1 = "dispenseRx";
    @SuppressWarnings("unused")
	private static final String endPoint2 = "status";
    @SuppressWarnings("unused")
   	private static final String endPoint3 = "cancel";
    
    //N0001400020676216 010000000009040000000000000000ISABELLA            SCOTT               400 PARSONS POND DR                               FRANKLIN LAKES           NJ07417260120126934000000000000201306272365289             PD1DODA           00+00000.00+00000.00+00000.00+00000.00+00000.007700NY20130709000000000 YNCURASCRIPT, INC. / TEMPE                PO BOX 52150                            PHOENIX AZ 85072                        Express Scripts                         1620 Century Center Pkwy                Memphis TN 38134                        CURASCRIPT, INC. / TEMPE                PO BOX 52150                            PHOENIX AZ 85072-9643                   188773631303877363130300000RDN00000000000000N          Plan Amount      N        0 www.express-scripts.com                           0008773631303    2013-06-272013-06-24+00000.00+00000.001+00000.00  000001-00036.00-00030.00-00053.00+00013.00 1969123120130708 00 0001N00NN                                        0       RNASDAS               400 PARSONS POND DR                               FRANKLIN LAKES           NJ0741726010000000000          +00100.00  XXXXX299                                                  95ISABELLA            SCOTT                                               01          N           1969123198I                                                                                                     N0030057Unknown   2013-08-12                    +00000.00N0041157181317800035ISABELLA            SCOTT               LANG                2908100000N0000100000000000020130812+00000.00+00013.00+00013.00Y201406202013062703000TAKE 1 TABLET DAILY                                                                                                                                                                                                                                       006580102   00   00   00   00   00   00                    37100E+000000.00  00001NN                                   ROBERTO                             5841 S MARYLAND AVEMCHICAGO             IL6063700007737021842                         201306270000000000000000                                                                   00 033         200712200000000000                                        79999                         +00000.00                              +00000.00                              +00000.00                              +00000.00                              +00000.00M131780003518   001GLEE              0299Y                                                                                                    N006002813178000350000916001N008012113178000350000916001<#MCPLTRNO=9160>                                                                                 
    
    @SuppressWarnings("unused")
    private static final String testXML1 = 
    		"<Request>\r\n" + 
    		"  <TestMode>N</TestMode>\r\n" + 
     		"  <OrderRecord>\r\n" + 
    		"    <InvoiceNumber>023676310</InvoiceNumber>\r\n" + 
    		"    <InvoiceSub>C</InvoiceSub>\r\n" + 
    		"    <AdminCode>AdminCode1</AdminCode>\r\n" + 
    		"    <NoRxRecs>1</NoRxRecs>\r\n" + 
    		"    <EnclosureNo>000000000904000000000000000</EnclosureNo>\r\n" + 
    		"    <DivertNo>0</DivertNo>\r\n" + 
    		"    <LabelNameFst>ISABELLA</LabelNameFst>\r\n" + 
    		"    <LabelNameLst>SCOTT</LabelNameLst>\r\n" + 
    		"    <MemAddLn1>400 PARSONS POND DR</MemAddLn1>\r\n" + 
    		"    <MemAddLn2></MemAddLn2>\r\n" + 
     		"    <MemCity>FRANKLIN LAKES</MemCity>\r\n" + 
    		"    <MemState>NJ</MemState>\r\n" + 
    		"    <MemZip5>07417</MemZip5>\r\n" + 
    		"    <MemZip4>2601</MemZip4>\r\n" + 
    		"    <MemDayPhone>2012693400</MemDayPhone>\r\n" + 
    		"    <MemEvePhone></MemEvePhone>\r\n" + 
    		"    <OrderDate>20130627</OrderDate>\r\n" + 
    		"    <MemberId>2365289</MemberId>\r\n" + 
    		"    <Group>PD1</Group>\r\n" + 
    		"    <Subgroup>DODA</Subgroup>\r\n" + 
    		"    <NoSobaMsgs>3</NoSobaMsgs>\r\n" + 
    		"    <NewCharges></NewCharges>\r\n" + 
    		"    <Tax>0</Tax>\r\n" + 
    		"    <DelService>7</DelService>\r\n" + 
    		"    <ClassServ>70</ClassServ>\r\n" + 
    		"    <LanguageFlag></LanguageFlag>\r\n" + 
    		"    <RushOrderFlag>N</RushOrderFlag>\r\n" + 
    		"    <GuarDelFlag>Y</GuarDelFlag>\r\n" + 
    		"    <GuarDelDate>20130709</GuarDelDate>\r\n" + 
    		"    <OrigInvno></OrigInvno>\r\n" + 
    		"    <OrigInvnoSub></OrigInvnoSub>\r\n" +
    		"    <SafetyCap>Y</SafetyCap>\r\n" +
    		"    <ModifyFlag>N</ModifyFlag>\r\n" + 
    		"    <InvPharmName>CURASCRIPT, INC. / TEMPE</InvPharmName>\r\n" + 
    		"    <InvPharmAdd1>PO BOX 52150</InvPharmAdd1>\r\n" + 
    		"    <InvPharmAdd2>PHOENIX AZ 85072</InvPharmAdd2>\r\n" + 
    		"    <RemitPharmName>Express Scripts</RemitPharmName>\r\n" + 
    		"    <RemitPharmAdd1>1620 Century Center Pkwy</RemitPharmAdd1>\r\n" + 
    		"    <RemitPharmAdd2>Memphis TN 38134</RemitPharmAdd2>\r\n" + 
    		"    <OrderPharmName>CURASCRIPT, INC. / TEMPE</OrderPharmName>\r\n" + 
    		"    <OrderPharmAdd1>PO BOX 52150</OrderPharmAdd1>\r\n" + 
    		"    <OrderPharmAdd2>PHOENIX AZ 85072-9643</OrderPharmAdd2>\r\n" + 
    		"    <PharmLocaNo>18</PharmLocaNo>\r\n" + 
    		"    <PharmacyPhone>8773631303</PharmacyPhone>\r\n" + 
    		"    <CustServPhone>8773631303</CustServPhone>\r\n" + 
    		"    <BusReplyPermit></BusReplyPermit>\r\n" + 
    		"    <CommResInd>R</CommResInd>\r\n" + 
    		"    <DomInterInd>D</DomInterInd>\r\n" + 
    		"    <QaFlag>N</QaFlag>\r\n" + 
    		"    <QaCodeList>\r\n" +
    		"       <QaCode>0000</QaCode>\r\n" + 
       		"    </QaCodeList>\r\n" + 
    		"    <RateShopInd>0</RateShopInd>\r\n" + 
    		"    <PackRelNumber></PackRelNumber>\r\n" + 
    		"    <ReplFlag>N</ReplFlag>\r\n" + 
    		"    <ClientAmount></ClientAmount>\r\n" + 
    		"    <ClientAmtDsc>Plan Amount</ClientAmtDsc>\r\n" + 
    		"    <UnionBug_ind>N</UnionBug_ind>\r\n" + 
    		"    <ClientLogo></ClientLogo>\r\n" + 
    		"    <InternetInd></InternetInd>\r\n" + 
    		"    <NetCommInd></NetCommInd>\r\n" + 
    		"    <ClientNetAddr>www.express-scripts.com</ClientNetAddr>\r\n" + 
    		"    <VerbCode></VerbCode>\r\n" + 
    		"    <Opt800Nbr>8773631303</Opt800Nbr>\r\n" + 
    		"    <AcctSummDate>2013-06-27</AcctSummDate>\r\n" + 
    		"    <AcctBalDate>2013-06-24</AcctBalDate>\r\n" + 
    		"    <OthPkgAmount>.29</OthPkgAmount>\r\n" + 
    		"    <ShipChgAmount>.31</ShipChgAmount>\r\n" + 
    		"    <AcctSummFormat>1</AcctSummFormat>\r\n" + 
    		"    <CcChgAmount>0</CcChgAmount>\r\n" + 
    		"    <AutoChgInd></AutoChgInd>\r\n" + 
    		"    <CcTypeCode></CcTypeCode>\r\n" + 
    		"    <CcLast4Digit></CcLast4Digit>\r\n" + 
    		"    <PaymentRecCount>1</PaymentRecCount>\r\n" + 
    		"    <OrdrPriorBal>-36.00</OrdrPriorBal>\r\n" + 
    		"    <OrdrPayRecv>-30.00</OrdrPayRecv>\r\n" + 
    		"    <OrdrNewBal>-53.00</OrdrNewBal>\r\n" + 
    		"    <OrdrNewChrgs>13.00</OrdrNewChrgs>\r\n" + 
    		"    <TargetDate>20130708</TargetDate>\r\n" + 
    		"    <Apdata> 0001N00NN</Apdata>\r\n" + 
    		"    <QaOrderMode></QaOrderMode>\r\n" + 
    		"    <RetailPharmNum></RetailPharmNum>\r\n" + 
    		"    <AddressType>R</AddressType>\r\n" + 
    		"    <RefrigFlag>N</RefrigFlag>\r\n" + 
    		"    <AltShippingName>ASDAS</AltShippingName>\r\n" + 
    		"    <AltShippingAddLn1>400 PARSONS POND DR</AltShippingAddLn1>\r\n" + 
    		"    <AltShippingAddLn2></AltShippingAddLn2>\r\n" + 
    		"    <AltShippingCity>FRANKLIN LAKES</AltShippingCity>\r\n" + 
    		"    <AltShippingState>NJ</AltShippingState>\r\n" + 
    		"    <AltShippingZip5>07417</AltShippingZip5>\r\n" + 
    		"    <AltShippingZip4>2601</AltShippingZip4>\r\n" + 
    		"    <AltShippingPhoneNum></AltShippingPhoneNum>\r\n" + 
    		"    <GroupShippingId></GroupShippingId>\r\n" + 
    		"    <DeclaredValue>100.00</DeclaredValue>\r\n" + 
    		"    <OrgRxSrce>XXXXX</OrgRxSrce>\r\n" + 
    		"    <SvcBranchId>299</SvcBranchId>\r\n" + 
    		"    <DispNo>19</DispNo>\r\n" + 
    		"    <MemNameFst>ISABELLA</MemNameFst>\r\n" + 
    		"    <MemNameLst>SCOTT</MemNameLst>\r\n" + 
    		"    <WrkOrdrId></WrkOrdrId>\r\n" + 
    		"	 <DispPharmList>\r\n" +
    	    "      <DispPharmNo>26</DispPharmNo>\r\n" +
    	    "      <DispPharmNo>15</DispPharmNo>\r\n" +
    	    "      <DispPharmNo>03</DispPharmNo>\r\n" +
    	    "	 </DispPharmList>\r\n" +
    		"    <MedicareFlag>N</MedicareFlag>\r\n" + 
    		"    <QsiOptions></QsiOptions>\r\n" + 
    		"    <CstScrubFlag></CstScrubFlag>\r\n" + 
    		"    <QsiDelivDate>19691231</QsiDelivDate>\r\n" + 
    		"    <Brandid>98</Brandid>\r\n" + 
    		"    <CleanInterv>Y</CleanInterv>\r\n" + 
    		"    <EastWestFlag>M</EastWestFlag>\r\n" + 
    		"    <QsiDelivInstr></QsiDelivInstr>\r\n" + 
    		"    <PageCount>1</PageCount>\r\n" + 
    		"    <NDPSobaRecord>\r\n" + 
    		"      <RxNum>RxNum1</RxNum>\r\n" + 
    		"      <MessCodeNo>MessCodeNo1</MessCodeNo>\r\n" + 
    		"      <MessText>MessText1</MessText>\r\n" + 
    		"    </NDPSobaRecord>\r\n" + 
    		"    <NDPSobaRecord>\r\n" + 
    		"      <RxNum>Rxno2</RxNum>\r\n" + 
    		"      <MessCodeNo>MessCodeNo2</MessCodeNo>\r\n" + 
    		"      <MessText>MessText2</MessText>\r\n" + 
    		"    </NDPSobaRecord>\r\n" + 
    		"    <NDPSobaRecord>\r\n" + 
    		"      <RxNum>Rxno3</RxNum>\r\n" + 
    		"      <MessCodeNo>MessCodeNo3</MessCodeNo>\r\n" + 
    		"      <MessText>MessText3</MessText>\r\n" + 
    		"    </NDPSobaRecord>\r\n" + 
    		"    <NDPPaymentRecord>\r\n" + 
    		"      <TypeDesc>TypeDesc1</TypeDesc>\r\n" + 
    		"      <DatePosted>DatePosted1</DatePosted>\r\n" + 
    		"      <RefInfo>RefInfo1</RefInfo>\r\n" + 
    		"      <Amount>1</Amount>\r\n" + 
    		"    </NDPPaymentRecord>\r\n" + 
    		"    <NDPPaymentRecord>\r\n" + 
    		"      <TypeDesc>TypeDesc2</TypeDesc>\r\n" + 
    		"      <DatePosted>DatePosted2</DatePosted>\r\n" + 
    		"      <RefInfo>RefInfo2</RefInfo>\r\n" + 
    		"      <Amount>2</Amount>\r\n" + 
    		"    </NDPPaymentRecord>\r\n" + 
    		"    <NDPPaymentRecord>\r\n" + 
    		"      <TypeDesc>TypeDesc3</TypeDesc>\r\n" + 
    		"      <DatePosted>DatePosted3</DatePosted>\r\n" + 
    		"      <RefInfo>RefInfo3</RefInfo>\r\n" + 
    		"      <Amount>3</Amount>\r\n" + 
    		"    </NDPPaymentRecord>\r\n" + 
    		"    <NDPRxRecord>\r\n" + 
    		"      <RxLocaNo>70</RxLocaNo>\r\n" + 
    		"      <RxNum>1290198333</RxNum>\r\n" + 
    		"      <PatNameFst>PatNameFst1</PatNameFst>\r\n" + 
    		"      <PatNameLst>PatNameLst1</PatNameLst>\r\n" + 
    		"      <MdNameFst>MdNameFst1</MdNameFst>\r\n" + 
    		"      <MdNameLst>MdNameLst1</MdNameLst>\r\n" + 
    		"      <DrugNum>1</DrugNum>\r\n" + 
    		"      <NpDrugNum>1</NpDrugNum>\r\n" + 
    		"      <CompoundFlag>CompoundFlag1</CompoundFlag>\r\n" + 
    		"      <Quantity>1</Quantity>\r\n" + 
    		"      <DateOfServ>DateOfServ1</DateOfServ>\r\n" + 
    		"      <Price>21</Price>\r\n" + 
    		"      <Copay>1</Copay>\r\n" + 
    		"      <PatPayAmount>1</PatPayAmount>\r\n" + 
    		"      <SafetyCap>SafetyCap1</SafetyCap>\r\n" + 
    		"      <RefilBefDt>RefilBefDt1</RefilBefDt>\r\n" + 
    		"      <RefilAftDt>RefilAftDt1</RefilAftDt>\r\n" + 
    		"      <ActRefills>1</ActRefills>\r\n" + 
    		"      <RefillNumber>1</RefillNumber>\r\n" + 
    		"      <RenewalFlag>RenewalFlag1</RenewalFlag>\r\n" + 
    		"      <Directions1>Directions11</Directions1>\r\n" + 
    		"      <Directions2>Directions21</Directions2>\r\n" + 
    		"      <Directions3>Directions31</Directions3>\r\n" + 
    		"      <Directions4>Directions41</Directions4>\r\n" + 
    		"      <Directions5>Directions51</Directions5>\r\n" + 
    		"      <DrugInsertno>1</DrugInsertno>\r\n" + 
    		"      <NoMcl>1</NoMcl>\r\n" + 
    		"      <DrugInsertnoPgs>1</DrugInsertnoPgs>\r\n" + 
    		"      <MandPpi>MandPpi1</MandPpi>\r\n" + 
    		"      <MandPpiPgs>1</MandPpiPgs>\r\n" + 
    		"      <ClientAmtDsc>ClientAmtDsc1</ClientAmtDsc>\r\n" + 
    		"      <BarcodeFormat>BarcodeFormat1</BarcodeFormat>\r\n" + 
    		"      <BarcodeCheckDigit>BarcodeCheckDigit1</BarcodeCheckDigit>\r\n" + 
    		"      <RenewalCode>RenewalCode1</RenewalCode>\r\n" + 
    		"      <EastWestFlag></EastWestFlag>\r\n" + 
    		"      <Apdata>Apdata1</Apdata>\r\n" + 
    		"      <MdAdd>MdAdd1</MdAdd>\r\n" + 
    		"      <MdCity>MdCity1</MdCity>\r\n" + 
    		"      <MdState>MdState1</MdState>\r\n" + 
    		"      <MdZip>MdZip1</MdZip>\r\n" + 
    		"      <MdPhoneNum>MdPhoneNum1</MdPhoneNum>\r\n" + 
    		"      <DateWritten>DateWritten1</DateWritten>\r\n" + 
    		"      <CompName>CompName1</CompName>\r\n" + 
    		"      <RefillsRemaining>1</RefillsRemaining>\r\n" + 
    		"      <BotMsgCd>1</BotMsgCd>\r\n" + 
    		"      <PatDob>PatDob1</PatDob>\r\n" + 
    		"      <MdFaxNum>MdFaxNum1</MdFaxNum>\r\n" + 
    		"      <Retail_track_num>Retail_track_num1</Retail_track_num>\r\n" + 
    		"      <PayName1>PayName11</PayName1>\r\n" + 
    		"      <PayAmount1>1</PayAmount1>\r\n" + 
    		"      <PayName2>PayName21</PayName2>\r\n" + 
    		"      <PayAmount2>2</PayAmount2>\r\n" + 
    		"      <PayName3>PayName31</PayName3>\r\n" + 
    		"      <PayAmount3>3.50</PayAmount3>\r\n" + 
    		"      <PayName4>PayName41</PayName4>\r\n" + 
    		"      <PayAmount4>4</PayAmount4>\r\n" + 
    		"      <PayName5>PayName51</PayName5>\r\n" + 
    		"      <PayAmount5>5</PayAmount5>\r\n" + 
    		"      <Rxtype>Rxtype1</Rxtype>\r\n" + 
    		"      <LabelRxNum>LabelRxno1</LabelRxNum>\r\n" + 
    		"      <DaysSupply>1</DaysSupply>\r\n" + 
    		"      <TherapyType>TherapyType1</TherapyType>\r\n" + 
    		"      <OptExpirydate>OptExpirydate1</OptExpirydate>\r\n" + 
    		"      <ExtraLabelcnt>1</ExtraLabelcnt>\r\n" + 
    		"      <DispSvcBranch>1</DispSvcBranch>\r\n" +
    		"      <TrackLotnumFlag>N</TrackLotnumFlag>\r\n" + 
    		"      <NdcNum></NdcNum>\r\n" + 
    		"      <NpNdcNum></NpNdcNum>\r\n" +
    		"    </NDPRxRecord>\r\n" +
    		"    <NDPManagedCareLetterList>\r\n" + 
    		"      <NDPManagedCareLetter>\r\n" + 
    		"        <RxNum>Rxno1</RxNum>\r\n" + 
    		"        <LetterNumber>1</LetterNumber>\r\n" + 
    		"        <NoOfParams>1</NoOfParams>\r\n" + 
    		"        <NDPManagedCareParameterList>\r\n" + 
    		"          <NDPManagedCareParameter>\r\n" + 
    		"            <ParamNumber>1</ParamNumber>\r\n" + 
    		"            <Param>Param1</Param>\r\n" + 
    		"            <BeginDelim>BeginDelim1</BeginDelim>\r\n" + 
    		"            <Tag>Tag1</Tag>\r\n" + 
    		"            <MidDelim>MidDelim1</MidDelim>\r\n" + 
    		"            <Text>Text1</Text>\r\n" + 
    		"            <EndDelim>EndDelim1</EndDelim>\r\n" + 
    		"          </NDPManagedCareParameter>\r\n" + 
    		"          <NDPManagedCareParameter>\r\n" + 
    		"            <ParamNumber>-2147483647</ParamNumber>\r\n" + 
    		"            <Param>Param2</Param>\r\n" + 
    		"            <BeginDelim>BeginDelim2</BeginDelim>\r\n" + 
    		"            <Tag>Tag2</Tag>\r\n" + 
    		"            <MidDelim>MidDelim2</MidDelim>\r\n" + 
    		"            <Text>Text2</Text>\r\n" + 
    		"            <EndDelim>EndDelim2</EndDelim>\r\n" + 
    		"          </NDPManagedCareParameter>\r\n" + 
    		"          <NDPManagedCareParameter>\r\n" + 
    		"            <ParamNumber>2147483647</ParamNumber>\r\n" + 
    		"            <Param>Param3</Param>\r\n" + 
    		"            <BeginDelim>BeginDelim3</BeginDelim>\r\n" + 
    		"            <Tag>Tag3</Tag>\r\n" + 
    		"            <MidDelim>MidDelim3</MidDelim>\r\n" + 
    		"            <Text>Text3</Text>\r\n" + 
    		"            <EndDelim>EndDelim3</EndDelim>\r\n" + 
    		"          </NDPManagedCareParameter>\r\n" + 
    		"        </NDPManagedCareParameterList>\r\n" + 
    		"      </NDPManagedCareLetter>\r\n" + 
    		"      <NDPManagedCareLetter>\r\n" + 
    		"        <RxNum>Rxno2</RxNum>\r\n" + 
    		"        <LetterNumber>-2147483647</LetterNumber>\r\n" + 
    		"        <NoOfParams>-2147483647</NoOfParams>\r\n" + 
    		"        <NDPManagedCareParameterList>\r\n" + 
    		"          <NDPManagedCareParameter>\r\n" + 
    		"            <ParamNumber>0</ParamNumber>\r\n" + 
    		"            <Param>Param4</Param>\r\n" + 
    		"            <BeginDelim>BeginDelim4</BeginDelim>\r\n" + 
    		"            <Tag>Tag4</Tag>\r\n" + 
    		"            <MidDelim>MidDelim4</MidDelim>\r\n" + 
    		"            <Text>Text4</Text>\r\n" + 
    		"            <EndDelim>EndDelim4</EndDelim>\r\n" + 
    		"          </NDPManagedCareParameter>\r\n" + 
    		"          <NDPManagedCareParameter>\r\n" + 
    		"            <ParamNumber>2</ParamNumber>\r\n" + 
    		"            <Param>Param5</Param>\r\n" + 
    		"            <BeginDelim>BeginDelim5</BeginDelim>\r\n" + 
    		"            <Tag>Tag5</Tag>\r\n" + 
    		"            <MidDelim>MidDelim5</MidDelim>\r\n" + 
    		"            <Text>Text5</Text>\r\n" + 
    		"            <EndDelim>EndDelim5</EndDelim>\r\n" + 
    		"          </NDPManagedCareParameter>\r\n" + 
    		"          <NDPManagedCareParameter>\r\n" + 
    		"            <ParamNumber>-2147483646</ParamNumber>\r\n" + 
    		"            <Param>Param6</Param>\r\n" + 
    		"            <BeginDelim>BeginDelim6</BeginDelim>\r\n" + 
    		"            <Tag>Tag6</Tag>\r\n" + 
    		"            <MidDelim>MidDelim6</MidDelim>\r\n" + 
    		"            <Text>Text6</Text>\r\n" + 
    		"            <EndDelim>EndDelim6</EndDelim>\r\n" + 
    		"          </NDPManagedCareParameter>\r\n" + 
    		"        </NDPManagedCareParameterList>\r\n" + 
    		"      </NDPManagedCareLetter>\r\n" + 
    		"      <NDPManagedCareLetter>\r\n" + 
    		"        <RxNum>Rxno3</RxNum>\r\n" + 
    		"        <LetterNumber>2147483647</LetterNumber>\r\n" + 
    		"        <NoOfParams>2147483647</NoOfParams>\r\n" + 
    		"        <NDPManagedCareParameterList>\r\n" + 
    		"          <NDPManagedCareParameter>\r\n" + 
    		"            <ParamNumber>2147483646</ParamNumber>\r\n" + 
    		"            <Param>Param7</Param>\r\n" + 
    		"            <BeginDelim>BeginDelim7</BeginDelim>\r\n" + 
    		"            <Tag>Tag7</Tag>\r\n" + 
    		"            <MidDelim>MidDelim7</MidDelim>\r\n" + 
    		"            <Text>Text7</Text>\r\n" + 
    		"            <EndDelim>EndDelim7</EndDelim>\r\n" + 
    		"          </NDPManagedCareParameter>\r\n" + 
    		"          <NDPManagedCareParameter>\r\n" + 
    		"            <ParamNumber>-1</ParamNumber>\r\n" + 
    		"            <Param>Param8</Param>\r\n" + 
    		"            <BeginDelim>BeginDelim8</BeginDelim>\r\n" + 
    		"            <Tag>Tag8</Tag>\r\n" + 
    		"            <MidDelim>MidDelim8</MidDelim>\r\n" + 
    		"            <Text>Text8</Text>\r\n" + 
    		"            <EndDelim>EndDelim8</EndDelim>\r\n" + 
    		"          </NDPManagedCareParameter>\r\n" + 
    		"          <NDPManagedCareParameter>\r\n" + 
    		"            <ParamNumber>3</ParamNumber>\r\n" + 
    		"            <Param>Param9</Param>\r\n" + 
    		"            <BeginDelim>BeginDelim9</BeginDelim>\r\n" + 
    		"            <Tag>Tag9</Tag>\r\n" + 
    		"            <MidDelim>MidDelim9</MidDelim>\r\n" + 
    		"            <Text>Text9</Text>\r\n" + 
    		"            <EndDelim>EndDelim9</EndDelim>\r\n" + 
    		"          </NDPManagedCareParameter>\r\n" + 
    		"        </NDPManagedCareParameterList>\r\n" + 
    		"      </NDPManagedCareLetter>\r\n" + 
    		"    </NDPManagedCareLetterList>\r\n" +
    		"  </OrderRecord>\r\n" + 
    		"</Request>";
    @SuppressWarnings("unused")
    private static final String testXML2 = "<Request>\r\n" + 
    		"  <TestMode>N</TestMode>\r\n" + 
    		"  <OrgId>OrgId1</OrgId>\r\n" + 
    		"  <Channel>Channel1</Channel>\r\n" + 
    		"  <Role>Role1</Role>\r\n" + 
    		"  <Format>Format1</Format>\r\n" + 
    		"  <UserId>UserId1</UserId>\r\n" + 
    		"  <InvoiceNumber>InvoiceNumber1</InvoiceNumber>\r\n" + 
    		"  <InvoiceSub>InvoiceSub1</InvoiceSub>\r\n" + 
    		"  <Location>Location1</Location>\r\n" + 
    		"  <OrderNum>OrderNum1</OrderNum>\r\n" + 
    		"</Request>"; 
    @SuppressWarnings("unused")
    private static final String testXML3 = "<Request>\r\n" + 
    		"  <TestMode>Y</TestMode>\r\n" + 
    		"  <OrgId>OrgId1</OrgId>\r\n" + 
    		"  <Channel>Channel1</Channel>\r\n" + 
    		"  <Role>Role1</Role>\r\n" + 
    		"  <Format>Format1</Format>\r\n" + 
    		"  <UserId>UserId1</UserId>\r\n" + 
    		"  <InvoiceNumber>InvoiceNumber1</InvoiceNumber>\r\n" + 
    		"  <InvoiceSub>InvoiceSub1</InvoiceSub>\r\n" + 
    		"  <OrderNum>OrderNum1</OrderNum>\r\n" + 
    		"  <Location>Location1</Location>\r\n" + 
    		"  <DispPharm>DispPharm1</DispPharm>\r\n" + 
    		"  <CancelCode>CancelCode1</CancelCode>\r\n" + 
    		"  <CancelText>CancelText1</CancelText>\r\n" + 
    		"</Request>";
  //"
/*    		"<Request>\n" +
    				"<InvoiceNumber>173527187</InvoiceNumber>\n" + 
    				"<SubCode>B</SubCode>\n" +
    				"<Location>26</Location>\n" +
    				"<TestMode>Y</TestMode>\n" +
    				"<Channel>PAC</Channel>\n" +
    				"</Request>";    
  */  
    public static void main(String argsp[]) throws Exception{
    	TestClient client= new TestClient();
        client.test(endPoint1, testXML1); 
     }

    private void test(String endPoint, String xml) {
		service = Service.create(qname);
		service.addPort(qname, HTTPBinding.HTTP_BINDING, url + endPoint); //Constants.WS_STATUS);
        Dispatch<Source> dispatcher = service.createDispatch(qname, Source.class, Service.Mode.MESSAGE);
        List <String> l = new ArrayList<String>();
//        String auth = "extordwsdev:*Drt#Fty"; //dev credentials
        String auth = "dfdfdfdfdfdfdfffddfdf:bdfgdgdgdfgdgd"; //dev credentials

//        User: extordwsdev
//        Password: *Drt#Fty
        auth = "Basic " + Base64.encodeBase64(auth.getBytes());
        l.add(auth);
        java.util.Map <java.lang.String, java.util.List<java.lang.String>> headers = new HashMap<java.lang.String, java.util.List<java.lang.String>>();
        headers.put("Authorization", l);
        Map<String, Object> requestContext = dispatcher.getRequestContext();
        requestContext.put(MessageContext.HTTP_REQUEST_METHOD, "POST");
        requestContext.put(MessageContext.HTTP_REQUEST_HEADERS, headers);
        Source result = dispatcher.invoke(new StreamSource(new StringReader(xml)));
        printSource(result);
    }
     
    public  void printSource(Source s) {
        try {
            System.out.println("============================= PAC Response Received =========================================");
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            // also print to console
            transformer.transform(s, new StreamResult(System.out));
            System.out.println("\n=========================================================================================");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
