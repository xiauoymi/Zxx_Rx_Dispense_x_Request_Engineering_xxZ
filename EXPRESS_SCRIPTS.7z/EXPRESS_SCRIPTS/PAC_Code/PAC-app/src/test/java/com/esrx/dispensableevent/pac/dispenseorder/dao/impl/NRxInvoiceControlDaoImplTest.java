package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceControl;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceControlId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceControlDao;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderRequestConstant.CATAMARAN_CONTROL_TABLE;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class NRxInvoiceControlDaoImplTest {

	@Autowired
	NRxInvoiceControlDao nrxInvoiceControlDao;
	
	List<NRxInvoiceControl> nrxInvoiceControlList;
	
	@Test
	public void testGetNRxInvoiceControlList() {
		final NRxInvoiceControlId nrxInvoiceControlId = new NRxInvoiceControlId();
		nrxInvoiceControlId.setNrxcdeCodeVlu("0000001740");
		nrxInvoiceControlId.setNrxcdeTableNo("ESI");
		
		nrxInvoiceControlList = nrxInvoiceControlDao.getNRxInvoiceControlList(nrxInvoiceControlId);
		
		assertNotNull(nrxInvoiceControlList);
		assertTrue(nrxInvoiceControlList.size() > 0);	
	}
	
	@Test
	public void testGetNRxInvoiceControlListByNMC() {
		
		nrxInvoiceControlList = nrxInvoiceControlDao.getNRxInvoiceControlListByNMC("ODE");
		assertNotNull(nrxInvoiceControlList);
	}
	
	@Test
	public void testGetNRxInvoiceControlForClientTable() {
		
		NRxInvoiceControl nrxInvoiceControl = nrxInvoiceControlDao.getNRxInvoiceControlForClientTable(CATAMARAN_CONTROL_TABLE);
		assertNotNull(nrxInvoiceControl);
	}

}
