package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxRxFinancial;
import com.esrx.dispensableevent.nrxupdate.domain.NRxRxFinancialId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxRxFinancialDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class NRxRxFinancialDaoImplTest {
	
	@Autowired
	NRxRxFinancialDao nrxRxFinancialDao;
	
	@Test
	public void testGetNRxRxFinancialInfoWithUR() {
		final NRxRxFinancialId nrxRxFinancialId = new NRxRxFinancialId();
		
		nrxRxFinancialId.setErxExtInvno(32600200);
		nrxRxFinancialId.setErxExtRxno(Double.valueOf(832300004));
		nrxRxFinancialId.setErxFillNo(10);
//		nrxRxFinancialId.setErxInvnoSub();
		nrxRxFinancialId.setErxLocaNo(10);
		nrxRxFinancialId.setErxPartNbr(0);
		nrxRxFinancialId.setErxRefillNo(0);
		
		NRxRxFinancial nrxRxFinancial  = nrxRxFinancialDao.getNRxRxFinancialInfoWithUR(nrxRxFinancialId);
		assertNotNull(nrxRxFinancial);
		assertEquals("ABSBC01", nrxRxFinancial.getClientId().trim());
		assertEquals("MESQUITE", nrxRxFinancial.getPatCityNme().trim());
	}
}
