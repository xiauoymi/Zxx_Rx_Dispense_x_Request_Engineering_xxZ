package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.util.Calendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoice;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class NRxInvoiceDaoImplTest {

	@Autowired
	NRxInvoiceDao nrxInvoiceDao;

	@Test
	public void testGetN000OrderRecord() {
		final NRxInvoiceId nrxInvoiceId = new NRxInvoiceId();
		nrxInvoiceId.setNdiFillNo(new Integer(1));
		nrxInvoiceId.setNdiInvno(new Integer(36959297));
		nrxInvoiceId.setNdiInvnoSub("A");
		
		NRxInvoice nrxInvoice = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		
		assertNotNull(nrxInvoice);
		assertTrue("AUBURN".equals(nrxInvoice.getMemAddCity().trim()));
	}
	
	@Test
	public void testUpdateNDIVersionNo() {
		final NRxInvoiceId nrxInvoiceId = new NRxInvoiceId();
		nrxInvoiceId.setNdiFillNo(new Integer(1));
		nrxInvoiceId.setNdiInvno(new Integer(36959297));
		nrxInvoiceId.setNdiInvnoSub("A");
		
		NRxInvoice nrxInvoice = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		assertNotNull(nrxInvoice);
		
		nrxInvoiceDao.updateNDIVersionNo(nrxInvoice.getVerNo()+1,nrxInvoice);
		
		NRxInvoice nrxInvoice1 = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		System.out.println("nrxInvoice1.getVerNo() is "+nrxInvoice1.getVerNo());
		System.out.println("nrxInvoice.getVerNo() is "+nrxInvoice.getVerNo());
		assertNotSame(nrxInvoice1.getVerNo(), nrxInvoice.getVerNo());
	}

	@Test
	public void testUpdateNDIMEMFirstLastName() {
		final NRxInvoiceId nrxInvoiceId = new NRxInvoiceId();
		nrxInvoiceId.setNdiFillNo(new Integer(1));
		nrxInvoiceId.setNdiInvno(new Integer(37153355));
		nrxInvoiceId.setNdiInvnoSub("");
		
		NRxInvoice nrxInvoice  = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		NRxInvoice  nrxInvoiceUpdate = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		nrxInvoiceUpdate.setMemNameFst("vsbsddsvjhsdjh12");
		nrxInvoiceUpdate.setMemNameLst("sxbdsfgsefsyu674");
		assertNotNull(nrxInvoiceUpdate);
		
		nrxInvoiceDao.updateNDIMEMFirstLastName(nrxInvoiceUpdate);
		
		NRxInvoice nrxInvoice1 = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		System.out.println("nrxInvoice1.getMemNameFst() is "+nrxInvoice1.getMemNameFst());
		System.out.println("nrxInvoice.getMemNameFst() is "+nrxInvoice.getMemNameFst());
		System.out.println("nrxInvoice1.getMemNameLst() is "+nrxInvoice1.getMemNameLst());
		System.out.println("nrxInvoice.getMemNameLst() is "+nrxInvoice.getMemNameLst());
		
		assertNotSame(nrxInvoice1.getMemNameFst(), nrxInvoice.getMemNameFst());
		assertNotSame(nrxInvoice1.getMemNameLst(), nrxInvoice.getMemNameLst());	
	}
	
	@Test
	public void testUpdateNDITimeStatusErrorCode() {
		final NRxInvoiceId nrxInvoiceId = new NRxInvoiceId();
		nrxInvoiceId.setNdiFillNo(new Integer(1));
		nrxInvoiceId.setNdiInvno(new Integer(36959297));
		nrxInvoiceId.setNdiInvnoSub("A");

		NRxInvoice nrxInvoice = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		assertNotNull(nrxInvoice);
		
		NRxInvoice nrxInvoice1 = new NRxInvoice();
		nrxInvoice1.setId(nrxInvoiceId);
		
		nrxInvoice1.setSendTms(new Timestamp(Calendar.getInstance().getTime().getTime()));
		nrxInvoice1.setSendStatus(21);
		nrxInvoice1.setRecvErrorCde(56);
		
		nrxInvoiceDao.updateNDITimeStatusErrorCode(nrxInvoice1);
		
		assertNotSame(nrxInvoice.getSendTms(), nrxInvoice1.getSendTms());
	}
	
	@Test
	public void testUpdateNDISendStatus() {
		final NRxInvoiceId nrxInvoiceId = new NRxInvoiceId();
		nrxInvoiceId.setNdiFillNo(new Integer(1));
		nrxInvoiceId.setNdiInvno(new Integer(37153355));
		nrxInvoiceId.setNdiInvnoSub("");
		
		NRxInvoice nrxInvoice  = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		NRxInvoice  nrxInvoiceUpdate = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		nrxInvoiceUpdate.setSendStatus((nrxInvoice.getSendStatus()+1));
		
		nrxInvoiceDao.updateNDISendStatus(nrxInvoiceUpdate);
		
		NRxInvoice nrxInvoice1 = nrxInvoiceDao.getN000OrderRecord(nrxInvoiceId);
		System.out.println("nrxInvoice1.getSendStatus() is "+nrxInvoice1.getSendStatus());
		System.out.println("nrxInvoice.getSendStatus() is "+nrxInvoice.getSendStatus());

		assertNotSame(nrxInvoice.getSendStatus(), nrxInvoice1.getSendStatus());	
	}
}
