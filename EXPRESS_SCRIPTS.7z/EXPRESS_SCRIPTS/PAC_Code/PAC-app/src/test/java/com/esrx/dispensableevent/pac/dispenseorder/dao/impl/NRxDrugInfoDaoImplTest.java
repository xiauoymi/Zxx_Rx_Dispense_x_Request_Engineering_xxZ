package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxDrugInfo;
import com.esrx.dispensableevent.nrxupdate.domain.NRxDrugInfoId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxDrugInfoDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class NRxDrugInfoDaoImplTest {

	@Autowired
	NRxDrugInfoDao nrxDrugInfoDao;
	
	@Test
	public void testGetNRxDrugInfo() {
		final NRxDrugInfoId nrxDrugInfoId = new NRxDrugInfoId();
		nrxDrugInfoId.setDrno(1002);
		nrxDrugInfoId.setFillNo(1);
		
		NRxDrugInfo nrxDrugInfo = nrxDrugInfoDao.getNRxDrugInfo(nrxDrugInfoId);
		
		assertNotNull(nrxDrugInfo);
		assertEquals("2511", nrxDrugInfo.getNdcProd());
		assertEquals("WYETH", nrxDrugInfo.getManu().trim());
		assertEquals("OVRAL", nrxDrugInfo.getMltBrdNm().trim());
	}
	
	@Test
	public void testGetNRxDrugInfoWithUR() {
		final NRxDrugInfoId nrxDrugInfoId = new NRxDrugInfoId();
		nrxDrugInfoId.setDrno(1002);
		nrxDrugInfoId.setFillNo(1);
		
		NRxDrugInfo nrxDrugInfo = nrxDrugInfoDao.getNRxDrugInfoWithUR(nrxDrugInfoId);
		
		assertNotNull(nrxDrugInfo);
		assertEquals("2511", nrxDrugInfo.getNdcProd());
		assertEquals("WYETH", nrxDrugInfo.getManu().trim());

	}
}	