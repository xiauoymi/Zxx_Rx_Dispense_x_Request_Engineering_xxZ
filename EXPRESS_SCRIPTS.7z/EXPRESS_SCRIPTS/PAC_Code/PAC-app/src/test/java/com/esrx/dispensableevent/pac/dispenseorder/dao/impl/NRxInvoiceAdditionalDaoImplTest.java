package com.esrx.dispensableevent.pac.dispenseorder.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;

import java.sql.Timestamp;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditional;
import com.esrx.dispensableevent.nrxupdate.domain.NRxInvoiceAdditionalId;
import com.esrx.dispensableevent.pac.dispenseorder.dao.NRxInvoiceAdditionalDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/context/component-test-context.xml")
// @Transactional
public class NRxInvoiceAdditionalDaoImplTest {

	@Autowired
	NRxInvoiceAdditionalDao nrxInvoiceAdditionalDao;

	@Test
	public void testGetN000OrderRecordAdditional() {
		final NRxInvoiceAdditionalId nrxInvoiceAdditionalId = new NRxInvoiceAdditionalId();
		nrxInvoiceAdditionalId.setOrdExtInvno(new Integer(300));
		nrxInvoiceAdditionalId.setOrdFillNo(new Integer(49));
		nrxInvoiceAdditionalId.setOrdInvnoSub("");
		nrxInvoiceAdditionalId.setOrdPartNbr(new Integer(0));
		
		NRxInvoiceAdditional nrxInvoiceAdditional = nrxInvoiceAdditionalDao.getN000OrderRecordAdditional(nrxInvoiceAdditionalId);
		
		assertNotNull(nrxInvoiceAdditional);
		assertSame(15, nrxInvoiceAdditional.getDispPhyNo());
		assertNotSame(500, nrxInvoiceAdditional.getDispPhyNo());
	}
	
	@Test
	public void testUpdateNDPTmsStatusCde() {
		
		final NRxInvoiceAdditional nrxInvoiceAdditional = new NRxInvoiceAdditional();
		
		final NRxInvoiceAdditionalId nrxInvoiceAdditionalId = new NRxInvoiceAdditionalId();
		nrxInvoiceAdditionalId.setOrdExtInvno(new Integer(300));
		nrxInvoiceAdditionalId.setOrdFillNo(new Integer(49));
		nrxInvoiceAdditionalId.setOrdPartNbr(new Integer(0));
		nrxInvoiceAdditionalId.setOrdInvnoSub("");
		
		NRxInvoiceAdditional nrxInvoiceAdditionalRetrieve = nrxInvoiceAdditionalDao.getN000OrderRecordAdditional(nrxInvoiceAdditionalId);
		nrxInvoiceAdditional.setId(nrxInvoiceAdditionalId);
		nrxInvoiceAdditional.setNdpTms(new Timestamp(new Date().getTime()));
		nrxInvoiceAdditional.setStatusCde(String.valueOf(Integer.parseInt(nrxInvoiceAdditionalRetrieve.getStatusCde())+1));
		
		
		
		nrxInvoiceAdditionalDao.updateNDPTmsStatusCde(nrxInvoiceAdditional);
		
		NRxInvoiceAdditional nrxInvoiceAdditionalAfterUpdate = nrxInvoiceAdditionalDao.getN000OrderRecordAdditional(nrxInvoiceAdditionalId);
		
		assertNotSame(nrxInvoiceAdditionalRetrieve.getStatusCde(), nrxInvoiceAdditionalAfterUpdate.getStatusCde());
	}

	@Test
	public void testGetOrderAdditionalForPackagePacData() { 
//		final NRxInvoiceAdditional nrxInvoiceAdditional = new NRxInvoiceAdditional();
		
		final NRxInvoiceAdditionalId nrxInvoiceAdditionalId = new NRxInvoiceAdditionalId();
		nrxInvoiceAdditionalId.setOrdExtInvno(new Integer(300));
		nrxInvoiceAdditionalId.setOrdFillNo(new Integer(49));
		nrxInvoiceAdditionalId.setOrdPartNbr(new Integer(0));

		NRxInvoiceAdditional nrxInvoiceAdditionalRetrieve = nrxInvoiceAdditionalDao.getOrderAdditionalForPackagePacData(nrxInvoiceAdditionalId);
		
		assertNotNull(nrxInvoiceAdditionalRetrieve);
		System.out.println("nrxInvoiceAdditionalRetrieve.getXrfRequstTxt() is  : "+nrxInvoiceAdditionalRetrieve.getXrfRequstTxt());
	}
}
