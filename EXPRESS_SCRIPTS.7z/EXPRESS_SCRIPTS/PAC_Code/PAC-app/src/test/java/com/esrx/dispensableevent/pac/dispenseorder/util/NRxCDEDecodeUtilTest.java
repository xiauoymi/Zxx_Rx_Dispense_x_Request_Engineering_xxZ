package com.esrx.dispensableevent.pac.dispenseorder.util;

import static org.junit.Assert.*;

import java.util.List;

import static com.esrx.dispensableevent.pac.dispenseorder.util.NRxCDEDecodeUtil.getNRxCDEDecode;
import org.junit.Test;

public class NRxCDEDecodeUtilTest {

	@Test
	public void testGetNRxCDEDecode() {
		List<String> nrxCDEDecodeList = getNRxCDEDecode("jkasldfahsdfkjsfbsdkfsbkn");
		assertNotNull(nrxCDEDecodeList);
		System.out.println("What is first token: "+nrxCDEDecodeList.get(0));
		System.out.println("What is first token: "+nrxCDEDecodeList.get(1));

	}

}
