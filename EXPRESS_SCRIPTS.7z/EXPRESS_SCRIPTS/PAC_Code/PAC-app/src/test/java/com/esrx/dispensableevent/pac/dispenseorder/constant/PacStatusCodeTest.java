package com.esrx.dispensableevent.pac.dispenseorder.constant;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

import org.junit.Test;

import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.INITIAL_SETUP;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.REPLACEMENT_SETUP;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.CORRECTION_SETUP;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.QUEUE_DATA_READY;
import static com.esrx.dispensableevent.pac.dispenseorder.constant.PacDispenseOrderStatusCode.getPacStatusCode;

public class PacStatusCodeTest {

	@Test
	public void testGetPacStatusCode() {
		int pacStatusVal;
		
		pacStatusVal = getPacStatusCode(INITIAL_SETUP);
		System.out.println("what is the returned value : "+pacStatusVal);
		assertEquals(1, pacStatusVal);
		
		pacStatusVal = getPacStatusCode(REPLACEMENT_SETUP);
		System.out.println("what is the returned value : "+pacStatusVal);
		assertEquals(2, pacStatusVal);

		pacStatusVal = getPacStatusCode(CORRECTION_SETUP);
		System.out.println("what is the returned value : "+pacStatusVal);
		assertNotSame(22, pacStatusVal);
		
		pacStatusVal = getPacStatusCode(QUEUE_DATA_READY);
		System.out.println("what is the returned value : "+pacStatusVal);
		assertNotSame(44, pacStatusVal);
	}
}
