package com.esrx.dispensableevent.pac.dispenseorder.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.esrx.dispensableevent.pac.dispenseorder.bo.impl.PackageInvoiceDataBoHelper;
import static com.esrx.dispensableevent.pac.dispenseorder.util.PacDispenseOrderPartNbrUtil.getOrdPartNbr;

public class PacDispenseOrderPartNbrUtilTest {

	@Test
	public void testGetOrdPartNbr() {
		String str = getOrdPartNbr(1234567890);

		assertNotNull(str);
		System.out.println("str  is  : "+str);
	}

}
