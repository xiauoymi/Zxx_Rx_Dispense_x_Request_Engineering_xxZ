package com.esrx.dispensableevent.pac.dispenseorder.jaxrs;

import generated.Response;

import javax.ws.rs.POST;
import javax.ws.rs.Path;


@Path("/pacdispenseorder") 
public interface PacDispenseOrderResource {
	
	@POST
	@Path("processpacdispenseorder")
	public Response processPacDispenseOrderList();
	
}
